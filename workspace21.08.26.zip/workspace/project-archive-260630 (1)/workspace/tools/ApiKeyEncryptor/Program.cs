using System;
using System.Security.Cryptography;
using System.Text;

namespace ApiKeyEncryptor;

class Program
{
    static void Main(string[] args)
    {
        if (args.Length < 2)
        {
            Console.WriteLine("Usage: ApiKeyEncryptor <plain-key> <password> [base64|hex]");
            Console.WriteLine("Example: ApiKeyEncryptor \"my-secret-key\" \"MySecretKey2024!Secure\" base64");
            Environment.Exit(1);
        }

        string plainKey = args[0];
        string password = args[1];
        string outputFormat = args.Length > 2 ? args[2].ToLower() : "base64";

        if (string.IsNullOrWhiteSpace(plainKey))
        {
            Console.WriteLine("ERROR: PlainKey cannot be empty");
            Environment.Exit(1);
        }

        if (string.IsNullOrWhiteSpace(password))
        {
            Console.WriteLine("ERROR: Password cannot be empty");
            Environment.Exit(1);
        }

        if (password.Length < 16)
        {
            Console.WriteLine("WARNING: Password is short (less than 16 characters). Consider using a stronger password.");
        }

        try
        {
            using var sha256 = SHA256.Create();
            byte[] keyBytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(password));

            using var aes = Aes.Create();
            aes.Key = keyBytes;
            aes.GenerateIV();
            byte[] ivBytes = aes.IV;

            var encryptor = aes.CreateEncryptor(aes.Key, aes.IV);
            byte[] plainBytes = Encoding.UTF8.GetBytes(plainKey);
            byte[] encryptedBytes = encryptor.TransformFinalBlock(plainBytes, 0, plainBytes.Length);

            byte[] combined = new byte[ivBytes.Length + encryptedBytes.Length];
            Buffer.BlockCopy(ivBytes, 0, combined, 0, ivBytes.Length);
            Buffer.BlockCopy(encryptedBytes, 0, combined, ivBytes.Length, encryptedBytes.Length);

            string encryptedOutput = outputFormat switch
            {
                "hex" => BitConverter.ToString(combined).Replace("-", "").ToLower(),
                _ => Convert.ToBase64String(combined)
            };

            Console.WriteLine();
            Console.WriteLine("=============================================");
            Console.WriteLine("Encrypted Key:");
            Console.WriteLine("=============================================");
            Console.WriteLine();
            Console.WriteLine(encryptedOutput);
            Console.WriteLine();
            Console.WriteLine("=============================================");
            Console.WriteLine("Usage in appsettings.json:");
            Console.WriteLine("=============================================");
            Console.WriteLine();
            Console.WriteLine($"\"EncryptedApiKey\": \"{encryptedOutput}\",");
            Console.WriteLine($"\"EncryptionKey\": \"{password}\"");
            Console.WriteLine();
            Console.WriteLine("IMPORTANT:");
            Console.WriteLine("  - Store EncryptionKey securely (environment variable, secret manager)");
            Console.WriteLine("  - Do NOT commit EncryptionKey to source control");
            Console.WriteLine("  - EncryptedApiKey CAN be committed (it's encrypted)");
            Console.WriteLine();
        }
        catch (Exception ex)
        {
            Console.WriteLine($"ERROR: Encryption failed - {ex.Message}");
            Environment.Exit(1);
        }
    }
}
