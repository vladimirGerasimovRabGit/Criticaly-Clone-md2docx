# Тестовый документ

## Ссылки

Посетите [MonkeyCode](https://monkeycode-ai.online) для документации.

Также смотрите [GitHub](https://github.com) и [Stack Overflow](https://stackoverflow.com).

## Изображения

![Логотип](test-image.png)

## Текст с форматированием

Это **жирный текст** и *курсив* в одном абзаце.

Ссылка с **жирным**: **[MonkeyCode Pro](https://monkeycode-ai.online/pro)**
