#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ClonerSuite Documentation to DOCX Converter

Использует инструкцию из doc-format-instructions-copilot.md и шаблон Doc1.dotx
для создания отформатированного DOCX файла из Markdown документации.

Поддерживает:
- Заголовки (H1, H2, H3)
- Таблицы
- Списки
- Жирный/курсив текст
- Code blocks
- Гиперссылки [текст](url)
- Изображения ![alt](path)
"""

import zipfile
import os
import re
import base64
from pathlib import Path


# ─── Констанции ───────────────────────────────────────────────────────

TEMPLATE = 'Doc1.dotx'
OUTPUT = 'output.docx'
BCOL = 'BDD7EE'
BORD = 'BFBFBF'


# ─── Менеджер отношений (rels) и ссылок ───────────────────────────────

class RelationshipManager:
    """Управляет relationships для гиперссылок и изображений."""
    
    def __init__(self, rels_xml):
        self.rels_xml = rels_xml
        self.next_rid = self._get_next_rid()
        self.hyperlinks = {}  # url -> rId
        self.images = {}      # path -> rId
    
    def _get_next_rid(self):
        """Найти максимальный существующий rId."""
        matches = re.findall(r'Id="(rId\d+)"', self.rels_xml)
        if not matches:
            return 1
        max_id = max(int(m[3:]) for m in matches)
        return max_id + 1
    
    def get_next_rid(self):
        """Получить следующий rId и увеличить счётчик."""
        rid = f'rId{self.next_rid}'
        self.next_rid += 1
        return rid
    
    def add_hyperlink(self, url):
        """Добавить гиперссылку, вернуть rId."""
        if url not in self.hyperlinks:
            rid = self.get_next_rid()
            self.hyperlinks[url] = rid
            rel_xml = (f'<Relationship Id="{rid}" '
                      f'Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/hyperlink" '
                      f'Target="{esc_attr(url)}" TargetMode="External"/>')
            # Вставляем перед закрывающим тегом
            self.rels_xml = self.rels_xml.replace('</Relationships>', f'{rel_xml}</Relationships>')
        return self.hyperlinks[url]
    
    def add_image(self, img_path, content_type):
        """Добавить изображение, вернуть rId."""
        # Используем только имя файла для отношения
        img_name = os.path.basename(img_path)
        if img_name not in self.images:
            rid = self.get_next_rid()
            self.images[img_name] = rid
            rel_xml = (f'<Relationship Id="{rid}" '
                      f'Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" '
                      f'Target="media/{img_name}"/>')
            self.rels_xml = self.rels_xml.replace('</Relationships>', f'{rel_xml}</Relationships>')
        return self.images[img_name]
    
    def get_rels_xml(self):
        return self.rels_xml


# ─── XML-функции ──────────────────────────────────────────────────────

def esc(s):
    return (s.replace('&', '&amp;').replace('<', '&lt;')
             .replace('>', '&gt;').replace('"', '&quot;'))


def esc_attr(s):
    """Экранирование для атрибутов XML."""
    return esc(s).replace("'", '&apos;')


def rh(text):
    """Run для заголовков — БЕЗ rPr."""
    return f'<w:r><w:t>{esc(text)}</w:t></w:r>'


def r(text, bold=False, italic=False):
    """Run для обычного текста — с rPr."""
    b = '<w:b/><w:bCs/>' if bold else ''
    i = '<w:i/><w:iCs/>' if italic else ''
    fonts = '<w:rFonts w:asciiTheme="minorHAnsi" w:hAnsiTheme="minorHAnsi" w:cstheme="minorBidi"/>'
    rpr = f'<w:rPr>{fonts}{b}{i}<w:sz w:val="24"/><w:szCs w:val="24"/></w:rPr>'
    sp = ' xml:space="preserve"' if text != text.strip() or '  ' in text else ''
    return f'<w:r>{rpr}<w:t{sp}>{esc(text)}</w:t></w:r>'


def hyperlink_run(text, url, rel_mgr):
    """Гиперссылка с rPr."""
    rid = rel_mgr.add_hyperlink(url)
    b = '<w:b/><w:bCs/>'
    fonts = '<w:rFonts w:asciiTheme="minorHAnsi" w:hAnsiTheme="minorHAnsi" w:cstheme="minorBidi"/>'
    rpr = f'<w:rPr>{fonts}<w:color w:val="0000FF"/><w:u w:val="single"/></w:rPr>'
    sp = ' xml:space="preserve"' if text != text.strip() or '  ' in text else ''
    return f'<w:hyperlink r:id="{rid}" w:history="1"><w:r>{rpr}<w:t{sp}>{esc(text)}</w:t></w:r></w:hyperlink>'


def h1(text):
    """Heading 1 — уровень 0."""
    return f'<w:p><w:pPr><w:pStyle w:val="1"/><w:numPr><w:numId w:val="1"/><w:ilvl w:val="0"/></w:numPr></w:pPr>{rh(text)}</w:p>\n'


def h2(text):
    """Heading 2 — уровень 1 (подраздел)."""
    return f'<w:p><w:pPr><w:pStyle w:val="2"/><w:numPr><w:numId w:val="1"/><w:ilvl w:val="1"/></w:numPr></w:pPr>{rh(text)}</w:p>\n'


def h3(text):
    """Heading 3 — уровень 2 (подподраздел)."""
    return f'<w:p><w:pPr><w:pStyle w:val="3"/><w:numPr><w:numId w:val="1"/><w:ilvl w:val="2"/></w:numPr></w:pPr>{rh(text)}</w:p>\n'


def title(text):
    ppr = ('<w:pPr><w:pStyle w:val="a3"/>'
           '<w:pBdr><w:bottom w:val="single" w:sz="6" w:space="1" w:color="auto"/></w:pBdr>'
           '</w:pPr>')
    return f'<w:p>{ppr}{rh(text)}</w:p>\n'


def subtitle(text):
    return f'<w:p><w:pPr><w:pStyle w:val="a5"/></w:pPr>{rh(text)}</w:p>\n'


def body(*runs):
    return f'<w:p><w:pPr><w:pStyle w:val="a"/><w:spacing w:after="80"/></w:pPr>{"".join(runs)}</w:p>\n'


def li(*runs, bullet_num_id='3', level=0):
    ppr = (f'<w:pPr><w:pStyle w:val="a7"/>'
           f'<w:numPr><w:ilvl w:val="{level}"/><w:numId w:val="{bullet_num_id}"/></w:numPr>'
           f'<w:spacing w:after="40"/></w:pPr>')
    return f'<w:p>{ppr}{"".join(runs)}</w:p>\n'


def empty():
    return '<w:p><w:pPr><w:spacing w:after="40"/></w:pPr></w:p>\n'


# ─── Изображения ──────────────────────────────────────────────────────

def image_embed(img_path, alt_text, rel_mgr, images_data):
    """
    Создать XML для встроенного изображения.
    img_path: путь к файлу изображения
    alt_text: альтернативный текст
    rel_mgr: менеджер отношений
    images_data: dict для хранения бинарных данных изображений
    """
    if not os.path.exists(img_path):
        return body(r(f'[Изображение не найдено: {img_path}]', italic=True))
    
    with open(img_path, 'rb') as f:
        img_data = f.read()
    
    ext = os.path.splitext(img_path)[1].lower()
    content_type_map = {
        '.png': 'image/png',
        '.jpg': 'image/jpeg',
        '.jpeg': 'image/jpeg',
        '.gif': 'image/gif',
        '.bmp': 'image/bmp',
        '.svg': 'image/svg+xml',
    }
    content_type = content_type_map.get(ext, 'image/png')
    
    img_name = os.path.basename(img_path)
    images_data[img_name] = img_data
    
    rid = rel_mgr.add_image(img_path, content_type)
    
    width_emu = 5080000
    height_emu = 3810000
    
    # Генерируем DrawingML XML
    drawing_xml = f'''<w:drawing>
<wp:inline xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing" 
           xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main"
           xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"
           distT="0" distB="0" distL="0" distR="0">
  <wp:extent cx="{width_emu}" cy="{height_emu}"/>
  <wp:docPr id="1" name="Picture 1" descr="{esc_attr(alt_text)}"/>
  <wp:cNvGraphicFramePr>
    <a:graphicFrameLocks xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" noChangeAspect="1"/>
  </wp:cNvGraphicFramePr>
  <a:graphic>
    <a:graphicData uri="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image">
      <pic:pic xmlns:pic="http://schemas.openxmlformats.org/drawingml/2006/picture">
        <pic:nvPicPr>
          <pic:cNvPr id="0" name="{esc_attr(alt_text)}"/>
          <pic:cNvPicPr/>
        </pic:nvPicPr>
        <pic:blipFill>
          <a:blip r:embed="{rid}">
            <a:extLst>
              <a:ext uri="{{28A0092B-C50C-407E-A947-70E7372C202}}">
                <a14:useLocalDpi xmlns:a14="http://schemas.microsoft.com/office/drawing/2010/main" val="0"/>
              </a:ext>
            </a:extLst>
          </a:blip>
          <a:stretch>
            <a:fillRect/>
          </a:stretch>
        </pic:blipFill>
        <pic:spPr bwMode="auto">
          <a:xfrm>
            <a:off x="0" y="0"/>
            <a:ext cx="{width_emu}" cy="{height_emu}"/>
          </a:xfrm>
          <a:prstGeom prst="rect">
            <a:avLst/>
          </a:prstGeom>
        </pic:spPr>
      </pic:pic>
    </a:graphicData>
  </a:graphic>
</wp:inline>
</w:drawing>'''
    
    return f'<w:p><w:pPr><w:pStyle w:val="a"/><w:spacing w:after="80"/></w:pPr><w:r>{drawing_xml}</w:r></w:p>\n'


# ─── Таблицы ──────────────────────────────────────────────────────────

def H(text):
    return {'t': text, 'hdr': True}


def D(text, bold=False):
    return {'t': text, 'b': bold}


def tbl(col_widths, rows):
    _b = (f'<w:top w:val="single" w:sz="4" w:color="{BORD}"/>'
          f'<w:left w:val="single" w:sz="4" w:color="{BORD}"/>'
          f'<w:bottom w:val="single" w:sz="4" w:color="{BORD}"/>'
          f'<w:right w:val="single" w:sz="4" w:color="{BORD}"/>')
    TW = sum(col_widths)
    grid = ''.join(f'<w:gridCol w:w="{w}"/>' for w in col_widths)
    out = (f'<w:tbl><w:tblPr><w:tblW w:w="{TW}" w:type="dxa"/>'
           f'<w:tblBorders>{_b}</w:tblBorders>'
           f'<w:tblLook w:val="04A0"/></w:tblPr>'
           f'<w:tblGrid>{grid}</w:tblGrid>\n')
    for row in rows:
        is_hdr = row[0].get('hdr', False)
        trpr = '<w:trPr><w:tblHeader/></w:trPr>' if is_hdr else ''
        cells = ''
        for j, cell_data in enumerate(row):
            hdr = cell_data.get('hdr', False)
            bold = cell_data.get('b', hdr)
            shd = f'<w:shd w:val="clear" w:color="auto" w:fill="{BCOL}"/>' if hdr else ''
            w = col_widths[j]
            tcpr = (f'<w:tcPr><w:tcW w:w="{w}" w:type="dxa"/>'
                    f'<w:tcBorders>{_b}</w:tcBorders>{shd}'
                    f'<w:tcMar><w:top w:w="80" w:type="dxa"/>'
                    f'<w:left w:w="120" w:type="dxa"/>'
                    f'<w:bottom w:w="80" w:type="dxa"/>'
                    f'<w:right w:w="120" w:type="dxa"/></w:tcMar></w:tcPr>')
            inner = (f'<w:p><w:pPr><w:pStyle w:val="a"/>'
                     f'<w:spacing w:after="40"/></w:pPr>'
                     f'{r(cell_data.get("t", ""), bold=bold)}</w:p>')
            cells += f'<w:tc>{tcpr}{inner}</w:tc>'
        out += f'<w:tr>{trpr}{cells}</w:tr>\n'
    return out + '</w:tbl>\n'


# ─── Колонтитул и document.xml ────────────────────────────────────────

def build_footer(footer_rid):
    return f"""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:ftr xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
  <w:p>
    <w:pPr><w:pStyle w:val="a"/><w:jc w:val="right"/></w:pPr>
    <w:r><w:rPr><w:rFonts w:asciiTheme="minorHAnsi" w:hAnsiTheme="minorHAnsi"/>
      <w:sz w:val="24"/><w:szCs w:val="24"/></w:rPr>
      <w:t xml:space="preserve">Страница </w:t></w:r>
    <w:r><w:rPr><w:rFonts w:asciiTheme="minorHAnsi" w:hAnsiTheme="minorHAnsi"/>
      <w:b/><w:bCs/><w:sz w:val="24"/><w:szCs w:val="24"/></w:rPr>
      <w:fldChar w:fldCharType="begin"/></w:r>
    <w:r><w:rPr><w:rFonts w:asciiTheme="minorHAnsi" w:hAnsiTheme="minorHAnsi"/>
      <w:b/><w:bCs/><w:sz w:val="24"/><w:szCs w:val="24"/></w:rPr>
      <w:instrText xml:space="preserve"> PAGE </w:instrText></w:r>
    <w:r><w:rPr><w:rFonts w:asciiTheme="minorHAnsi" w:hAnsiTheme="minorHAnsi"/>
      <w:b/><w:bCs/><w:sz w:val="24"/><w:szCs w:val="24"/></w:rPr>
      <w:fldChar w:fldCharType="end"/></w:r>
    <w:r><w:rPr><w:rFonts w:asciiTheme="minorHAnsi" w:hAnsiTheme="minorHAnsi"/>
      <w:sz w:val="24"/><w:szCs w:val="24"/></w:rPr>
      <w:t xml:space="preserve"> из </w:t></w:r>
    <w:r><w:rPr><w:rFonts w:asciiTheme="minorHAnsi" w:hAnsiTheme="minorHAnsi"/>
      <w:b/><w:bCs/><w:sz w:val="24"/><w:szCs w:val="24"/></w:rPr>
      <w:fldChar w:fldCharType="begin"/></w:r>
    <w:r><w:rPr><w:rFonts w:asciiTheme="minorHAnsi" w:hAnsiTheme="minorHAnsi"/>
      <w:b/><w:bCs/><w:sz w:val="24"/><w:szCs w:val="24"/></w:rPr>
      <w:instrText xml:space="preserve"> NUMPAGES </w:instrText></w:r>
    <w:r><w:rPr><w:rFonts w:asciiTheme="minorHAnsi" w:hAnsiTheme="minorHAnsi"/>
      <w:b/><w:bCs/><w:sz w:val="24"/><w:szCs w:val="24"/></w:rPr>
      <w:fldChar w:fldCharType="end"/></w:r>
  </w:p>
</w:ftr>"""


NS = ('xmlns:mc="http://schemas.openxmlformats.org/markup-compatibility/2006" '
      'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" '
      'xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" '
      'xmlns:w14="http://schemas.microsoft.com/office/word/2010/wordml" '
      'mc:Ignorable="w14"')


def build_document(sect, content):
    return (f'<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n'
            f'<w:document {NS}>\n<w:body>\n'
            f'{content}'
            f'{sect}\n</w:body>\n</w:document>')


def find_bullet_num_id(nxml):
    for m in re.finditer(r'<w:num\b[^>]*w:numId="(\d+)"', nxml):
        nid = m.group(1)
        abs_ref = re.search(
            rf'<w:num\b[^>]*w:numId="{nid}".*?<w:abstractNumId w:val="(\d+)"',
            nxml, re.DOTALL)
        if not abs_ref:
            continue
        aid = abs_ref.group(1)
        ab = re.search(
            rf'<w:abstractNum\b[^>]*w:abstractNumId="{aid}".*?</w:abstractNum>',
            nxml, re.DOTALL)
        if not ab:
            continue
        l0 = re.search(r'<w:lvl\b[^>]*w:ilvl="0".*?</w:lvl>',
                        ab.group(0), re.DOTALL)
        if not l0:
            continue
        fmt = re.search(r'<w:numFmt w:val="([^"]+)"', l0.group(0))
        ltxt = re.search(r'<w:lvlText w:val="([^"]*)"', l0.group(0))
        if fmt and fmt.group(1) == 'bullet' and ltxt and ltxt.group(1) == '':
            return nid
    return '3'


def create_numbering_xml():
    """Создаёт numbering.xml с нумерацией для заголовков и bullets."""
    return ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n'
'<w:numbering xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">\n'
'  <!-- Единая нумерация: H1=1,2,3, H2=1.1,1.2, H3=1.1.1 -->\n'
'  <w:abstractNum w:abstractNumId="0">\n'
'    <w:nsid w:val="00000001"/>\n'
'    <w:tmpl w:val="00000001"/>\n'
'    <!-- H1: уровень 0 -->\n'
'    <w:lvl w:ilvl="0">\n'
'      <w:start w:val="1"/>\n'
'      <w:numFmt w:val="decimal"/>\n'
'      <w:lvlText w:val="%1."/>\n'
'      <w:lvlJc w:val="left"/>\n'
'      <w:pPr><w:ind w:left="0" w:hanging="0"/></w:pPr>\n'
'      <w:rPr><w:b/></w:rPr>\n'
'    </w:lvl>\n'
'    <!-- H2: уровень 1 (подраздел) -->\n'
'    <w:lvl w:ilvl="1">\n'
'      <w:start w:val="1"/>\n'
'      <w:numFmt w:val="decimal"/>\n'
'      <w:lvlText w:val="%1.%2."/>\n'
'      <w:lvlJc w:val="left"/>\n'
'      <w:pPr><w:ind w:left="0" w:hanging="0"/></w:pPr>\n'
'      <w:rPr><w:b/></w:rPr>\n'
'    </w:lvl>\n'
'    <!-- H3: уровень 2 (подподраздел) -->\n'
'    <w:lvl w:ilvl="2">\n'
'      <w:start w:val="1"/>\n'
'      <w:numFmt w:val="decimal"/>\n'
'      <w:lvlText w:val="%1.%2.%3."/>\n'
'      <w:lvlJc w:val="left"/>\n'
'      <w:pPr><w:ind w:left="0" w:hanging="0"/></w:pPr>\n'
'      <w:rPr><w:b/></w:rPr>\n'
'    </w:lvl>\n'
'  </w:abstractNum>\n'
'  \n'
'  <!-- Маркированный список -->\n'
'  <w:abstractNum w:abstractNumId="1">\n'
'    <w:nsid w:val="00000002"/>\n'
'    <w:tmpl w:val="00000002"/>\n'
'    <w:lvl w:ilvl="0">\n'
'      <w:start w:val="1"/>\n'
'      <w:numFmt w:val="bullet"/>\n'
'      <w:lvlText w:val=""/>\n'
'      <w:lvlJc w:val="left"/>\n'
'      <w:pPr><w:ind w:left="360" w:hanging="180"/></w:pPr>\n'
'      <w:rPr><w:rFonts w:ascii="Symbol" w:hAnsi="Symbol" w:hint="default"/></w:rPr>\n'
'    </w:lvl>\n'
'  </w:abstractNum>\n'
'  \n'
'  <!-- Привязка: numId=1 для H1/H2/H3, numId=2 для bullets -->\n'
'  <w:num w:numId="1">\n'
'    <w:abstractNumId w:val="0"/>\n'
'  </w:num>\n'
'  <w:num w:numId="2">\n'
'    <w:abstractNumId w:val="1"/>\n'
'  </w:num>\n'
'</w:numbering>').encode('utf-8')


def update_styles_with_numbering(styles_xml):
    """Добавляет numPr к заголовкам в styles.xml."""
    # H1 -> numId=1, ilvl=0 (добавляем в конец pPr)
    styles_xml = re.sub(
        r'(<w:style[^>]*w:styleId="1"[^>]*>.*?<w:pPr>.*?)(</w:pPr>)',
        r'\1<w:numPr><w:numId w:val="1"/><w:ilvl w:val="0"/></w:numPr>\2',
        styles_xml,
        flags=re.DOTALL
    )
    
    # H2 -> numId=1, ilvl=1
    styles_xml = re.sub(
        r'(<w:style[^>]*w:styleId="2"[^>]*>.*?<w:pPr>.*?)(</w:pPr>)',
        r'\1<w:numPr><w:numId w:val="1"/><w:ilvl w:val="1"/></w:numPr>\2',
        styles_xml,
        flags=re.DOTALL
    )
    
    # H3 -> numId=1, ilvl=2
    styles_xml = re.sub(
        r'(<w:style[^>]*w:styleId="3"[^>]*>.*?<w:pPr>.*?)(</w:pPr>)',
        r'\1<w:numPr><w:numId w:val="1"/><w:ilvl w:val="2"/></w:numPr>\2',
        styles_xml,
        flags=re.DOTALL
    )
    
    return styles_xml


def get_existing_footer_rid(rels_xml):
    """Найти существующий footer rId или вернуть новый."""
    rid_m = re.search(r'<Relationship Id="(rId\d+)"[^>]*footer[^>]*/>', rels_xml)
    if rid_m:
        return rid_m.group(1)
    
    # Если нет footer, создаём новый rId
    matches = re.findall(r'Id="rId(\d+)"', rels_xml)
    if matches:
        max_id = max(int(m) for m in matches)
        return f'rId{max_id + 1}'
    return 'rId10'


def create_footer_xml():
    """Создаёт footer с полями страниц."""
    return ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n'
'<w:ftr xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">\n'
'  <w:p>\n'
'    <w:pPr><w:pStyle w:val="a"/><w:jc w:val="right"/></w:pPr>\n'
'    <w:r><w:rPr><w:rFonts w:asciiTheme="minorHAnsi" w:hAnsiTheme="minorHAnsi"/>\n'
'      <w:sz w:val="24"/><w:szCs w:val="24"/></w:rPr>\n'
'      <w:t xml:space="preserve">Страница </w:t></w:r>\n'
'    <w:r><w:rPr><w:rFonts w:asciiTheme="minorHAnsi" w:hAnsiTheme="minorHAnsi"/>\n'
'      <w:b/><w:bCs/><w:sz w:val="24"/><w:szCs w:val="24"/></w:rPr>\n'
'      <w:fldChar w:fldCharType="begin"/></w:r>\n'
'    <w:r><w:rPr><w:rFonts w:asciiTheme="minorHAnsi" w:hAnsiTheme="minorHAnsi"/>\n'
'      <w:b/><w:bCs/><w:sz w:val="24"/><w:szCs w:val="24"/></w:rPr>\n'
'      <w:instrText xml:space="preserve"> PAGE </w:instrText></w:r>\n'
'    <w:r><w:rPr><w:rFonts w:asciiTheme="minorHAnsi" w:hAnsiTheme="minorHAnsi"/>\n'
'      <w:b/><w:bCs/><w:sz w:val="24"/><w:szCs w:val="24"/></w:rPr>\n'
'      <w:fldChar w:fldCharType="end"/></w:r>\n'
'    <w:r><w:rPr><w:rFonts w:asciiTheme="minorHAnsi" w:hAnsiTheme="minorHAnsi"/>\n'
'      <w:sz w:val="24"/><w:szCs w:val="24"/></w:rPr>\n'
'      <w:t xml:space="preserve"> из </w:t></w:r>\n'
'    <w:r><w:rPr><w:rFonts w:asciiTheme="minorHAnsi" w:hAnsiTheme="minorHAnsi"/>\n'
'      <w:b/><w:bCs/><w:sz w:val="24"/><w:szCs w:val="24"/></w:rPr>\n'
'      <w:fldChar w:fldCharType="begin"/></w:r>\n'
'    <w:r><w:rPr><w:rFonts w:asciiTheme="minorHAnsi" w:hAnsiTheme="minorHAnsi"/>\n'
'      <w:b/><w:bCs/><w:sz w:val="24"/><w:szCs w:val="24"/></w:rPr>\n'
'      <w:instrText xml:space="preserve"> NUMPAGES </w:instrText></w:r>\n'
'    <w:r><w:rPr><w:rFonts w:asciiTheme="minorHAnsi" w:hAnsiTheme="minorHAnsi"/>\n'
'      <w:b/><w:bCs/><w:sz w:val="24"/><w:szCs w:val="24"/></w:rPr>\n'
'      <w:fldChar w:fldCharType="end"/></w:r>\n'
'  </w:p>\n'
'</w:ftr>').encode('utf-8')


# ─── Парсинг Markdown ─────────────────────────────────────────────────

def parse_inline_with_links(text, rel_mgr):
    """
    Парсит текст с возможными ссылками [текст](url) и **bold**.
    Возвращает список кортежей (text, type, url) где type: 'text', 'bold', 'link'
    """
    result = []
    i = 0
    
    while i < len(text):
        # Проверяем ссылку [text](url)
        link_match = re.match(r'\[([^\]]+)\]\(([^)]+)\)', text[i:])
        if link_match:
            link_text = link_match.group(1)
            link_url = link_match.group(2)
            result.append((link_text, 'link', link_url))
            i += len(link_match.group(0))
            continue
        
        # Проверяем bold **text**
        bold_match = re.match(r'\*\*([^*]+)\*\*', text[i:])
        if bold_match:
            result.append((bold_match.group(1), 'bold', None))
            i += len(bold_match.group(0))
            continue
        
        # Проверяем italic *text*
        italic_match = re.match(r'\*([^*]+)\*', text[i:])
        if italic_match:
            result.append((italic_match.group(1), 'italic', None))
            i += len(italic_match.group(0))
            continue
        
        # Обычный текст до следующего спецсимвола
        next_special = len(text)
        for pattern in [r'\[', r'\*\*']:
            m = re.search(pattern, text[i:])
            if m:
                next_special = min(next_special, i + m.start())
        
        if next_special > i:
            result.append((text[i:next_special], 'text', None))
            i = next_special
        elif i < len(text):
            # Одиночный спецсимвол, добавляем как текст
            result.append((text[i], 'text', None))
            i += 1
    
    return result


def parse_md_to_content(md_text, bullet_num_id, rel_mgr, images_data, md_dir):
    """Конвертирует Markdown в XML-контент для Word."""
    content = []
    lines = md_text.split('\n')
    i = 0
    skip_toc = False
    
    while i < len(lines):
        line = lines[i]
        stripped = line.strip()
        
        if not stripped:
            i += 1
            continue
        
        if stripped.startswith('---'):
            i += 1
            continue
        
        if stripped == '## Содержание':
            skip_toc = True
            i += 1
            continue
        
        if skip_toc and re.match(r'^\d+\.\s*\[', stripped):
            i += 1
            continue
        
        if stripped.startswith('# '):
            # Заголовок документа (Title) — без нумерации
            h_text = stripped[2:].strip()
            content.append(title(h_text))
            i += 1
            continue
        
        if stripped.startswith('## '):
            # H1 (главный раздел): ## 1. Текст или ## Текст
            skip_toc = False
            if 'Содержание' in stripped or 'содержание' in stripped:
                skip_toc = True
            
            h_text = stripped[3:].strip()
            # Удаляем префикс цифры "1. ", "2. " и т.д. — Word добавит свою нумерацию
            h_text = re.sub(r'^[\d.]+\s+', '', h_text)
            # Пропускаем только оглавление (ссылки)
            if not h_text.startswith('['):
                content.append(h1(h_text))
            i += 1
            continue
        
        if stripped.startswith('### '):
            # H2 (подраздел): ### 4.1 Текст или ### Текст
            h_text = stripped[4:].strip()
            # Удаляем префикс "4.1 ", "4.2 " и т.д. — Word добавит свою нумерацию
            h_text = re.sub(r'^[\d.]+\s+', '', h_text)
            content.append(h2(h_text))
            i += 1
            continue
        
        if stripped.startswith('#### '):
            # H3 (подподраздел): #### 4.1.1 Текст или #### Текст
            h_text = stripped[5:].strip()
            # Удаляем префикс "4.1.1 " — Word добавит свою нумерацию
            h_text = re.sub(r'^[\d.]+\s+', '', h_text)
            content.append(h3(h_text))
            i += 1
            continue
        
        if stripped.startswith('```'):
            i += 1
            code_lines = []
            while i < len(lines) and not lines[i].strip().startswith('```'):
                code_lines.append(lines[i])
                i += 1
            i += 1
            if code_lines:
                code_text = '\n'.join(code_lines)
                content.append(body(r(code_text)))
                content.append(empty())
            continue
        
        # Изображение: ![alt](path)
        if stripped.startswith('!['):
            img_match = re.match(r'!\[([^\]]*)\]\(([^)]+)\)', stripped)
            if img_match:
                alt_text = img_match.group(1)
                img_path = img_match.group(2)
                # Если путь относительный, добавляем директорию MD файла
                if not os.path.isabs(img_path) and md_dir:
                    img_path = os.path.join(md_dir, img_path)
                content.append(image_embed(img_path, alt_text, rel_mgr, images_data))
                content.append(empty())
            i += 1
            continue
        
        if stripped.startswith('- [ ]') or stripped.startswith('- '):
            list_items = []
            while i < len(lines) and (lines[i].strip().startswith('- [ ]') or lines[i].strip().startswith('- ')):
                item = lines[i].strip()
                if item.startswith('- [ ]'):
                    item = item[5:].strip()
                else:
                    item = item[2:].strip()
                list_items.append(item)
                i += 1
            
            for item in list_items:
                parts = parse_inline_with_links(item, rel_mgr)
                runs = []
                for text, ptype, url in parts:
                    if ptype == 'link':
                        runs.append(hyperlink_run(text, url, rel_mgr))
                    elif ptype == 'bold':
                        runs.append(r(text, bold=True))
                    elif ptype == 'italic':
                        runs.append(r(text, italic=True))
                    else:
                        runs.append(r(text))
                content.append(li(*runs, bullet_num_id=bullet_num_id))
            
            content.append(empty())
            continue
        
        if stripped.startswith('|'):
            table_rows = []
            header_row = None
            
            while i < len(lines) and lines[i].strip().startswith('|'):
                row_line = lines[i].strip()
                if re.match(r'^\|[\s\-:|]+\|$', row_line):
                    i += 1
                    continue
                cells = [c.strip() for c in row_line.split('|')[1:-1]]
                if header_row is None:
                    header_row = cells
                else:
                    table_rows.append(cells)
                i += 1
            
            if header_row and table_rows:
                num_cols = len(header_row)
                if num_cols == 2:
                    col_widths = [4677, 4678]
                elif num_cols == 3:
                    col_widths = [3118, 3118, 3119]
                elif num_cols == 4:
                    col_widths = [2339, 2339, 2339, 2338]
                else:
                    col_widths = [9355 // num_cols] * num_cols
                
                rows_data = [[H(header_row[j]) for j in range(num_cols) if j < len(header_row)]]
                
                for row_cells in table_rows:
                    row_data = []
                    for j in range(num_cols):
                        cell_text = row_cells[j] if j < len(row_cells) else ''
                        parts = parse_inline_with_links(cell_text, rel_mgr)
                        runs_text = ''
                        has_bold = False
                        for text, ptype, url in parts:
                            if ptype == 'bold':
                                has_bold = True
                            runs_text += text
                        row_data.append(D(runs_text, bold=has_bold))
                    rows_data.append(row_data)
                
                content.append(tbl(col_widths, rows_data))
                content.append(empty())
            continue
        
        # Обычный текст с возможными ссылками
        if stripped and not stripped.startswith('['):
            parts = parse_inline_with_links(stripped, rel_mgr)
            runs = []
            for text, ptype, url in parts:
                if ptype == 'link':
                    runs.append(hyperlink_run(text, url, rel_mgr))
                elif ptype == 'bold':
                    runs.append(r(text, bold=True))
                elif ptype == 'italic':
                    runs.append(r(text, italic=True))
                else:
                    runs.append(r(text))
            if runs:
                content.append(body(*runs))
        
        i += 1
    
    return ''.join(content)


# ─── Основная логика ──────────────────────────────────────────────────

def convert_md_to_docx(md_file, template_file, output_file):
    """Конвертирует MD файл в DOCX используя шаблон."""
    
    md_dir = os.path.dirname(os.path.abspath(md_file))
    
    # Читаем Markdown
    with open(md_file, 'r', encoding='utf-8') as f:
        md_content = f.read()
    
    # Читаем шаблон
    with zipfile.ZipFile(template_file, 'r') as z:
        files = {n: z.read(n) for n in z.namelist()}
    
    # Извлекаем sectPr
    orig_doc = files['word/document.xml'].decode('utf-8')
    sect_m = re.search(r'<w:sectPr\b.*?</w:sectPr>', orig_doc, re.DOTALL)
    sect = sect_m.group(0) if sect_m else ''
    
    # Получаем footer rId
    rels_xml = files['word/_rels/document.xml.rels'].decode('utf-8')
    footer_rid = get_existing_footer_rid(rels_xml)
    
    # Создаём менеджер отношений
    rel_mgr = RelationshipManager(rels_xml)
    
    # Создаём numbering.xml с нумерацией для заголовков
    files['word/numbering.xml'] = create_numbering_xml()
    bullet_num_id = '2'  # numId=2 для маркированных списков
    
    # Обновляем styles.xml - добавляем numPr для заголовков
    if 'word/styles.xml' in files:
        styles_xml = files['word/styles.xml'].decode('utf-8')
        styles_xml = update_styles_with_numbering(styles_xml)
        files['word/styles.xml'] = styles_xml.encode('utf-8')
    
    # Хранилище для изображений
    images_data = {}
    
    # Парсим Markdown в XML
    content_xml = parse_md_to_content(md_content, bullet_num_id, rel_mgr, images_data, md_dir)
    
    # Собираем document.xml
    new_doc = build_document(sect, content_xml)
    
    # Обновляем файлы
    # Добавляем footer reference в sectPr
    footer_ref = f'<w:footerReference r:id="{footer_rid}" w:type="default"/>'
    # sectPr может иметь атрибуты, поэтому ищем <w:sectPr 
    new_doc = re.sub(r'<w:sectPr(\s[^>]*)>', rf'<w:sectPr\1>{footer_ref}', new_doc)
    
    files['word/document.xml'] = new_doc.encode('utf-8')
    files['word/footer1.xml'] = create_footer_xml()
    
    # Добавляем footer в relationships
    rels_xml = rel_mgr.get_rels_xml()
    if f'Target="footer1.xml"' not in rels_xml:
        footer_rel = f'<Relationship Id="{footer_rid}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/footer" Target="footer1.xml"/>'
        rels_xml = rels_xml.replace('</Relationships>', f'{footer_rel}</Relationships>')
    files['word/_rels/document.xml.rels'] = rels_xml.encode('utf-8')
    
    # Обновляем [Content_Types].xml для footer
    ct = files['[Content_Types].xml'].decode('utf-8')
    if 'footer1.xml' not in ct:
        ct = ct.replace('</Types>',
                       '<Override PartName="/word/footer1.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.footer+xml"/></Types>')
        files['[Content_Types].xml'] = ct.encode('utf-8')
    
    # Добавляем изображения в архив и обновляем ContentType
    for img_name, img_data in images_data.items():
        files[f'word/media/{img_name}'] = img_data
        
        ext = os.path.splitext(img_name)[1].lower()
        content_type_map = {
            '.png': 'image/png',
            '.jpg': 'image/jpeg',
            '.jpeg': 'image/jpeg',
            '.gif': 'image/gif',
            '.bmp': 'image/bmp',
            '.svg': 'image/svg+xml',
        }
        content_type = content_type_map.get(ext, 'image/png')
        
        ct = files['[Content_Types].xml'].decode('utf-8')
        if f'Extension="{ext[1:]}"' not in ct:
            ct = ct.replace('</Types>',
                           f'<Default Extension="{ext[1:]}" ContentType="{content_type}"/></Types>')
            files['[Content_Types].xml'] = ct.encode('utf-8')
    
    # Исправляем ContentType для документа
    ct = files['[Content_Types].xml'].decode('utf-8')
    ct = ct.replace('wordprocessingml.template.main+xml',
                    'wordprocessingml.document.main+xml')
    files['[Content_Types].xml'] = ct.encode('utf-8')
    
    # Сохраняем результат
    with zipfile.ZipFile(output_file, 'w', zipfile.ZIP_DEFLATED) as z:
        for name, data in files.items():
            z.writestr(name, data)
    
    # Отчёт
    print(f"✓ Документ создан: {output_file}")
    print(f"  • Гиперссылок: {len(rel_mgr.hyperlinks)}")
    print(f"  • Изображений: {len(images_data)}")


if __name__ == '__main__':
    import argparse
    
    parser = argparse.ArgumentParser(
        description='Конвертер Markdown в DOCX с поддержкой ссылок и изображений'
    )
    parser.add_argument('md_file', nargs='?', default='input.md',
                       help='Исходный MD файл (по умолчанию: input.md)')
    parser.add_argument('-t', '--template', default='Doc1.dotx',
                       help='Шаблон DOTX (по умолчанию: Doc1.dotx)')
    parser.add_argument('-o', '--output', default='output.docx',
                       help='Выходной файл (по умолчанию: output.docx)')
    
    args = parser.parse_args()
    
    md_file = Path(args.md_file)
    template_file = Path(args.template)
    output_file = Path(args.output)
    
    if not md_file.exists():
        print(f"✗ Файл не найден: {md_file}")
        exit(1)
    
    if not template_file.exists():
        print(f"✗ Шаблон не найден: {template_file}")
        exit(1)
    
    convert_md_to_docx(md_file, template_file, output_file)
