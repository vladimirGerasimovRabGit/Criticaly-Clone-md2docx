<#
.SYNOPSIS
    Restores NuGet packages and builds all projects in ClonerSuite.
.DESCRIPTION
    Run on a machine WITH internet access.
    Downloads all NuGet packages, builds, and publishes all projects.
    After running, the source tree is ready to be archived and transferred.

    The published output is placed in each project's .\publish folder.
.PARAMETER Runtime
    Target runtime. Default: win-x64
.EXAMPLE
    .\prepare-for-offline.ps1
.EXAMPLE
    .\prepare-for-offline.ps1 -Runtime win-x64
#>
[CmdletBinding()]
param(
    [string]$Runtime = "win-x64"
)

$ErrorActionPreference = "Stop"

Write-Host ""
Write-Host "========================================================" -ForegroundColor Cyan
Write-Host " ClonerSuite - Prepare for Offline Deployment" -ForegroundColor Cyan
Write-Host "========================================================" -ForegroundColor Cyan
Write-Host "Runtime: $Runtime" -ForegroundColor Yellow
Write-Host ""

$projects = @(
    @{ Name = "ServiceReqCloner"; Path = "$PSScriptRoot\ServiceReqCloner" },
    @{ Name = "Criticality"; Path = "$PSScriptRoot\Criticality" },
    @{ Name = "ApiKeyEncryptor"; Path = "$PSScriptRoot\tools\ApiKeyEncryptor" }
)

# Step 1: Restore all projects
Write-Host "[1/3] Restoring NuGet packages..." -ForegroundColor Cyan
foreach ($proj in $projects) {
    $csproj = Get-ChildItem -Path $proj.Path -Filter "*.csproj" | Select-Object -First 1
    if ($csproj) {
        Write-Host "  Restoring: $($proj.Name)..." -ForegroundColor Gray
        Push-Location $csproj.DirectoryName
        dotnet restore --force
        Pop-Location
    }
}
Write-Host "  Done." -ForegroundColor Green

# Step 2: Publish all projects
Write-Host ""
Write-Host "[2/3] Publishing projects..." -ForegroundColor Cyan
foreach ($proj in $projects) {
    $csproj = Get-ChildItem -Path $proj.Path -Filter "*.csproj" | Select-Object -First 1
    if ($csproj) {
        Write-Host ""
        Write-Host "  Publishing: $($proj.Name)..." -ForegroundColor Gray

        $publishDir = Join-Path $proj.Path "publish"
        dotnet publish $csproj.FullName `
            -c Release `
            -r $Runtime `
            --self-contained false `
            -o $publishDir

        # Copy appsettings and configs
        Get-ChildItem -Path $proj.Path -Filter "appsettings*.json" | Copy-Item -Destination $publishDir -Force
        $webConfig = Join-Path $proj.Path "web.config"
        if (Test-Path $webConfig) {
            Copy-Item $webConfig -Destination $publishDir -Force
        }

        $fileCount = (Get-ChildItem $publishDir -File).Count
        Write-Host "  Published: $fileCount files" -ForegroundColor Green
    }
}

# Step 3: Create run.bat for service projects
Write-Host ""
Write-Host "[3/3] Creating run scripts..." -ForegroundColor Cyan

$services = @(
    @{ Name = "ServiceReqCloner"; Exe = "ServiceReqCloner.exe"; Path = "$PSScriptRoot\ServiceReqCloner\publish" },
    @{ Name = "Criticality"; Exe = "Criticality.exe"; Path = "$PSScriptRoot\Criticality\publish" }
)

foreach ($svc in $services) {
    if (Test-Path $svc.Path) {
        $bat = @"
@echo off
echo.
echo ============================================
echo  $($svc.Name) - Starting
echo ============================================
echo.
set ASPNETCORE_ENVIRONMENT=Development
$($svc.Exe)
pause
"@
        $bat | Out-File -FilePath "$($svc.Path)\run.bat" -Encoding ASCII
        Write-Host "  Created: $($svc.Path)\run.bat" -ForegroundColor Green
    }
}

# Summary
Write-Host ""
Write-Host "========================================================" -ForegroundColor Green
Write-Host " All projects prepared for offline deployment!" -ForegroundColor Green
Write-Host "========================================================" -ForegroundColor Green
Write-Host ""
Write-Host "Published folders:" -ForegroundColor Cyan
Write-Host "  ServiceReqCloner\publish\" -ForegroundColor White
Write-Host "  Criticality\publish\" -ForegroundColor White
Write-Host "  tools\ApiKeyEncryptor\publish\" -ForegroundColor White
Write-Host ""
Write-Host "Next step: Archive the entire folder with:" -ForegroundColor Yellow
Write-Host ""
Write-Host "  tar -acf ClonerSuite.zip -C .. ClonerSuite" -ForegroundColor Gray
Write-Host ""
Write-Host "Or in Windows Explorer:" -ForegroundColor Gray
Write-Host "  Right-click folder -> Send to -> Compressed folder" -ForegroundColor Gray
Write-Host ""
