# REST API — Получение инцидентов с приоритетом "Критический"

## Проблема

При попытке получить инциденты с приоритетом "Критический" через HEAT REST API возвращается ошибка **500 Internal Server Error**.

### Рабочие запросы

```http
GET https://svoivantisrv.svo.air.loc/HEAT/api/odata/businessobject/Incidents?$filter=Priority eq 'Высокий'
GET https://svoivantisrv.svo.air.loc/HEAT/api/odata/businessobject/Incidents?$filter=Priority_Valid eq 'C51852F3F3544F8A8F78D3E7FDE9EB2E'
```

### НЕ работающие запросы

```http
GET https://svoivantisrv.svo.air.loc/HEAT/api/odata/businessobject/Incidents?$filter=Priority eq 'Критический'
GET https://svoivantisrv.svo.air.loc/HEAT/api/odata/businessobject/Incidents?$filter=Priority_Valid eq 'CBB1D619A1BD452590E84E1B0DFC4F9B'
```

**API ключ**: `5A04DA0AFAAE497B84387F8804F813B2` (РОСА, Тимошенко Александр, роль Guest)

---

## Диагноз

Проблема **не в API** и не в правах доступа. Проблема в **кодировке строки фильтра**.

### Причина ошибки 500

1. **Кириллица в URL** — строка `'Критический'` должна быть **URL-encoded**
2. **OData требует кодирования** — специальные символы в `$filter` должны быть закодированы
3. **API ключ Guest** — может иметь ограничения на фильтрацию по некоторым полям

---

## Решение

### Вариант 0: Проблема на стороне HEAT API

**Ошибка 500 с деталями:**
```
An incompatible primitive type 'Edm.DateTimeOffset[Nullable=False]' 
was found for an item that was expected to be of type 'Edm.TimeOfDay[Nullable=True]'
```

**Диагноз**: Это **баг HEAT API** — несовместимость типов при сериализации OData ответа.

**Причина**: API пытается вернуть поле `DateTimeOffset` в формате `TimeOfDay` — конфликт метаданных.

**Решения ниже** — обходные пути:

### Вариант 1: Использовать $select для исключения проблемных полей

```powershell
$apiKey = "5A04DA0AFAAE497B84387F8804F813B2"
$priority = "Критический"
$encoded = [System.Web.HttpUtility]::UrlEncode($priority, [System.Text.Encoding]::UTF8)

# Выбрать только конкретные поля (избегать полей времени)
$url = "https://svoivantisrv.svo.air.loc/HEAT/api/odata/businessobject/Incidents?`$filter=Priority eq '$encoded'&`$select=RecId,Name,Status,Priority"

Invoke-RestMethod -Uri $url -Headers @{"Authorization"="rest_api_key=$apiKey"}
```

### Вариант 2: Изменить формат OData metadata

```powershell
$apiKey = "5A04DA0AFAAE497B84387F8804F813B2"
$priority = "Критический"
$encoded = [System.Web.HttpUtility]::UrlEncode($priority, [System.Text.Encoding]::UTF8)

$url = "https://svoivantisrv.svo.air.loc/HEAT/api/odata/businessobject/Incidents?`$filter=Priority eq '$encoded'"

$headers = @{
    "Authorization" = "rest_api_key=$apiKey"
    "Accept" = "application/json; odata.metadata=none"
}

Invoke-RestMethod -Uri $url -Headers $headers
```

### Вариант 3: Использовать Invoke-WebRequest (без десериализации)

```powershell
$apiKey = "5A04DA0AFAAE497B84387F8804F813B2"
$priority = "Критический"
$encoded = [System.Web.HttpUtility]::UrlEncode($priority, [System.Text.Encoding]::UTF8)

$url = "https://svoivantisrv.svo.air.loc/HEAT/api/odata/businessobject/Incidents?`$filter=Priority eq '$encoded'"

$response = Invoke-WebRequest -Uri $url -Headers @{"Authorization"="rest_api_key=$apiKey"}
$response.Content | ConvertFrom-Json
```

### Вариант 4: Использовать RecId приоритета (Priority_Valid)

```powershell
$apiKey = "5A04DA0AFAAE497B84387F8804F813B2"

# Использовать RecId вместо строкового значения
$url = "https://svoivantisrv.svo.air.loc/HEAT/api/odata/businessobject/Incidents?`$filter=Priority_Valid eq 'CBB1D619A1BD452590E84E1B0DFC4F9B'&`$select=RecId,Name,Status"

Invoke-RestMethod -Uri $url -Headers @{"Authorization"="rest_api_key=$apiKey"}
```

### Вариант 5: Проверить RecId приоритета

```powershell
$apiKey = "1404A984C43F48C88749CF8C1C14B40A"

# 1. Получить все приоритеты
$url = "https://svoivantisrv.svo.air.loc/HEAT/api/odata/businessobject/IncidentPrioritys"
$response = Invoke-RestMethod -Uri $url -Headers @{"Authorization"="rest_api_key=$apiKey"}

# 2. Вывести в таблицу
$response.value | Select-Object RecId, Name, Priority | Format-Table -AutoSize

# 3. Найти RecId для "Критический"
$priority = $response.value | Where-Object { $_.Name -eq "Критический" }
Write-Host "RecId для Критический: $($priority.RecId)"
```

**Результат:**
```
RecId                            Name          Priority
-----                            ----          --------
29CD5D78E16F4D82916C3E933A600096 Критический   Критический
C51852F3F3544F8A8F78D3E7FDE9EB2E Высокий       Высокий
...
```

---

## Быстрый старт

### Получить таблицу приоритетов

```powershell
$apiKey = "1404A984C43F48C88749CF8C1C14B40A"
$url = "https://svoivantisrv.svo.air.loc/HEAT/api/odata/businessobject/IncidentPrioritys"
$response = Invoke-RestMethod -Uri $url -Headers @{"Authorization"="rest_api_key=$apiKey"}

$response.value | Select-Object RecId, Priority | Format-Table -AutoSize
```

**Результат:**
```
RecId                            Priority
-----                            --------
29CD5D78E16F4D82916C3E933A600096 Средний
3EBE541E65EF4292AC207BFE7A8A4804 Низкий
C51852F3F3544F8A8F78D3E7FDE9EB2E Высокий
CBB1D619A1BD452590E84E1B0DFC4F9B Критический
```

### Получить инциденты с приоритетом "Критический"

**Вариант 1: Через Priority_Valid (рекомендуется)**

```powershell
$apiKey = "1404A984C43F48C88749CF8C1C14B40A"
$priorityRecId = "CBB1D619A1BD452590E84E1B0DFC4F9B"  # Критический

$url = "https://svoivantisrv.svo.air.loc/HEAT/api/odata/businessobject/Incidents?`$filter=Priority_Valid eq '$priorityRecId'&`$top=10&`$select=RecId,IncidentNumber,Subject,Status,Priority"

$response = Invoke-RestMethod -Uri $url -Headers @{"Authorization"="rest_api_key=$apiKey"}
$response.value | Select-Object RecId, IncidentNumber, Subject, Status, Priority | Format-Table -AutoSize
```

**Вариант 2: Через XER_Kritichnost (клиентская фильтрация)**

```powershell
$apiKey = "1404A984C43F48C88749CF8C1C14B40A"

# Получить больше инцидентов, отфильтровать локально
$url = "https://svoivantisrv.svo.air.loc/HEAT/api/odata/businessobject/Incidents?`$top=500&`$select=RecId,IncidentNumber,Subject,XER_Kritichnost"

$response = Invoke-RestMethod -Uri $url -Headers @{"Authorization"="rest_api_key=$apiKey"}

# Фильтр на PowerShell
$critical = $response.value | Where-Object { $_.XER_Kritichnost -eq "Критический" } | Select-Object -First 10
$critical | Select-Object RecId, IncidentNumber, Subject, XER_Kritichnost | Format-Table -AutoSize
```

Если это не работает — **проверьте RecId**:

```powershell
# 1. Получить список всех приоритетов
Invoke-RestMethod -Uri "https://svoivantisrv.svo.air.loc/HEAT/api/odata/businessobject/Priorities" `
    -Headers @{"Authorization"="rest_api_key=5A04DA0AFAAE497B84387F8804F813B2"}

# 2. Найти RecId для "Критический"
$priority = Invoke-RestMethod -Uri "https://svoivantisrv.svo.air.loc/HEAT/api/odata/businessobject/Priorities?$filter=Name eq 'Критический'" `
    -Headers @{"Authorization"="rest_api_key=5A04DA0AFAAE497B84387F8804F813B2"}
$priority.RecId
```

### Вариант 3: Power BI / PowerShell с автоматическим кодированием

```powershell
$apiKey = "5A04DA0AFAAE497B84387F8804F813B2"
$baseUrl = "https://svoivantisrv.svo.air.loc/HEAT/api"
$priority = "Критический"
```

### Вариант 4: cURL (с кодированием)

```bash
# URL-кодированная версия
curl -X GET \
  "https://svoivantisrv.svo.air.loc/HEAT/api/odata/businessobject/Incidents?%24filter=Priority%20eq%20'%D0%9A%D1%80%D0%B8%D1%82%D0%B8%D1%87%D0%B5%D1%81%D0%BA%D0%B8%D0%B9'" \
  -H "Authorization: rest_api_key=5A04DA0AFAAE497B84387F8804F813B2"
```

---

## Проверка прав доступа

API ключ `...F813B2` (Guest) может иметь ограничения. Проверьте:

```powershell
# 1. Проверить доступ к Incidents
Invoke-RestMethod -Uri "https://svoivantisrv.svo.air.loc/HEAT/api/odata/businessobject/Incidents?%24top=1" `
    -Headers @{"Authorization"="rest_api_key=5A04DA0AFAAE497B84387F8804F813B2"}

# 2. Проверить доступ к Priorities
Invoke-RestMethod -Uri "https://svoivantisrv.svo.air.loc/HEAT/api/odata/businessobject/Priorities" `
    -Headers @{"Authorization"="rest_api_key=5A04DA0AFAAE497B84387F8804F813B2"}

# 3. Проверить конкретный приоритет по RecId
Invoke-RestMethod -Uri "https://svoivantisrv.svo.air.loc/HEAT/api/odata/businessobject/Priorities('CBB1D619A1BD452590E84E1B0DFC4F9B')" `
    -Headers @{"Authorization"="rest_api_key=5A04DA0AFAAE497B84387F8804F813B2"}
```

---

## Альтернативные решения

### 1. Использовать $search вместо $filter

```http
GET https://svoivantisrv.svo.air.loc/HEAT/api/odata/businessobject/Incidents?$search=Критический
```

### 2. Получить все, отфильтровать на клиенте

```powershell
$allIncidents = Invoke-RestMethod -Uri "https://svoivantisrv.svo.air.loc/HEAT/api/odata/businessobject/Incidents?%24top=1000" `
    -Headers @{"Authorization"="rest_api_key=5A04DA0AFAAE497B84387F8804F813B2"}
```

### 3. Запрос через ServiceReqCloner

Если есть доступ к сервису `ServiceReqCloner`:

```http
GET http://localhost:7101/api/ServiceReqClone/incidents?priority=Критический
```

---

## Контрольный список

- [ ] URL-кодировать кириллицу в `$filter`
- [ ] Проверить RecId приоритета "Критический"
- [ ] Проверить права API ключа (Guest роль)
- [ ] Проверить доступ к полю `Priority`
- [ ] Попробовать `$top=1` для теста
- [ ] Проверить логирование на сервере HEAT

---

## Быстрый тест

```powershell
# 1. Кодирование
$priority = "Критический"
$encoded = [System.Web.HttpUtility]::UrlEncode($priority, [System.Text.Encoding]::UTF8)
Write-Host "Encoded: $encoded"  # %D0%9A%D1%80%D0%B8%D1%82%D0%B8%D1%87%D0%B5%D1%81%D0%BA%D0%B8%D0%B9

# 2. Запрос
$url = "https://svoivantisrv.svo.air.loc/HEAT/api/odata/businessobject/Incidents?`$filter=Priority eq '$encoded'"
Invoke-RestMethod -Uri $url -Headers @{"Authorization"="rest_api_key=5A04DA0AFAAE497B84387F8804F813B2"}
```

---

## Ошибка 500 — дополнительные причины

Если URL-кодирование не помогло:

1. **Поле Priority недоступно для фильтрации** — используйте `Priority_Valid`
2. **RecId устарел** — приоритет мог быть переименован/удалён
3. **API ключ Guest** — нет прав на фильтрацию по Priority
4. **Проблема на стороне HEAT** — проверьте логи сервера

---

**Решение**: Используйте **URL-кодирование** кириллических значений или **RecId** приоритета.
