@echo off
echo.
echo ============================================
echo  Criticality API - Starting
echo ============================================
echo.
echo Environment: %ASPNETCORE_ENVIRONMENT%
echo.
set ASPNETCORE_ENVIRONMENT=Development
Criticality.exe
pause
