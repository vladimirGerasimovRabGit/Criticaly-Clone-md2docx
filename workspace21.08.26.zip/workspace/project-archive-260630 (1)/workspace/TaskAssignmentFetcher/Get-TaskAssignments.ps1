<#
.SYNOPSIS
    Fetches AssignmentId and TRN_Resolution from HEAT API Task#assignment objects.
.DESCRIPTION
    Standalone script that connects to HEAT API via OData endpoint and retrieves
    AssignmentId and TRN_Resolution fields from Task#assignment records.
.PARAMETER ApiUrl
    Base URL of the HEAT API (default: https://svoivantisrv/HEAT/api).
.PARAMETER ApiKey
    HEAT API key for authentication (default: pre-configured).
.PARAMETER Top
    Number of records to return (default: 100).
.PARAMETER OutputFile
    Path to save results as CSV. If not specified, results are displayed in console.
.PARAMETER Filter
    Optional OData filter (e.g., "Status eq 'Completed'").
.PARAMETER SkipCertificateValidation
    Skip SSL certificate validation (for self-signed certs).
.EXAMPLE
    .\Get-TaskAssignments.ps1
.EXAMPLE
    .\Get-TaskAssignments.ps1 -Top 500 -OutputFile "assignments.csv"
.EXAMPLE
    .\Get-TaskAssignments.ps1 -Filter "Status eq 'Completed'" -Top 100
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory=$false)]
    [string]$ApiUrl = "https://svoivantisrv/HEAT/api",

    [Parameter(Mandatory=$false)]
    [string]$ApiKey = "1404A984C43F48C88749CF8C1C14B40A",

    [int]$Top = 100,

    [string]$OutputFile = "",

    [string]$Filter = "",

    [switch]$SkipCertificateValidation
)

$ErrorActionPreference = "Stop"
$ApiUrl = $ApiUrl.TrimEnd('/')

# Skip SSL validation if requested
if ($SkipCertificateValidation) {
    [System.Net.ServicePointManager]::ServerCertificateValidationCallback = { $true }
}

# OData endpoint for Task#assignment
$entitySet = "task__assignments"

# Build OData URL
$endpoint = "${ApiUrl}/odata/businessobject/${entitySet}?`$top=${Top}&`$select=AssignmentId,TRN_Resolution&`$orderby=AssignmentId desc&`$filter=TRN_Status eq 'Закрыт'"

if ($Filter) {
    $endpoint += "&`$filter=${Filter}"
}

Write-Host ""
Write-Host "=============================================" -ForegroundColor Cyan
Write-Host " Task Assignment Fetcher (OData)" -ForegroundColor Cyan
Write-Host "=============================================" -ForegroundColor Cyan
Write-Host "Endpoint: $endpoint" -ForegroundColor Gray
Write-Host ""

# Headers
$headers = @{
    "Authorization" = "rest_api_key=$ApiKey"
}

try {
    Write-Host "Fetching data..." -ForegroundColor Yellow
    $response = Invoke-RestMethod -Uri $endpoint -Headers $headers -ErrorAction Stop

    # Extract records from OData response
    $records = @()
    if ($response.value) {
        foreach ($item in $response.value) {
            $records += [PSCustomObject]@{
                AssignmentId  = $item.AssignmentId
                TRN_Resolution = $item.TRN_Resolution
            }
        }
    }

    Write-Host ""
    Write-Host "Found $($records.Count) records" -ForegroundColor Green
    Write-Host ""

    if ($records.Count -gt 0) {
        $records | Format-Table -AutoSize -Wrap

        if ($OutputFile) {
            $records | Export-Csv -Path $OutputFile -NoTypeInformation -Encoding UTF8
            Write-Host ""
            Write-Host "Results saved to: $OutputFile" -ForegroundColor Green
        }
    }
    else {
        Write-Host "No records found." -ForegroundColor Yellow
    }

} catch {
    Write-Host "ERROR: Failed to fetch data" -ForegroundColor Red
    Write-Host "Status: $($_.Exception.Response.StatusCode.value__)" -ForegroundColor Red
    Write-Host "Message: $($_.Exception.Message)" -ForegroundColor Red
    if ($_.Exception.Response) {
        $reader = New-Object System.IO.StreamReader($_.Exception.Response.GetResponseStream())
        $errorBody = $reader.ReadToEnd()
        Write-Host "Response: $errorBody" -ForegroundColor Red
    }
    exit 1
}
