@echo off
chcp 65001 >nul
REM ========================================
REM MD2DOCX Converter — Быстрая конвертация
REM ========================================

echo.
echo ============================================
echo  MD2DOCX Converter
echo ============================================
echo.

cd /d "%~dp0"

if not exist "md2docx.py" (
    echo ОШИБКА: md2docx.py не найден в текущей папке
    pause
    exit /b 1
)

if not exist "Doc1-no-outline.dotx" (
    echo ОШИБКА: Doc1-no-outline.dotx не найден в текущей папке
    pause
    exit /b 1
)

if "%~1"=="" (
    echo Использование:
    echo   %~nx0 файл.md [output.docx]
    echo.
    echo Пример:
    echo   %~nx0 ClonerSuite-Documentation.md
    echo.
    pause
    exit /b 0
)

if not exist "%~1" (
    echo ОШИБКА: Файл не найден: %~1
    pause
    exit /b 1
)

set OUTPUT=%~2
if "%OUTPUT%"=="" set OUTPUT=%~n1.docx

echo Конвертация: %~1
echo Результат:   %OUTPUT%
echo.

python md2docx.py "%~1" -t Doc1-no-outline.dotx -o "%OUTPUT%"

if errorlevel 1 (
    echo.
    echo ОШИБКА при конвертации!
    pause
    exit /b 1
)

echo.
echo Готово! Файл создан: %OUTPUT%
echo.
pause
