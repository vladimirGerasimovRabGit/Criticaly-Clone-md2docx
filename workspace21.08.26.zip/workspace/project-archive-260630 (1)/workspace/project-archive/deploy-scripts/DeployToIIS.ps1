# DeployToIIS.ps1
# Скрипт развёртывания ClonerSuite в IIS
# Запуск: powershell -ExecutionPolicy Bypass -File DeployToIIS.ps1

param(
    [string]$SourcePath = "C:\workspace",
    [string]$ClonerSuitePath = "C:\ClonerSuite",
    [string]$CriticalityPath = "$ClonerSuitePath\Criticality",
    [string]$ServiceReqClonerPath = "$ClonerSuitePath\ServiceReqCloner"
)

$ErrorActionPreference = "Stop"
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  ClonerSuite IIS Deployment" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# Проверка прав администратора
$isAdmin = ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $isAdmin) {
    Write-Host "[FAIL] Запустите от имени администратора!" -ForegroundColor Red
    exit 1
}

# 1. Создание директорий
Write-Host "1. Создание директорий..." -ForegroundColor Cyan
$dirs = @(
    $ClonerSuitePath,
    "$ClonerSuitePath\logs",
    "$CriticalityPath\publish-iis",
    "$ServiceReqClonerPath\publish-iis"
)

foreach ($dir in $dirs) {
    if (-not (Test-Path $dir)) {
        New-Item -ItemType Directory -Path $dir -Force | Out-Null
        Write-Host "  [OK] Создано: $dir" -ForegroundColor Green
    } else {
        Write-Host "  [INFO] Существует: $dir" -ForegroundColor Yellow
    }
}

# 2. Копирование файлов публикации
Write-Host ""
Write-Host "2. Копирование файлов публикации..." -ForegroundColor Cyan

$sourceCriticality = "$SourcePath\Criticality\publish"
$sourceServiceReq = "$SourcePath\ServiceReqCloner\publish"

if (Test-Path $sourceCriticality) {
    Copy-Item "$sourceCriticality\*" -Destination "$CriticalityPath\publish-iis" -Recurse -Force
    Write-Host "  [OK] Скопировано: Criticality -> $CriticalityPath\publish-iis" -ForegroundColor Green
} else {
    Write-Host "  [WARN] Исходная папка не найдена: $sourceCriticality" -ForegroundColor Yellow
}

if (Test-Path $sourceServiceReq) {
    Copy-Item "$sourceServiceReq\*" -Destination "$ServiceReqClonerPath\publish-iis" -Recurse -Force
    Write-Host "  [OK] Скопировано: ServiceReqCloner -> $ServiceReqClonerPath\publish-iis" -ForegroundColor Green
} else {
    Write-Host "  [WARN] Исходная папка не найдена: $sourceServiceReq" -ForegroundColor Yellow
}

# 3. Проверка файлов
Write-Host ""
Write-Host "3. Проверка скопированных файлов..." -ForegroundColor Cyan

$requiredFiles = @(
    "$CriticalityPath\publish-iis\Criticality.dll",
    "$CriticalityPath\publish-iis\web.config",
    "$ServiceReqClonerPath\publish-iis\ServiceReqCloner.dll",
    "$ServiceReqClonerPath\publish-iis\web.config"
)

foreach ($file in $requiredFiles) {
    if (Test-Path $file) {
        Write-Host "  [OK] $([System.IO.Path]::GetFileName($file))" -ForegroundColor Green
    } else {
        Write-Host "  [FAIL] Не найден: $([System.IO.Path]::GetFileName($file))" -ForegroundColor Red
    }
}

# 4. Создание Application Pools
Write-Host ""
Write-Host "4. Создание Application Pools..." -ForegroundColor Cyan

try {
    Import-Module WebAdministration -ErrorAction Stop
    
    $appPools = @(
        @{Name="CriticalityAppPool"; Runtime=""; ManagedPipelineMode="Integrated"},
        @{Name="ServiceReqClonerAppPool"; Runtime=""; ManagedPipelineMode="Integrated"}
    )
    
    foreach ($pool in $appPools) {
        $existing = Get-WebAppPoolState -Name $pool.Name -ErrorAction SilentlyContinue
        if ($existing) {
            Write-Host "  [INFO] AppPool '$($pool.Name)' существует" -ForegroundColor Yellow
        } else {
            New-WebAppPool -Name $pool.Name | Out-Null
            Set-ItemProperty "IIS:\AppPools\$($pool.Name)" -Name "managedRuntimeVersion" -Value $pool.Runtime
            Set-ItemProperty "IIS:\AppPools\$($pool.Name)" -Name "managedPipelineMode" -Value $pool.ManagedPipelineMode
            Set-ItemProperty "IIS:\AppPools\$($pool.Name)" -Name "startMode" -Value "AlwaysRunning"
            Set-ItemProperty "IIS:\AppPools\$($pool.Name)" -Name "autoStart" -Value "True"
            Set-ItemProperty "IIS:\AppPools\$($pool.Name)" -Name "enable32BitAppOnWin64" -Value "False"
            
            Write-Host "  [OK] AppPool '$($pool.Name)' создан" -ForegroundColor Green
        }
    }
} catch {
    Write-Host "  [FAIL] WebAdministration недоступен" -ForegroundColor Red
    Write-Host "  >>> Установите: Add-WindowsFeature Web-Mgmt-Console" -ForegroundColor Yellow
    exit 1
}

# 5. Создание сайтов IIS
Write-Host ""
Write-Host "5. Создание сайтов IIS..." -ForegroundColor Cyan

$sites = @(
    @{Name="Criticality"; Port=5000; Path="$CriticalityPath\publish-iis"; Pool="CriticalityAppPool"},
    @{Name="ServiceReqCloner"; Port=5001; Path="$ServiceReqClonerPath\publish-iis"; Pool="ServiceReqClonerAppPool"}
)

foreach ($site in $sites) {
    $existing = Get-Website -Name $site.Name -ErrorAction SilentlyContinue
    if ($existing) {
        Write-Host "  [INFO] Сайт '$($site.Name)' существует (порт $($site.Port))" -ForegroundColor Yellow
    } else {
        New-Website -Name $site.Name -Port $site.Port -PhysicalPath $site.Path -ApplicationPool $site.Pool | Out-Null
        Write-Host "  [OK] Сайт '$($site.Name)' создан (порт $($site.Port))" -ForegroundColor Green
    }
}

# 6. Настройка прав доступа
Write-Host ""
Write-Host "6. Настройка прав доступа..." -ForegroundColor Cyan

$aclPaths = @(
    "$ClonerSuitePath\logs",
    "$CriticalityPath\publish-iis",
    "$ServiceReqClonerPath\publish-iis"
)

foreach ($path in $aclPaths) {
    if (Test-Path $path) {
        $acl = Get-Acl $path
        $rule = New-Object System.Security.AccessControl.FileSystemAccessRule("IIS_IUSRS", "Modify", "ContainerInherit,ObjectInherit", "None", "Allow")
        $acl.AddAccessRule($rule)
        Set-Acl $path $acl
        Write-Host "  [OK] Права IIS_IUSRS на $path" -ForegroundColor Green
    }
}

# 7. Перезапуск AppPool
Write-Host ""
Write-Host "7. Перезапуск Application Pools..." -ForegroundColor Cyan

try {
    Restart-WebAppPool -Name "CriticalityAppPool"
    Write-Host "  [OK] CriticalityAppPool перезапущен" -ForegroundColor Green
    
    Restart-WebAppPool -Name "ServiceReqClonerAppPool"
    Write-Host "  [OK] ServiceReqClonerAppPool перезапущен" -ForegroundColor Green
} catch {
    Write-Host "  [WARN] Не удалось перезапустить AppPool" -ForegroundColor Yellow
}

# 8. Финальная проверка
Write-Host ""
Write-Host "8. Финальная проверка..." -ForegroundColor Cyan

Write-Host ""
Write-Host "  Application Pools:" -ForegroundColor Cyan
Get-WebAppPoolState | Where-Object {$_.Name -match "Criticality|ServiceReq"} | 
    ForEach-Object { Write-Host "    $($_.Name): $($_.State)" -ForegroundColor Green }

Write-Host ""
Write-Host "  Сайты:" -ForegroundColor Cyan
Get-Website | Where-Object {$_.Name -match "Criticality|ServiceReq"} | 
    ForEach-Object { Write-Host "    $($_.Name): $($_.State) (порт $($_.Bindings.Collection.bindingInformation -join ', '))" -ForegroundColor Green }

Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  Развёртывание завершено!" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "Проверка доступности:" -ForegroundColor Cyan
Write-Host "  http://localhost:5000/ - Criticality" -ForegroundColor White
Write-Host "  http://localhost:5001/ - ServiceReqCloner" -ForegroundColor White
Write-Host ""
Write-Host "Нажмите Enter для выхода..." -ForegroundColor Gray
Read-Host
