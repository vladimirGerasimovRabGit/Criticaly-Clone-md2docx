# PreDeploymentCheck.ps1
# Скрипт проверки готовности сервера перед развёртыванием ClonerSuite в IIS
# Запуск: powershell -ExecutionPolicy Bypass -File PreDeploymentCheck.ps1

param(
    [string]$ClonerSuitePath = "C:\ClonerSuite",
    [string]$CriticalityPath = "$ClonerSuitePath\Criticality",
    [string]$ServiceReqClonerPath = "$ClonerSuitePath\ServiceReqCloner",
    [string]$LogPath = "$ClonerSuitePath\deployment-check.log"
)

# Включение цветов
$ErrorColor = "Red"
$WarningColor = "Yellow"
$SuccessColor = "Green"
$InfoColor = "Cyan"

function Write-Status {
    param([string]$Status, [string]$Color)
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    Write-Host "[$timestamp] $Status" -ForegroundColor $Color
    "[$timestamp] $Status" | Out-File -FilePath $LogPath -Append -Encoding UTF8
}

function Test-Admin {
    $currentUser = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
    return $currentUser.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

# Начало проверки
Clear-Host
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  ClonerSuite Pre-Deployment Check" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

$checkTime = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
"===== Проверка начата: $checkTime =====" | Out-File -FilePath $LogPath -Encoding UTF8
"" | Out-File -FilePath $LogPath -Append

# 1. Проверка прав администратора
Write-Host "1. Проверка прав администратора..." -ForegroundColor Cyan
if (Test-Admin) {
    Write-Status "  [OK] Запуск от имени администратора" $SuccessColor
} else {
    Write-Status "  [FAIL] Требуется запуск от имени администратора!" $ErrorColor
    Write-Host "  Перезапустите PowerShell: Run as Administrator" -ForegroundColor Red
    exit 1
}

# 2. Проверка .NET Runtime
Write-Host ""
Write-Host "2. Проверка .NET Runtime..." -ForegroundColor Cyan
$dotnetVersions = @("8.0", "7.0", "6.0")
$dotnetFound = $false

try {
    $dotnetOutput = dotnet --list-runtimes 2>&1
    foreach ($version in $dotnetVersions) {
        if ($dotnetOutput -match "Microsoft\.AspNetCore\.App $version") {
            Write-Status "  [OK] .NET $version установлен" $SuccessColor
            $dotnetFound = $true
            break
        }
    }
    if (-not $dotnetFound) {
        Write-Status "  [WARN] .NET 6/7/8 не найден. Установите .NET 8 Runtime" $WarningColor
    }
} catch {
    Write-Status "  [FAIL] dotnet CLI не найден" $ErrorColor
}

# 3. Проверка IIS
Write-Host ""
Write-Host "3. Проверка IIS..." -ForegroundColor Cyan
try {
    $iisStatus = Get-Service -Name "W3SVC" -ErrorAction SilentlyContinue
    if ($iisStatus) {
        Write-Status "  [OK] IIS установлен (W3SVC: $($iisStatus.Status))" $SuccessColor
    } else {
        Write-Status "  [FAIL] IIS не установлен" $ErrorColor
        Write-Host "  Установите: Add-WindowsFeature Web-Server" -ForegroundColor Yellow
    }
} catch {
    Write-Status "  [FAIL] IIS не установлен" $ErrorColor
}

# 4. Проверка Application Pool
Write-Host ""
Write-Host "4. Проверка Application Pools..." -ForegroundColor Cyan
Import-Module WebAdministration -ErrorAction SilentlyContinue
$requiredAppPools = @("ClonerSuiteAppPool", "CriticalityAppPool", "ServiceReqClonerAppPool")

foreach ($appPool in $requiredAppPools) {
    $pool = Get-WebAppPoolState -Name $appPool -ErrorAction SilentlyContinue
    if ($pool) {
        Write-Status "  [OK] AppPool '$appPool' существует (Status: $($pool.State))" $SuccessColor
    } else {
        Write-Status "  [WARN] AppPool '$appPool' не найден" $WarningColor
    }
}

# 5. Проверка сайтов IIS
Write-Host ""
Write-Host "5. Проверка сайтов IIS..." -ForegroundColor Cyan
$requiredSites = @("ClonerSuite", "Criticality", "ServiceReqCloner")

foreach ($siteName in $requiredSites) {
    $site = Get-Website -Name $siteName -ErrorAction SilentlyContinue
    if ($site) {
        $bindings = $site.Bindings.Collection | ForEach-Object { "$($_.protocol)://$($_.bindingInformation)" }
        Write-Status "  [OK] Сайт '$siteName' существует (Status: $($site.State))" $SuccessColor
        Write-Status "    Bindings: $($bindings -join ', ')" $InfoColor
    } else {
        Write-Status "  [WARN] Сайт '$siteName' не найден" $WarningColor
    }
}

# 6. Проверка директорий публикации
Write-Host ""
Write-Host "6. Проверка директорий публикации..." -ForegroundColor Cyan
$publishPaths = @(
    "$CriticalityPath\publish-standalone",
    "$CriticalityPath\publish-iis",
    "$ServiceReqClonerPath\publish-standalone",
    "$ServiceReqClonerPath\publish-iis"
)

foreach ($path in $publishPaths) {
    if (Test-Path $path) {
        $fileCount = (Get-ChildItem -Path $path -File | Measure-Object).Count
        Write-Status "  [OK] $path ($fileCount файлов)" $SuccessColor
    } else {
        Write-Status "  [FAIL] Директория не найдена: $path" $ErrorColor
    }
}

# 7. Проверка DLL и конфигов
Write-Host ""
Write-Host "7. Проверка DLL и appsettings.json..." -ForegroundColor Cyan
$requiredFiles = @(
    "$CriticalityPath\publish-iis\ClonerSuite.Criticality.dll",
    "$CriticalityPath\publish-iis\appsettings.json",
    "$CriticalityPath\publish-iis\appsettings.Production.json",
    "$ServiceReqClonerPath\publish-iis\ClonerSuite.ServiceReqCloner.dll",
    "$ServiceReqClonerPath\publish-iis\appsettings.json",
    "$ServiceReqClonerPath\publish-iis\appsettings.Production.json"
)

foreach ($file in $requiredFiles) {
    if (Test-Path $file) {
        $size = (Get-Item $file).Length / 1KB
        Write-Status "  [OK] $([System.IO.Path]::GetFileName($file)) ($([math]::Round($size, 1)) KB)" $SuccessColor
    } else {
        Write-Status "  [FAIL] Файл не найден: $file" $ErrorColor
    }
}

# 8. Проверка прав доступа к папкам
Write-Host ""
Write-Host "8. Проверка прав доступа к папкам..." -ForegroundColor Cyan
$checkPaths = @(
    "$CriticalityPath\publish-iis",
    "$ServiceReqClonerPath\publish-iis",
    "$ClonerSuitePath\logs"
)

try {
    $appPoolIdentity = [System.Security.Principal.WindowsIdentity]::GetCurrent().Name
    foreach ($path in $checkPaths) {
        if (Test-Path $path) {
            $acl = Get-Acl $path
            $hasAccess = $false
            foreach ($access in $acl.Access) {
                if ($access.IdentityReference -match "IIS_IUSRS|ApplicationPoolIdentity|NETWORK SERVICE") {
                    $hasAccess = $true
                    break
                }
            }
            if ($hasAccess) {
                Write-Status "  [OK] $path - доступ для IIS_IUSRS предоставлен" $SuccessColor
            } else {
                Write-Status "  [WARN] $path - проверьте права для IIS_IUSRS" $WarningColor
            }
        }
    }
} catch {
    Write-Status "  [ERROR] Ошибка проверки прав: $_" $ErrorColor
}

# 9. Проверка connectionString в appsettings
Write-Host ""
Write-Host "9. Проверка connectionString в appsettings.json..." -ForegroundColor Cyan
$configFiles = @(
    "$CriticalityPath\publish-iis\appsettings.json",
    "$CriticalityPath\publish-iis\appsettings.Production.json",
    "$ServiceReqClonerPath\publish-iis\appsettings.json",
    "$ServiceReqClonerPath\publish-iis\appsettings.Production.json"
)

foreach ($configFile in $configFiles) {
    if (Test-Path $configFile) {
        $config = Get-Content $configFile -Raw | ConvertFrom-Json
        $connStr = $config.ConnectionStrings.DefaultConnectionString
        if ($connStr) {
            $server = $connStr -replace ".*Server=([^;]+);.*", '$1'
            $database = $connStr -replace ".*Database=([^;]+);.*", '$1'
            Write-Status "  [OK] $([System.IO.Path]::GetFileName($configFile))" $SuccessColor
            Write-Status "    Server: $server, Database: $database" $InfoColor
        } else {
            Write-Status "  [FAIL] $([System.IO.Path]::GetFileName($configFile)) - нет ConnectionString" $ErrorColor
        }
    }
}

# 10. Проверка портов
Write-Host ""
Write-Host "10. Проверка занятых портов..." -ForegroundColor Cyan
$ports = @(80, 443, 5000, 5001)
foreach ($port in $ports) {
    $connection = Get-NetTCPConnection -LocalPort $port -ErrorAction SilentlyContinue -WarningAction SilentlyContinue
    if ($connection) {
        $process = Get-Process -Id $connection.OwningProcess -ErrorAction SilentlyContinue
        Write-Status "  [INFO] Порт $port занят процессом: $($process.ProcessName)" $WarningColor
    } else {
        Write-Status "  [OK] Порт $port свободен" $SuccessColor
    }
}

# 11. Проверка сертификатов (если HTTPS)
Write-Host ""
Write-Host "11. Проверка SSL сертификатов..." -ForegroundColor Cyan
try {
    $certs = Get-ChildItem Cert:\LocalMachine\My | Where-Object {
        $_.HasPrivateKey -and $_.NotAfter -gt (Get-Date)
    }
    if ($certs) {
        Write-Status "  [OK] Найдено $($certs.Count) валидных сертификатов" $SuccessColor
        foreach ($cert in $certs | Select-Object -First 3) {
            Write-Status "    $($cert.Subject) (до: $($cert.NotAfter.ToString('yyyy-MM-dd')))" $InfoColor
        }
    } else {
        Write-Status "  [INFO] SSL сертификаты не найдены" $InfoColor
    }
} catch {
    Write-Status "  [ERROR] Ошибка проверки сертификатов: $_" $ErrorColor
}

# 12. Проверка брандмауэра
Write-Host ""
Write-Host "12. Проверка правил брандмауэра..." -ForegroundColor Cyan
try {
    $fwRules = Get-NetFirewallRule -Enabled True -Direction Inbound -ErrorAction SilentlyContinue |
        Where-Object { $_.Action -eq "Allow" -and ($_.DisplayName -match "IIS|HTTP|HTTPS|World Wide Web") }
    if ($fwRules) {
        Write-Status "  [OK] Найдено $($fwRules.Count) правил брандмауэра для IIS" $SuccessColor
    } else {
        Write-Status "  [WARN] Правила брандмауэра для IIS не найдены" $WarningColor
    }
} catch {
    Write-Status "  [ERROR] Ошибка проверки брандмауэра: $_" $ErrorColor
}

# 13. Проверка ASP.NET Core Module
Write-Host ""
Write-Host "13. Проверка ASP.NET Core Module..." -ForegroundColor Cyan
$modulePath = "C:\Windows\System32\inetsrv\config\applicationHost.config"
if (Test-Path $modulePath) {
    $config = Get-Content $modulePath -Raw
    if ($config -match "AspNetCoreModuleV2") {
        Write-Status "  [OK] ASP.NET Core Module V2 установлен" $SuccessColor
    } elseif ($config -match "AspNetCoreModule") {
        Write-Status "  [WARN] ASP.NET Core Module V1 установлен (рекомендуется V2)" $WarningColor
    } else {
        Write-Status "  [FAIL] ASP.NET Core Module не найден" $ErrorColor
        Write-Host "  Установите: https://dotnet.microsoft.com/download/dotnet" -ForegroundColor Yellow
    }
}

# 14. Проверка веб-конфигов
Write-Host ""
Write-Host "14. Проверка web.config..." -ForegroundColor Cyan
$webConfigPaths = @(
    "$CriticalityPath\publish-iis\web.config",
    "$ServiceReqClonerPath\publish-iis\web.config"
)

foreach ($webConfig in $webConfigPaths) {
    if (Test-Path $webConfig) {
        $config = Get-Content $webConfig -Raw
        if ($config -match "aspNetCore") {
            $processPath = $config -replace ".*processPath=[`"']([^`"']+)[`"'].*", '$1'
            $arguments = $config -replace ".*arguments=[`"']([^`"']+)[`"'].*", '$1'
            Write-Status "  [OK] $([System.IO.Path]::GetFileName((Split-Path $webConfig -Parent)))" $SuccessColor
            Write-Status "    processPath: $processPath" $InfoColor
        } else {
            Write-Status "  [WARN] $([System.IO.Path]::GetFileName($webConfig)) - нет секции aspNetCore" $WarningColor
        }
    } else {
        Write-Status "  [FAIL] web.config не найден: $webConfig" $ErrorColor
    }
}

# 15. Проверка переменных окружения
Write-Host ""
Write-Host "15. Проверка переменных окружения..." -ForegroundColor Cyan
$envVars = @("ASPNETCORE_ENVIRONMENT", "DOTNET_ENVIRONMENT")
foreach ($envVar in $envVars) {
    $value = [Environment]::GetEnvironmentVariable($envVar, "Machine")
    if ($value) {
        Write-Status "  [OK] $envVar = $value" $SuccessColor
    } else {
        Write-Status "  [INFO] $envVar не установлена (по умолчанию: Production)" $InfoColor
    }
}

# Итоги
Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  Итоги проверки" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan

$logContent = Get-Content $LogPath -Raw
$failCount = ([regex]::Matches($logContent, "\[FAIL\]")).Count
$warnCount = ([regex]::Matches($logContent, "\[WARN\]")).Count
$okCount = ([regex]::Matches($logContent, "\[OK\]")).Count

Write-Host "  OK:     $okCount" -ForegroundColor Green
Write-Host "  WARN:   $warnCount" -ForegroundColor Yellow
Write-Host "  FAIL:   $failCount" -ForegroundColor Red
Write-Host ""
Write-Host "Лог сохранён: $LogPath" -ForegroundColor Cyan
Write-Host ""

if ($failCount -gt 0) {
    Write-Host "  [!] Обнаружены критические ошибки! Устраните перед развёртыванием." -ForegroundColor Red
    exit 1
} elseif ($warnCount -gt 0) {
    Write-Host "  [*] Есть предупреждения. Проверьте лог для деталей." -ForegroundColor Yellow
    exit 0
} else {
    Write-Host "  [✓] Все проверки пройдены. Сервер готов к развёртыванию!" -ForegroundColor Green
    exit 0
}
