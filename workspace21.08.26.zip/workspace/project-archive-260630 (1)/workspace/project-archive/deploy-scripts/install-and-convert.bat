@echo off
chcp 65001 >nul
REM ========================================
REM MD2DOCX Converter — Автоустановка и запуск
REM ========================================

echo.
echo ============================================
echo  MD2DOCX Converter — Установка и конвертация
echo ============================================
echo.

REM Целевая папка
set TARGET_DIR=G:\md2docx\md2docx
REM Исходная папка (откуда копируем)
set SOURCE_DIR=%~dp0

echo [1] Проверка целевой папки...
if not exist "%TARGET_DIR%" (
    echo.
    echo ОШИБКА: Папка не найдена: %TARGET_DIR%
    echo.
    echo Создайте папку или измените путь в этом файле.
    pause
    exit /b 1
)
echo OK: %TARGET_DIR%

echo.
echo [2] Копирование файлов конвертера...

REM Копируем md2docx.py
if exist "%SOURCE_DIR%md2docx.py" (
    copy /Y "%SOURCE_DIR%md2docx.py" "%TARGET_DIR%md2docx.py" >nul
    echo   + md2docx.py
) else (
    echo.
    echo ОШИБКА: Файл не найден: %SOURCE_DIR%md2docx.py
    pause
    exit /b 1
)

REM Копируем Doc1-no-outline.dotx
if exist "%SOURCE_DIR%Doc1-no-outline.dotx" (
    copy /Y "%SOURCE_DIR%Doc1-no-outline.dotx" "%TARGET_DIR%Doc1-no-outline.dotx" >nul
    echo   + Doc1-no-outline.dotx
) else (
    echo.
    echo ОШИБКА: Файл не найден: %SOURCE_DIR%Doc1-no-outline.dotx
    pause
    exit /b 1
)

echo.
echo [3] Проверка Python...
python --version >nul 2>&1
if errorlevel 1 (
    echo.
    echo ОШИБКА: Python не найден в PATH
    echo.
    echo Установите Python или укажите полный путь:
    echo   "C:\Path\To\Python\python.exe" "%TARGET_DIR%\md2docx.py" ...
    pause
    exit /b 1
)
python --version
echo OK

echo.
echo [4] Конвертация ClonerSuite-Documentation.md...
cd /d "%TARGET_DIR%"

if not exist "ClonerSuite-Documentation.md" (
    echo.
    echo ОШИБКА: Файл не найден: %TARGET_DIR%\ClonerSuite-Documentation.md
    echo.
    echo Положите файл ClonerSuite-Documentation.md в папку:
    echo   %TARGET_DIR%
    pause
    exit /b 1
)

python md2docx.py ClonerSuite-Documentation.md -t Doc1-no-outline.dotx -o ClonerSuite-Documentation.docx

if errorlevel 1 (
    echo.
    echo ОШИБКА при конвертации!
    pause
    exit /b 1
)

echo.
echo ============================================
echo  Готово!
echo ============================================
echo.
echo Результат: %TARGET_DIR%\ClonerSuite-Documentation.docx
echo.
echo Для повторной конвертации запустите:
echo   cd %TARGET_DIR%
echo   python md2docx.py ClonerSuite-Documentation.md
echo.
pause
