# HEAT OData API — справочник REST-запросов

ServiceReq, CI и связи между ними. Маппинг полей СУОС → Ivanti SD.

---

## Часть 1 — ServiceReq

### Справочные RecID

| Поле | RecID |
|---|---|
| TemplateRecID | `8EDC5BCA48E0480EA3E9EE3579F35C94` |
| ProfileRecID | `3DE0511365F4462FA8680BB20581BD43` |
| ServiceValid | `61E89C0789824D21A56C72149ABDBE45` |
| SourceValid | `B7065708DF4B449F8503621393B4A7AE` |
| UrgencyValid | `C052472E5ADC45DB94624B6010F24B01` |

### Статусная модель ServiceReq

| Статус | RecID | TRN_Status | Событие СУОС |
|---|---|---|---|
| Draft (Черновик) | `4E4F8733EFEE45328B535D9FDC3CC20A` | Черновик | Создание заявки |
| Открыт | `062E2C58B3FB4E5897232951562F2EA0` | Открыт | Заявка принята |
| В работе РГ | `FED59A3B1E1647A8860FD9B6B0302E38` | В работе | Исполнение |
| Работы завершены | `FA33038158414CAC9598E91AFBFBB914` | Выполнен | VM создана (Fulfilled) |
| Закрыт | `F3F825C732B04500A231EC2EB5A13CC1` | Закрыт | Закрытие |
| Отменено | `A1DEF744921648418504B5D41A42A94B` | Отменено | Отмена |
| На стороне Инициатора | `8A0FD3CB378A4E7F81F93CCCC144388B` | В ожидании | Ожидание клиента |
| Анализ Диспетчером СД | `3BCC23001813491DA5ECA2FE6A03CB76` | В работе | Анализ |
| Анализ Начальником смены СД | `4EFB2D1D7C784E52A20A565F071F620D` | В работе | Анализ |
| Согласование 1 | `6C45586666174C1F93BDCA2C03A072D9` | На согласовании | Согласование |
| Согласование 2 | `DA06217122EC42179F1CA730A24C5E78` | На согласовании | Согласование |
| Согласование 3 | `A6D96FD4F5534DED9EC75A64D2FDC010` | На согласовании | Согласование |
| Не согласовано | `23A661646B2140AB95E9F1C7F04CAA7E` | Закрыт | Отказ |
| На стороне техподдержки | `9E076F3944824F169B41EDC663D16795` | В ожидании | Эскалация |
| Назначен | `AA91F1E45FBC495193303A59F142B1CE` | Назначен | Назначение |
| Submitted (Назначено) | `5EC26C9226544F688B1416B54AD0A5BE` | Назначено | Назначение |
| Возврат | `9C95CD85DCF54867A3C7AC27AB51C45D` | Возврат | Возврат |

### Маппинг полей СУОС → ServiceReq

| Поле СУОС | Поле Ivanti | Тип | Обязательное | Подтверждение |
|---|---|---|---|---|
| Subject | `Subject` | nvarchar | Да | Имя поля верное |
| Description | `Description` или `Symptom` | nvarchar | ? | В схеме есть оба. `Symptom` в ServiceReqCloner. Уточнить целевое |
| Owner | `Owner_Valid` + `Owner` | varchar + nvarchar | Да | Ссылочное поле. Пара: `Owner_Valid`=RecID, `Owner`=имя |

### 1.1 Создание ServiceReq

`POST` `https://svoivantisrv/HEAT/api/odata/businessobject/ServiceReqs`

```json
{
    "Status": "Draft",
    "Status_Valid": "4E4F8733EFEE45328B535D9FDC3CC20A",
    "Subject": "Запрос на ВМ: vm-proj01-prod-app-001",
    "Symptom": "Автоматически создано СУОС при обработке заявки 10231",
    "Service_Valid": "61E89C0789824D21A56C72149ABDBE45",
    "Source_Valid": "B7065708DF4B449F8503621393B4A7AE",
    "Urgency_Valid": "C052472E5ADC45DB94624B6010F24B01",
    "SvcReqTmplLink_Category": "SvcReqTemplate",
    "SvcReqTmplLink_RecID": "8EDC5BCA48E0480EA3E9EE3579F35C94",
    "ProfileLink_Category": "Profile",
    "ProfileLink_RecID": "3DE0511365F4462FA8680BB20581BD43",
    "Owner_Valid": "<RecID_подразделения>",
    "IsVIP": false,
    "IsDraft": true,
    "Cancelable": true,
    "IsNewRecord": true,
    "IsUnRead": true,
    "CreatedBy": "HEATAdmin",
    "LastModBy": "HEATAdmin",
    "CreatedDateTime": "2026-06-25T10:00:00Z",
    "LastModDateTime": "2026-06-25T10:00:00Z",
    "Phone": "+998901234567",
    "Email": "demo@svo.uz",
    "ivnt_CILink_Category": "CI",
    "ivnt_CILink_RecID": "<RecID_CI>"
}
```

Из ответа запомнить `RecId`.

### 1.2 Создание параметра ServiceReq

`POST` `https://svoivantisrv/HEAT/api/odata/businessobject/ServiceReqParams`

```json
{
    "ParentLink_Category": "ServiceReq",
    "ParentLink_RecID": "<RecID_ServiceReq>",
    "ParameterName": "Kommentariy",
    "ParameterValue": "Тестовый комментарий",
    "ParameterDisplayValue": "Тестовый комментарий",
    "DisplayType": "Text",
    "ReadOnly": false,
    "SvcReqTmplParamLink_Category": "SvcReqTmplParam",
    "SvcReqTmplParamLink_RecID": "386025EC4C75486EA57BF30A3D978B88",
    "CreatedBy": "HEATAdmin",
    "LastModBy": "HEATAdmin",
    "CreatedDateTime": "2026-06-25T10:00:00Z",
    "LastModDateTime": "2026-06-25T10:00:00Z"
}
```

`SvcReqTmplParamLink_RecID` — RecID параметра из шаблона:

`GET` `https://svoivantisrv/HEAT/api/odata/businessobject/SvcReqTmplParams?$filter=SvcReqTmplLink_RecID eq '8EDC5BCA48E0480EA3E9EE3579F35C94'`

### 1.3 Обновление статуса — «Работы завершены» (Fulfilled)

`PATCH` `https://svoivantisrv/HEAT/api/odata/businessobject/ServiceReqs('<RecID_ServiceReq>')`

```json
{
    "Status": "Работы завершены",
    "Status_Valid": "FA33038158414CAC9598E91AFBFBB914",
    "Resolution": "VM создана: vm-proj01-prod-app-001",
    "LastModBy": "HEATAdmin",
    "LastModDateTime": "2026-06-25T10:00:00Z"
}
```

TRN_Status этой записи = «Выполнен».

---

## Часть 2 — CI (XER_ServerEquipment / Виртуальная машина)

### Подтипы XER_CIKind

| XER_CIKind_Valid | XER_CIKind |
|---|---|
| `8071645256A54397900EA98D27792E64` | Стандартная ВМ |
| `BE5898C6E94144AAA70885CC5C8F415E` | VDI |
| `F858B3E5CA1A41BF846A7ED05B6C237E` | Хост для контейнеров |
| `2D9B4ABA126044A68785DA4F65A9A3AD` | Специализированная ВМ |

Родительский тип: `CIType_Valid` = `C32D9B0D80BF4EAFBEC0C987C1A1D474`
Подтип актива: `ivnt_AssetSubtype_Valid` = `73BB868A445A4B08BEFFC318A1CD3EB1`

### Статусная модель CI

| Статус | RecID | Допустимые FromStatus |
|---|---|---|
| Создано | `A7039EBB00A04F02A5D1C72222C1FB56` | — |
| В разработке | `5A70A7784A604FA6B8D2CCFC2E8C33A2` | любой |
| Готова к эксплуатации | `34B4FB5B326D4ADCB9D776908579606D` | Эксплуатация, На обслуживании |
| Эксплуатация | `70F21F43F4D545CEA6746B51AD4CB97E` | Готова к эксплуатации, На обслуживании; В разработке |
| В обслуживании | `686747E8667141E2A074BBBD7C8BAD9E` | Неисправна, Эксплуатация |
| Неисправна | `1C019659B0534E57AC1939F509EBFD74` | Эксплуатация |
| Выведена из эксплуатации | `641D296837A34453A92D3B93FF7704CE` | Эксплуатация, Неисправна, В обслуживании |
| Архив | `313F5FB659FE4998B9721F33AF795F2B` | В разработке, Эксплуатация |
| Утилизирована | `1D085734036C47DE9D8726EB8392EAE8` | Выведена из эксплуатации; Архив, Эксплуатация |

Путь: **Создано** → **В разработке** → **Эксплуатация** → **Готова к эксплуатации**

### Маппинг полей СУОС → CI

| Поле СУОС | Поле Ivanti | Тип | Обязательное | Решение |
|---|---|---|---|---|
| Name | `Name` | nvarchar | Да | Подтверждено |
| SerialNumber | `SerialNumber` | nvarchar | Да | Приоритетно для схлопывания с MESM. GUID: `422b4be3-7d2d-d583-a846-5aa4996f5351` |
| Type (VM/VP/K8S) | `XER_CIKind` + `XER_CIKind_Valid` | nvarchar + varchar | Да | Стандартная ВМ, VDI, Хост для контейнеров, Специализированная ВМ |
| CPUCount | `CPUCount` | varchar | Да | Число строкой: `"4"` |
| Memory | `TotalMemory` | decimal | Да | В МБ. 16 ГБ = `"16384.00"` |
| DiskSSD | `XER_HDD` (отдельный POST, раздел 2.2) | — | Да | Тип: SSD, HDD SAS, HDD NL-SAS, VSAN |
| DiskHDD | `XER_HDD` (отдельный POST, раздел 2.2) | — | Да | Аналогично DiskSSD |
| Owner | `Owner_Valid` + `Owner` | varchar + nvarchar | Да | Ссылочное: RecID + имя |
| System | `TRNInformacionnayaSistema_Valid` | varchar | Да | RecID ИС. Пример: `08F5BB133B4B4E8998A3314A9505C8B3` |
| Status | `Status` + `Status_Valid` | nvarchar + varchar | Да | При создании: `"Создано"` + `A7039EBB00A04F02A5D1C72222C1FB56` |
| AllocatedAt | `XER_CommissioningDate` | datetime | Да | Дата ввода в эксплуатацию |
| OwnerCode | Кастомное поле | — | Да | Требуется создать |
| Project | Кастомное поле | — | Да | Требуется создать |
| Contour | Кастомное поле | — | Да | Требуется создать |
| Function | Кастомное поле | — | Да | Требуется создать |
| Licenses | Кастомное поле / таблица | — | Да | Требуется создать |

### 2.1 Создание CI

`POST` `https://svoivantisrv/HEAT/api/odata/businessobject/cis`

```json
{
    "CIType": "XER_ServerEquipment",
    "CIType_Valid": "C32D9B0D80BF4EAFBEC0C987C1A1D474",
    "Name": "vm-proj01-prod-app-001",
    "Status": "Создано",
    "Status_Valid": "A7039EBB00A04F02A5D1C72222C1FB56",
    "SerialNumber": "4221-0E5A-xxxx-xxxx-xxxxxxxxxxxx",
    "VMUUID": "4221-0E5A-xxxx-xxxx-xxxxxxxxxxxx",
    "XER_CIKind": "Стандартная ВМ",
    "XER_CIKind_Valid": "8071645256A54397900EA98D27792E64",
    "ivnt_AssetSubtype": "Виртуальная машина",
    "ivnt_AssetSubtype_Valid": "73BB868A445A4B08BEFFC318A1CD3EB1",
    "ivnt_AssetFullType": "Серверное оборудование - Виртуальная машина",
    "TRNCITypeLocal": "Вычислительная часть",
    "XER_CIType_ru": "Сервер",
    "Manufacturer": "VMware",
    "CPUCount": "4",
    "TotalMemory": "16384.00",
    "CPUName": "Intel Xeon",
    "CPUArchitecture": "intel x86",
    "CPUManufacturer": "Intel",
    "CPUCoreCount": "2",
    "BIOSManufacturer": "VMware",
    "IPAddress": "10.0.0.200",
    "MACAddress": "00:50:56:ab:37:d1",
    "OperatingSystem": "Red Hat Enterprise Linux 7 (64-bit)",
    "Owner_Valid": "F37BF3E87BC04195A74762DE6DA8E5A7",
    "OrgUnitLink_Category": "OrganizationalUnit",
    "OrgUnitLink_RecID": "8FBE0E8B39E14F4AA5B946EFD06E2EA8",
    "ExecutionEnvironment": "Production",
    "ExecutionEnvironment_Valid": "<RecID_контура>",
    "TRNInformacionnayaSistema_Valid": "08F5BB133B4B4E8998A3314A9505C8B3",
    "XER_CommissioningDate": "2026-06-25T10:00:00Z",
    "XER_logicObj": "1",
    "LastChangeDateTime": "2026-06-25T10:00:00Z",
    "CreatedBy": "HEATAdmin",
    "CreatedDateTime": "2026-06-25T10:00:00Z",
    "LastModBy": "HEATAdmin",
    "LastModDateTime": "2026-06-25T10:00:00Z"
}
```

### 2.2 Создание дисков (XER_HDD)

Связь CI → XER_HDD: 1:M через `CIAssocXER_HDDLink`. Одна КЕ — много дисков.

#### Типы дисков

| HDD_Type | HDD_Type_Valid |
|---|---|
| SSD | `8F26264095D34FF08D764740AFD59A8A` |
| HDD | `49934EB702B54E73994BD56D4B6CD85C` |
| HDD SAS | `A84C94CBDE0548188C2D4F57B89A0CAF` |
| HDD NL-SAS | `FF0FBC345A7C492C800B5A2092D3011B` |
| VSAN | `F588D4AAB8524CBDBE9C358459680CEB` |

#### Создание диска

`POST` `https://svoivantisrv/HEAT/api/odata/businessobject/XER_HDD`

```json
{
    "CIAssocXER_HDDLink_Category": "CI",
    "CIAssocXER_HDDLink_RecID": "<RecID_CI>",
    "HDD_Quantity": "1",
    "HDD_Capacity": "100.00",
    "HDD_Type": "SSD",
    "HDD_Type_Valid": "8F26264095D34FF08D764740AFD59A8A",
    "CreatedBy": "HEATAdmin",
    "LastModBy": "HEATAdmin",
    "CreatedDateTime": "2026-06-25T10:00:00Z",
    "LastModDateTime": "2026-06-25T10:00:00Z"
}
```

#### ВМ с двумя дисками: SSD 100 ГБ + HDD 500 ГБ

```json
// Диск 1 — SSD
{
    "CIAssocXER_HDDLink_Category": "CI",
    "CIAssocXER_HDDLink_RecID": "<RecID_CI>",
    "HDD_Quantity": "1",
    "HDD_Capacity": "100.00",
    "HDD_Type": "SSD",
    "HDD_Type_Valid": "8F26264095D34FF08D764740AFD59A8A"
}

// Диск 2 — HDD
{
    "CIAssocXER_HDDLink_Category": "CI",
    "CIAssocXER_HDDLink_RecID": "<RecID_CI>",
    "HDD_Quantity": "1",
    "HDD_Capacity": "500.00",
    "HDD_Type": "HDD",
    "HDD_Type_Valid": "49934EB702B54E73994BD56D4B6CD85C"
}
```

### 2.3 Смена статуса CI

| Статус | RecID |
|---|---|
| В разработке | `5A70A7784A604FA6B8D2CCFC2E8C33A2` |
| Эксплуатация | `70F21F43F4D545CEA6746B51AD4CB97E` |
| Готова к эксплуатации | `34B4FB5B326D4ADCB9D776908579606D` |
| Выведена из эксплуатации | `641D296837A34453A92D3B93FF7704CE` |

`PATCH` `https://svoivantisrv/HEAT/api/odata/businessobject/cis('<RecID_CI>')`

```json
{
    "Status": "Эксплуатация",
    "Status_Valid": "70F21F43F4D545CEA6746B51AD4CB97E",
    "LastModBy": "HEATAdmin",
    "LastModDateTime": "2026-06-25T10:00:00Z"
}
```

При освобождении ВМ (RELEASED/KILLED) — перевод в «Выведена из эксплуатации»:

```json
{
    "Status": "Выведена из эксплуатации",
    "Status_Valid": "641D296837A34453A92D3B93FF7704CE",
    "LastModBy": "HEATAdmin",
    "LastModDateTime": "2026-06-25T10:00:00Z"
}
```

---

## Часть 3 — Связь CI и ServiceReq

Связь M:1 через поле `ivnt_CILink` в ServiceReq. Обратная связь — `ServiceReqAssociatedByCI` (reversed, CI → ServiceReq).

### 3.1 При создании ServiceReq

```json
{
    "ivnt_CILink_Category": "CI",
    "ivnt_CILink_RecID": "<RecID_CI>"
}
```

В теле POST `/odata/businessobject/ServiceReqs`.

### 3.2 Обновление существующего ServiceReq

`PATCH` `https://svoivantisrv/HEAT/api/odata/businessobject/ServiceReqs('<RecID_ServiceReq>')`

```json
{
    "ivnt_CILink_Category": "CI",
    "ivnt_CILink_RecID": "<RecID_CI>",
    "LastModBy": "HEATAdmin",
    "LastModDateTime": "2026-06-25T10:00:00Z"
}
```

### 3.3 Полный цикл: CI + ServiceReq + связь

1. `POST /cis` — создать CI, запомнить `RecID_CI`
2. `POST /ServiceReqs` с `ivnt_CILink_RecID: "<RecID_CI>"` — создать заявку сразу с привязкой
3. `POST /ServiceReqParams` — добавить параметры
4. `PATCH /ServiceReqs` — статус «Работы завершены» (Fulfilled)
5. `PATCH /cis` — статус «Эксплуатация»

---

## Часть 4 — Открытые вопросы (требуют обсуждения)

Все 5 требуют создания новых кастомных полей в cis — существующие не подходят:

| Поле СУОС | Причина |
|---|---|
| **OwnerCode** | Код подразделения. `OrgUnitLink_RecID` — ссылка на оргструктуру, не код |
| **Function** | APP/DB/WEB из нейминга. Парсить из `Name` ненадёжно |
| **Contour** | Prod/PreProd/Dev. `ExecutionEnvironment` занят (Test) |
| **Licenses** | Список лицензий. Нет подходящего поля |
| **Project** | Название проекта. `TRNInformacionnayaSistema` — это ИС, не проект |

---

## Замечания

- Поля с суффиксом `_Valid` всегда в паре: значение + RecID. Без пары HEAT возвращает ошибку валидации
- Статус **Создано** у CI — начальный. PATCH на него не пройдёт, только при создании POST
- Поля критичности (`TRN_KritichnostKE_Valid`, `XER_CSI_Valid`, `TargetAvailability`) заполняются Criticality-сервисом автоматически
- Для участия CI в расчёте критичности он должен быть в графе связей (`cinamedrellinks`)
- `SvcReqTmplParamLink_RecID` обязателен для отображения параметра на вкладке «ПАРАМЕТРЫ» в HEAT UI
- Все запросы: `Authorization: rest_api_key=***`, `Content-Type: application/json; charset=utf-8`
- `CPUCount`/`CPUCoreCount` в cis — varchar/int. Передавать строкой
- `TotalMemory` — decimal, в МБ. 16 ГБ = `"16384.00"`
