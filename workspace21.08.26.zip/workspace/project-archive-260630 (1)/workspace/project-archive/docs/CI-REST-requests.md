# REST-запросы для создания CI в HEAT

Создание CI типа `XER_ServerEquipment` (подтип «Виртуальная машина») через OData API.

## Справочные данные

### Подтипы XER_CIKind

| RecID (XER_CIKind_Valid) | Kind (XER_CIKind) |
|---|---|
| `8071645256A54397900EA98D27792E64` | Стандартная ВМ |
| `BE5898C6E94144AAA70885CC5C8F415E` | VDI |
| `F858B3E5CA1A41BF846A7ED05B6C237E` | Хост для контейнеров |
| `2D9B4ABA126044A68785DA4F65A9A3AD` | Специализированная ВМ |

Родительский тип: `CIType_Valid` = `C32D9B0D80BF4EAFBEC0C987C1A1D474`

Подтип актива: `ivnt_AssetSubtype_Valid` = `73BB868A445A4B08BEFFC318A1CD3EB1` («Виртуальная машина»)

### Статусная модель CI

| Статус | RecID | Допустимые FromStatus |
|---|---|---|
| Создано | `A7039EBB00A04F02A5D1C72222C1FB56` | нет |
| В разработке | `5A70A7784A604FA6B8D2CCFC2E8C33A2` | none, none |
| Готова к эксплуатации | `34B4FB5B326D4ADCB9D776908579606D` | Эксплуатация, На обслуживании |
| Эксплуатация | `70F21F43F4D545CEA6746B51AD4CB97E` | Готова к эксплуатации, На обслуживании; В разработке |
| В обслуживании | `686747E8667141E2A074BBBD7C8BAD9E` | Неисправна, Эксплуатация; none |
| Неисправна | `1C019659B0534E57AC1939F509EBFD74` | Эксплуатация; none |
| Выведена из эксплуатации | `641D296837A34453A92D3B93FF7704CE` | Эксплуатация, Неисправна, В обслуживании; none |
| Архив | `313F5FB659FE4998B9721F33AF795F2B` | none; В разработке, Эксплуатация |
| На согласовании | `DA0353CF73DF469E8FB5E21A777AD8C5` | none, none |
| Утилизирована | `1D085734036C47DE9D8726EB8392EAE8` | Выведена из эксплуатации; Архив, Эксплуатация |
| Передано контрагенту | `3F2421BB1B7F46F0A171D4EAF18BF7AC` | нет |
| Отправить в ремонт | `781CA4482B6941D4BCACD5615070C55E` | нет |
| В ремонте | `B676258384C64FE59F74911D10AAC36D` | нет |
| Списано | `C54FFC1BAB3B48D49FC661117F8C2C3B` | нет |
| Production | `748D72BC93894C5DA9F279A1C10865EA` | нет |
| Archived | `1DEE5806CE0A4263841A07B44B7C904D` | нет |

Путь создания: **Создано** → **В разработке** → **Эксплуатация** → **Готова к эксплуатации**

Поля `XER_FromStatus1` / `XER_FromStatus2` — допустимые исходные статусы для перехода. `none` означает любой статус. Пустое поле — переход запрещён (системный статус).

### Ключевые RecID (из примера ВМ `SVOSAPERQ-01`)

| Поле | Значение |
|---|---|
| `CIType_Valid` | `C32D9B0D80BF4EAFBEC0C987C1A1D474` |
| `Status_Valid` (Создано) | `A7039EBB00A04F02A5D1C72222C1FB56` |
| `XER_CIKind_Valid` (Стандартная ВМ) | `8071645256A54397900EA98D27792E64` |
| `ivnt_AssetSubtype_Valid` | `73BB868A445A4B08BEFFC318A1CD3EB1` |
| `Owner_Valid` | `F37BF3E87BC04195A74762DE6DA8E5A7` |
| `OrgUnitLink_RecID` | `8FBE0E8B39E14F4AA5B946EFD06E2EA8` |
| `ExecutionEnvironment_Valid` | `1616103CC1AE4B47AF8669A19DD70530` |

---

## Запрос 1 — Создание CI

**Метод:** `POST`
**URL:** `https://svoivantisrv/HEAT/api/odata/businessobject/cis`

**Headers:**

```
Content-Type: application/json; charset=utf-8
Authorization: rest_api_key=***
```

**Body (raw JSON):**

```json
{
    "CIType": "XER_ServerEquipment",
    "CIType_Valid": "C32D9B0D80BF4EAFBEC0C987C1A1D474",
    "Name": "VM-TEST-001",
    "Status": "Создано",
    "Status_Valid": "A7039EBB00A04F02A5D1C72222C1FB56",
    "XER_CIKind": "Стандартная ВМ",
    "XER_CIKind_Valid": "8071645256A54397900EA98D27792E64",
    "ivnt_AssetSubtype": "Виртуальная машина",
    "ivnt_AssetSubtype_Valid": "73BB868A445A4B08BEFFC318A1CD3EB1",
    "ivnt_AssetFullType": "Серверное оборудование - Виртуальная машина",
    "TRNCITypeLocal": "Вычислительная часть",
    "XER_CIType_ru": "Сервер",
    "Manufacturer": "VMware",
    "IPAddress": "10.0.0.200",
    "OperatingSystem": "Red Hat Enterprise Linux 7 (64-bit)",
    "CPUArchitecture": "intel x86",
    "CPUManufacturer": "Intel",
    "CPUName": "Intel Xeon",
    "CPUCoreCount": "1",
    "CPUCount": "32",
    "BIOSManufacturer": "VMware",
    "TotalMemory": "200704.00",
    "MACAddress": "00:50:56:ab:37:d1",
    "Owner_Valid": "F37BF3E87BC04195A74762DE6DA8E5A7",
    "OrgUnitLink_Category": "OrganizationalUnit",
    "OrgUnitLink_RecID": "8FBE0E8B39E14F4AA5B946EFD06E2EA8",
    "ExecutionEnvironment": "Test",
    "ExecutionEnvironment_Valid": "1616103CC1AE4B47AF8669A19DD70530",
    "XER_logicObj": "1",
    "LastChangeDateTime": "2026-06-25T10:00:00Z",
    "CreatedBy": "HEATAdmin",
    "CreatedDateTime": "2026-06-25T10:00:00Z",
    "LastModBy": "HEATAdmin",
    "LastModDateTime": "2026-06-25T10:00:00Z"
}
```

Из ответа запомнить **`RecId`**. Для смены подтипа — заменить `XER_CIKind` / `XER_CIKind_Valid` на нужный из таблицы подтипов.

---

## Запрос 2 — Смена статуса на «Готова к эксплуатации»

**Метод:** `PATCH`
**URL:** `https://svoivantisrv/HEAT/api/odata/businessobject/cis('<RecID из запроса 1>')`

**Headers:**

```
Content-Type: application/json; charset=utf-8
Authorization: rest_api_key=***
```

**Body (raw JSON):**

```json
{
    "Status": "Готова к эксплуатации",
    "Status_Valid": "34B4FB5B326D4ADCB9D776908579606D",
    "LastModBy": "HEATAdmin",
    "LastModDateTime": "2026-06-25T10:00:00Z"
}
```

Допустимые исходные статусы: `Эксплуатация`, `На обслуживании`.

---

## Запрос 3 — Смена статуса на «В разработке»

**Метод:** `PATCH`
**URL:** `https://svoivantisrv/HEAT/api/odata/businessobject/cis('<RecID>')`

**Headers:**

```
Content-Type: application/json; charset=utf-8
Authorization: rest_api_key=***
```

**Body (raw JSON):**

```json
{
    "Status": "В разработке",
    "Status_Valid": "5A70A7784A604FA6B8D2CCFC2E8C33A2",
    "LastModBy": "HEATAdmin",
    "LastModDateTime": "2026-06-25T10:00:00Z"
}
```

Переход без ограничений (`XER_FromStatus1` = `none`, `XER_FromStatus2` = `none`).

---

## Запрос 4 — Смена статуса на «Эксплуатация»

**Метод:** `PATCH`
**URL:** `https://svoivantisrv/HEAT/api/odata/businessobject/cis('<RecID>')`

**Headers:**

```
Content-Type: application/json; charset=utf-8
Authorization: rest_api_key=***
```

**Body (raw JSON):**

```json
{
    "Status": "Эксплуатация",
    "Status_Valid": "70F21F43F4D545CEA6746B51AD4CB97E",
    "LastModBy": "HEATAdmin",
    "LastModDateTime": "2026-06-25T10:00:00Z"
}
```

Допустимые исходные статусы: `Готова к эксплуатации`, `На обслуживании` (FromStatus1); `В разработке` (FromStatus2).

---

## Замечания

- Статус **Создано** — начальный. Поля `XER_FromStatus1`/`XER_FromStatus2` пустые — переход разрешён только при создании, PATCH на этот статус не пройдёт
- Поля критичности (`TRN_KritichnostKE_Valid`, `XER_CSI_Valid`, `TargetAvailability`) не включены в запрос — Criticality-сервис заполнит их автоматически при синхронизации
- Для участия в расчёте критичности CI должен быть добавлен в граф связей через `POST /odata/businessobject/cinamedrellinks`
- Поля с суффиксом `_Valid` всегда должны быть парами: само значение + его RecID — иначе HEAT вернёт ошибку валидации
