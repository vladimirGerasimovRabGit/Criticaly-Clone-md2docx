# REST-запросы для создания ServiceReq в HEAT

Два запроса для создания заявки ServiceReq с параметрами через OData API.

## Запрос 1 — Создание ServiceReq

**Метод:** `POST`
**URL:** `https://svoivantisrv/HEAT/api/odata/businessobject/ServiceReqs`

**Headers:**

```
Content-Type: application/json; charset=utf-8
Authorization: rest_api_key=***
```

**Body (raw JSON):**

```json
{
    "Status": "Draft",
    "Subject": "Тестовая заявка (Postman)",
    "Symptom": "Создано через REST",
    "Service_Valid": "61E89C0789824D21A56C72149ABDBE45",
    "Source_Valid": "B7065708DF4B449F8503621393B4A7AE",
    "Urgency_Valid": "C052472E5ADC45DB94624B6010F24B01",
    "SvcReqTmplLink_Category": "SvcReqTemplate",
    "SvcReqTmplLink_RecID": "8EDC5BCA48E0480EA3E9EE3579F35C94",
    "ProfileLink_Category": "Profile",
    "ProfileLink_RecID": "3DE0511365F4462FA8680BB20581BD43",
    "IsVIP": false,
    "IsDraft": true,
    "Cancelable": true,
    "IsNewRecord": true,
    "IsUnRead": true,
    "CreatedBy": "HEATAdmin",
    "LastModBy": "HEATAdmin",
    "CreatedDateTime": "2026-06-24T12:00:00Z",
    "LastModDateTime": "2026-06-24T12:00:00Z",
    "Phone": "+998901234567",
    "Email": "demo@svo.uz"
}
```

Из ответа запомнить **`RecId`**.

---

## Запрос 2 — Создание параметра ServiceReq

**Метод:** `POST`
**URL:** `https://svoivantisrv/HEAT/api/odata/businessobject/ServiceReqParams`

**Headers:**

```
Content-Type: application/json; charset=utf-8
Authorization: rest_api_key=***
```

**Body (raw JSON):**

```json
{
    "ParentLink_Category": "ServiceReq",
    "ParentLink_RecID": "<RecId из запроса 1>",
    "ParameterName": "Kommentariy",
    "ParameterValue": "Тестовый комментарий",
    "ParameterDisplayValue": "Тестовый комментарий",
    "DisplayType": "Text",
    "ReadOnly": false,
    "SvcReqTmplParamLink_Category": "SvcReqTmplParam",
    "SvcReqTmplParamLink_RecID": "386025EC4C75486EA57BF30A3D978B88",
    "CreatedBy": "HEATAdmin",
    "LastModBy": "HEATAdmin",
    "CreatedDateTime": "2026-06-24T12:00:00Z",
    "LastModDateTime": "2026-06-24T12:00:00Z"
}
```

Для каждого параметра нужен свой `SvcReqTmplParamLink_RecID`.

---

## Предварительный запрос — получение RecID параметров шаблона

**Метод:** `GET`
**URL:** `https://svoivantisrv/HEAT/api/odata/businessobject/SvcReqTmplParams?$filter=SvcReqTmplLink_RecID eq '8EDC5BCA48E0480EA3E9EE3579F35C94'`

**Headers:**

```
Authorization: rest_api_key=***
```

Ответ содержит массив параметров, где поле `RecId` — это искомый `SvcReqTmplParamLink_RecID`.

### Пример ответа:

```json
{
    "value": [
        {
            "RecId": "89DF4B78DC654E399D45FE9784D41473",
            "ParameterName": "Mestopologenie",
            "DisplayType": "Valid"
        },
        {
            "RecId": "BE79CD7AD442445C85EE71EC3C987828",
            "ParameterName": "checkbox_1",
            "DisplayType": "Checkbox"
        },
        {
            "RecId": "9E3B94DC036B4C248121D55935627C95",
            "ParameterName": "Registrator",
            "DisplayType": "Valid"
        },
        {
            "RecId": "A3ADAEA8A4784AC7A2464CFD92BDAFEE",
            "ParameterName": "Iniciator",
            "DisplayType": "Valid"
        },
        {
            "RecId": "386025EC4C75486EA57BF30A3D978B88",
            "ParameterName": "Kommentariy",
            "DisplayType": "Text"
        }
    ]
}
```

## Важно

Без `SvcReqTmplParamLink_RecID` параметр **не отобразится** на вкладке «ПАРАМЕТРЫ» в HEAT UI.

---

## Запрос 3 — Обновление статуса на Fulfilled и заполнение решения

**Метод:** `PATCH`
**URL:** `https://svoivantisrv/HEAT/api/odata/businessobject/ServiceReqs('<RecId из запроса 1>')`

**Headers:**

```
Content-Type: application/json; charset=utf-8
Authorization: rest_api_key=***
```

**Body (raw JSON):**

```json
{
    "Status": "Fulfilled",
    "Resolution": "Заявка выполнена. Оборудование настроено и передано пользователю.",
    "LastModBy": "HEATAdmin",
    "LastModDateTime": "2026-06-24T12:00:00Z"
}
```
