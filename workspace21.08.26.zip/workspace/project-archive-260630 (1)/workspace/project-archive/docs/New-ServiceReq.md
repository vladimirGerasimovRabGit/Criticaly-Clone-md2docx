# Создание ServiceReq через HEAT OData API

Полный цикл создания заявки ServiceReq с параметрами: получение шаблонных параметров, создание черновика, добавление параметров с привязкой к шаблону, проверка.

## Параметры

| Параметр | По умолчанию | Описание |
|---|---|---|
| `BaseUrl` | `https://svoivantisrv/HEAT/api` | Базовый URL HEAT OData API |
| `ApiKey` | `***` | Ключ REST API |
| `TemplateRecID` | `8EDC5BCA48E0480EA3E9EE3579F35C94` | RecID шаблона заявки |
| `ProfileRecID` | `3DE0511365F4462FA8680BB20581BD43` | RecID профиля |
| `ServiceValid` | `61E89C0789824D21A56C72149ABDBE45` | Valid сервиса |
| `SourceValid` | `B7065708DF4B449F8503621393B4A7AE` | Valid источника |
| `UrgencyValid` | `C052472E5ADC45DB94624B6010F24B01` | Valid срочности |
| `CreatedBy` | `HEATAdmin` | Имя создателя |
| `SourceServiceReqID` | `""` | RecID заявки-образца для копирования `SvcReqTmplParamLink_RecID` |
| `SkipCertificateCheck` | `$false` | Отключить проверку SSL-сертификата |

## Использование

Базовый запуск (параметры из шаблона):

```powershell
.\New-ServiceReq.ps1
```

Копирование `SvcReqTmplParamLink_RecID` из существующей заявки (параметры будут видны в UI):

```powershell
.\New-ServiceReq.ps1 -SkipCertificateCheck -SourceServiceReqID "9F21AAE0FFB4457FBA6CDAE59D75598E"
```

Кастомный сервер:

```powershell
.\New-ServiceReq.ps1 -BaseUrl "https://iesm-appsrv-prd/HEAT/api" -ApiKey "your-key" -SkipCertificateCheck
```

## Два HTTP-стека

GET-запросы идут через WinHTTP COM (обходит TLS-проблему .NET `Invoke-RestMethod` на некоторых серверах):

```powershell
function Get-ODataJson {
    param([string]$Url, [string]$ApiKey)
    $http = New-Object -ComObject WinHttp.WinHttpRequest.5.1
    $http.Open("GET", $Url, $false)
    $http.SetRequestHeader("Authorization", "rest_api_key=$ApiKey")
    $http.Option(4) = 0x3300  # Игнорировать все ошибки SSL
    $http.Send()
    if ($http.Status -ne 200) {
        throw "HTTP $($http.Status): $($http.StatusText)"
    }
    return $http.ResponseText | ConvertFrom-Json
}
```

POST-запросы — через `Invoke-RestMethod` (.NET), он работает без проблем:

```powershell
[System.Net.ServicePointManager]::SecurityProtocol = `
    [System.Net.SecurityProtocolType]::Tls12 -bor
    [System.Net.SecurityProtocolType]::Tls11 -bor
    [System.Net.SecurityProtocolType]::Tls

$authHeader = @{ Authorization = "rest_api_key=$ApiKey" }
$contentType = "application/json; charset=utf-8"
```

Отключение проверки сертификата:

```powershell
if ($SkipCertificateCheck) {
    [System.Net.ServicePointManager]::ServerCertificateValidationCallback = { $true }
}
```

## Схема выполнения

```mermaid
graph TD
    A["Старт"] --> B{"SourceServiceReqID задан?"}
    B -->|Да| C["GET ServiceReqParams заявки-образца"]
    B -->|Нет| D["GET SvcReqTmplParams шаблона"]
    C --> E["Извлечь SvcReqTmplParamLink_RecID"]
    D --> F["Использовать параметры шаблона"]
    E --> G["POST ServiceReqs — создать заявку"]
    F --> G
    G --> H["POST ServiceReqParams — для каждого параметра"]
    H --> I["GET ServiceReqParams — проверка"]
    I --> J["Вывод итогов"]
```

## Шаг 0 — Получение параметров

**Режим 1: из заявки-образца.** Если передан `SourceServiceReqID`, параметры вместе с `SvcReqTmplParamLink_RecID` копируются из существующей заявки. Именно `SvcReqTmplParamLink_RecID` обеспечивает видимость параметра на вкладке «ПАРАМЕТРЫ» в HEAT UI:

```powershell
if ($SourceServiceReqID) {
    $usedSourceReq = $true
    $encodedId = [uri]::EscapeDataString($SourceServiceReqID)
    $srcUrl = "$baseUrlTrimmed/odata/businessobject/ServiceReqParams?`$filter=ParentLink_RecID%20eq%20'$encodedId'"
    $srcData = Get-ODataJson -Url $srcUrl -ApiKey $ApiKey
    $srcParams = @($srcData.Value)

    foreach ($sp in $srcParams) {
        $tp = [PSCustomObject]@{
            ParameterName               = $sp.ParameterName
            RecId                       = $sp.SvcReqTmplParamLink_RecID
            DisplayType                 = $sp.DisplayType
            SvcReqTmplParamLink_Category = $sp.SvcReqTmplParamLink_Category
            SvcReqTmplParamLink_RecID   = $sp.SvcReqTmplParamLink_RecID
            DefaultValue                = $sp.DefaultValue
        }
        $tmplParams += $tp
    }
}
```

**Режим 2: из шаблона.** Без `SourceServiceReqID` параметры берутся напрямую из шаблона:

```powershell
if (-not $SourceServiceReqID) {
    $encodedId = [uri]::EscapeDataString($TemplateRecID)
    $tmplParamsUrl = "$baseUrlTrimmed/odata/businessobject/SvcReqTmplParams?`$filter=SvcReqTmplLink_RecID%20eq%20'$encodedId'"
    $tmplData = Get-ODataJson -Url $tmplParamsUrl -ApiKey $ApiKey
    $tmplParams = @($tmplData.Value)
}
```

## Шаг 1 — Создание заявки

Черновик ServiceReq (`Status = "Draft"`) через POST в OData:

```powershell
$body = @{
    Status                   = "Draft"
    Subject                  = "Тестовая заявка (PowerShell)"
    Symptom                  = "Заявка создана через PowerShell"
    Service_Valid            = $ServiceValid
    Source_Valid             = $SourceValid
    Urgency_Valid            = $UrgencyValid
    SvcReqTmplLink_Category  = "SvcReqTemplate"
    SvcReqTmplLink_RecID     = $TemplateRecID
    ProfileLink_Category     = "Profile"
    ProfileLink_RecID        = $ProfileRecID
    IsVIP                    = $false
    IsDraft                  = $true
    Cancelable               = $true
    IsNewRecord              = $true
    IsUnRead                 = $true
    CreatedBy                = $CreatedBy
    LastModBy                = $CreatedBy
    CreatedDateTime          = (Get-Date -Format "yyyy-MM-ddTHH:mm:ssZ")
    LastModDateTime          = (Get-Date -Format "yyyy-MM-ddTHH:mm:ssZ")
    Phone                    = "+998901234567"
    Email                    = "demo@svo.uz"
}

$json = $body | ConvertTo-Json -Depth 5 -Compress

$response = Invoke-RestMethod `
    -Uri "$baseUrlTrimmed/odata/businessobject/ServiceReqs" `
    -Method Post `
    -Headers $authHeader `
    -Body $json `
    -ContentType $contentType

$newRecId = $response.RecId
$newNumber = $response.ServiceReqNumber
```

При ошибке — читается тело ответа для диагностики:

```powershell
catch {
    if ($_.Exception.Response) {
        $reader = New-Object System.IO.StreamReader($_.Exception.Response.GetResponseStream())
        $errorBody = $reader.ReadToEnd()
        $reader.Close()
        Write-Host $errorBody
    }
}
```

## Шаг 2 — Создание параметров

Значение подбирается по `DisplayType`: для `Checkbox`/`Boolean` — `"true"`, для остальных — `"Test <ParameterName>"`.

```powershell
foreach ($tp in $tmplParams) {
    if ($tp.SvcReqTmplParamLink_RecID) {
        $val = if ($tp.DisplayType -match 'Checkbox|Boolean') {
            "true"
        } else {
            "Test $($tp.ParameterName)"
        }
        $parameters += @{
            ParentLink_Category           = "ServiceReq"
            ParentLink_RecID              = $newRecId
            ParameterName                 = $tp.ParameterName
            ParameterValue                = $val
            ParameterDisplayValue         = $val
            DisplayType                   = $tp.DisplayType
            ReadOnly                      = $false
            SvcReqTmplParamLink_Category  = $tp.SvcReqTmplParamLink_Category
            SvcReqTmplParamLink_RecID     = $tp.SvcReqTmplParamLink_RecID
            CreatedBy                     = $CreatedBy
            LastModBy                     = $CreatedBy
            CreatedDateTime               = (Get-Date -Format "yyyy-MM-ddTHH:mm:ssZ")
            LastModDateTime               = (Get-Date -Format "yyyy-MM-ddTHH:mm:ssZ")
        }
    }
}
```

Параметры без `SvcReqTmplParamLink_RecID` (как `Vlozheniya` в заявке-образце) пропускаются — без этой привязки параметр не отобразится в UI.

Каждый параметр отправляется отдельным POST:

```powershell
foreach ($param in $parameters) {
    $paramJson = $param | ConvertTo-Json -Depth 3 -Compress
    Invoke-RestMethod `
        -Uri "$baseUrlTrimmed/odata/businessobject/ServiceReqParams" `
        -Method Post `
        -Headers $authHeader `
        -Body $paramJson `
        -ContentType $contentType
}
```

Если шаблон не вернул параметры — создаётся fallback-параметр без привязки:

```powershell
$parameters = @(
    @{
        ParentLink_Category = "ServiceReq"
        ParentLink_RecID    = $newRecId
        ParameterName       = "Description"
        ParameterValue      = "Тестовый параметр"
        ReadOnly            = $false
        CreatedBy           = $CreatedBy
        LastModBy           = $CreatedBy
        CreatedDateTime     = (Get-Date -Format "yyyy-MM-ddTHH:mm:ssZ")
        LastModDateTime     = (Get-Date -Format "yyyy-MM-ddTHH:mm:ssZ")
    }
)
```

## Шаг 3 — Проверка

GET созданных параметров для подтверждения корректности:

```powershell
$encodedNewId = [uri]::EscapeDataString($newRecId)
$checkUrl = "$baseUrlTrimmed/odata/businessobject/ServiceReqParams?`$filter=ParentLink_RecID%20eq%20'$encodedNewId'"
$checkData = Get-ODataJson -Url $checkUrl -ApiKey $ApiKey
$checkParams = @($checkData.Value)

foreach ($p in $checkParams) {
    Write-Host "  - $($p.ParameterName): $($p.ParameterValue)"
    Write-Host "    SvcReqTmplParamLink_RecID: $($p.SvcReqTmplParamLink_RecID)"
}
```

Первый параметр выводится полным JSON для отладки:

```powershell
$checkParams[0] | ConvertTo-Json -Depth 5
```

## Итог и ссылка на HEAT UI

```powershell
$heatUi = $BaseUrl -replace '/api$', ''
$encodedRecId = [System.Web.HttpUtility]::UrlEncode($newRecId)
Write-Host "$heatUi/Login.aspx?Scope=ObjectWorkspace&CommandId=Search&ObjectType=ServiceReq%23&CommandData=RecId%2c%3d%2c0%2c$encodedRecId%2cstring%2cAND%7C"
```

## Требования

- PowerShell 5.1+
- Доступ к HEAT OData API
- COM-объект `WinHttp.WinHttpRequest.5.1` (встроен во все Windows)
