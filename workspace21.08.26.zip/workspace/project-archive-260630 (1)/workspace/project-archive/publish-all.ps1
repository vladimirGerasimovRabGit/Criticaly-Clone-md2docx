<#
.SYNOPSIS
    Publishes both ServiceReqCloner and Criticality as self-contained packages.
.DESCRIPTION
    Runs publish.ps1 in each project directory. The output includes the
    .NET 8 runtime and all dependencies - no internet connection required.
.PARAMETER Runtime
    Target runtime identifier. Default: linux-x64
.PARAMETER Configuration
    Build configuration. Default: Release
.EXAMPLE
    .\publish-all.ps1
.EXAMPLE
    .\publish-all.ps1 -Runtime win-x64
#>
[CmdletBinding()]
param(
    [string]$Runtime = "linux-x64",
    [string]$Configuration = "Release"
)

$ErrorActionPreference = "Stop"
$scriptRoot = $PSScriptRoot

Write-Host ""
Write-Host "=======================================================" -ForegroundColor Cyan
Write-Host " ClonerSuite - Publish All Services" -ForegroundColor Cyan
Write-Host "=======================================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "Runtime:       $Runtime" -ForegroundColor Yellow
Write-Host "Configuration: $Configuration" -ForegroundColor Yellow
Write-Host ""

# Publish ServiceReqCloner
Write-Host ">>> Publishing ServiceReqCloner..." -ForegroundColor Magenta
Push-Location "$scriptRoot\ServiceReqCloner"
& "$scriptRoot\ServiceReqCloner\publish.ps1" -Runtime $Runtime -Configuration $Configuration
Pop-Location

Write-Host ""

# Publish Criticality
Write-Host ">>> Publishing Criticality..." -ForegroundColor Magenta
Push-Location "$scriptRoot\Criticality"
& "$scriptRoot\Criticality\publish.ps1" -Runtime $Runtime -Configuration $Configuration
Pop-Location

Write-Host ""
Write-Host "=======================================================" -ForegroundColor Green
Write-Host " All services published!" -ForegroundColor Green
Write-Host "=======================================================" -ForegroundColor Green
Write-Host ""
Write-Host "To run ServiceReqCloner:" -ForegroundColor Cyan
Write-Host "  cd ServiceReqCloner; .\run-server.ps1" -ForegroundColor White
Write-Host "To run Criticality:" -ForegroundColor Cyan
Write-Host "  cd Criticality; .\run-server.ps1" -ForegroundColor White
Write-Host ""
