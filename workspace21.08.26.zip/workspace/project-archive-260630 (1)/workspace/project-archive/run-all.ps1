<#
.SYNOPSIS
    Runs both ServiceReqCloner and Criticality services.
.DESCRIPTION
    Starts both services in the background. The ServiceReqCloner API runs
    on port 7101 and the Criticality Sync Service on port 7102.
.PARAMETER Environment
    ASP.NET Core environment. Default: Development
.EXAMPLE
    .\run-all.ps1
.EXAMPLE
    .\run-all.ps1 -Environment Production
#>
[CmdletBinding()]
param(
    [string]$Environment = "Development"
)

$ErrorActionPreference = "Stop"
$scriptRoot = $PSScriptRoot

Write-Host ""
Write-Host "=======================================================" -ForegroundColor Cyan
Write-Host " ClonerSuite - Start All Services" -ForegroundColor Cyan
Write-Host "=======================================================" -ForegroundColor Cyan
Write-Host "Environment: $Environment" -ForegroundColor Yellow
Write-Host ""

# Start ServiceReqCloner in background
Write-Host "[1/2] Starting ServiceReqCloner on port 7101..." -ForegroundColor Gray
Push-Location "$scriptRoot\ServiceReqCloner"
$srcJob = Start-Process -FilePath "powershell" -ArgumentList "-NoProfile", "-File", "$scriptRoot\ServiceReqCloner\run-server.ps1", "-Environment", $Environment -PassThru
Pop-Location

# Start Criticality in background
Write-Host "[2/2] Starting Criticality on port 7102..." -ForegroundColor Gray
Push-Location "$scriptRoot\Criticality"
$critJob = Start-Process -FilePath "powershell" -ArgumentList "-NoProfile", "-File", "$scriptRoot\Criticality\run-server.ps1", "-Environment", $Environment -PassThru
Pop-Location

Write-Host ""
Write-Host "=======================================================" -ForegroundColor Green
Write-Host " Services starting..." -ForegroundColor Green
Write-Host "=======================================================" -ForegroundColor Green
Write-Host ""
Write-Host "ServiceReqCloner  PID: $($srcJob.Id)  Port: 7101" -ForegroundColor Yellow
Write-Host "Criticality       PID: $($critJob.Id)  Port: 7102" -ForegroundColor Yellow
Write-Host ""
Write-Host "Endpoints:" -ForegroundColor Cyan
Write-Host "  ServiceReqClone: http://localhost:7101/api/ServiceReqClone/clone-with-view?id=ID"
Write-Host "  IncidentClone:   http://localhost:7101/api/IncidentClone/clone-with-view?id=ID"
Write-Host "  Criticality:     http://localhost:7102/api/CriticalitySync/status"
Write-Host ""
Write-Host "To stop:  Stop-Process -Id $($srcJob.Id), $($critJob.Id)" -ForegroundColor Gray
Write-Host ""

# Wait for both processes
Wait-Process -Id $srcJob.Id, $critJob.Id -ErrorAction SilentlyContinue
