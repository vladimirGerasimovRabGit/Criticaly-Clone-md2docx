# HEAT API Integration Project — Полный архив

## Назначение

Интеграция Ivanti Service Desk (HEAT) с внешними системами:
- Создание заявок ServiceReq через REST API
- Импорт конфигурационных единиц (CI) из RVTools/vCenter
- Маппинг полей СУОС → Ivanti SD
- Маппинг полей RVTools → SQB (чистая коробка)

## Состав проекта

### Документация

| Файл | Описание |
|---|---|
| `docs/HEAT-API-Reference.md` | Единый справочник REST-запросов: ServiceReq, CI, связь, маппинг |
| `docs/HEAT-API-Reference.docx` | DOCX-версия справочника |
| `docs/ServiceReq-REST-requests.md` | Запросы ServiceReq |
| `docs/CI-REST-requests.md` | Запросы CI (XER_ServerEquipment) |
| `docs/New-ServiceReq.md` | Документация скрипта создания заявок |

### Скрипты

| Файл | Описание |
|---|---|
| `scripts/New-ServiceReq.ps1` | Создание ServiceReq с параметрами (WinHTTP COM + Invoke-RestMethod) |
| `scripts/Get-ServiceReqParams.ps1` | Получение параметров заявки через WinHTTP COM |

### Конвертер MD→DOCX

| Файл | Описание |
|---|---|
| `md2docx/md2docx.py` | Конвертер Markdown → DOCX |
| `md2docx/DocTemplate-1.dotx` | Шаблон для конвертации |
| `md2docx/MD2DOCX-README.md` | Инструкция по конвертеру |

### Справочные данные

| Файл | Описание |
|---|---|
| `field-lists/ci-fields-project1.txt` | 704 поля cis (проект с кастомными полями TRN_, XER_) |
| `field-lists/ci-fields-sqb.txt` | 504 поля cis SQB (чистая коробка, без кастомных) |
| `field-lists/branch-structure.xlsx` | 89 подразделений: коды ЦБУ, локальной структуры, иерархия |

### RVTools — инвентаризация VMware

| Файл | Описание |
|---|---|
| `rvtools-data/*.xlsx` | 4 экспорта RVTools с 4 vCenter (всего 934 ВМ) |
| `rvtools-data/analysis.md` | Результаты анализа RVTools-данных |

---

## Окружение

### Тестовая среда
- .NET 8, IIS
- HTTP: порт 7104
- HTTPS: порт 7105

### Продуктив
- `https://svoivantisrv/HEAT/api`
- OData API: `https://svoivantisrv/HEAT/api/odata/businessobject/...`

### PowerShell
- Версия: 5.1+
- GET-запросы: `WinHttp.WinHttpRequest.5.1` COM (обходит TLS-баг .NET)
- POST-запросы: `Invoke-RestMethod`

---

## Ключевые технические решения

### 1. WinHTTP COM для GET-запросов

```powershell
$http = New-Object -ComObject WinHttp.WinHttpRequest.5.1
$http.Option(4) = 0x3300  # SSL/TLS flags
$http.Open("GET", $url, $false)
$http.Send()
```

Причина: `Invoke-RestMethod`, `HttpClient`, `curl.exe` не работают из-за TLS-проблем на сервере.

### 2. ServiceReq — создание заявки

- `SourceServiceReqID` копирует `SvcReqTmplParamLink_RecID` из заявки-образца — это ключ к видимости параметров в UI
- Значения параметров по DisplayType: checkbox → "true", остальные → "Test <ParameterName>"

### 3. Статусная модель ServiceReq (17 статусов)

Путь: Logged → Active → Resolved → Closed. Дополнительные: AwaitingInfo, PendingChange и др. Статус «Fulfilled» в HEAT = `"Работы завершены"`, не `"Fulfilled"`.

### 4. CI — XER_ServerEquipment / Виртуальная машина

- Подтипы (`XER_CIKind`): Стандартная ВМ, VDI, Хост для контейнеров, Спец. ВМ
- Статус при создании: `"Создано"` (`A7039EBB00A04F02A5D1C72222C1FB56`)
- Диски: отдельная сущность `XER_HDD` через `CIAssocXER_HDDLink`
- Связь CI↔ServiceReq: `ivnt_CILink` (M:1)

### 5. Поле решения

`Resolution` (не `Resolved_Symptom`) для поля решения заявки.

---

## Маппинг СУОС → CI (проект 1, с кастомными полями)

16 полей, из них 5 требуют создания кастомных: OwnerCode, Function, Contour, Project, Licenses

### Подтверждённые поля

| СУОС | Ivanti | Тип |
|---|---|---|
| Name | `Name` | nvarchar |
| SerialNumber | `SerialNumber` | nvarchar |
| Type | `XER_CIKind` | nvarchar |
| CPUCount | `CPUCount` | varchar |
| Memory | `TotalMemory` | decimal |
| DiskSSD/HDD | `XER_HDD` (отдельный POST) | — |
| Owner | `Owner_Valid` + `Owner` | varchar + nvarchar |
| System | `TRNInformacionnayaSistema_Valid` | varchar |
| Status | `Status` + `Status_Valid` | nvarchar + varchar |
| AllocatedAt | `XER_CommissioningDate` | datetime |
| OwnerCode | Кастомное — требуется создать | — |
| Function | Кастомное — требуется создать | — |
| Contour | Кастомное — требуется создать | — |
| Project | Кастомное — требуется создать | — |
| Licenses | Кастомное — требуется создать | — |

---

## Маппинг RVTools → SQB (чистая коробка)

Проект SQB: 504 стандартных поля (без TRN_, XER_, SVO_, SWO_, IPCM_). Сопоставлено 23 поля:

| # | RVTools | HEAT (SQB) | Тип |
|---|---|---|---|
| 1 | VM (vInfo) | `Name` | nvarchar |
| 2 | VM UUID (vInfo) | `VMUUID` | varchar |
| 3 | Primary IP (vInfo) | `IPAddress` | nvarchar |
| 4 | DNS Name (vInfo) | `FullyQualifiedDomainName` | nvarchar |
| 5 | OS (vInfo) | `OperatingSystem` | nvarchar |
| 6 | CPUs (vInfo) | `CPUCount` | varchar |
| 7 | Sockets×Cores (vCPU) | `CPUCoreCount` | varchar |
| 8 | Memory MiB (vInfo) | `TotalMemory` | decimal |
| 9 | Host ESXi (vInfo) | `PhysicalHostName` | nvarchar |
| 10 | Datacenter (vInfo) | `PhysicalLocation` | varchar |
| 11 | Cluster (vInfo) | `PhysicalName` | nvarchar |
| 12 | Creation date (vInfo) | `CreatedDateTime` | datetime |
| 13 | HW version (vInfo) | `AppVersion` | varchar |
| 14 | Total disk MiB (vInfo) | `TotalDiskSpace` | varchar |
| 15 | Free disk (vPartition) | `FreeDiskSpace` | varchar |
| 16 | Free % (vPartition) | `PercentFreeDiskspace` | decimal |
| 17 | MAC Address (vNetwork) | `MACAddress` | nvarchar |
| 18 | VLAN (vNetwork) | `Subnet` | varchar |
| 19 | Annotation (vInfo) | `Description` | nvarchar |
| 20 | Manufacturer | `Manufacturer` | nvarchar |
| 21 | Tools Version (vTools) | `AgentVersion` | varchar |
| 22 | Tools Status (vTools) | `ComplianceState` | varchar |
| 23 | Discovery Method | `DiscoveryMethod` | varchar |

### Не имеют аналога в коробке (16 полей)

Powerstate, In Use MiB, Thin provisioning, Disk UUID, Disk Mode, Controller, Sockets (отдельно), Hot Add/Remove, Reservation/Limit, VLAN name, Adapter type, Snapshots (количество+размер), Tools upgradeable, Connected status.

---

## Анализ RVTools (4 файла, 934 ВМ)

### Сводка

| vCenter | ВМ | Хосты | Оборудование |
|---|---|---|---|
| 192.168.168.30 | 481 | 12 | VxRail VE-660 |
| 192.168.171.110 | 45 | 1 | H3C R4900 G6 |
| 192.168.172.197 | 397 | 9 | Lenovo ThinkSystem |
| 192.168.172.216 | 11 | 1 | Dell PowerEdge R6625 |

### Статистика

- Включено: 648 (69%), Выключено: 285 (31%), Suspended: 1
- ОС: Ubuntu 292, Oracle Linux 261, Windows 112, CentOS 55, прочие
- Без VMware Tools: 124 (13%)
- Аннотация заполнена: 65%
- Снапшоты: 171 ВМ, 44.8 TiB
- Диски thin: 96%
- 5 Datacenter'ов, 1 кластер, 23 ESXi хоста

### Ключевые проблемы

1. **285 выключенных ВМ (31%)** — кандидаты на утилизацию
2. **124 ВМ без VMware Tools** — нет данных об OS
3. **44.8 TiB снапшотов** — 171 ВМ, риск переполнения datastore
4. **244 Zombie VMDK** — осиротевшие файлы на СХД
5. **62 ВМ видны с двух vCenter** — нужна дедупликация по VM UUID
6. **1 ВМ suspended** — утечка ресурсов
7. **69 ВМ с устаревшими VMware Tools**
8. **20 ВМ с /boot < 10% свободно**

### Привязка к филиалам

Справочник содержит 89 подразделений (14 региональных центров, 67 ЦБУ-филиалов), но в RVTools **нет никакой корреляции** с филиалами. Все ВМ централизованы в 3-4 ЦОДах. Для привязки нужен внешний источник: MESM или реестр «VM → Код ЦБУ».

### Дедупликация

VM UUID заполнен у всех 934 ВМ. 872 уникальных, 62 дубликата (одна ВМ видна с двух vCenter). SMBIOS UUID: 828 уникальных. SerialNumber: столбец отсутствует в RVTools.

### Health checks (545 проблем)

| Тип | Кол-во |
|---|---|
| Zombie VMDK | 244 |
| Active snapshots | 175 |
| VMware Tools issues | 69 |
| Low disk /boot | 20 |
| Inconsistent folder | 16 |
| Performance tips | 9 |
| USB devices (HASP keys) | 4 |
| CPU overcommit | 4 |
| SSH enabled | 1 |
| NTPD issues | 2 |

---

## vCenter — окружение

| vCenter | IP | Тип | Datacenter |
|---|---|---|---|
| VxRail | 192.168.168.30 | VMware vCenter 8.0.3 | VxRail-Datacenter |
| Security | 192.168.171.110 | VMware vCenter | AT-Datacenter |
| Main/Reserve | 192.168.172.197 | VMware vCenter | Main, Reserve |
| Standalone | 192.168.172.216 | VMware ESXi | ha-datacenter |

### Хосты VxRail (.30)
12 узлов Dell VxRail VE-660, Intel Xeon Platinum 8462Y+, ESXi 8.0.3, vSAN. Кластер: VxRail-Virtual-SAN. Сертификаты до 2030-2031.

---

## PowerShell — WinHTTP COM

### Шаблон GET-запроса

```powershell
$http = New-Object -ComObject WinHttp.WinHttpRequest.5.1
$http.Option(4) = 0x3300
$http.SetTimeouts(30000, 30000, 30000, 30000)
$http.Open("GET", $url, $false)
$http.SetRequestHeader("Authorization", "restAuthKey $apiKey")
$http.SetRequestHeader("Accept", "application/json")
$http.Send()
$response = $http.ResponseText | ConvertFrom-Json
```

### Шаблон POST-запроса (Invoke-RestMethod)

```powershell
$body = @{ ... } | ConvertTo-Json
Invoke-RestMethod -Uri $url -Method Post `
  -Headers @{ "restAuthKey" = $apiKey } `
  -ContentType "application/json" -Body $body
```

---

## API — ключевые endpoint'ы

```
GET  /HEAT/api/odata/businessobject/cis
POST /HEAT/api/odata/businessobject/cis
GET  /HEAT/api/odata/businessobject/ServiceReq
POST /HEAT/api/odata/businessobject/ServiceReq
GET  /HEAT/api/odata/businessobject/ServiceReq(RecId='...')/SvcReqTmplParamLink
POST /HEAT/api/odata/businessobject/XER_HDD
POST /HEAT/api/odata/businessobject/ivnt_CILink
```

---

## Открытые вопросы

1. SQB: 16 полей без коробочного аналога — нужны кастомные или пропустить?
2. SQB: привязка ВМ к филиалам — внешний источник (MESM?)
3. Проект 1: 5 кастомных полей для CI не созданы
4. Проект 1: RecID urgency `C052472E5ADC45DB94624B6010F24B01` не идентифицирован
5. Автоматизация периодического сбора RVTools и синхронизации с CMDB
