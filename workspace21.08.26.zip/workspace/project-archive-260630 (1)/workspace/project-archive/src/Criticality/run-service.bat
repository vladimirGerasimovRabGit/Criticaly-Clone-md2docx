@echo off
REM Run Criticality service (CMD version - no PowerShell execution policy issues)
echo ============================================
echo  Criticality API - Starting
echo ============================================
echo.

cd /d "%~dp0"

echo Building...
dotnet build --configuration Release --verbosity quiet
if errorlevel 1 (
    echo Build failed!
    pause
    exit /b 1
)

echo.
echo Starting on port 7102...
echo.

dotnet run --configuration Release --no-build

pause
