@echo off
REM Build all projects (CMD version - no PowerShell execution policy issues)
echo ============================================
echo  ClonerSuite - Build All Projects
echo ============================================
echo.

cd /d "%~dp0"

echo [1/3] Building ServiceReqCloner...
cd ServiceReqCloner
dotnet build --configuration Release --verbosity quiet
if errorlevel 1 (
    echo ERROR: Build failed!
    pause
    exit /b 1
)
cd ..
echo.

echo [2/3] Building Criticality...
cd Criticality
dotnet build --configuration Release --verbosity quiet
if errorlevel 1 (
    echo ERROR: Build failed!
    pause
    exit /b 1
)
cd ..
echo.

echo [3/3] Building ApiKeyEncryptor...
cd tools\ApiKeyEncryptor
dotnet build --configuration Release --verbosity quiet
if errorlevel 1 (
    echo ERROR: Build failed!
    pause
    exit /b 1
)
cd ..\..
echo.

echo ============================================
echo  Build complete!
echo ============================================
echo.
echo Run services:
echo   cd Criticality ^&^& dotnet run --configuration Release
echo   cd ServiceReqCloner ^&^& dotnet run --configuration Release
echo.
pause
