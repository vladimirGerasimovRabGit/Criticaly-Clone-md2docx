#!/bin/bash
# Build ApiKeyEncryptor as self-contained single-file tool

cd "$(dirname "$0")"

echo "Building ApiKeyEncryptor..."
dotnet publish -c Release -r linux-x64 --self-contained true -p:PublishSingleFile=true -o ./publish

echo ""
echo "Binary location: ./publish/ApiKeyEncryptor"
echo ""
echo "Usage:"
echo "  ./publish/ApiKeyEncryptor <plain-key> <password> [base64|hex]"
echo ""
