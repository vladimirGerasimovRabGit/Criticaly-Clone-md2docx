# API Key Encryption Tool

Утилита для шифрования API ключей Heat API для безопасного хранения в `appsettings.json`.

## Использование

### Через PowerShell (если доступен)

```powershell
# ServiceReqCloner
.\ServiceReqCloner\encrypt-apikey.ps1 -PlainKey "your-api-key" -Password "MySecretKey2024!Secure"

# Criticality
.\Criticality\encrypt-apikey.ps1 -PlainKey "your-api-key" -Password "MySecretKey2024!Secure"
```

### Через C# утилиту (кроссплатформенно)

```bash
# Скомпилировать
./tools/ApiKeyEncryptor/build.sh

# Использовать
./tools/ApiKeyEncryptor/publish/ApiKeyEncryptor "your-api-key" "MySecretKey2024!Secure"
```

### Прямой запуск (требуется .NET SDK)

```bash
dotnet run --project tools/ApiKeyEncryptor/ApiKeyEncryptor.csproj -- "your-api-key" "MySecretKey2024!Secure"
```

## Пример вывода

```
=============================================
Encrypted Key:
=============================================

cvxjo0X+YdR0K4VGkdMpQrGACBKlObevEyNDTm95+mpFphXu+bUOcUcVvvYjRu8V

=============================================
Usage in appsettings.json:
=============================================

"EncryptedApiKey": "cvxjo0X+YdR0K4VGkdMpQrGACBKlObevEyNDTm95+mpFphXu+bUOcUcVvvYjRu8V",
"EncryptionKey": "MySecretKey2024!Secure"

IMPORTANT:
  - Store EncryptionKey securely (environment variable, secret manager)
  - Do NOT commit EncryptionKey to source control
  - EncryptedApiKey CAN be committed (it's encrypted)
```

## Безопасность

| Можно коммитить в git | НЕЛЬЗЯ коммитить в git |
|----------------------|------------------------|
| `EncryptedApiKey`    | `EncryptionKey`        |
| `appsettings.json`   | Пароли от баз данных   |
| `appsettings.Production.json` (без ключей) | API ключи в открытом виде |

### Рекомендации

1. **Храните `EncryptionKey` в переменных окружения:**
   ```bash
   export HEAT_ENCRYPTION_KEY="MySecretKey2024!Secure"
   ```

2. **Используйте secret manager в development:**
   ```bash
   dotnet user-secrets set "HeatApi:EncryptionKey" "MySecretKey2024!Secure"
   ```

3. **В production используйте:**
   - Azure Key Vault
   - AWS Secrets Manager
   - HashiCorp Vault
   - Kubernetes Secrets

## Алгоритм шифрования

- **AES-256** в режиме CBC
- **Ключ:** SHA-256 хеш от пароля (32 байта)
- **IV:** Случайный (16 байт), сохраняется вместе с зашифрованными данными
- **Формат вывода:** Base64 (IV + encrypted_data)
