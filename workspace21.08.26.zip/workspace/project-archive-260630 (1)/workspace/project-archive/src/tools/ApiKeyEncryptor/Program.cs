using System;
using System.Security.Cryptography;
using System.Text;

namespace ApiKeyEncryptor;

class Program
{
    static void Main(string[] args)
    {
        if (args.Length < 2)
        {
            Console.WriteLine("Usage: ApiKeyEncryptor <plain-key> <password> [base64|hex]");
            Console.WriteLine("Example: ApiKeyEncryptor \"my-secret-key\" \"MySecretKey2024!Secure\" base64");
            Environment.Exit(1);
        }

        string plainKey = args[0];
        string password = args[1];
        string outputFormat = args.Length > 2 ? args[2].ToLower() : "base64";

        if (string.IsNullOrWhiteSpace(plainKey))
        {
            Console.WriteLine("ERROR: PlainKey cannot be empty");
            Environment.Exit(1);
        }

        if (string.IsNullOrWhiteSpace(password))
        {
            Console.WriteLine("ERROR: Password cannot be empty");
            Environment.Exit(1);
        }

        if (password.Length < 16)
        {
            Console.WriteLine("WARNING: Password is short (less than 16 characters). Consider using a stronger password.");
        }

        try
        {
            using var aes = Aes.Create();
            aes.KeySize = 256;
            aes.BlockSize = 128;
            aes.Mode = CipherMode.CBC;
            aes.Padding = PaddingMode.PKCS7;

            // 1. Generate Salt (16 bytes)
            var salt = RandomNumberGenerator.GetBytes(16);

            // 2. Derive Key using PBKDF2 (matches EncryptionService)
            using var deriveBytes = new Rfc2898DeriveBytes(password, salt, 10000, HashAlgorithmName.SHA256);
            aes.Key = deriveBytes.GetBytes(32);

            // 3. Generate IV (16 bytes)
            aes.GenerateIV();
            byte[] ivBytes = aes.IV;

            // 4. Encrypt
            var encryptor = aes.CreateEncryptor(aes.Key, aes.IV);
            byte[] plainBytes = Encoding.UTF8.GetBytes(plainKey);
            
            using var memoryStream = new System.IO.MemoryStream();
            memoryStream.Write(salt, 0, salt.Length); // Prepend Salt
            memoryStream.Write(ivBytes, 0, ivBytes.Length); // Prepend IV

            using var cryptoStream = new CryptoStream(memoryStream, encryptor, CryptoStreamMode.Write);
            cryptoStream.Write(plainBytes, 0, plainBytes.Length);
            cryptoStream.FlushFinalBlock();

            byte[] combined = memoryStream.ToArray();

            string encryptedOutput = outputFormat switch
            {
                "hex" => BitConverter.ToString(combined).Replace("-", "").ToLower(),
                _ => Convert.ToBase64String(combined)
            };

            Console.WriteLine();
            Console.WriteLine("=============================================");
            Console.WriteLine("Encrypted Key:");
            Console.WriteLine("=============================================");
            Console.WriteLine();
            Console.WriteLine(encryptedOutput);
            Console.WriteLine();
            Console.WriteLine("=============================================");
            Console.WriteLine("Usage in appsettings.json:");
            Console.WriteLine("=============================================");
            Console.WriteLine();
            Console.WriteLine($"\"EncryptedApiKey\": \"{encryptedOutput}\",");
            Console.WriteLine($"\"EncryptionKey\": \"{password}\"");
            Console.WriteLine();
            Console.WriteLine("IMPORTANT:");
            Console.WriteLine("  - Store EncryptionKey securely (environment variable, secret manager)");
            Console.WriteLine("  - Do NOT commit EncryptionKey to source control");
            Console.WriteLine("  - EncryptedApiKey CAN be committed (it's encrypted)");
            Console.WriteLine();
        }
        catch (Exception ex)
        {
            Console.WriteLine($"ERROR: Encryption failed - {ex.Message}");
            Environment.Exit(1);
        }
    }
}
