# Get-ServiceReqParams.ps1
# Получение параметров ServiceReq через HEAT OData API (WinHTTP COM)
# Использует WinHttp.WinHttpRequest.5.1 — отдельный HTTP-стек, 
# не имеющий проблем с TLS как у .NET Invoke-RestMethod
#
# Использование:
#   .\Get-ServiceReqParams.ps1 -ServiceReqID "9F21AAE0FFB4457FBA6CDAE59D75598E"

[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)]
    [string]$ServiceReqID,

    [string]$BaseUrl = "https://svoivantisrv/HEAT/api",
    [string]$ApiKey = "1404A984C43F48C88749CF8C1C14B40A"
)

$ErrorActionPreference = "Stop"

$baseUrlTrimmed = $BaseUrl.TrimEnd('/')
$authHeaderValue = "rest_api_key=$ApiKey"

# Собираем URL
$url = "$baseUrlTrimmed/odata/businessobject/ServiceReqParams?`$filter=ParentLink_RecID eq '$ServiceReqID'"
Write-Host "GET $url" -ForegroundColor Gray

# WinHTTP COM-объект (не .NET, свой TLS-стек)
$http = New-Object -ComObject WinHttp.WinHttpRequest.5.1
$http.Open("GET", $url, $false)
$http.SetRequestHeader("Authorization", $authHeaderValue)

# Игнорировать ошибки SSL (аналог SkipCertificateCheck)
$http.Option(4) = 0x3300

$http.Send()

if ($http.Status -ne 200) {
    Write-Host "[FAIL] HTTP $($http.Status): $($http.StatusText)" -ForegroundColor Red
    Write-Host $http.ResponseText -ForegroundColor Red
    exit 1
}

$responseText = $http.ResponseText
Write-Host "[OK] HTTP $($http.Status)" -ForegroundColor Green

# Парсим JSON
$data = $responseText | ConvertFrom-Json
$params = @($data.Value)

Write-Host ""
Write-Host "Найдено параметров: $($params.Count)" -ForegroundColor Green
Write-Host ""

foreach ($p in $params) {
    Write-Host "========================================" -ForegroundColor Cyan
    Write-Host "  RecId:                        $($p.RecId)"
    Write-Host "  ParameterName:                $($p.ParameterName)"
    Write-Host "  ParameterValue:               $($p.ParameterValue)"
    Write-Host "  DisplayType:                  $($p.DisplayType)"
    Write-Host "  SvcReqTmplParamLink_RecID:    $($p.SvcReqTmplParamLink_RecID)"
    Write-Host "  SvcReqTmplParamLink_Category: $($p.SvcReqTmplParamLink_Category)"
    Write-Host "  ParentLink_RecID:             $($p.ParentLink_RecID)"
    Write-Host ""

    if ($p.SvcReqTmplParamLink_RecID) {
        Write-Host ">> VALID: имеет привязку к шаблонному параметру" -ForegroundColor Green
    } else {
        Write-Host ">> NULL:  НЕТ привязки к шаблонному параметру (не отобразится в UI)" -ForegroundColor Yellow
    }

    Write-Host ""
    Write-Host "--- Полный JSON ---" -ForegroundColor DarkGray
    $p | ConvertTo-Json -Depth 5
    Write-Host ""
}
