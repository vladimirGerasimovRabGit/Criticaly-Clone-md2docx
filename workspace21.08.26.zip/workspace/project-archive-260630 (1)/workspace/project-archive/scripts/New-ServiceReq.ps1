# New-ServiceReq.ps1
# Создание новой заявки ServiceReq и связанных параметров через HEAT OData API
# Демонстрация работы с API без клонирования — создание "с нуля"
#
# Использование:
#   .\New-ServiceReq.ps1
#   .\New-ServiceReq.ps1 -BaseUrl "https://iesm-appsrv-prd/HEAT/api" -ApiKey "key"

[CmdletBinding()]
param(
    [string]$BaseUrl = "https://svoivantisrv/HEAT/api",
    [string]$ApiKey = "1404A984C43F48C88749CF8C1C14B40A",
    [string]$TemplateRecID = "8EDC5BCA48E0480EA3E9EE3579F35C94",
    [string]$ProfileRecID = "3DE0511365F4462FA8680BB20581BD43",
    [string]$ServiceValid = "61E89C0789824D21A56C72149ABDBE45",
    [string]$SourceValid = "B7065708DF4B449F8503621393B4A7AE",
    [string]$UrgencyValid = "C052472E5ADC45DB94624B6010F24B01",
    [string]$CreatedBy = "HEATAdmin",
    [string]$SourceServiceReqID = "",
    [switch]$SkipCertificateCheck
)

$ErrorActionPreference = "Stop"

# Настройка HTTP-клиента для GET-запросов (WinHTTP COM — отдельный стек, обходит TLS-проблему .NET)
function Get-ODataJson {
    param([string]$Url, [string]$ApiKey)
    $http = New-Object -ComObject WinHttp.WinHttpRequest.5.1
    $http.Open("GET", $Url, $false)
    $http.SetRequestHeader("Authorization", "rest_api_key=$ApiKey")
    $http.Option(4) = 0x3300  # SslErrorIgnoreFlags = Ignore all
    $http.Send()
    if ($http.Status -ne 200) {
        throw "HTTP $($http.Status): $($http.StatusText)"
    }
    return $http.ResponseText | ConvertFrom-Json
}

[System.Net.ServicePointManager]::SecurityProtocol = [System.Net.SecurityProtocolType]::Tls12 -bor [System.Net.SecurityProtocolType]::Tls11 -bor [System.Net.SecurityProtocolType]::Tls13 -bor [System.Net.SecurityProtocolType]::Tls

Add-Type -AssemblyName System.Web

# ============================================================
# Настройка
# ============================================================

$baseUrlTrimmed = $BaseUrl.TrimEnd('/')
$authHeader = @{ Authorization = "rest_api_key=$ApiKey" }
$contentType = "application/json; charset=utf-8"

if ($SkipCertificateCheck) {
    Write-Host "[WARN] Проверка SSL-сертификата ОТКЛЮЧЕНА" -ForegroundColor Yellow
    [System.Net.ServicePointManager]::ServerCertificateValidationCallback = { $true }
}

Write-Host "[OK] BaseUrl: $baseUrlTrimmed" -ForegroundColor Green
Write-Host "[OK] Authorization: rest_api_key=***" -ForegroundColor Green

# ============================================================
# Шаг 0: Получение шаблонных параметров
# ============================================================

$tmplParams = @()
$usedSourceReq = $false

# Режим 1: получаем параметры из заявки-образца (SourceServiceReqID)
if ($SourceServiceReqID) {
    $usedSourceReq = $true
    try {
        $encodedId = [uri]::EscapeDataString($SourceServiceReqID)
        $srcUrl = "$baseUrlTrimmed/odata/businessobject/ServiceReqParams?`$filter=ParentLink_RecID%20eq%20'$encodedId'"
        Write-Host "GET $srcUrl" -ForegroundColor Gray
        $srcData = Get-ODataJson -Url $srcUrl -ApiKey $ApiKey
        $srcParams = @($srcData.Value)
        Write-Host "[OK] Найдено параметров заявки-образца: $($srcParams.Count)" -ForegroundColor Green

        foreach ($sp in $srcParams) {
            $tp = [PSCustomObject]@{
                ParameterName = $sp.ParameterName
                RecId = $sp.SvcReqTmplParamLink_RecID
                DisplayType = $sp.DisplayType
                SvcReqTmplParamLink_Category = $sp.SvcReqTmplParamLink_Category
                SvcReqTmplParamLink_RecID = $sp.SvcReqTmplParamLink_RecID
                DefaultValue = $sp.DefaultValue
            }
            $tmplParams += $tp
            Write-Host "  - $($tp.ParameterName) (RecId: $($tp.RecId), DisplayType: $($tp.DisplayType))" -ForegroundColor White
        }
    }
    catch {
        Write-Host "[FAIL] Не удалось получить параметры заявки-образца: $($_.Exception.Message)" -ForegroundColor Red
        exit 1
    }
}

# Режим 2: получаем параметры из шаблона
if (-not $SourceServiceReqID) {
    try {
        $encodedId = [uri]::EscapeDataString($TemplateRecID)
        $tmplParamsUrl = "$baseUrlTrimmed/odata/businessobject/SvcReqTmplParams?`$filter=SvcReqTmplLink_RecID%20eq%20'$encodedId'"
        Write-Host "GET $tmplParamsUrl" -ForegroundColor Gray
        $tmplData = Get-ODataJson -Url $tmplParamsUrl -ApiKey $ApiKey
        $tmplParams = @($tmplData.Value)
        Write-Host "[OK] Найдено параметров шаблона: $($tmplParams.Count)" -ForegroundColor Green
        foreach ($tp in $tmplParams) {
            Write-Host "  - $($tp.ParameterName) (RecId: $($tp.RecId), DisplayType: $($tp.DisplayType))" -ForegroundColor White
        }
    }
    catch {
        Write-Host "[WARN] Не удалось получить параметры шаблона: $($_.Exception.Message)" -ForegroundColor Yellow
    }
}

if ($tmplParams.Count -eq 0) {
    Write-Host ""
    Write-Host "[INFO] Параметры шаблона не найдены." -ForegroundColor Cyan
    Write-Host "[INFO] Проверьте TemplateRecID — шаблон должен содержать параметры." -ForegroundColor Cyan
    Write-Host "[INFO] Параметры будут созданы без привязки к шаблону (не отобразятся в UI)." -ForegroundColor Yellow
}

# ============================================================
# Шаг 1: Создание новой заявки ServiceReq
# ============================================================

Write-Host ""
Write-Host "==================== Шаг 1: Создание ServiceReq ====================" -ForegroundColor Cyan

$body = @{
    Status                   = "Draft"
    Subject                  = "Тестовая заявка (PowerShell)"
    Symptom                  = "Заявка создана через PowerShell для демонстрации работы с HEAT OData API"
    Service_Valid            = $ServiceValid
    Source_Valid             = $SourceValid
    Urgency_Valid            = $UrgencyValid
    SvcReqTmplLink_Category  = "SvcReqTemplate"
    SvcReqTmplLink_RecID     = $TemplateRecID
    ProfileLink_Category     = "Profile"
    ProfileLink_RecID        = $ProfileRecID
    IsVIP                    = $false
    IsDraft                  = $true
    Cancelable               = $true
    IsNewRecord              = $true
    IsUnRead                 = $true
    CreatedBy                = $CreatedBy
    LastModBy                = $CreatedBy
    CreatedDateTime          = (Get-Date -Format "yyyy-MM-ddTHH:mm:ssZ")
    LastModDateTime          = (Get-Date -Format "yyyy-MM-ddTHH:mm:ssZ")
    Phone                    = "+998901234567"
    Email                    = "demo@svo.uz"
}

$json = $body | ConvertTo-Json -Depth 5 -Compress

Write-Host "Request JSON:" -ForegroundColor Gray
Write-Host ($body | ConvertTo-Json -Depth 5)

try {
    $response = Invoke-RestMethod `
        -Uri "$baseUrlTrimmed/odata/businessobject/ServiceReqs" `
        -Method Post `
        -Headers $authHeader `
        -Body $json `
        -ContentType $contentType

    Write-Host ""
    Write-Host "[OK] ServiceReq создан!" -ForegroundColor Green
    Write-Host "Response:" -ForegroundColor Gray
    Write-Host ($response | ConvertTo-Json -Depth 3)

    $newRecId = $response.RecId
    $newNumber = $response.ServiceReqNumber

    Write-Host ""
    Write-Host "  RecId:  $newRecId" -ForegroundColor White
    Write-Host "  Number: $newNumber" -ForegroundColor White
}
catch {
    Write-Host ""
    Write-Host "[FAIL] Не удалось создать ServiceReq" -ForegroundColor Red
    Write-Host $_.Exception.Message -ForegroundColor Red
    if ($_.Exception.Response) {
        $reader = New-Object System.IO.StreamReader($_.Exception.Response.GetResponseStream())
        $errorBody = $reader.ReadToEnd()
        $reader.Close()
        Write-Host "Response body:" -ForegroundColor DarkRed
        Write-Host $errorBody -ForegroundColor Red
    }
    elseif ($_.ErrorDetails.Message) {
        Write-Host "Error details:" -ForegroundColor DarkRed
        Write-Host $_.ErrorDetails.Message -ForegroundColor Red
    }
    exit 1
}

# ============================================================
# Шаг 2: Создание параметров заявки
# ============================================================

Write-Host ""
Write-Host "=============== Шаг 2: Создание параметров ServiceReq ===============" -ForegroundColor Cyan

$parameters = @()

if ($tmplParams.Count -gt 0) {
    if ($usedSourceReq) {
        Write-Host "Используем SvcReqTmplParamLink_RecID из заявки-образца с новыми значениями:" -ForegroundColor Cyan
    }
    else {
        Write-Host "Используем параметры из шаблона:" -ForegroundColor Cyan
    }

    foreach ($tp in $tmplParams) {
        if ($tp.SvcReqTmplParamLink_RecID) {
            $val = if ($tp.DisplayType -match 'Checkbox|Boolean') { "true" } else { "Test $($tp.ParameterName)" }
            $parameters += @{
                ParentLink_Category         = "ServiceReq"
                ParentLink_RecID            = $newRecId
                ParameterName               = $tp.ParameterName
                ParameterValue              = $val
                ParameterDisplayValue       = $val
                DisplayType                 = $tp.DisplayType
                ReadOnly                    = $false
                SvcReqTmplParamLink_Category = $tp.SvcReqTmplParamLink_Category
                SvcReqTmplParamLink_RecID   = $tp.SvcReqTmplParamLink_RecID
                CreatedBy                   = $CreatedBy
                LastModBy                   = $CreatedBy
                CreatedDateTime             = (Get-Date -Format "yyyy-MM-ddTHH:mm:ssZ")
                LastModDateTime             = (Get-Date -Format "yyyy-MM-ddTHH:mm:ssZ")
            }
            Write-Host "  -> $($tp.ParameterName) = $val (Link: $($tp.SvcReqTmplParamLink_RecID))" -ForegroundColor DarkGray
        }
    }
}
else {
    Write-Host "[INFO] Шаблон без параметров — создаём без привязки" -ForegroundColor Yellow
    $parameters = @(
        @{
            ParentLink_Category = "ServiceReq"
            ParentLink_RecID    = $newRecId
            ParameterName       = "Description"
            ParameterValue      = "Тестовый параметр"
            ReadOnly            = $false
            CreatedBy           = $CreatedBy
            LastModBy           = $CreatedBy
            CreatedDateTime     = (Get-Date -Format "yyyy-MM-ddTHH:mm:ssZ")
            LastModDateTime     = (Get-Date -Format "yyyy-MM-ddTHH:mm:ssZ")
        }
    )
}

$paramSuccess = 0
$paramFail = 0
$paramErrors = @()

foreach ($param in $parameters) {
    $paramJson = $param | ConvertTo-Json -Depth 3 -Compress

    try {
        $paramResponse = Invoke-RestMethod `
            -Uri "$baseUrlTrimmed/odata/businessobject/ServiceReqParams" `
            -Method Post `
            -Headers $authHeader `
            -Body $paramJson `
            -ContentType $contentType

        Write-Host "  [OK] $($param.ParameterName) = $($param.ParameterValue)" -ForegroundColor Green
        $paramSuccess++
    }
    catch {
        Write-Host "  [FAIL] $($param.ParameterName): $($_.Exception.Message)" -ForegroundColor Red
        $paramFail++
        $paramErrors += @{ Name = $param.ParameterName; Error = $_.Exception.Message }
    }
}

# ============================================================
# Шаг 3: Проверка — получение параметров созданной заявки
# ============================================================

Write-Host ""
Write-Host "============= Шаг 3: Проверка параметров созданной заявки ===========" -ForegroundColor Cyan

$encodedNewId = [uri]::EscapeDataString($newRecId)
$checkUrl = "$baseUrlTrimmed/odata/businessobject/ServiceReqParams?`$filter=ParentLink_RecID%20eq%20'$encodedNewId'"

try {
    $checkData = Get-ODataJson -Url $checkUrl -ApiKey $ApiKey
    $checkParams = @($checkData.Value)

    if ($checkParams.Count -gt 0) {
        Write-Host "[OK] Найдено параметров: $($checkParams.Count)" -ForegroundColor Green
        Write-Host ""
        Write-Host "--- Полная структура первого параметра (для отладки) ---" -ForegroundColor Cyan
        $checkParams[0] | ConvertTo-Json -Depth 5
        Write-Host "--------------------------------------------------------" -ForegroundColor Cyan
        Write-Host ""
        foreach ($p in $checkParams) {
            Write-Host "  - $($p.ParameterName): $($p.ParameterValue) (SvcReqTmplParamLink_RecID: $($p.SvcReqTmplParamLink_RecID))" -ForegroundColor White
        }
    }
    else {
        Write-Host "[INFO] Параметры не найдены (возвращён пустой список)" -ForegroundColor Yellow
    }
}
catch {
    Write-Host "[WARN] Не удалось получить параметры: $($_.Exception.Message)" -ForegroundColor Yellow
}

# ============================================================
# Итог
# ============================================================

Write-Host ""
Write-Host "============================= ИТОГ =================================" -ForegroundColor Cyan
Write-Host "  ServiceReq RecId:  $newRecId" -ForegroundColor White
Write-Host "  ServiceReq Number: $newNumber" -ForegroundColor White
Write-Host "  Параметров создано: $paramSuccess из $($parameters.Count)" -ForegroundColor $(if ($paramFail -eq 0) { "Green" } else { "Yellow" })
Write-Host ""
Write-Host "  Ссылка на заявку в HEAT:" -ForegroundColor Cyan
$heatUi = $BaseUrl -replace '/api$', ''
$encodedRecId = [System.Web.HttpUtility]::UrlEncode($newRecId)
Write-Host "  $heatUi/Login.aspx?Scope=ObjectWorkspace&CommandId=Search&ObjectType=ServiceReq%23&CommandData=RecId%2c%3d%2c0%2c$encodedRecId%2cstring%2cAND%7C" -ForegroundColor White
Write-Host "======================================================================" -ForegroundColor Cyan
