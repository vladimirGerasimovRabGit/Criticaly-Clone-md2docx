# ServiceReq Cloner Service — Техническая документация

**Продукт**: ClonerSuite  
**Клиент**: SVO AVIA  
**Дата**: Июнь 2026 г.

---

## 1. Назначение документа

Настоящий документ описывает архитектуру, развертывание и эксплуатацию сервиса **ServiceReq Cloner** — компонента системы ClonerSuite для клонирования заявок (ServiceReq) и инцидентов (Incident) в системе Ivanti HEAT ISM.

Документ предназначен для:
- Системных администраторов, выполняющих развертывание сервиса
- Инженеров поддержки, осуществляющих диагностику и устранение неполадок
- Разработчиков, расширяющих функциональность сервиса

---

## 2. Термины и аббревиатуры

- **ServiceReq** — заявка на обслуживание в Ivanti HEAT ISM
- **Incident** — инцидент в Ivanti HEAT ISM
- **RecId** — уникальный идентификатор записи в HEAT
- **HEAT / ISM** — система управления ИТ-услугами Ivanti (Ivanti Service Manager)
- **OData** — протокол REST API для доступа к данным HEAT
- **Clone (Клон)** — копия исходной заявки или инцидента с новым идентификатором
- **Parameter** — параметр заявки (дополнительные поля шаблона)
- **Attachment** — вложение, прикреплённое к заявке или инциденту
- **PBKDF2** — алгоритм вывода ключа на основе пароля (RFC 2898)

---

## 3. Архитектура сервиса

### 3.1 Общая схема

```mermaid
flowchart TD
    subgraph IIS ["IIS (HTTPS 443)"]
        direction TB
        ARR["Application Request Routing"]
        SSL["SSL Termination"]
    end

    subgraph Cloner ["ServiceReq Cloner"]
        direction TB
        Ports["Порт: 7104 (HTTP) / 7105 (HTTPS)"]

        subgraph Controllers ["API Endpoints"]
            C1["/api/ServiceReqClone/*"]
            C2["/api/IncidentClone/*"]
            C3["/api/Diagnostic/*"]
        end

        subgraph Services ["Business Logic"]
            S1["ServiceReqClonerService"]
            S2["IncidentClonerService"]
            S3["HeatApiService"]
            S4["EncryptionService"]
        end
    end

    subgraph HEAT ["Ivanti HEAT ISM"]
        direction TB
        API["https://svoivantisrv/HEAT/api"]
        OData["odata/businessobject/ServiceReqs<br/>odata/businessobject/incidents<br/>odata/businessobject/ServiceReqParams<br/>odata/businessobject/Attachments"]
    end

    subgraph Browser ["Браузер / HEAT UI Action"]
        B1["UI Action: Клонировать ServiceReq"]
        B2["UI Action: Клонировать Incident"]
    end

    Browser --> IIS
    IIS --> Cloner
    Cloner --> HEAT
```

### 3.2 Компоненты сервиса

| Компонент | Файл | Описание |
|-----------|------|----------|
| **Program.cs** | Program.cs | Точка входа, настройка DI, Kestrel, Serilog |
| **ServiceReqCloneController** | Controllers/ServiceReqCloneController.cs | REST API для клонирования заявок |
| **IncidentCloneController** | Controllers/IncidentCloneController.cs | REST API для клонирования инцидентов |
| **DiagnosticController** | Controllers/DiagnosticController.cs | Диагностика: память, проверка CI |
| **ServiceReqClonerService** | Services/ServiceReqClonerService.cs | Основная логика клонирования ServiceReq |
| **IncidentClonerService** | Services/IncidentClonerService.cs | Основная логика клонирования инцидентов |
| **HeatApiService** | Services/HeatApiService.cs | HTTP-клиент для HEAT OData API |
| **EncryptionService** | Services/EncryptionService.cs | AES-256 шифрование/расшифровка API-ключа |
| **MemoryHealthService** | Services/MemoryHealthService.cs | Мониторинг использования памяти |
| **RequestLoggingMiddleware** | Middleware/RequestLoggingMiddleware.cs | Логирование всех HTTP-запросов |
| **LocalhostOnlyMiddleware** | Middleware/LocalhostOnlyMiddleware.cs | Ограничение доступа к эндпоинтам |
| **HeatApiSettings** | Configuration/HeatApiSettings.cs | Конфигурация подключения к HEAT |

### 3.3 Модель данных

#### ServiceReq (Заявка)

```csharp
public class ServiceReq
{
    public string? RecId { get; set; }                // Уникальный ID
    public decimal ServiceReqNumber { get; set; }     // Номер заявки
    public string? Subject { get; set; }              // Тема
    public string? Symptom { get; set; }              // Описание
    public string? Status { get; set; }               // Статус ("Draft")
    public string? Status_Valid { get; set; }         // Valid-идентификатор статуса
    public string? TRN_Status { get; set; }           // Статус транзакции
    public string? Service_Valid { get; set; }        // Сервис (Valid)
    public string? Source_Valid { get; set; }         // Источник (Valid)
    public string? Urgency_Valid { get; set; }        // Срочность (Valid)
    public string? ProfileLink_RecID { get; set; }    // ID профиля заявителя
    public string? SvcReqTmplLink_RecID { get; set; } // ID шаблона заявки
    public string? Owner_Valid { get; set; }          // Владелец (Valid)
    public string? OwnerTeam_Valid { get; set; }      // Группа владельца (Valid)
    public string? OrganizationUnitID { get; set; }   // Орг. единица
    public bool IsDraft { get; set; }                 // Черновик
    public bool IsVIP { get; set; }                   // VIP
    public bool Cancelable { get; set; }              // Можно отменить
    public bool IsEditable { get; set; }              // Можно редактировать
    public string? Email { get; set; }                // Email
    public string? Phone { get; set; }                // Телефон
    public string? Resolution { get; set; }           // Решение
    public decimal? Price { get; set; }               // Цена
    public DateTime CreatedDateTime { get; set; }     // Дата создания
    public DateTime LastModDateTime { get; set; }     // Дата изменения
    public string CreatedBy { get; set; }             // Кто создал
    public string LastModBy { get; set; }             // Кто изменил
}
```

#### Incident (Инцидент)

```csharp
public class Incident
{
    public string? RecId { get; set; }                // Уникальный ID
    public int IncidentNumber { get; set; }           // Номер инцидента
    public string? Subject { get; set; }              // Тема
    public string? Symptom { get; set; }              // Симптомы
    public string? Status { get; set; }               // Статус ("Открыт")
    public string? Status_Valid { get; set; }         // Valid-идентификатор статуса
    public string? TRN_Status { get; set; }           // Статус транзакции
    public string? Service_Valid { get; set; }        // Сервис (Valid)
    public string? Source_Valid { get; set; }         // Источник (Valid)
    public string? Priority_Valid { get; set; }       // Приоритет (Valid)
    public string? Category_Valid { get; set; }       // Категория (Valid)
    public string? ActualCategory_Valid { get; set; } // Фактическая категория
    public string? CauseCode_Valid { get; set; }      // Код причины
    public string? Urgency_Valid { get; set; }        // Срочность (Valid)
    public string? Impact_Valid { get; set; }         // Влияние (Valid)
    public string? Owner_Valid { get; set; }          // Владелец (Valid)
    public string? OwnerTeam_Valid { get; set; }      // Группа владельца
    public string? ProfileLink_RecID { get; set; }    // ID профиля заявителя
    public string? OrganizationUnitID { get; set; }   // Орг. единица
    public string? Email { get; set; }                // Email
    public string? LoginId { get; set; }              // Логин
    public string? HoursOfOperation { get; set; }     // Часы работы
    public bool IsVIP { get; set; }                   // VIP
    public bool FirstCallResolution { get; set; }     // Решение при первом звонке
    public bool IsWorkAround { get; set; }            // Обходное решение
    public bool IsNotification { get; set; }          // Уведомление
    public DateTime CreatedDateTime { get; set; }     // Дата создания
    public DateTime LastModDateTime { get; set; }     // Дата изменения
    public string CreatedBy { get; set; }             // Кто создал
    public string LastModBy { get; set; }             // Кто изменил
}
```

#### ServiceReqParameter (Параметр заявки)

```csharp
public class ServiceReqParameter
{
    public string? RecId { get; set; }
    public string ParentLink_Category { get; set; }     // "ServiceReq"
    public string ParentLink_RecID { get; set; }        // ID родительской заявки
    public string? ParameterName { get; set; }          // Имя параметра
    public string? ParameterValue { get; set; }         // Значение параметра
    public string? ParameterDisplayValue { get; set; }  // Отображаемое значение
    public string? DisplayType { get; set; }            // Тип отображения
    public decimal? ParameterPrice { get; set; }        // Цена параметра
    public bool ReadOnly { get; set; }                  // Только чтение
    public string? SvcReqTmplParamLink_RecID { get; set; } // ID параметра шаблона
}
```

#### ODataResponse (Обёртка OData)

```csharp
public class ODataResponse<T>
{
    [JsonPropertyName("@odata.context")]
    public string? ODataContext { get; set; }
    public List<T>? Value { get; set; }
}
```

---

## 4. API Endpoints

### 4.1 ServiceReqCloneController

| Метод | Маршрут | Описание |
|-------|---------|----------|
| **GET** | `/api/ServiceReqClone/clone-with-view?id={ID}&openInNewTab={bool}` | Клонирование с HTML-страницей ожидания (для UI Action) |
| **GET** | `/api/ServiceReqClone/clone?id={ID}&openInNewTab={bool}` | Клонирование с JSON-ответом |
| **POST** | `/api/ServiceReqClone/clone/{id}?openInNewTab={bool}` | Клонирование с ID в URL |
| **POST** | `/api/ServiceReqClone/clone` | Клонирование с полным телом запроса (CloneRequest) |
| **GET** | `/api/ServiceReqClone/health` | Проверка здоровья (healthy / degraded) |
| **GET** | `/api/ServiceReqClone/next-number` | Получить следующий номер заявки |
| **GET** | `/api/ServiceReqClone/server-info` | Информация о сервере (порты, URL) |
| **GET** | `/api/ServiceReqClone/test-create-direct?id={ID}` | Диагностическое создание напрямую |

### 4.2 IncidentCloneController

| Метод | Маршрут | Описание |
|-------|---------|----------|
| **GET** | `/api/IncidentClone/clone-with-view?id={ID}&openInNewTab={bool}` | Клонирование с HTML-страницей ожидания |
| **GET** | `/api/IncidentClone/clone?id={ID}&openInNewTab={bool}` | Клонирование с JSON-ответом |
| **GET** | `/api/IncidentClone/next-number` | Получить следующий номер инцидента |
| **GET** | `/api/IncidentClone/health` | Проверка здоровья |
| **GET** | `/api/IncidentClone/debug-create/{id}` | Отладка создания инцидента напрямую |

### 4.3 DiagnosticController

| Метод | Маршрут | Описание |
|-------|---------|----------|
| **GET** | `/api/Diagnostic/memory` | Информация об использовании памяти |
| **GET** | `/api/Diagnostic/ci/{id}` | Поиск CI по различным URL |
| **GET** | `/api/Diagnostic/ci/{id}/relations` | Связи CI |

### 4.4 Модели запросов и ответов

#### CloneRequest

```csharp
public class CloneRequest
{
    public string SourceRecId { get; set; }      // ID исходной заявки
    public bool CloneParameters { get; set; }     // Клонировать параметры (по умолчанию true)
    public bool CloneAttachments { get; set; }    // Клонировать вложения
    public bool OpenInNewTab { get; set; }        // Открыть в новой вкладке
    public string? RedirectBaseUrl { get; set; }   // Базовый URL для редиректа
    public Dictionary<string, object>? OverrideFields { get; set; } // Переопределяемые поля
}
```

#### CloneResponse

```csharp
public class CloneResponse
{
    public string? NewRecId { get; set; }         // RecId созданной заявки
    public decimal NewServiceReqNumber { get; set; } // Номер созданной заявки
    public bool Success { get; set; }             // Успешность операции
    public string? Message { get; set; }          // Сообщение
    public List<string>? Errors { get; set; }     // Ошибки (параметры, вложения)
    public string? RedirectUrl { get; set; }      // URL для редиректа в HEAT
    public bool OpenInNewTab { get; set; }        // Флаг новой вкладки
    public TimeSpan ElapsedTime { get; set; }     // Время выполнения
}
```

---

## 5. Диаграммы процессов

### 5.1 Клонирование ServiceReq (полный цикл)

```mermaid
sequenceDiagram
    participant UI as "HEAT UI Action"
    participant IIS as "IIS (Reverse Proxy)"
    participant SC as "ServiceReqCloneController"
    participant CS as "ServiceReqClonerService"
    participant HAS as "HeatApiService"
    participant HEAT as "HEAT OData API"

    Note over UI,HEAT: "Клонирование заявки"

    UI->>IIS: "GET /api/ServiceReqClone/clone-with-view?id=ABC123"
    IIS->>SC: "Запрос"
    SC->>CS: "CloneServiceReqAsync(request)"

    CS->>HAS: "GetServiceReqAsync(sourceRecId)"
    HAS->>HEAT: "GET odata/businessobject/ServiceReqs?$filter=RecId eq 'ABC123'"
    HEAT-->>HAS: "Исходная заявка"
    HAS-->>CS: "ServiceReq"

    CS->>HAS: "GetNextServiceReqNumberAsync()"
    HAS->>HEAT: "GET odata/businessobject/ServiceReqs?$top=1&$orderby=ServiceReqNumber desc"
    HEAT-->>HAS: "Последний номер"
    HAS-->>CS: "Следующий номер"

    opt CloneParameters = true
        CS->>HAS: "GetServiceReqParametersAsync(sourceRecId)"
        HAS->>HEAT: "GET odata/businessobject/ServiceReqs('ABC123')/ServiceReqContainsServiceReqParam"
        HEAT-->>HAS: "Список параметров"
        HAS-->>CS: "List<ServiceReqParameter>"
    end

    opt CloneAttachments = true
        CS->>HAS: "GetServiceReqAttachmentsAsync(sourceRecId)"
        HAS->>HEAT: "GET odata/businessobject/ServiceReqs('ABC123')/ServiceReqContainsAttachment"
        HEAT-->>HAS: "Список вложений"
        HAS-->>CS: "List<ServiceReqAttachment>"
    end

    CS->>CS: "CloneServiceReqObject(): Status='Draft', Owner=null"

    CS->>HAS: "CreateServiceReqAsync(clonedReq)"
    HAS->>HEAT: "POST odata/businessobject/ServiceReqs"
    HEAT-->>HAS: "Созданная заявка (RecId, Number)"
    HAS-->>CS: "New ServiceReq"

    loop Для каждого параметра
        CS->>HAS: "CreateParameterAsync(parameter)"
        HAS->>HEAT: "POST odata/businessobject/ServiceReqParams"
        HEAT-->>HAS: "201 Created"
        HAS-->>CS: "true"
    end

    loop Для каждого вложения
        CS->>HAS: "CreateAttachmentAsync(attachment)"
        HAS->>HEAT: "POST odata/businessobject/Attachments"
        HEAT-->>HAS: "201 Created"
        HAS-->>CS: "true"
    end

    CS-->>SC: "CloneResponse { Success=true }"
    SC-->>UI: "302 Redirect: /clone-waiting.html?recId=...&success=true"
```

### 5.2 Клонирование Incident

```mermaid
sequenceDiagram
    participant UI as "HEAT UI Action"
    participant IC as "IncidentCloneController"
    participant IS as "IncidentClonerService"
    participant HAS as "HeatApiService"
    participant HEAT as "HEAT OData API"

    Note over UI,HEAT: "Клонирование инцидента"

    UI->>IC: "GET /api/IncidentClone/clone-with-view?id=DEF456"
    IC->>IS: "CloneIncidentAsync(request)"

    IS->>HAS: "GetIncidentAsync(sourceRecId)"
    HAS->>HEAT: "GET odata/businessobject/incidents?$filter=RecId eq 'DEF456'"
    HEAT-->>HAS: "Исходный инцидент"
    HAS-->>IS: "Incident"

    IS->>IS: "CloneIncidentObject(): Status='Открыт', Owner=null"

    IS->>HAS: "CreateIncidentAsync(clonedIncident)"
    HAS->>HEAT: "POST odata/businessobject/incidents"
    HEAT-->>HAS: "Созданный инцидент (RecId, Number)"
    HAS-->>IS: "New Incident"

    IS-->>IC: "CloneIncidentResponse { Success=true }"
    IC-->>UI: "302 Redirect: /clone-waiting.html?recId=...&success=true&type=Incident"
```

### 5.3 Блок-схема клонирования ServiceReq

```mermaid
flowchart TD
    Start(["Начало: CloneServiceReqAsync"]) --> GetSource["Получить исходную заявку из HEAT"]

    GetSource --> CheckSource{"Исходная<br/>найдена?"}
    CheckSource -->|"Нет"| Error1["Вернуть ошибку: not found"]
    CheckSource -->|"Да"| GetNextNum["Получить следующий номер"]

    GetNextNum --> CloneParams{"CloneParameters?"}
    CloneParams -->|"Да"| GetParams["Получить параметры из HEAT"]
    CloneParams -->|"Нет"| CloneAttach{"CloneAttachments?"}
    GetParams --> CloneAttach

    CloneAttach -->|"Да"| GetAttach["Получить вложения из HEAT"]
    CloneAttach -->|"Нет"| CloneObj["Клонировать объект ServiceReq"]
    GetAttach --> CloneObj

    CloneObj --> SetStatus["Установить: Status='Draft'<br/>Owner=null, IsDraft=true<br/>CreatedBy='HEATAdmin'"]
    SetStatus --> ApplyOverride{"Есть<br/>OverrideFields?"}
    ApplyOverride -->|"Да"| ApplyFields["Применить переопределения полей"]
    ApplyOverride -->|"Нет"| CreateReq["Создать заявку через HEAT API"]
    ApplyFields --> CreateReq

    CreateReq --> CheckCreate{"Успешно<br/>создана?"}
    CheckCreate -->|"Нет"| Error2["Вернуть ошибку: failed to create"]
    CheckCreate -->|"Да"| CloneParamsLoop{"Есть<br/>параметры?"}

    CloneParamsLoop -->|"Да"| CloneEachParam["Клонировать каждый параметр"]
    CloneEachParam --> CloneAttachLoop{"Есть<br/>вложения?"}
    CloneParamsLoop -->|"Нет"| CloneAttachLoop

    CloneAttachLoop -->|"Да"| CloneEachAtt["Клонировать каждое вложение"]
    CloneEachAtt --> Success["Вернуть CloneResponse { Success=true }"]
    CloneAttachLoop -->|"Нет"| Success
```

### 5.4 Процесс клонирования Incident

```mermaid
flowchart TD
    Start(["CloneIncidentAsync"]) --> GetInc["GetIncidentAsync(sourceRecId)"]

    GetInc --> CheckInc{"Инцидент<br/>найден?"}
    CheckInc -->|"Нет"| Error1["Вернуть: not found"]
    CheckInc -->|"Да"| CloneInc["CloneIncidentObject()"]

    CloneInc --> CopyFields["Копировать: Service, Source, Priority<br/>Category, ActualCategory, CauseCode<br/>Urgency, Impact, ProfileLink<br/>TRN_Category"]
    CopyFields --> ClearOwner["Очистить: Owner, OwnerTeam"]
    ClearOwner --> SetStatus["Установить: Status='Открыт'<br/>CreatedBy='HEATAdmin'<br/>LastModBy='HEATAdmin'"]
    SetStatus --> ApplyOverride{"OverrideFields?"}
    ApplyOverride -->|"Да"| Apply["Применить переопределения"]
    ApplyOverride -->|"Нет"| CreateInc["CreateIncidentAsync()"]
    Apply --> CreateInc

    CreateInc --> CheckCreate{"Успешно?"}
    CheckCreate -->|"Нет"| Error2["Вернуть: failed to create"]
    CheckCreate -->|"Да"| BuildURL["Сформировать RedirectUrl<br/>для HEAT Login.aspx"]
    BuildURL --> Success["Вернуть: Success=true<br/>NewRecId, NewIncidentNumber"]
```

---

## 6. Конфигурация

### 6.1 Файлы конфигурации

| Файл | Назначение |
|------|-----------|
| `appsettings.json` | Базовая конфигурация (dev) |
| `appsettings.Development.json` | Конфигурация для разработки |
| `appsettings.Production.json` | Конфигурация для тестовой и промышленной среды |

### 6.2 Параметры конфигурации

```json
{
  "Server": {
    "Port": 7104,
    "UseHttps": true,
    "HttpsPort": 7105,
    "CertificatePath": "",
    "CertificatePassword": "",
    "CertificateThumbprint": ""
  },
  "HeatApi": {
    "BaseUrl": "https://svoivantisrv/HEAT/api",
    "ApiKey": "",
    "EncryptedApiKey": "8owtwbON81PUPSx0qf+FFi...",
    "EncryptionKey": "MySecretKey2024!",
    "TimeoutSeconds": 60,
    "DefaultUser": "HEATAdmin",
    "SkipCertificateValidation": true,
    "RequireWebServer": false
  },
  "HeatUI": {
    "BaseUrl": "https://svoivantisrv/HEAT"
  },
  "AllowedOrigins": ["https://svoivantisrv"]
}
```

| Параметр | Описание |
|----------|----------|
| `Server:Port` | HTTP-порт (dev: 7101, test/prod: 7104) |
| `Server:HttpsPort` | HTTPS-порт (dev: 7102, test/prod: 7105) |
| `HeatApi:BaseUrl` | Базовый URL HEAT OData API |
| `HeatApi:ApiKey` | API-ключ открытым текстом |
| `HeatApi:EncryptedApiKey` | Зашифрованный API-ключ (Base64) |
| `HeatApi:EncryptionKey` | Пароль для расшифровки |
| `HeatApi:SkipCertificateValidation` | Пропустить проверку SSL-сертификата |
| `HeatApi:RequireWebServer` | Требовать окружение Production для использования ApiKey |
| `HeatUI:BaseUrl` | Базовый URL HEAT UI для редиректов |

---

## 7. Middleware и безопасность

### 7.1 RequestLoggingMiddleware

Логирует каждый HTTP-запрос: метод, путь, параметры, время выполнения и HTTP-статус.

```
[INF] [ServiceReqCloner.Request] GET /api/IncidentClone/clone-with-view?id=ABC started
[INF] [ServiceReqCloner.Request] GET /api/IncidentClone/clone-with-view completed in 296.89ms with status 302
```

### 7.2 LocalhostOnlyMiddleware

Позволяет ограничить доступ к определённым эндпоинтам только с localhost. По умолчанию список ограниченных префиксов пуст — middleware не блокирует запросы.

### 7.3 CORS

Настроен для разрешения запросов от `AllowedOrigins` (по умолчанию `https://svoivantisrv`).

---

## 8. Логирование и мониторинг

### 8.1 Serilog

Логирование через Serilog с двумя выводами:
- **Консоль** — цветной вывод с форматом `[{Timestamp:yyyy-MM-dd HH:mm:ss} {Level:u3}] {Message}`
- **Файл** — `logs/app-{date}.log`, ротация ежедневно, максимум 50 МБ на файл, хранится 10 файлов

### 8.2 Уровни логирования

| Компонент | Уровень по умолчанию |
|-----------|---------------------|
| Общий | Information |
| Microsoft.AspNetCore | Warning |
| HeatApiService | Debug |

### 8.3 Проверка здоровья

```
GET /api/ServiceReqClone/health

{"status":"healthy","timestamp":"2026-06-22T09:12:59Z","port":7104}
```

- **healthy** — HEAT API доступен
- **degraded** — HEAT API недоступен

### 8.4 Мониторинг памяти

```
GET /api/Diagnostic/memory

{"WorkingSetMB": 85.3, "GCHeapMB": 12.1, "TotalAllocatedMB": 45.2, "GCRatio": 14.2}
```

---

## 9. Развёртывание

### 9.1 Требования

- Windows Server с IIS
- .NET 8 Runtime (ASP.NET Core Module V2)
- Доступ к HEAT API (`https://svoivantisrv/HEAT/api`)

### 9.2 Порядок развёртывания

```powershell
# 1. Копирование файлов на сервер
xcopy /E /Y F:\ClonerSuite-Deploy\Cloner-Server\* C:\ClonerSuite\ServiceReqCloner\

# 2. Проверка сервера
powershell -ExecutionPolicy Bypass -File C:\ClonerSuite\ServiceReqCloner\ServerPreCheck.ps1

# 3. Развёртывание в IIS
powershell -ExecutionPolicy Bypass -File C:\ClonerSuite\ServiceReqCloner\Deploy-ServiceReqCloner.ps1

# 4. Настройка appsettings.Production.json
# 5. Перезапуск AppPool
Restart-WebAppPool -Name "ServiceReqClonerAppPool"

# 6. Проверка
Invoke-WebRequest -Uri http://localhost:7104/api/ServiceReqClone/health -UseBasicParsing
```

### 9.3 Структура развёртывания

```
C:\ClonerSuite\ServiceReqCloner\
├── publish-iis\           ← Файлы публикации
│   ├── ServiceReqCloner.exe
│   ├── ServiceReqCloner.dll
│   ├── web.config
│   ├── appsettings.json
│   ├── appsettings.Production.json
│   └── wwwroot\
│       └── clone-waiting.html
└── logs\                  ← Логи приложения
    └── app-20260622.log
```

### 9.4 Запуск без IIS (standalone)

```powershell
$env:ASPNETCORE_ENVIRONMENT="Production"
F:\rsnpt\publish\ServiceReqCloner.exe --urls "http://0.0.0.0:7104;https://0.0.0.0:7105"
```

---

## 10. Отличия от Criticality Sync Service

| Характеристика | ServiceReq Cloner | Criticality Sync Service |
|---------------|-------------------|-------------------------|
| Назначение | Клонирование заявок/инцидентов | Синхронизация критичности CI |
| Тип операций | GET/POST (создание записей) | GET/PATCH (обновление записей) |
| Режим работы | По запросу (on-demand) | Фоновый (BackgroundService) |
| Порты (dev) | 7101/7102 | 7102/7103 |
| Порты (test/prod) | 7104/7105 | 7102/7103 |
| Статус клона ServiceReq | "Draft" | N/A |
| Статус клона Incident | "Открыт" | N/A |
| Клонирование параметров | Да | Нет |
| Клонирование вложений | Да | Нет |
| Шифрование API-ключа | PBKDF2 (C#) / SHA256 (PS) | Только PBKDF2 (C#) |

---

## 11. Диагностика и устранение неполадок

### 11.1 Сервис не запускается

```powershell
# Проверить наличие .NET Runtime
dotnet --list-runtimes

# Проверить порты
netstat -ano | findstr "7104 7105"

# Проверить логи
Get-Content F:\rsnpt\publish\logs\app-*.log -Tail 30
```

### 11.2 HEAT API возвращает 401 Unauthorized

Проверить конфигурацию API-ключа:
```json
"HeatApi": {
    "EncryptedApiKey": "8owtwbON81PUPSx0qf+FFi...",
    "EncryptionKey": "MySecretKey2024!",
    "SkipCertificateValidation": true,
    "RequireWebServer": false
}
```

### 11.3 Клонирование возвращает 404 (clone-waiting.html)

Скопировать папку `wwwroot` в директорию публикации:
```powershell
xcopy /E /Y .\wwwroot\* .\publish\wwwroot\
```

### 11.4 Endpoint возвращает 404

Убедиться, что `HeatApi:RequireWebServer` = `false` для non-Production окружений, или использовать `ASPNETCORE_ENVIRONMENT=Production`.

### 11.5 HTTPS не работает

Для тестовой среды используйте HTTP или настройте сертификат:
```json
"Server": {
    "UseHttps": false
}
```

---

## 12. Исходный код

### 12.1 Структура проекта

```
ServiceReqCloner/
├── Program.cs                         # Точка входа
├── ServiceReqCloner.csproj            # Проектный файл (.NET 8)
├── appsettings.json                   # Базовая конфигурация
├── appsettings.Development.json       # Dev-конфигурация
├── appsettings.Production.json        # Production-конфигурация
├── web.config                         # IIS конфигурация
├── encrypt-apikey.ps1                 # Утилита шифрования ключа
├── publish.ps1                        # Скрипт публикации
├── run-server.ps1                     # Скрипт запуска
├── Controllers/
│   ├── ServiceReqCloneController.cs   # API заявок (417 строк)
│   ├── IncidentCloneController.cs     # API инцидентов (185 строк)
│   └── DiagnosticController.cs        # Диагностика (115 строк)
├── Services/
│   ├── ServiceReqClonerService.cs     # Логика клонирования заявок (334 строки)
│   ├── IncidentClonerService.cs       # Логика клонирования инцидентов (179 строк)
│   ├── HeatApiService.cs              # HTTP-клиент HEAT (624 строки)
│   ├── EncryptionService.cs           # AES-256 шифрование (96 строк)
│   ├── MemoryHealthService.cs         # Мониторинг памяти
│   └── I*.cs                          # Интерфейсы
├── Models/
│   ├── ServiceReqModels.cs            # Модели ServiceReq (1080 строк)
│   └── IncidentModels.cs              # Модели Incident
├── Configuration/
│   └── HeatApiSettings.cs             # Настройки подключения
├── Middleware/
│   ├── RequestLoggingMiddleware.cs    # Логирование запросов
│   └── LocalhostOnlyMiddleware.cs     # Ограничение доступа
├── Converters/
│   ├── StringJsonConverter.cs
│   ├── DateTimeJsonConverter.cs
│   └── JsonConverters.cs
└── wwwroot/
    └── clone-waiting.html             # Страница ожидания клонирования
```
