<#
.SYNOPSIS
    Deploys ServiceReqCloner and Criticality to IIS with HTTPS.
.DESCRIPTION
    Creates IIS application pools, applications, and configures
    both services for production hosting under IIS with HTTPS.

    Prerequisites:
    - IIS installed with ASP.NET Core Module (ANCM)
    - Published files in .\ServiceReqCloner\publish and .\Criticality\publish
    - Administrator privileges

.PARAMETER SiteName
    IIS site name to deploy under. Default: Default Web Site
.PARAMETER InstallDir
    Physical directory for deployment. Default: C:\inetpub\ClonerSuite
.PARAMETER HttpsPort
    HTTPS binding port. Default: 443
.PARAMETER HostName
    Host name for HTTPS binding (e.g., svoivantisrv.svo.air.loc).
    If empty, binds to all hostnames.
.PARAMETER CertificateThumbprint
    Thumbprint of existing SSL certificate to use.
    If not specified, a self-signed certificate is created.
.PARAMETER CreateSelfSignedCert
    Create a self-signed certificate for HTTPS.
.PARAMETER AppPoolIdentity
    Application pool identity. Default: ApplicationPoolIdentity
.PARAMETER SkipPublish
    Skip publishing step (use existing published files).
.EXAMPLE
    .\Deploy-ToIIS.ps1
.EXAMPLE
    .\Deploy-ToIIS.ps1 -HttpsPort 443 -CreateSelfSignedCert
.EXAMPLE
    .\Deploy-ToIIS.ps1 -HostName "svoivantisrv.svo.air.loc" -CertificateThumbprint "ABCD1234..."
#>
[CmdletBinding()]
param(
    [string]$SiteName = "Default Web Site",
    [string]$InstallDir = "C:\inetpub\ClonerSuite",
    [int]$HttpsPort = 443,
    [string]$HostName = "",
    [string]$CertificateThumbprint = "",
    [switch]$CreateSelfSignedCert,
    [string]$AppPoolIdentity = "ApplicationPoolIdentity",
    [switch]$SkipPublish
)

$ErrorActionPreference = "Stop"

Write-Host ""
Write-Host "========================================================" -ForegroundColor Cyan
Write-Host " ClonerSuite - IIS HTTPS Deployment" -ForegroundColor Cyan
Write-Host "========================================================" -ForegroundColor Cyan
Write-Host "Site:        $SiteName" -ForegroundColor Yellow
Write-Host "Install Dir: $InstallDir" -ForegroundColor Yellow
Write-Host "HTTPS Port:  $HttpsPort" -ForegroundColor Yellow
if ($HostName) { Write-Host "Host Name:   $HostName" -ForegroundColor Yellow }
Write-Host ""

# Check admin rights
$isAdmin = ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $isAdmin) {
    Write-Host "ERROR: Run as Administrator" -ForegroundColor Red
    exit 1
}

# Check ASP.NET Core Module
$ancm = Get-WindowsOptionalFeature -Online -FeatureName IIS-ASPNET45 -ErrorAction SilentlyContinue
if (-not $ancm -or $ancm.State -ne "Enabled") {
    Write-Host "Installing ASP.NET Core Module..." -ForegroundColor Yellow
    Install-WindowsFeature Web-ASP -ErrorAction SilentlyContinue
}

if (-not (Get-Module -ListAvailable -Name WebAdministration)) {
    Write-Host "ERROR: IIS PowerShell module not available. Install IIS Management Tools first." -ForegroundColor Red
    exit 1
}

Import-Module WebAdministration

# Step 1: Publish if needed
if (-not $SkipPublish) {
    Write-Host ""
    Write-Host "[1/6] Publishing services..." -ForegroundColor Cyan

    Push-Location "$PSScriptRoot\ServiceReqCloner"
    & "$PSScriptRoot\ServiceReqCloner\publish.ps1" -Runtime "win-x64" -Configuration "Release"
    Pop-Location

    Write-Host ""

    Push-Location "$PSScriptRoot\Criticality"
    & "$PSScriptRoot\Criticality\publish.ps1" -Runtime "win-x64" -Configuration "Release"
    Pop-Location
}

# Step 2: Create deployment directory
Write-Host ""
Write-Host "[2/6] Creating deployment directory..." -ForegroundColor Cyan

if (-not (Test-Path $InstallDir)) {
    New-Item -Path $InstallDir -ItemType Directory -Force | Out-Null
}

Copy-Item -Path "$PSScriptRoot\ServiceReqCloner\publish\*" -Destination "$InstallDir\ServiceReqCloner" -Recurse -Force
Copy-Item -Path "$PSScriptRoot\Criticality\publish\*" -Destination "$InstallDir\Criticality" -Recurse -Force

Write-Host "Files copied to: $InstallDir" -ForegroundColor Green

# Step 3: Create application pools
Write-Host ""
Write-Host "[3/6] Creating application pools..." -ForegroundColor Cyan

$appPools = @(
    @{ Name = "ClonerServiceReqPool"; Path = "$InstallDir\ServiceReqCloner" },
    @{ Name = "ClonerCriticalityPool"; Path = "$InstallDir\Criticality" }
)

foreach ($pool in $appPools) {
    if (Test-Path "IIS:\AppPools\$($pool.Name)") {
        Write-Host "  AppPool $($pool.Name) already exists, recycling..." -ForegroundColor Gray
        Restart-WebAppPool -Name $pool.Name
    } else {
        Write-Host "  Creating AppPool: $($pool.Name)" -ForegroundColor Gray
        New-WebAppPool -Name $pool.Name -Force | Out-Null
    }

    Set-ItemProperty "IIS:\AppPools\$($pool.Name)" -Name "managedRuntimeVersion" -Value ""
    Set-ItemProperty "IIS:\AppPools\$($pool.Name)" -Name "processModel.identityType" -Value $AppPoolIdentity
    Set-ItemProperty "IIS:\AppPools\$($pool.Name)" -Name "startMode" -Value "AlwaysRunning"
    Set-ItemProperty "IIS:\AppPools\$($pool.Name)" -Name "autoStart" -Value $true
}

# Step 4: Create IIS applications
Write-Host ""
Write-Host "[4/6] Creating IIS applications..." -ForegroundColor Cyan

$apps = @(
    @{ Name = "ServiceReqCloner"; Pool = "ClonerServiceReqPool"; Path = "$InstallDir\ServiceReqCloner" },
    @{ Name = "Criticality"; Pool = "ClonerCriticalityPool"; Path = "$InstallDir\Criticality" }
)

foreach ($app in $apps) {
    $appPath = "$SiteName/$($app.Name)"

    if (Get-WebApplication -Site $SiteName -Name $app.Name -ErrorAction SilentlyContinue) {
        Write-Host "  App $($app.Name) already exists, updating..." -ForegroundColor Gray
        Remove-WebApplication -Site $SiteName -Name $app.Name
    }

    Write-Host "  Creating app: $appPath" -ForegroundColor Gray
    New-WebApplication -Site $SiteName -Name $app.Name -PhysicalPath $app.Path -ApplicationPool $app.Pool | Out-Null
}

# Step 5: Get or create SSL certificate
Write-Host ""
Write-Host "[5/6] Configuring SSL certificate..." -ForegroundColor Cyan

$cert = $null

if ($CertificateThumbprint) {
    Write-Host "  Using existing certificate: $CertificateThumbprint" -ForegroundColor Gray
    $cert = Get-ChildItem Cert:\LocalMachine\My\$CertificateThumbprint -ErrorAction SilentlyContinue
    if (-not $cert) {
        Write-Host "ERROR: Certificate not found: $CertificateThumbprint" -ForegroundColor Red
        exit 1
    }
}
elseif ($CreateSelfSignedCert) {
    $certName = $HostName
    if (-not $certName) { $certName = "localhost" }

    Write-Host "  Creating self-signed certificate for: $certName" -ForegroundColor Gray

    # Check if cert already exists
    $cert = Get-ChildItem Cert:\LocalMachine\My | Where-Object { $_.Subject -eq "CN=$certName" -and $_.FriendlyName -eq "ClonerSuite-Dev" } | Select-Object -First 1

    if (-not $cert) {
        if ($HostName) {
            $cert = New-SelfSignedCertificate -DnsName $HostName, "localhost" -CertStoreLocation Cert:\LocalMachine\My -FriendlyName "ClonerSuite-Dev"
        } else {
            $cert = New-SelfSignedCertificate -DnsName "localhost" -CertStoreLocation Cert:\LocalMachine\My -FriendlyName "ClonerSuite-Dev"
        }
        Write-Host "  Certificate created: $($cert.Thumbprint)" -ForegroundColor Green
    } else {
        Write-Host "  Certificate already exists: $($cert.Thumbprint)" -ForegroundColor Yellow
    }
}
else {
    # Find first valid cert
    $cert = Get-ChildItem Cert:\LocalMachine\My | Where-Object { $_.HasPrivateKey -and $_.NotAfter -gt (Get-Date) } | Select-Object -First 1
    if (-not $cert) {
        Write-Host "ERROR: No SSL certificate found. Use -CreateSelfSignedCert or -CertificateThumbprint" -ForegroundColor Red
        exit 1
    }
    Write-Host "  Using certificate: $($cert.Thumbprint)" -ForegroundColor Yellow
}

$CertificateThumbprint = $cert.Thumbprint

# Step 6: Configure HTTPS binding
Write-Host ""
Write-Host "[6/6] Configuring HTTPS binding on port $HttpsPort..." -ForegroundColor Cyan

$bindingParams = @{
    SiteName = $SiteName
    Protocol = "https"
    Port = $HttpsPort
    CertificateThumbPrint = $CertificateThumbprint
    CertStoreLocation = "Cert:\LocalMachine\My"
    Force = $true
}

if ($HostName) {
    $bindingParams.HostHeader = $HostName
}

$existingBinding = Get-WebBinding -Site $SiteName -Protocol "https" -Port $HttpsPort -ErrorAction SilentlyContinue
if ($existingBinding) {
    Write-Host "  Updating existing HTTPS binding..." -ForegroundColor Gray
    $existingBinding | Remove-WebBinding
}

New-WebBinding @bindingParams | Out-Null
Write-Host "  HTTPS binding created: https://$($HostName -or "*"):$HttpsPort" -ForegroundColor Green

# Remove HTTP binding if exists (force HTTPS only)
$httpBinding = Get-WebBinding -Site $SiteName -Protocol "http" -Port 80 -ErrorAction SilentlyContinue
if ($httpBinding) {
    Write-Host "  Removing HTTP binding on port 80..." -ForegroundColor Gray
    $httpBinding | Remove-WebBinding
}

# Final summary
Write-Host ""
Write-Host "========================================================" -ForegroundColor Green
Write-Host " HTTPS Deployment complete!" -ForegroundColor Green
Write-Host "========================================================" -ForegroundColor Green
Write-Host ""
Write-Host "URLs:" -ForegroundColor Cyan
$baseUrl = "https://" + ($HostName -or "localhost") + ":$HttpsPort"
Write-Host "  ServiceReqCloner:  $baseUrl/ServiceReqCloner/api/ServiceReqClone/health" -ForegroundColor White
Write-Host "  Criticality:       $baseUrl/Criticality/api/CriticalitySync/status" -ForegroundColor White
Write-Host ""
Write-Host "Certificate: $($cert.Thumbprint)" -ForegroundColor Cyan
Write-Host "Valid until: $($cert.NotAfter)" -ForegroundColor Cyan
Write-Host ""
Write-Host "IIS AppPools:" -ForegroundColor Cyan
Write-Host "  ClonerServiceReqPool" -ForegroundColor White
Write-Host "  ClonerCriticalityPool" -ForegroundColor White
Write-Host ""
Write-Host "Files: $InstallDir" -ForegroundColor Cyan
Write-Host ""
