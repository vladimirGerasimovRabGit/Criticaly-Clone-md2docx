#!/usr/bin/env python3
import re

with open('/workspace/Criticality-Technical-Specification.md', 'r') as f:
    lines = f.read().split('\n')

i = 0
list_num = 0

while i < len(lines):
    stripped = lines[i].strip()
    
    if stripped.startswith('- [ ]') or stripped.startswith('- ') or re.match(r'^\d+\.\s+', stripped):
        list_items = []
        is_numbered = False
        
        while i < len(lines):
            line_stripped = lines[i].strip()
            
            if not line_stripped:
                i += 1
                continue
            
            # Заголовок ### или ## — конец списка
            if line_stripped.startswith('###') or line_stripped.startswith('##'):
                break
            
            if line_stripped.startswith('```'):
                i += 1  # Пропускаем открывающий ```
                while i < len(lines) and not lines[i].strip().startswith('```'):
                    i += 1
                i += 1  # Пропускаем закрывающий ```
                continue
            
            if line_stripped.startswith('|'):
                break
            
            if line_stripped.startswith('- [ ]'):
                if not is_numbered:
                    list_items.append(line_stripped[5:].strip())
                i += 1
            elif line_stripped.startswith('- '):
                # Маркированный внутри нумерованного — пропускаем
                if not is_numbered:
                    list_items.append(line_stripped[2:].strip())
                i += 1
            elif re.match(r'^\d+\.\s+', line_stripped):
                is_numbered = True
                list_items.append(re.sub(r'^\d+\.\s+', '', line_stripped))
                i += 1
            else:
                break
        
        if is_numbered:
            list_num += 1
            print(f'Список #{list_num}: {len(list_items)} элементов')
            print(f'  Первый: {list_items[0][:40]}')
            if len(list_items) > 1:
                print(f'  Последний: {list_items[-1][:40]}')
    else:
        i += 1

print(f'\nВсего нумерованных списков: {list_num}')
