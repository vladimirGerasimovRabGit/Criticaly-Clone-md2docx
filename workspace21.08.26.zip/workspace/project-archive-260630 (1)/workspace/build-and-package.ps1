<#
.SYNOPSIS
    Builds and packages ClonerSuite for offline deployment.
.DESCRIPTION
    Run this script on a machine WITH internet access.
    It will download NuGet packages, build, publish, and create
    a self-contained deployment package (without .NET runtime)
    that can be transferred to the target machine.

    The target machine must have .NET 8 Runtime installed.
.PARAMETER OutputZip
    Path to the output ZIP file. Default: .\ClonerSuite-Deploy.zip
.PARAMETER IncludeSource
    Include source code in the package.
.PARAMETER IncludeApiKeyEncryptor
    Include the API key encryption tool.
.EXAMPLE
    .\build-and-package.ps1
.EXAMPLE
    .\build-and-package.ps1 -OutputZip "D:\ClonerSuite-v1.0.zip" -IncludeApiKeyEncryptor
#>
[CmdletBinding()]
param(
    [string]$OutputZip = ".\ClonerSuite-Deploy.zip",
    [switch]$IncludeSource,
    [switch]$IncludeApiKeyEncryptor
)

$ErrorActionPreference = "Stop"
$buildDir = Join-Path $PSScriptRoot "build-output"

Write-Host ""
Write-Host "========================================================" -ForegroundColor Cyan
Write-Host " ClonerSuite - Build and Package for Offline Deploy" -ForegroundColor Cyan
Write-Host "========================================================" -ForegroundColor Cyan
Write-Host "Output: $OutputZip" -ForegroundColor Yellow
Write-Host ""

# Step 1: Clean previous build
Write-Host "[1/6] Cleaning previous build..." -ForegroundColor Cyan
if (Test-Path $buildDir) {
    Remove-Item -Recurse -Force $buildDir
}
New-Item -Path $buildDir -ItemType Directory | Out-Null

# Step 2: Restore NuGet packages
Write-Host ""
Write-Host "[2/6] Restoring NuGet packages..." -ForegroundColor Cyan

Push-Location "$PSScriptRoot\ServiceReqCloner"
dotnet restore
Pop-Location

Push-Location "$PSScriptRoot\Criticality"
dotnet restore
Pop-Location

Write-Host "  Done." -ForegroundColor Green

# Step 3: Publish ServiceReqCloner
Write-Host ""
Write-Host "[3/6] Publishing ServiceReqCloner..." -ForegroundColor Cyan

$srcPublish = Join-Path $buildDir "ServiceReqCloner"
dotnet publish "$PSScriptRoot\ServiceReqCloner\ServiceReqCloner.csproj" `
    -c Release `
    -r win-x64 `
    --self-contained false `
    -o $srcPublish

Write-Host "  Published to: $srcPublish" -ForegroundColor Green

# Step 4: Publish Criticality
Write-Host ""
Write-Host "[4/6] Publishing Criticality..." -ForegroundColor Cyan

$critPublish = Join-Path $buildDir "Criticality"
dotnet publish "$PSScriptRoot\Criticality\Criticality.csproj" `
    -c Release `
    -r win-x64 `
    --self-contained false `
    -o $critPublish

Write-Host "  Published to: $critPublish" -ForegroundColor Green

# Step 5: Copy configs and run scripts
Write-Host ""
Write-Host "[5/6] Copying configurations and scripts..." -ForegroundColor Cyan

# Copy appsettings files
Copy-Item "$PSScriptRoot\ServiceReqCloner\appsettings*.json" -Destination $srcPublish -Force
Copy-Item "$PSScriptRoot\Criticality\appsettings*.json" -Destination $critPublish -Force

# Copy web.config for IIS
if (Test-Path "$PSScriptRoot\ServiceReqCloner\web.config") {
    Copy-Item "$PSScriptRoot\ServiceReqCloner\web.config" -Destination $srcPublish -Force
}
if (Test-Path "$PSScriptRoot\Criticality\web.config") {
    Copy-Item "$PSScriptRoot\Criticality\web.config" -Destination $critPublish -Force
}

# Create run.bat for ServiceReqCloner
$srcBat = @"
@echo off
echo.
echo ============================================
echo  ServiceReqCloner API - Starting
echo ============================================
echo.
echo Environment: %ASPNETCORE_ENVIRONMENT%
echo.
set ASPNETCORE_ENVIRONMENT=Development
ServiceReqCloner.exe
pause
"@
$srcBat | Out-File -FilePath "$srcPublish\run.bat" -Encoding ASCII

# Create run.bat for Criticality
$critBat = @"
@echo off
echo.
echo ============================================
echo  Criticality API - Starting
echo ============================================
echo.
echo Environment: %ASPNETCORE_ENVIRONMENT%
echo.
set ASPNETCORE_ENVIRONMENT=Development
Criticality.exe
pause
"@
$critBat | Out-File -FilePath "$critPublish\run.bat" -Encoding ASCII

# Copy API key encryptor if requested
if ($IncludeApiKeyEncryptor) {
    $encryptDest = Join-Path $buildDir "tools\ApiKeyEncryptor"
    New-Item -Path $encryptDest -ItemType Directory -Force | Out-Null

    Copy-Item "$PSScriptRoot\tools\ApiKeyEncryptor\*.cs" -Destination $encryptDest -Force
    Copy-Item "$PSScriptRoot\tools\ApiKeyEncryptor\*.csproj" -Destination $encryptDest -Force

    # Build the encryptor
    Write-Host "  Building ApiKeyEncryptor..." -ForegroundColor Gray
    dotnet publish "$encryptDest\ApiKeyEncryptor.csproj" `
        -c Release `
        -r win-x64 `
        --self-contained false `
        -o "$encryptDest\publish"

    Write-Host "  Done." -ForegroundColor Green
}

# Copy source if requested
if ($IncludeSource) {
    $srcDest = Join-Path $buildDir "src"
    robocopy "$PSScriptRoot" $srcDest *.cs *.csproj *.sln *.json *.ps1 *.sh *.md *.bat /S /XF *.dll *.exe *.pdb /XD bin obj publish build-output .git /NFL /NDL /NJH /NJS /NC /NS /NP
}

# Step 6: Create ZIP
Write-Host ""
Write-Host "[6/6] Creating deployment package..." -ForegroundColor Cyan

if (Test-Path $OutputZip) {
    Remove-Item -Force $OutputZip
}

Compress-Archive -Path "$buildDir\*" -DestinationPath $OutputZip -Force

# Cleanup
Remove-Item -Recurse -Force $buildDir

# Summary
$packageSize = [math]::Round((Get-Item $OutputZip).Length / 1MB, 2)

Write-Host ""
Write-Host "========================================================" -ForegroundColor Green
Write-Host " Package created!" -ForegroundColor Green
Write-Host "========================================================" -ForegroundColor Green
Write-Host ""
Write-Host "File: $OutputZip" -ForegroundColor Yellow
Write-Host "Size: $packageSize MB" -ForegroundColor Yellow
Write-Host ""
Write-Host "=== Deployment Instructions ===" -ForegroundColor Cyan
Write-Host ""
Write-Host "1. Transfer $OutputZip to the target machine" -ForegroundColor White
Write-Host "2. Extract to any folder (e.g., C:\ClonerSuite)" -ForegroundColor White
Write-Host "3. Install .NET 8 Runtime if not installed:" -ForegroundColor White
Write-Host "   https://dotnet.microsoft.com/download/dotnet/8.0" -ForegroundColor Gray
Write-Host "   File: dotnet-runtime-8.x.x-win-x64.exe" -ForegroundColor Gray
Write-Host "4. Run services:" -ForegroundColor White
Write-Host "   cd ServiceReqCloner" -ForegroundColor Gray
Write-Host "   run.bat" -ForegroundColor Gray
Write-Host ""
Write-Host "   cd Criticality" -ForegroundColor Gray
Write-Host "   run.bat" -ForegroundColor Gray
Write-Host ""
if ($IncludeApiKeyEncryptor) {
    Write-Host "5. Encrypt API key (optional):" -ForegroundColor White
    Write-Host "   cd tools\ApiKeyEncryptor\publish" -ForegroundColor Gray
    Write-Host "   ApiKeyEncryptor.exe `"your-api-key`" `"your-password`"" -ForegroundColor Gray
    Write-Host ""
}
Write-Host "=== URLs (after start) ===" -ForegroundColor Cyan
Write-Host "  ServiceReqCloner:  http://localhost:7101/api/ServiceReqClone/health" -ForegroundColor White
Write-Host "  Criticality:       http://localhost:7102/api/CriticalitySync/status" -ForegroundColor White
Write-Host ""
