# Deploy-Criticality.ps1
# Скрипт развёртывания Criticality в IIS
# Запуск: powershell -ExecutionPolicy Bypass -File Deploy-Criticality.ps1

param(
    [string]$SourcePath = "C:\workspace",
    [string]$InstallPath = "C:\ClonerSuite\Criticality",
    [int]$HttpPort = 7102,
    [int]$HttpsPort = 7103
)

$ErrorActionPreference = "Stop"
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  Criticality IIS Deployment" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# Проверка прав администратора
$isAdmin = ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $isAdmin) {
    Write-Host "[FAIL] Запустите от имени администратора!" -ForegroundColor Red
    exit 1
}

# 1. Создание директорий
Write-Host "1. Создание директорий..." -ForegroundColor Cyan
$dirs = @(
    $InstallPath,
    "$InstallPath\publish-iis",
    "$InstallPath\logs"
)

foreach ($dir in $dirs) {
    if (-not (Test-Path $dir)) {
        New-Item -ItemType Directory -Path $dir -Force | Out-Null
        Write-Host "  [OK] Создано: $dir" -ForegroundColor Green
    } else {
        Write-Host "  [INFO] Существует: $dir" -ForegroundColor Yellow
    }
}

# 2. Копирование файлов публикации
Write-Host ""
Write-Host "2. Копирование файлов публикации..." -ForegroundColor Cyan

$sourcePath = "$SourcePath\Criticality\publish"

if (Test-Path $sourcePath) {
    Copy-Item "$sourcePath\*" -Destination "$InstallPath\publish-iis" -Recurse -Force
    $fileCount = (Get-ChildItem "$InstallPath\publish-iis" -File | Measure-Object).Count
    Write-Host "  [OK] Скопировано файлов: $fileCount" -ForegroundColor Green
} else {
    Write-Host "  [WARN] Исходная папка не найдена: $sourcePath" -ForegroundColor Yellow
    Write-Host "  >>> Скопируйте файлы вручную из Criticality\publish\" -ForegroundColor Gray
}

# 3. Проверка файлов
Write-Host ""
Write-Host "3. Проверка файлов..." -ForegroundColor Cyan

$requiredFiles = @(
    "Criticality.dll",
    "web.config",
    "appsettings.json",
    "appsettings.Production.json"
)

foreach ($file in $requiredFiles) {
    $filePath = "$InstallPath\publish-iis\$file"
    if (Test-Path $filePath) {
        $size = (Get-Item $filePath).Length / 1KB
        Write-Host "  [OK] $file ($([math]::Round($size, 1)) KB)" -ForegroundColor Green
    } else {
        Write-Host "  [FAIL] Не найден: $file" -ForegroundColor Red
    }
}

# 4. Создание Application Pool
Write-Host ""
Write-Host "4. Создание Application Pool..." -ForegroundColor Cyan

try {
    Import-Module WebAdministration -ErrorAction Stop
    
    $poolName = "CriticalityAppPool"
    $existing = Get-WebAppPoolState -Name $poolName -ErrorAction SilentlyContinue
    
    if ($existing) {
        Write-Host "  [INFO] AppPool '$poolName' существует" -ForegroundColor Yellow
    } else {
        New-WebAppPool -Name $poolName | Out-Null
        Set-ItemProperty "IIS:\AppPools\$poolName" -Name "managedRuntimeVersion" -Value ""
        Set-ItemProperty "IIS:\AppPools\$poolName" -Name "managedPipelineMode" -Value "Integrated"
        Set-ItemProperty "IIS:\AppPools\$poolName" -Name "startMode" -Value "AlwaysRunning"
        Set-ItemProperty "IIS:\AppPools\$poolName" -Name "autoStart" -Value "True"
        Write-Host "  [OK] AppPool '$poolName' создан" -ForegroundColor Green
    }
} catch {
    Write-Host "  [FAIL] WebAdministration недоступен" -ForegroundColor Red
    Write-Host "  >>> Установите: Add-WindowsFeature Web-Mgmt-Console" -ForegroundColor Yellow
    exit 1
}

# 5. Создание сайта IIS
Write-Host ""
Write-Host "5. Создание сайта IIS..." -ForegroundColor Cyan

try {
    Import-Module WebAdministration -ErrorAction Stop
    
    $siteName = "Criticality"
    $existing = Get-Website -Name $siteName -ErrorAction SilentlyContinue
    
    if ($existing) {
        Write-Host "  [INFO] Сайт '$siteName' существует (HTTP $HttpPort, HTTPS $HttpsPort)" -ForegroundColor Yellow
    } else {
        # Создание HTTP сайта
        New-Website -Name $siteName -Port $HttpPort -PhysicalPath "$InstallPath\publish-iis" -ApplicationPool $poolName | Out-Null
        Write-Host "  [OK] Сайт '$siteName' создан (HTTP $HttpPort, HTTPS $HttpsPort)" -ForegroundColor Green
        
        # Примечание: HTTPS требует отдельной настройки с SSL сертификатом
        Write-Host "  [INFO] Для HTTPS настройте SSL binding в IIS Manager" -ForegroundColor Cyan
    }
} catch {
    Write-Host "  [FAIL] Не удалось создать сайт" -ForegroundColor Red
    Write-Host "  >>> Создайте вручную через IIS Manager" -ForegroundColor Yellow
}

# 6. Настройка прав доступа
Write-Host ""
Write-Host "6. Настройка прав доступа..." -ForegroundColor Cyan

$aclPaths = @(
    "$InstallPath\logs",
    "$InstallPath\publish-iis"
)

foreach ($path in $aclPaths) {
    if (Test-Path $path) {
        try {
            $acl = Get-Acl $path
            $rule = New-Object System.Security.AccessControl.FileSystemAccessRule("IIS_IUSRS", "Modify", "ContainerInherit,ObjectInherit", "None", "Allow")
            $acl.AddAccessRule($rule)
            Set-Acl $path $acl
            Write-Host "  [OK] Права IIS_IUSRS на $path" -ForegroundColor Green
        } catch {
            Write-Host "  [WARN] Не удалось настроить права на $path" -ForegroundColor Yellow
        }
    }
}

# 7. Перезапуск AppPool
Write-Host ""
Write-Host "7. Перезапуск Application Pool..." -ForegroundColor Cyan

try {
    Restart-WebAppPool -Name $poolName
    Write-Host "  [OK] $poolName перезапущен" -ForegroundColor Green
} catch {
    Write-Host "  [WARN] Не удалось перезапустить AppPool" -ForegroundColor Yellow
}

# 8. Финальная проверка
Write-Host ""
Write-Host "8. Финальная проверка..." -ForegroundColor Cyan

Write-Host ""
$poolState = Get-WebAppPoolState -Name $poolName -ErrorAction SilentlyContinue
Write-Host "  Application Pool:" -ForegroundColor Cyan
Write-Host "    $poolName`: $($poolState.State)" -ForegroundColor Green

Write-Host ""
$site = Get-Website -Name $siteName -ErrorAction SilentlyContinue
if ($site) {
    $bindings = $site.Bindings.Collection.bindingInformation -join ", "
    Write-Host "  Сайт:" -ForegroundColor Cyan
    Write-Host "    $siteName`: $($site.State) (HTTP $HttpPort)" -ForegroundColor Green
    Write-Host "    Bindings: $bindings" -ForegroundColor Cyan
}

Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  Criticality развёртывание завершено!" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "Проверка доступности:" -ForegroundColor Cyan
Write-Host "  http://localhost:$HttpPort/" -ForegroundColor White
Write-Host "  http://localhost:$HttpPort/health" -ForegroundColor White
Write-Host ""
Write-Host "Нажмите Enter для выхода..." -ForegroundColor Gray
Read-Host
