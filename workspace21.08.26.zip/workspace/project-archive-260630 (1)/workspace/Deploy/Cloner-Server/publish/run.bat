@echo off
echo.
echo ============================================
echo  ServiceReqCloner API - Starting
echo ============================================
echo.
echo Environment: %ASPNETCORE_ENVIRONMENT%
echo.
set ASPNETCORE_ENVIRONMENT=Development
ServiceReqCloner.exe
pause
