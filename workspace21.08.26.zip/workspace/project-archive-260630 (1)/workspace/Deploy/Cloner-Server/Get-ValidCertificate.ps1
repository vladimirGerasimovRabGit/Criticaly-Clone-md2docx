# Get-ValidCertificate.ps1
# Скрипт поиска и получения информации о валидных SSL сертификатах
# Запуск: powershell -ExecutionPolicy Bypass -File Get-ValidCertificate.ps1

param(
    [string]$SubjectFilter = "",
    [switch]$AllStores,
    [switch]$ExportThumbprint
)

$ErrorActionPreference = "Stop"

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  SSL Certificate Finder" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# Поиск сертификатов
$certs = @()

# Локальное хранилище компьютера (Personal)
try {
    $certs += Get-ChildItem Cert:\LocalMachine\My | Where-Object {
        $_.HasPrivateKey -and $_.NotAfter -gt (Get-Date)
    }
} catch {
    Write-Host "[WARN] Не удалось прочитать Cert:\LocalMachine\My" -ForegroundColor Yellow
}

# Все хранилища (если указано)
if ($AllStores) {
    try {
        $certs += Get-ChildItem Cert:\LocalMachine\Root | Where-Object {
            $_.HasPrivateKey -and $_.NotAfter -gt (Get-Date)
        }
    } catch {}
    
    try {
        $certs += Get-ChildItem Cert:\LocalMachine\CA | Where-Object {
            $_.HasPrivateKey -and $_.NotAfter -gt (Get-Date)
        }
    } catch {}
}

# Фильтрация по Subject
if ($SubjectFilter) {
    $certs = $certs | Where-Object { $_.Subject -match $SubjectFilter }
}

# Сортировка по дате окончания (ближайшие сначала)
$certs = $certs | Sort-Object NotAfter

if ($certs.Count -eq 0) {
    Write-Host "[FAIL] Валидные сертификаты не найдены!" -ForegroundColor Red
    Write-Host ""
    Write-Host "Возможные решения:" -ForegroundColor Cyan
    Write-Host "  1. Установите SSL сертификат" -ForegroundColor White
    Write-Host "  2. Проверьте другое хранилище: Get-ChildItem Cert:\LocalMachine -Recurse" -ForegroundColor White
    Write-Host "  3. Создайте самоподписанный сертификат (для тестов):" -ForegroundColor White
    Write-Host "     New-SelfSignedCertificate -DnsName 'localhost' -CertStoreLocation Cert:\LocalMachine\My" -ForegroundColor Gray
    exit 1
}

Write-Host "Найдено валидных сертификатов: $($certs.Count)" -ForegroundColor Green
Write-Host ""

# Вывод информации о сертификатах
$index = 0
foreach ($cert in $certs) {
    $index++
    $daysLeft = ($cert.NotAfter - (Get-Date)).Days
    
    Write-Host "========================================" -ForegroundColor Cyan
    Write-Host " _CERTIFICATE_#$index" -ForegroundColor White
    Write-Host "========================================" -ForegroundColor Cyan
    Write-Host ""
    Write-Host "  Subject:        $($cert.Subject)" -ForegroundColor White
    Write-Host "  Issuer:         $($cert.Issuer)" -ForegroundColor White
    Write-Host "  Thumbprint:     $($cert.Thumbprint)" -ForegroundColor Yellow
    Write-Host "  Valid From:     $($cert.NotBefore.ToString('yyyy-MM-dd'))" -ForegroundColor White
    Write-Host "  Valid To:       $($cert.NotAfter.ToString('yyyy-MM-dd'))" -ForegroundColor White
    Write-Host "  Days Left:      $daysLeft" -ForegroundColor $(if ($daysLeft -lt 30) { "Red" } elseif ($daysLeft -lt 90) { "Yellow" } else { "Green" })
    Write-Host "  Has Private Key: $($cert.HasPrivateKey)" -ForegroundColor White
    Write-Host "  Friendly Name:  $($cert.FriendlyName)" -ForegroundColor White
    Write-Host ""
    
    # DNS имена (SAN)
    $dnsNames = @()
    try {
        $extensions = $cert.Extensions | Where-Object { $_.Oid.Value -eq "2.5.29.17" }
        if ($extensions) {
            $dnsNames = $extensions.Format($true) -split ", " | Where-Object { $_ -match "DNS=" }
        }
    } catch {}
    
    if ($dnsNames.Count -gt 0) {
        Write-Host "  DNS Names (SAN):" -ForegroundColor White
        foreach ($dns in $dnsNames) {
            Write-Host "    $($dns -replace 'DNS=', '')" -ForegroundColor Gray
        }
        Write-Host ""
    }
    
    # Рекомендуемое использование
    $isSelfSigned = $cert.Subject -eq $cert.Issuer
    $isLocalhost = $cert.Subject -match "localhost|127\.0\.0\.1"
    
    Write-Host "  Recommendation:" -ForegroundColor Cyan
    if ($isSelfSigned) {
        Write-Host "    ⚠️  Самоподписанный сертификат (только для тестов)" -ForegroundColor Yellow
    } elseif ($isLocalhost) {
        Write-Host "    ℹ️  Localhost сертификат (для локальной разработки)" -ForegroundColor Gray
    } else {
        Write-Host "    ✓  Подходит для продакшена" -ForegroundColor Green
    }
    Write-Host ""
}

# Экспорт thumbprint для appsettings
if ($ExportThumbprint -and $certs.Count -gt 0) {
    Write-Host "========================================" -ForegroundColor Cyan
    Write-Host "  Для appsettings.Production.json:" -ForegroundColor Cyan
    Write-Host "========================================" -ForegroundColor Cyan
    Write-Host ""
    
    foreach ($cert in $certs) {
        $subject = $cert.Subject -replace "CN=", "" -replace ".*CN=([^,]+).*", '$1'
        $thumbprint = $cert.Thumbprint -replace " ", ""
        
        Write-Host "  # Для $($subject):" -ForegroundColor Gray
        Write-Host "  `"Kestrel`": {" -ForegroundColor White
        Write-Host "    `"Endpoints`": {" -ForegroundColor White
        Write-Host "      `"Https`": {" -ForegroundColor White
        Write-Host "        `"Certificate`": {" -ForegroundColor White
        Write-Host "          `"Subject`": `"$subject`"," -ForegroundColor Yellow
        Write-Host "          `"Thumbprint`": `"$thumbprint`"," -ForegroundColor Yellow
        Write-Host "          `"Store`": `"My`"," -ForegroundColor Yellow
        Write-Host "          `"Location`": `"LocalMachine`"" -ForegroundColor Yellow
        Write-Host "        }" -ForegroundColor White
        Write-Host "      }" -ForegroundColor White
        Write-Host "    }" -ForegroundColor White
        Write-Host "  }" -ForegroundColor White
        Write-Host ""
    }
}

# Интерактивный выбор
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  Выбор сертификата" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

if ($certs.Count -eq 1) {
    Write-Host "  Найден 1 сертификат:" -ForegroundColor Green
    Write-Host "    Subject: $($certs[0].Subject)" -ForegroundColor White
    Write-Host "    Thumbprint: $($certs[0].Thumbprint)" -ForegroundColor Yellow
    Write-Host ""
    Write-Host "  Используйте этот thumbprint в appsettings.Production.json" -ForegroundColor Cyan
} else {
    Write-Host "  Выберите сертификат по номеру (1-$($certs.Count)):" -ForegroundColor Cyan
    Write-Host ""
    
    for ($i = 0; $i -lt $certs.Count; $i++) {
        $subject = $certs[$i].Subject -replace "CN=", "" -replace ".*CN=([^,]+).*", '$1'
        $daysLeft = ($certs[$i].NotAfter - (Get-Date)).Days
        Write-Host "    [$($i+1)] $($subject) (остаётся дней: $daysLeft)" -ForegroundColor White
    }
    Write-Host ""
    
    $choice = Read-Host "  Введите номер сертификата"
    if ($choice -match "^\d+$" -and $choice -ge 1 -and $choice -le $certs.Count) {
        $selectedCert = $certs[$choice - 1]
        Write-Host ""
        Write-Host "========================================" -ForegroundColor Green
        Write-Host "  Выбранный сертификат" -ForegroundColor Green
        Write-Host "========================================" -ForegroundColor Green
        Write-Host ""
        Write-Host "  Subject:      $($selectedCert.Subject)" -ForegroundColor White
        Write-Host "  Thumbprint:   $($selectedCert.Thumbprint)" -ForegroundColor Yellow
        Write-Host "  Valid To:     $($selectedCert.NotAfter.ToString('yyyy-MM-dd'))" -ForegroundColor White
        Write-Host ""
        Write-Host "  Скопируйте Thumbprint в appsettings.Production.json:" -ForegroundColor Cyan
        Write-Host ""
        Write-Host "  `"Kestrel`": {" -ForegroundColor White
        Write-Host "    `"Endpoints`": {" -ForegroundColor White
        Write-Host "      `"Https`": {" -ForegroundColor White
        Write-Host "        `"Certificate`": {" -ForegroundColor White
        Write-Host "          `"Subject`": `"$($selectedCert.Subject -replace 'CN=', '')`"," -ForegroundColor Yellow
        Write-Host "          `"Thumbprint`": `"$($selectedCert.Thumbprint -replace ' ', '')`"," -ForegroundColor Yellow
        Write-Host "          `"Store`": `"My`"," -ForegroundColor Yellow
        Write-Host "          `"Location`": `"LocalMachine`"" -ForegroundColor Yellow
        Write-Host "        }" -ForegroundColor White
        Write-Host "      }" -ForegroundColor White
        Write-Host "    }" -ForegroundColor White
        Write-Host "  }" -ForegroundColor White
        Write-Host ""
    } else {
        Write-Host "  [WARN] Неверный выбор. Используйте первый сертификат по умолчанию." -ForegroundColor Yellow
    }
}

Write-Host ""
Write-Host "Нажмите Enter для выхода..." -ForegroundColor Gray
Read-Host
