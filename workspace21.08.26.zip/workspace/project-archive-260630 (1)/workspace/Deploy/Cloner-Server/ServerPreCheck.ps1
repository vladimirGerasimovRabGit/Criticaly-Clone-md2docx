# ServerPreCheck.ps1
# Проверка готовности IIS-сервера перед развёртыванием ClonerSuite
# Запуск: powershell -ExecutionPolicy Bypass -File ServerPreCheck.ps1
# После завершения скрипт остаётся открытым (пауза в конце)

param(
    [string]$ClonerSuitePath = "C:\ClonerSuite",
    [string]$LogPath = "$ClonerSuitePath\server-check.log"
)

# Цвета вывода
$ErrorColor = "Red"
$WarningColor = "Yellow"
$SuccessColor = "Green"
$InfoColor = "Cyan"

function Write-Status {
    param([string]$Status, [string]$Color)
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    Write-Host "[$timestamp] $Status" -ForegroundColor $Color
    if ($LogPath) {
        try {
            "[$timestamp] $Status" | Out-File -FilePath $LogPath -Append -Encoding UTF8 -ErrorAction SilentlyContinue
        } catch {}
    }
}

function Test-Admin {
    $currentUser = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
    return $currentUser.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Wait-KeyPress {
    # Универсальная пауза для разных хостов PowerShell
    Write-Host ">>> Нажмите Enter для выхода..." -ForegroundColor Gray
    $null = Read-Host
}

# Создание директории для лога
try {
    $logDir = Split-Path $LogPath -Parent
    if (-not (Test-Path $logDir)) {
        New-Item -ItemType Directory -Path $logDir -Force | Out-Null
    }
} catch {
    $LogPath = $null  # Отключаем логирование если не удалось создать папку
}

# Заголовок
Clear-Host
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  ClonerSuite Server Pre-Check" -ForegroundColor Cyan
Write-Host "  Проверка IIS-сервера" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

$checkTime = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
if ($LogPath) {
    "===== Проверка сервера: $checkTime =====" | Out-File -FilePath $LogPath -Encoding UTF8
    "" | Out-File -FilePath $LogPath -Append
}

# 1. Проверка прав администратора
Write-Host "1. Права администратора..." -ForegroundColor Cyan
if (Test-Admin) {
    Write-Status "  [OK] Запуск от имени администратора" $SuccessColor
} else {
    Write-Status "  [FAIL] Требуется запуск от имени администратора!" $ErrorColor
    Write-Host "  >>> Перезапустите PowerShell: Right-click -> Run as Administrator" -ForegroundColor Red
}

# 2. Проверка .NET Runtime
Write-Host ""
Write-Host "2. .NET Runtime..." -ForegroundColor Cyan
try {
    $dotnetOutput = dotnet --list-runtimes 2>&1
    $dotnetVersions = @("8.0", "7.0", "6.0")
    $found = $false
    
    foreach ($version in $dotnetVersions) {
        if ($dotnetOutput -match "Microsoft\.AspNetCore\.App $version") {
            $fullVersion = $matches[0] -replace "Microsoft\.AspNetCore\.App ", ""
            Write-Status "  [OK] .NET $fullVersion установлен" $SuccessColor
            $found = $true
            break
        }
    }
    
    if (-not $found) {
        Write-Status "  [FAIL] .NET 6/7/8 Runtime не найден" $ErrorColor
        Write-Host "  >>> Скачайте: https://dotnet.microsoft.com/download/dotnet/8.0" -ForegroundColor Yellow
    }
} catch {
    Write-Status "  [FAIL] dotnet CLI не найден" $ErrorColor
    Write-Host "  >>> Установите .NET SDK/Runtime" -ForegroundColor Yellow
}

# 3. Проверка IIS
Write-Host ""
Write-Host "3. Служба IIS..." -ForegroundColor Cyan
try {
    $iisStatus = Get-Service -Name "W3SVC" -ErrorAction SilentlyContinue
    if ($iisStatus) {
        $statusText = switch ($iisStatus.Status) {
            "Running" { "Работает" }
            "Stopped" { "Остановлен" }
            default { $iisStatus.Status }
        }
        Write-Status "  [OK] IIS установлен: $statusText" $SuccessColor
        
        if ($iisStatus.Status -ne "Running") {
            Write-Host "  >>> Запустите: Start-Service W3SVC" -ForegroundColor Yellow
        }
    } else {
        Write-Status "  [FAIL] IIS не установлен" $ErrorColor
        Write-Host "  >>> Установите: Install-WindowsFeature Web-Server -IncludeManagementTools" -ForegroundColor Yellow
    }
} catch {
    Write-Status "  [FAIL] Ошибка проверки IIS: $_" $ErrorColor
}

# 4. Проверка ASP.NET Core Module
Write-Host ""
Write-Host "4. ASP.NET Core Module..." -ForegroundColor Cyan
$moduleConfig = "C:\Windows\System32\inetsrv\config\applicationHost.config"
if (Test-Path $moduleConfig) {
    $config = Get-Content $moduleConfig -Raw -ErrorAction SilentlyContinue
    if ($config -match "AspNetCoreModuleV2") {
        Write-Status "  [OK] ASP.NET Core Module V2 установлен" $SuccessColor
    } elseif ($config -match "AspNetCoreModule") {
        Write-Status "  [WARN] ASP.NET Core Module V1 (рекомендуется V2)" $WarningColor
        Write-Host "  >>> Обновите до V2" -ForegroundColor Yellow
    } else {
        Write-Status "  [FAIL] ASP.NET Core Module не найден" $ErrorColor
        Write-Host "  >>> Установите: https://dotnet.microsoft.com/download/dotnet" -ForegroundColor Yellow
    }
} else {
    Write-Status "  [FAIL] applicationHost.config не найден" $ErrorColor
}

# 5. Проверка Application Pools
Write-Host ""
Write-Host "5. Application Pools..." -ForegroundColor Cyan
$appPoolsAvailable = $false
try {
    Import-Module WebAdministration -ErrorAction Stop
    $appPoolsAvailable = $true
    $requiredPools = @("ClonerSuiteAppPool", "CriticalityAppPool", "ServiceReqClonerAppPool")
    $foundCount = 0
    
    foreach ($poolName in $requiredPools) {
        $pool = Get-WebAppPoolState -Name $poolName -ErrorAction SilentlyContinue
        if ($pool) {
            Write-Status "  [OK] AppPool '$poolName': $($pool.State)" $SuccessColor
            $foundCount++
        }
    }
    
    if ($foundCount -eq 0) {
        Write-Status "  [INFO] AppPools будут созданы при развёртывании" $InfoColor
    }
} catch {
    Write-Status "  [WARN] WebAdministration недоступен (требуется IIS Management Console)" $WarningColor
    Write-Host "  >>> Установите: Add-WindowsFeature Web-Mgmt-Console" -ForegroundColor Yellow
}

# 6. Проверка сайтов IIS
Write-Host ""
Write-Host "6. Сайты IIS..." -ForegroundColor Cyan
if ($appPoolsAvailable) {
    $requiredSites = @("ClonerSuite", "Criticality", "ServiceReqCloner")
    $foundCount = 0
    
    foreach ($siteName in $requiredSites) {
        $site = Get-Website -Name $siteName -ErrorAction SilentlyContinue
        if ($site) {
            $bindings = $site.Bindings.Collection | ForEach-Object { 
                "$($_.protocol)://$($_.bindingInformation)" 
            }
            Write-Status "  [OK] Сайт '$siteName': $($site.State)" $SuccessColor
            Write-Status "    Bindings: $($bindings -join ', ')" $InfoColor
            $foundCount++
        }
    }
    
    if ($foundCount -eq 0) {
        Write-Status "  [INFO] Сайты будут созданы при развёртывании" $InfoColor
    }
} else {
    Write-Status "  [SKIP] Пропущено (WebAdministration недоступен)" $WarningColor
}

# 7. Проверка портов (80, 443)
Write-Host ""
Write-Host "7. Порты (80, 443)..." -ForegroundColor Cyan
$ports = @(80, 443)
foreach ($port in $ports) {
    try {
        $connection = Get-NetTCPConnection -LocalPort $port -ErrorAction SilentlyContinue -WarningAction SilentlyContinue | Select-Object -First 1
        if ($connection) {
            $process = Get-Process -Id $connection.OwningProcess -ErrorAction SilentlyContinue
            $processName = $process.ProcessName
            Write-Status "  [WARN] Порт $port занят: $processName" $WarningColor
            
            # Проверка, не IIS ли это
            if ($processName -eq "System" -or $processName -eq "w3wp") {
                Write-Status "    (Это IIS - OK)" $SuccessColor
            }
        } else {
            Write-Status "  [OK] Порт $port свободен" $SuccessColor
        }
    } catch {
        Write-Status "  [INFO] Не удалось проверить порт $port" $InfoColor
    }
}

# 8. Проверка SSL сертификатов
Write-Host ""
Write-Host "8. SSL сертификаты..." -ForegroundColor Cyan
try {
    $certs = Get-ChildItem Cert:\LocalMachine\My | Where-Object {
        $_.HasPrivateKey -and $_.NotAfter -gt (Get-Date)
    } | Sort-Object NotAfter -Descending
    
    if ($certs) {
        Write-Status "  [OK] Найдено $($certs.Count) валидных сертификатов" $SuccessColor
        foreach ($cert in $certs | Select-Object -First 3) {
            $subject = $cert.Subject -replace "CN=", ""
            $expiry = $cert.NotAfter.ToString("yyyy-MM-dd")
            Write-Status "    ✓ $subject (до: $expiry)" $InfoColor
        }
        
        if ($certs.Count -gt 3) {
            Write-Status "    ... и ещё $($certs.Count - 3)" $InfoColor
        }
    } else {
        Write-Status "  [WARN] SSL сертификаты не найдены" $WarningColor
        Write-Host "  >>> Для HTTPS установите сертификат" -ForegroundColor Yellow
    }
} catch {
    Write-Status "  [ERROR] Ошибка проверки сертификатов: $_" $ErrorColor
}

# 9. Проверка брандмауэра
Write-Host ""
Write-Host "9. Брандмауэр (IIS правила)..." -ForegroundColor Cyan
try {
    $fwRules = Get-NetFirewallRule -Enabled True -Direction Inbound -ErrorAction SilentlyContinue | 
        Where-Object { 
            $_.Action -eq "Allow" -and 
            ($_.DisplayName -match "IIS|HTTP|HTTPS|World Wide Web|80|443") 
        }
    
    if ($fwRules) {
        Write-Status "  [OK] Найдено $($fwRules.Count) правил для IIS" $SuccessColor
        
        # Показать ключевые правила
        $keyRules = $fwRules | Where-Object { $_.DisplayName -match "80|443|HTTP" } | Select-Object -First 3
        foreach ($rule in $keyRules) {
            Write-Status "    ✓ $($rule.DisplayName)" $InfoColor
        }
    } else {
        Write-Status "  [WARN] Правила брандмауэра для IIS не найдены" $WarningColor
        Write-Host "  >>> Проверьте: firewall.cpl" -ForegroundColor Yellow
    }
} catch {
    Write-Status "  [ERROR] Ошибка проверки брандмауэра: $_" $ErrorColor
}

# 10. Проверка прав на создание директорий
Write-Host ""
Write-Host "10. Права на создание директорий..." -ForegroundColor Cyan
$testPaths = @(
    "C:\ClonerSuite",
    "C:\inetpub\wwwroot"
)

foreach ($basePath in $testPaths) {
    try {
        $parentDir = Split-Path $basePath -Parent
        if (Test-Path $parentDir) {
            $acl = Get-Acl $parentDir -ErrorAction SilentlyContinue
            if ($acl) {
                $hasWrite = $false
                foreach ($access in $acl.Access) {
                    if ($access.FileSystemRights -match "Write|Modify|FullControl") {
                        $hasWrite = $true
                        break
                    }
                }
                if ($hasWrite) {
                    Write-Status "  [OK] Запись в $parentDir возможна" $SuccessColor
                } else {
                    Write-Status "  [WARN] Проверьте права на $parentDir" $WarningColor
                }
            }
        } else {
            Write-Status "  [INFO] $parentDir не существует" $InfoColor
        }
    } catch {
        Write-Status "  [WARN] Не удалось проверить права: $_" $WarningColor
    }
}

# 11. Проверка свободной памяти
Write-Host ""
Write-Host "11. Свободная память..." -ForegroundColor Cyan
try {
    $os = Get-CimInstance Win32_OperatingSystem
    $totalMem = [math]::Round($os.TotalVisibleMemorySize / 1MB, 2)
    $freeMem = [math]::Round($os.FreePhysicalMemory / 1MB, 2)
    $percentFree = [math]::Round(($freeMem / $totalMem) * 100, 1)
    
    Write-Status "  [OK] Всего: ${totalMem}GB, Свободно: ${freeMem}GB ($percentFree%)" $SuccessColor
    
    if ($freeMem -lt 1) {
        Write-Status "  [WARN] Мало свободной памяти (< 1GB)" $WarningColor
    }
} catch {
    Write-Status "  [INFO] Не удалось проверить память" $InfoColor
}

# 12. Проверка места на диске
Write-Host ""
Write-Host "12. Свободное место на диске C:..." -ForegroundColor Cyan
try {
    $disk = Get-PSDrive C -ErrorAction SilentlyContinue
    if ($disk) {
        $freeGB = [math]::Round($disk.Free / 1GB, 2)
        $totalGB = [math]::Round($disk.Used / 1GB + $disk.Free / 1GB, 2)
        
        Write-Status "  [OK] Всего: ${totalGB}GB, Свободно: ${freeGB}GB" $SuccessColor
        
        if ($freeGB -lt 5) {
            Write-Status "  [WARN] Мало места (< 5GB)" $WarningColor
        }
    }
} catch {
    Write-Status "  [INFO] Не удалось проверить диск" $InfoColor
}

# 13. Проверка переменных окружения
Write-Host ""
Write-Host "13. Переменные окружения..." -ForegroundColor Cyan
$envVars = @{
    "ASPNETCORE_ENVIRONMENT" = "Production (по умолчанию)"
    "DOTNET_ENVIRONMENT" = "Production (по умолчанию)"
}

foreach ($envVar in $envVars.Keys) {
    $value = [Environment]::GetEnvironmentVariable($envVar, "Machine")
    if ($value) {
        Write-Status "  [OK] $envVar = $value" $SuccessColor
    } else {
        Write-Status "  [INFO] $envVar не установлена (будет: $($envVars[$envVar]))" $InfoColor
    }
}

# 14. Проверка версии Windows
Write-Host ""
Write-Host "14. Версия Windows..." -ForegroundColor Cyan
try {
    $os = Get-CimInstance Win32_OperatingSystem
    $version = "$($os.Version)"
    $caption = $os.Caption
    
    Write-Status "  [OK] $caption (build $version)" $SuccessColor
    
    # Проверка минимальной версии для ASP.NET Core
    if ($os.Version -lt "10.0") {
        Write-Status "  [WARN] Windows Server 2016+ рекомендуется" $WarningColor
    }
} catch {
    Write-Status "  [INFO] Не удалось проверить версию Windows" $InfoColor
}

# 15. Проверка доступа в интернет (опционально)
Write-Host ""
Write-Host "15. Доступ в интернет..." -ForegroundColor Cyan
try {
    $testConn = Test-NetConnection -ComputerName www.microsoft.com -Port 443 -InformationLevel Quiet -WarningAction SilentlyContinue 2>$null
    if ($testConn) {
        Write-Status "  [OK] Доступ в интернет есть" $SuccessColor
    } else {
        Write-Status "  [INFO] Нет доступа в интернет (не критично)" $InfoColor
    }
} catch {
    Write-Status "  [INFO] Не удалось проверить интернет" $InfoColor
}

# Итоги
Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  Итоги проверки сервера" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan

# Подсчёт статистики из лога
$failCount = 0
$warnCount = 0
$okCount = 0

if ($LogPath -and (Test-Path $LogPath)) {
    $logContent = Get-Content $LogPath -Raw
    $failCount = ([regex]::Matches($logContent, "\[FAIL\]")).Count
    $warnCount = ([regex]::Matches($logContent, "\[WARN\]")).Count
    $okCount = ([regex]::Matches($logContent, "\[OK\]")).Count
}

Write-Host ""
Write-Host "  OK:     $okCount" -ForegroundColor Green
Write-Host "  WARN:   $warnCount" -ForegroundColor Yellow
Write-Host "  FAIL:   $failCount" -ForegroundColor Red
Write-Host ""

if ($LogPath -and (Test-Path $LogPath)) {
    Write-Host "  Лог: $LogPath" -ForegroundColor Cyan
}

Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan

if ($failCount -gt 0) {
    Write-Host "  [!] КРИТИЧЕСКИЕ ОШИБКИ!" -ForegroundColor Red
    Write-Host "      Устраните FAIL перед развёртыванием" -ForegroundColor Red
} elseif ($warnCount -gt 0) {
    Write-Host "  [*] Есть предупреждения" -ForegroundColor Yellow
    Write-Host "      Рекомендуется проверить WARN пункты" -ForegroundColor Yellow
} else {
    Write-Host "  [✓] Сервер готов к развёртыванию!" -ForegroundColor Green
}

Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

Wait-KeyPress
