# Get-AppPoolMemory.ps1
# Скрипт проверки всех IIS AppPool с потреблением памяти
# Запуск: powershell -ExecutionPolicy Bypass -File Get-AppPoolMemory.ps1

$ErrorActionPreference = "Stop"

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  IIS AppPool Memory Checker" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# Проверка прав администратора
$isAdmin = ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $isAdmin) {
    Write-Host "[WARN] Запуск от имени администратора рекомендуется для полной информации" -ForegroundColor Yellow
    Write-Host ""
}

try {
    Import-Module WebAdministration -ErrorAction Stop
} catch {
    Write-Host "[FAIL] WebAdministration модуль недоступен" -ForegroundColor Red
    Write-Host "  >>> Установите: Add-WindowsFeature Web-Mgmt-Console" -ForegroundColor Yellow
    exit 1
}

# Получить список worker процессов через appcmd
$wps = & C:\Windows\System32\inetsrv\appcmd.exe list wp 2>$null

if (-not $wps) {
    Write-Host "[INFO] Нет активных worker процессов" -ForegroundColor Yellow
    Write-Host ""
    Write-Host "Все AppPool:" -ForegroundColor Cyan
    $appPools = Get-Item IIS:\AppPools\*
    foreach ($pool in $appPools) {
        $state = (Get-WebAppPoolState -Name $pool.Name).State
        Write-Host "  $($pool.Name): $state" -ForegroundColor $(if ($state -eq 'Started') { 'Green' } else { 'Yellow' })
    }
    exit 0
}

# Распарсить вывод appcmd
$appPoolData = @()

foreach ($line in $wps) {
    $lineStr = $line.ToString()
    
    # Извлечь имя AppPool
    $appPool = ""
    if ($lineStr -match 'WP "([^"]+)"') {
        $appPool = $matches[1]
    } elseif ($lineStr -match 'applicationPool:([^)]+)') {
        $appPool = $matches[1]
    }
    
    # Извлечь PID
    $procId = ""
    if ($lineStr -match 'id:(\d+)') {
        $procId = $matches[1]
    } elseif ($lineStr -match '"(\d+)"') {
        $procId = $matches[1]
    }
    
    if ($procId) {
        try {
            $proc = Get-Process $procId -ErrorAction SilentlyContinue
            if ($proc) {
                $appPoolData += [PSCustomObject]@{
                    AppPool = $appPool
                    PID = $procId
                    "Memory(MB)" = [math]::Round($proc.WorkingSet / 1MB, 2)
                    "Private(MB)" = [math]::Round($proc.PrivateMemorySize / 1MB, 2)
                    "CPU(s)" = [math]::Round($proc.CPU, 2)
                    Handles = $proc.Handles
                    Threads = $proc.Threads.Count
                    StartTime = $proc.StartTime.ToString("yyyy-MM-dd HH:mm:ss")
                }
            }
        } catch {
            # Процесс не найден
        }
    }
}

# Вывод результатов
if ($appPoolData.Count -gt 0) {
    Write-Host "=== Worker Processes ($($appPoolData.Count) active) ===" -ForegroundColor Cyan
    Write-Host ""
    
    $appPoolData | Format-Table AppPool, PID, @{N="Memory(MB)";E={[math]::Round($_."Memory(MB)",2)}}, @{N="Private(MB)";E={[math]::Round($_."Private(MB)",2)}}, @{N="CPU(s)";E={[math]::Round($_."CPU(s)",2)}} -AutoSize
    
    # Сводка
    Write-Host ""
    Write-Host "=== Summary ===" -ForegroundColor Cyan
    Write-Host ""
    
    $totalMemory = ($appPoolData | Measure-Object -Property "Memory(MB)" -Sum).Sum
    $totalPrivate = ($appPoolData | Measure-Object -Property "Private(MB)" -Sum).Sum
    $totalCPU = ($appPoolData | Measure-Object -Property "CPU(s)" -Sum).Sum
    
    Write-Host "  Total Memory:     $([math]::Round($totalMemory, 2)) MB" -ForegroundColor Green
    Write-Host "  Total Private:    $([math]::Round($totalPrivate, 2)) MB" -ForegroundColor Green
    Write-Host "  Total CPU Time:   $([math]::Round($totalCPU, 2)) sec" -ForegroundColor Yellow
    Write-Host ""
    
    # Поиск highest memory consumers
    Write-Host "=== Top 3 Memory Consumers ===" -ForegroundColor Cyan
    Write-Host ""
    $appPoolData | Sort-Object "Memory(MB)" -Descending | Select-Object -First 3 | Format-Table AppPool, PID, "Memory(MB)" -AutoSize
    Write-Host ""
    
    # Проверка на возможную утечку памяти (>500 MB)
    $highMemory = $appPoolData | Where-Object { $_."Memory(MB)" -gt 500 }
    if ($highMemory.Count -gt 0) {
        Write-Host "=== Warning: High Memory Usage (>500 MB) ===" -ForegroundColor Yellow
        Write-Host ""
        $highMemory | Format-Table AppPool, PID, "Memory(MB)" -AutoSize
        Write-Host ""
    }
} else {
    Write-Host "[INFO] Нет активных worker процессов" -ForegroundColor Yellow
    Write-Host ""
    Write-Host "Все AppPool:" -ForegroundColor Cyan
    Get-WebAppPoolState | Format-Table Name, State -AutoSize
}

# Статус всех AppPool
Write-Host ""
Write-Host "=== All AppPool Status ===" -ForegroundColor Cyan
Write-Host ""

# Правильное получение списка AppPool
$appPools = Get-Item IIS:\AppPools\*
foreach ($pool in $appPools) {
    $state = (Get-WebAppPoolState -Name $pool.Name).State
    Write-Host "  $($pool.Name): $state" -ForegroundColor $(if ($state -eq 'Started') { 'Green' } else { 'Yellow' })
}

Write-Host ""
Write-Host "Нажмите Enter для выхода..." -ForegroundColor Gray
Read-Host
