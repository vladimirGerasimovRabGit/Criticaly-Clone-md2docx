# Configure-HttpsEndpoint.ps1
# Скрипт настройки HTTPS endpoint в appsettings.Production.json
# Запуск: powershell -ExecutionPolicy Bypass -File Configure-HttpsEndpoint.ps1

param(
    [string]$ConfigPath = "",
    [string]$Thumbprint = "",
    [string]$Subject = "",
    [string]$Store = "My",
    [string]$Location = "LocalMachine"
)

$ErrorActionPreference = "Stop"

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  HTTPS Endpoint Configuration" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# Поиск сертификата
$cert = $null

if ($Thumbprint) {
    Write-Host "Поиск сертификата по Thumbprint..." -ForegroundColor Cyan
    try {
        $cert = Get-ChildItem Cert:\LocalMachine\$Store | Where-Object {
            $_.Thumbprint -replace " ", "" -eq $Thumbprint -replace " ", ""
        } | Select-Object -First 1
    } catch {}
} elseif ($Subject) {
    Write-Host "Поиск сертификата по Subject..." -ForegroundColor Cyan
    try {
        $cert = Get-ChildItem Cert:\LocalMachine\$Store | Where-Object {
            $_.Subject -match $Subject -and $_.NotAfter -gt (Get-Date)
        } | Select-Object -First 1
    } catch {}
}

if (-not $cert) {
    Write-Host "[FAIL] Сертификат не найден!" -ForegroundColor Red
    Write-Host ""
    Write-Host "Запустите без параметров для интерактивного выбора:" -ForegroundColor Yellow
    Write-Host "  powershell -ExecutionPolicy Bypass -File Configure-HttpsEndpoint.ps1" -ForegroundColor Gray
    exit 1
}

Write-Host "[OK] Сертификат найден:" -ForegroundColor Green
Write-Host "  Subject:      $($cert.Subject)" -ForegroundColor White
Write-Host "  Thumbprint:   $($cert.Thumbprint)" -ForegroundColor Yellow
Write-Host "  Valid To:     $($cert.NotAfter.ToString('yyyy-MM-dd'))" -ForegroundColor White
Write-Host ""

# Проверка файла конфигурации
if (-not $ConfigPath) {
    # Автоматический поиск
    $possiblePaths = @(
        "appsettings.Production.json",
        "C:\ClonerSuite\Criticality\publish-iis\appsettings.Production.json",
        "C:\ClonerSuite\ServiceReqCloner\publish-iis\appsettings.Production.json"
    )
    
    foreach ($path in $possiblePaths) {
        if (Test-Path $path) {
            $ConfigPath = $path
            break
        }
    }
}

if (-not $ConfigPath -or -not (Test-Path $ConfigPath)) {
    Write-Host "[WARN] Файл конфигурации не найден" -ForegroundColor Yellow
    Write-Host ""
    Write-Host "Укажите путь к файлу:" -ForegroundColor Cyan
    Write-Host "  -ConfigPath `"C:\path\to\appsettings.Production.json`"" -ForegroundColor Gray
    Write-Host ""
    Write-Host "Или отредактируйте вручную:" -ForegroundColor Cyan
    Write-Host ""
}

# Генерация конфигурации Kestrel
$configJson = @"
  "Kestrel": {
    "Endpoints": {
      "Https": {
        "Certificate": {
          "Subject": "$($cert.Subject -replace 'CN=', '')",
          "Thumbprint": "$($cert.Thumbprint -replace ' ', '')",
          "Store": "$Store",
          "Location": "$Location"
        }
      }
    }
  }
"@

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  Конфигурация для appsettings.Production.json" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""
Write-Host $configJson -ForegroundColor Yellow
Write-Host ""

if ($ConfigPath -and (Test-Path $ConfigPath)) {
    Write-Host "========================================" -ForegroundColor Cyan
    Write-Host "  Обновление файла конфигурации" -ForegroundColor Cyan
    Write-Host "========================================" -ForegroundColor Cyan
    Write-Host ""
    
    $choice = Read-Host "  Обновить файл $ConfigPath? (y/n)"
    
    if ($choice -eq "y" -or $choice -eq "Y") {
        try {
            # Чтение текущего JSON
            $config = Get-Content $ConfigPath -Raw | ConvertFrom-Json
            
            # Добавление/обновление секции Kestrel
            $config.PSObject.Properties.Remove('Kestrel')
            $config | Add-Member -MemberType NoteProperty -Name 'Kestrel' -Value @{
                Endpoints = @{
                    Https = @{
                        Certificate = @{
                            Subject = $cert.Subject -replace 'CN=', ''
                            Thumbprint = $cert.Thumbprint -replace ' ', ''
                            Store = $Store
                            Location = $Location
                        }
                    }
                }
            }
            
            # Сохранение
            $config | ConvertTo-Json -Depth 10 | Out-File $ConfigPath -Encoding UTF8
            Write-Host "[OK] Файл обновлён!" -ForegroundColor Green
            Write-Host ""
            Write-Host "  Перезапустите AppPool для применения изменений:" -ForegroundColor Cyan
            Write-Host "    Restart-WebAppPool -Name `"CriticalityAppPool`"" -ForegroundColor Gray
            Write-Host "    Restart-WebAppPool -Name `"ServiceReqClonerAppPool`"" -ForegroundColor Gray
        } catch {
            Write-Host "[FAIL] Ошибка обновления файла: $_" -ForegroundColor Red
        }
    }
} else {
    Write-Host "Пример полного appsettings.Production.json:" -ForegroundColor Cyan
    Write-Host ""
    Write-Host @"
{
  "ConnectionStrings": {
    "DefaultConnectionString": "Server=<SQL_SERVER>;Database=<DB_NAME>;User Id=<USER>;Password=<PASS>;"
  },
  "Kestrel": {
    "Endpoints": {
      "Https": {
        "Certificate": {
          "Subject": "$($cert.Subject -replace 'CN=', '')",
          "Thumbprint": "$($cert.Thumbprint -replace ' ', '')",
          "Store": "My",
          "Location": "LocalMachine"
        }
      }
    }
  },
  "Logging": {
    "LogLevel": {
      "Default": "Information"
    }
  }
}
"@ -ForegroundColor White
    Write-Host ""
}

Write-Host "Нажмите Enter для выхода..." -ForegroundColor Gray
Read-Host
