# Get-AppSettingsCertificate.ps1
# Скрипт для получения thumbprint сертификата и заполнения appsettings.Production.json
# Запуск: powershell -ExecutionPolicy Bypass -File Get-AppSettingsCertificate.ps1

param(
    [string]$SubjectFilter = "svoivantiprod1.svo.air.loc",
    [string]$ConfigPath = "",
    [switch]$AutoFill
)

$ErrorActionPreference = "Stop"

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  Certificate Thumbprint Finder" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# Поиск сертификата
Write-Host "Поиск сертификата для: $SubjectFilter" -ForegroundColor Cyan
Write-Host ""

try {
    $cert = Get-ChildItem Cert:\LocalMachine\My | Where-Object {
        $_.Subject -match $SubjectFilter -and 
        $_.HasPrivateKey -and 
        $_.NotAfter -gt (Get-Date)
    } | Select-Object -First 1
} catch {
    Write-Host "[FAIL] Ошибка чтения хранилища сертификатов: $_" -ForegroundColor Red
    Write-Host ""
    Write-Host "Проверьте:" -ForegroundColor Yellow
    Write-Host "  1. Сертификат импортирован в LocalMachine\My" -ForegroundColor White
    Write-Host "  2. Запуск от имени администратора" -ForegroundColor White
    exit 1
}

if (-not $cert) {
    Write-Host "[FAIL] Сертификат не найден!" -ForegroundColor Red
    Write-Host ""
    Write-Host "Возможные причины:" -ForegroundColor Yellow
    Write-Host "  1. Сертификат не импортирован" -ForegroundColor White
    Write-Host "  2. Сертификат в другом хранилище" -ForegroundColor White
    Write-Host "  3. Сертификат истёк" -ForegroundColor White
    Write-Host ""
    Write-Host "Проверьте все сертификаты:" -ForegroundColor Cyan
    Write-Host "  Get-ChildItem Cert:\LocalMachine\My | Format-Table Subject, NotAfter, Thumbprint" -ForegroundColor Gray
    exit 1
}

# Информация о сертификате
$daysLeft = ($cert.NotAfter - (Get-Date)).Days

Write-Host "[OK] Сертификат найден!" -ForegroundColor Green
Write-Host ""
Write-Host "  Subject:     $($cert.Subject)" -ForegroundColor White
Write-Host "  Issuer:      $($cert.Issuer)" -ForegroundColor White
Write-Host "  Thumbprint:  $($cert.Thumbprint)" -ForegroundColor Yellow
Write-Host "  Valid From:  $($cert.NotBefore.ToString('yyyy-MM-dd'))" -ForegroundColor White
Write-Host "  Valid To:    $($cert.NotAfter.ToString('yyyy-MM-dd'))" -ForegroundColor White
Write-Host "  Days Left:   $daysLeft" -ForegroundColor $(if ($daysLeft -lt 30) { "Red" } elseif ($daysLeft -lt 90) { "Yellow" } else { "Green" })
Write-Host ""

# Форматированный thumbprint (без пробелов)
$thumbprintClean = $cert.Thumbprint -replace " ", ""
$subjectClean = $cert.Subject -replace "CN=", "" -replace ".*CN=([^,]+).*", '$1'

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  Для appsettings.Production.json:" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "  Скопируйте эти значения:" -ForegroundColor White
Write-Host ""
Write-Host "  CertificateSubject:  `"$subjectClean`"" -ForegroundColor Yellow
Write-Host "  CertificateThumbprint: `"$thumbprintClean`"" -ForegroundColor Yellow
Write-Host ""

# JSON для вставки
Write-Host "  Или полный JSON блок:" -ForegroundColor White
Write-Host ""
Write-Host @"
  "Server": {
    "Port": 7102,
    "UseHttps": true,
    "HttpsPort": 7103,
    "CertificateSubject": "$subjectClean",
    "CertificateThumbprint": "$thumbprintClean",
    "CertificateStore": "My",
    "CertificateLocation": "LocalMachine"
  }
"@ -ForegroundColor Gray
Write-Host ""

# Автоматическое заполнение файла
if ($AutoFill -or $ConfigPath) {
    Write-Host "========================================" -ForegroundColor Cyan
    Write-Host "  Автоматическое заполнение файла" -ForegroundColor Cyan
    Write-Host "========================================" -ForegroundColor Cyan
    Write-Host ""
    
    if (-not $ConfigPath) {
        # Автоматический поиск
        $possiblePaths = @(
            "appsettings.Production.json",
            "publish-iis\appsettings.Production.json",
            "C:\ClonerSuite\Criticality\publish-iis\appsettings.Production.json",
            "C:\ClonerSuite\ServiceReqCloner\publish-iis\appsettings.Production.json"
        )
        
        foreach ($path in $possiblePaths) {
            if (Test-Path $path) {
                $ConfigPath = $path
                break
            }
        }
    }
    
    if ($ConfigPath -and (Test-Path $ConfigPath)) {
        Write-Host "  Файл: $ConfigPath" -ForegroundColor White
        Write-Host ""
        
        $choice = Read-Host "  Автоматически заполнить CertificateSubject и CertificateThumbprint? (y/n)"
        
        if ($choice -eq "y" -or $choice -eq "Y") {
            try {
                $config = Get-Content $ConfigPath -Raw | ConvertFrom-Json
                
                # Обновление секции Server
                if ($config.Server) {
                    $config.Server.CertificateSubject = $subjectClean
                    $config.Server.CertificateThumbprint = $thumbprintClean
                } else {
                    $config | Add-Member -MemberType NoteProperty -Name 'Server' -Value @{
                        CertificateSubject = $subjectClean
                        CertificateThumbprint = $thumbprintClean
                        CertificateStore = "My"
                        CertificateLocation = "LocalMachine"
                    }
                }
                
                # Сохранение
                $config | ConvertTo-Json -Depth 10 | Out-File $ConfigPath -Encoding UTF8
                
                Write-Host "[OK] Файл обновлён!" -ForegroundColor Green
                Write-Host ""
                Write-Host "  Перезапустите AppPool для применения:" -ForegroundColor Cyan
                Write-Host "    Restart-WebAppPool -Name `"CriticalityAppPool`"" -ForegroundColor Gray
                Write-Host "    Restart-WebAppPool -Name `"ServiceReqClonerAppPool`"" -ForegroundColor Gray
            } catch {
                Write-Host "[FAIL] Ошибка обновления файла: $_" -ForegroundColor Red
            }
        }
    } else {
        Write-Host "[WARN] Файл конфигурации не найден: $ConfigPath" -ForegroundColor Yellow
    }
}

Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  Команды для проверки:" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "  # Все сертификаты в хранилище:" -ForegroundColor Gray
Write-Host "  Get-ChildItem Cert:\LocalMachine\My | Format-Table Subject, NotAfter, Thumbprint -AutoSize" -ForegroundColor Gray
Write-Host ""
Write-Host "  # Конкретный сертификат:" -ForegroundColor Gray
Write-Host "  Get-ChildItem Cert:\LocalMachine\My | Where-Object { `$_.Subject -match '$SubjectFilter' }" -ForegroundColor Gray
Write-Host ""
Write-Host "  # Экспорт thumbprint:" -ForegroundColor Gray
Write-Host "  `$cert = Get-ChildItem Cert:\LocalMachine\My | Where-Object { `$_.Subject -match '$SubjectFilter' } | Select-Object -First 1" -ForegroundColor Gray
Write-Host "  `$cert.Thumbprint -replace ' ', ''" -ForegroundColor Gray
Write-Host ""

Write-Host "Нажмите Enter для выхода..." -ForegroundColor Gray
Read-Host
