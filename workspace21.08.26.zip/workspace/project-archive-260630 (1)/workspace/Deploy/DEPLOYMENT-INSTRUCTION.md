# Инструкция по развёртыванию ClonerSuite

## Архитектура

```
┌─────────────────────────┐         ┌─────────────────────────┐
│  Сервер 1: Criticality  │         │  Сервер 2: Cloner       │
│  (проверка критичности) │         │  (клонирование заявок)  │
├─────────────────────────┤         ├─────────────────────────┤
│  Порт HTTP: 7102        │         │  Порт HTTP: 7104        │
│  Порт HTTPS: 7103       │         │  Порт HTTPS: 7105       │
│  AppPool:               │         │  AppPool:               │
│  CriticalityAppPool     │         │  ServiceReqClonerAppPool│
│                         │         │                         │
│  Путь:                  │         │  Путь:                  │
│  C:\ClonerSuite\        │         │  C:\ClonerSuite\        │
│  Criticality\           │         │  ServiceReqCloner\      │
└─────────────────────────┘         └─────────────────────────┘
```

---

## 📦 Подготовка пакетов для переноса

### На машине с интернетом:

```
G:\ClonerSuite-Deploy\
├── Criticality-Server\
│   ├── Deploy-Criticality.ps1
│   ├── ServerPreCheck.ps1
│   └── publish\                  ← файлы из C:\workspace\Criticality\publish\
│       ├── Criticality.dll
│       ├── Criticality.exe
│       ├── web.config
│       ├── appsettings.json
│       └── appsettings.Production.json
│
└── Cloner-Server\
    ├── Deploy-ServiceReqCloner.ps1
    ├── ServerPreCheck.ps1
    └── publish\                  ← файлы из C:\workspace\ServiceReqCloner\publish\
        ├── ServiceReqCloner.dll
        ├── ServiceReqCloner.exe
        ├── web.config
        ├── appsettings.json
        └── appsettings.Production.json
```

---

## 🖥️ Сервер 1: Criticality

### 1. Проверка сервера

```powershell
# Скопируйте файлы на сервер
xcopy /E /Y G:\ClonerSuite-Deploy\Criticality-Server\* C:\ClonerSuite\

# Запустите проверку
powershell -ExecutionPolicy Bypass -File C:\ClonerSuite\ServerPreCheck.ps1
```

**Ожидаемые результаты:**
- ✅ .NET Runtime установлен
- ✅ IIS работает
- ✅ ASP.NET Core Module V2 установлен
- ✅ Web-Mgmt-Console установлен

### 2. Развёртывание

```powershell
# Запустите скрипт развёртывания
powershell -ExecutionPolicy Bypass -File C:\ClonerSuite\Deploy-Criticality.ps1
```

**Скрипт выполнит:**
1. Создание директории `C:\ClonerSuite\Criticality\publish-iis\`
2. Копирование файлов публикации
3. Создание AppPool `CriticalityAppPool`
4. Создание сайта IIS на порту **7102**
5. Настройка прав для IIS_IUSRS
6. Перезапуск AppPool

### 3. Проверка

```powershell
# Проверка сайта
Get-Website -Name "Criticality"

# Проверка AppPool
Get-WebAppPoolState -Name "CriticalityAppPool"

# Тест доступности
Invoke-WebRequest -Uri http://localhost:7102/health -UseBasicParsing
```

### 4. Настройка HTTPS (опционально)

```powershell
# Поиск валидных сертификатов
powershell -ExecutionPolicy Bypass -File Get-ValidCertificate.ps1

# Настройка HTTPS endpoint
powershell -ExecutionPolicy Bypass -File Configure-HttpsEndpoint.ps1
```

**Скрипт найдёт сертификат и предложит:**
- Выбрать из доступных в хранилище
- Автоматически обновить `appsettings.Production.json`
- Показать thumbprint для ручной настройки

### 5. Настройка appsettings.Production.json

```json
{
  "ConnectionStrings": {
    "DefaultConnectionString": "Server=<SQL_SERVER>;Database=<DB_NAME>;User Id=<USER>;Password=<PASS>;"
  },
  "Logging": {
    "LogLevel": {
      "Default": "Information"
    }
  }
}
```

**Перезапустите AppPool после изменений:**
```powershell
Restart-WebAppPool -Name "CriticalityAppPool"
```

---

## 🖥️ Сервер 2: ServiceReqCloner

### 1. Проверка сервера

```powershell
# Скопируйте файлы на сервер
xcopy /E /Y G:\ClonerSuite-Deploy\Cloner-Server\* C:\ClonerSuite\

# Запустите проверку
powershell -ExecutionPolicy Bypass -File C:\ClonerSuite\ServerPreCheck.ps1
```

### 2. Развёртывание

```powershell
# Запустите скрипт развёртывания
powershell -ExecutionPolicy Bypass -File C:\ClonerSuite\Deploy-ServiceReqCloner.ps1
```

**Скрипт выполнит:**
1. Создание директории `C:\ClonerSuite\ServiceReqCloner\publish-iis\`
2. Копирование файлов публикации
3. Создание AppPool `ServiceReqClonerAppPool`
4. Создание сайта IIS на порту **7104**
5. Настройка прав для IIS_IUSRS
6. Перезапуск AppPool

### 3. Проверка

```powershell
# Проверка сайта
Get-Website -Name "ServiceReqCloner"

# Проверка AppPool
Get-WebAppPoolState -Name "ServiceReqClonerAppPool"

# Тест доступности
Invoke-WebRequest -Uri http://localhost:7104/health -UseBasicParsing
```

### 4. Настройка HTTPS (опционально)

```powershell
# Поиск валидных сертификатов
powershell -ExecutionPolicy Bypass -File Get-ValidCertificate.ps1

# Настройка HTTPS endpoint
powershell -ExecutionPolicy Bypass -File Configure-HttpsEndpoint.ps1
```

### 5. Настройка appsettings.Production.json

```json
{
  "ConnectionStrings": {
    "DefaultConnectionString": "Server=<SQL_SERVER>;Database=<DB_NAME>;User Id=<USER>;Password=<PASS>;"
  },
  "CriticalityApi": {
    "BaseUrl": "http://<CRITICALITY_SERVER>:7102"
  },
  "Logging": {
    "LogLevel": {
      "Default": "Information"
    }
  }
}
```

**Перезапустите AppPool после изменений:**
```powershell
Restart-WebAppPool -Name "ServiceReqClonerAppPool"
```

---

## 🔧 Дополнительные команды

### Перезапуск сервисов

```powershell
# Перезапустить Criticality
Restart-WebAppPool -Name "CriticalityAppPool"

# Перезапустить ServiceReqCloner
Restart-WebAppPool -Name "ServiceReqClonerAppPool"
```

### Просмотр логов

```powershell
# Criticality
Get-Content C:\ClonerSuite\Criticality\logs\app.log -Tail 50

# ServiceReqCloner
Get-Content C:\ClonerSuite\ServiceReqCloner\logs\app.log -Tail 50
```

### Открытие IIS Manager

```powershell
inetmgr
```

---

## 🌐 Доступ к сервисам

| Сервис | URL | Порт |
|--------|-----|------|
| **Criticality** | `http://<server1>:7102/` | 7102 |
| **ServiceReqCloner** | `http://<server2>:7104/` | 7104 |

---

## 🔍 Troubleshooting

### Сайт не отвечает

```powershell
# Проверка состояния
Get-Website -Name "Criticality" | Select-Object Name, State

# Проверка порта
Get-NetTCPConnection -LocalPort 5000 -ErrorAction SilentlyContinue

# Просмотр логов событий
Get-EventLog -LogName Application -Source "IIS AspNetCore Module" -Newest 10
```

### AppPool останавливается

```powershell
# Проверка identity
Get-ItemProperty "IIS:\AppPools\CriticalityAppPool" | Select-Object name, startMode, autoStart

# Проверка прав на папку
Get-Acl C:\ClonerSuite\Criticality\publish-iis | Format-List
```

### Ошибка 500.19 - Configuration Error

```powershell
# Переустановите ASP.NET Core Module
# Скачайте с https://dotnet.microsoft.com/download/dotnet
# Установите dotnet-hosting-8.0.x-win.exe
```

---

## 📁 Файлы для переноса

| Файл | Сервер 1 (Criticality) | Сервер 2 (Cloner) |
|------|------------------------|-------------------|
| `ServerPreCheck.ps1` | ✅ | ✅ |
| `Deploy-Criticality.ps1` | ✅ | ❌ |
| `Deploy-ServiceReqCloner.ps1` | ❌ | ✅ |
| `Get-ValidCertificate.ps1` | ✅ | ✅ |
| `Configure-HttpsEndpoint.ps1` | ✅ | ✅ |
| `publish\Criticality.*` | ✅ | ❌ |
| `publish\ServiceReqCloner.*` | ❌ | ✅ |
| `appsettings.Production.json` | ✅ (настроить) | ✅ (настроить) |
