# ClonerSuite Criticality

Сервис проверки критичности | SVO | Июнь 2026

---

## 1. Термины и аббревиатуры

- **CI (Configuration Item)** — конфигурационная единица
- **ISM (Ivanti Service Manager)** — система управления ИТ-услугами
- **API (Application Programming Interface)** — программный интерфейс приложения
- **HTTPS (HTTP Secure)** — защищённая версия протокола HTTP
- **TLS (Transport Layer Security)** — криптографический протокол
- **AppPool (Application Pool)** — пул приложений IIS
- **RecID (Record ID)** — уникальный идентификатор записи в ISM

---

## 2. Назначение документа

Настоящий документ описывает техническую архитектуру, конфигурацию и эксплуатацию сервиса ClonerSuite Criticality. Документ предназначен для администраторов системы, разработчиков и инженеров технической поддержки.

---

## 3. Общие сведения

ClonerSuite Criticality — сервис для проверки и синхронизации критичности конфигурационных единиц (CI) в Ivanti Service Manager (ISM). Сервис обеспечивает автоматическую синхронизацию данных об устройствах с обновлением статуса и атрибутов CI.

### 3.1. Назначение сервиса

Сервис Criticality решает следующие задачи:

- Автоматическая синхронизация устройств в ISM
- Обновление статуса и атрибутов CI при изменении данных
- Отслеживание удалённых устройств и перевод CI в статус Retired
- Ведение журнала синхронизации для аудита и отладки

### 3.2. Основные возможности

| Функция | Описание | Метод |
|---------|----------|-------|
| Инкрементная синхронизация | Загрузка только изменённых устройств | last_updated курсор |
| Пакетная обработка | Обработка устройств группами (batch) | batch_size ≤ 500 |
| Маппинг статусов | Преобразование статусов Active/Planned/Staged | Статусы CI |
| Шифрование API ключа | Хранение токена в зашифрованном виде | AES encryption |
| Протоколирование | Логирование всех операций | Serilog + файлы |

---

## 4. Архитектура системы

Сервис Criticality работает в составе ClonerSuite и взаимодействует с ISM.

### 4.1. Компоненты сервиса

- **Criticality.exe** — исполняемый файл ASP.NET Core приложения
- **web.config** — конфигурация IIS и ASP.NET Core Module V2
- **appsettings.Production.json** — настройки подключения и синхронизации
- **logs/** — директория для файлов журнала (app.log, stdout*.txt)

### 4.2. Взаимодействие с внешними системами

Сервис Criticality взаимодействует со следующими системами:

| Система | Назначение | Протокол | Порт |
|---------|------------|----------|------|
| IIS | Хостинг сервиса | HTTP.sys | 7102/7103 |
| ISM Database | Хранилище данных CI | TDS (MSSQL) | 1433 |

### 4.3. Потоки данных

- **Поток 1: Создание и обновление CI** — выборка устройств по last_updated
- **Поток 2: Удаление CI** — выборка событий удаления из object-changes

Оба потока используют инкрементальную загрузку методом скользящего окна на основе времени изменения данных.

---

## 5. Конфигурация

### 5.1. Структура конфигурационных файлов

```
C:\ClonerSuite\Criticality\
├── publish-iis/
│   ├── Criticality.exe
│   ├── Criticality.dll
│   ├── web.config
│   ├── appsettings.json
│   └── appsettings.Production.json
└── logs/
    ├── app.log
    └── stdout*.txt
```

### 5.2. Параметры подключения к ISM

| Параметр | Описание | Требуется |
|----------|----------|-----------|
| BaseUrl | URL API ISM | Да |
| EncryptedApiKey | Зашифрованный токен доступа | Да |
| EncryptionKey | Ключ дешифрования токена | Да |
| TimeoutSeconds | Таймаут запросов (сек) | Нет (60) |
| DefaultUser | Пользователь по умолчанию | Нет |

### 5.3. Настройки сервера

| Параметр | Значение | Описание |
|----------|----------|----------|
| Port | 7102 | Порт HTTP |
| UseHttps | true | Включить HTTPS |
| HttpsPort | 7103 | Порт HTTPS |
| CertificateThumbprint | D20F89216A25C85F84FAA0B9E0DC37A496C61F72 | Отпечаток сертификата |
| CertificateStore | My | Хранилище сертификатов |
| CertificateLocation | LocalMachine | Расположение хранилища |

### 5.4. Параметры синхронизации

| Параметр | Значение | Описание |
|----------|----------|----------|
| batch_size | ≤ 500 | Макс. число устройств за цикл |
| Интервал | 15 мин | Период запуска синхронизации |
| last_sync | datetime | Время последней синхронизации |

---

## 6. API сервиса

### 6.1. Конечные точки (Endpoints)

| Метод | URL | Описание |
|-------|-----|----------|
| GET | `/api/CriticalitySync/status` | Получить статус синхронизации |
| POST | `/api/CriticalitySync/start` | Запустить синхронизацию |
| POST | `/api/CriticalitySync/reset` | Сбросить статус |

### 6.2. Формат запросов

#### Получить статус

```http
GET http://<host>:7102/api/CriticalitySync/status
Accept: application/json
```

**Ответ:**
```json
{
  "lastProcessedRecId": "0FB037DA3CE6404F896B41477360E678",
  "isCompleted": true,
  "lastRunTime": "2026-06-02T16:41:52.0171723Z"
}
```

#### Запустить синхронизацию

```http
POST http://<host>:7102/api/CriticalitySync/start
Content-Type: application/json
```

**Ответ:**
```json
{
  "success": true,
  "message": "Processed 17 CIs.",
  "processedCount": 17,
  "lastProcessedRecId": "0FB037DA3CE6404F896B41477360E678",
  "isCompleted": false,
  "elapsedTime": "00:00:35.3222388"
}
```

---

## 7. Логирование и мониторинг

### 7.1. Расположение логов

```
C:\ClonerSuite\Criticality\publish-iis\logs\
├── app.log              — журнал приложения (Serilog)
└── stdout*.txt          — вывод ASP.NET Core (ошибки запуска)
```

### 7.2. Формат записей журнала

```
{Timestamp:yyyy-MM-dd HH:mm:ss.fff zzz} [{Level:u3}] {Message:lj}{NewLine}{Exception}
```

### 7.3. Уровни логирования

| Уровень | Код | Описание |
|---------|-----|----------|
| Information | INF | Штатные события работы |
| Warning | WRN | Предупреждения (не критично) |
| Error | ERR | Ошибки выполнения |
| Debug | DBG | Отладочная информация (отключено) |

### 7.4. Протоколируемые события

- Старт и завершение службы Criticality
- Запуск и завершение цикла синхронизации
- Количество обработанных устройств (processedCount)
- Время выполнения синхронизации (elapsedTime)
- Ошибки подключения к API
- Ошибки обновления CI в ISM

---

## 8. Развёртывание

### 8.1. Требования к серверу

| Компонент | Требование |
|-----------|------------|
| ОС | Windows Server 2019+ |
| IIS | 10.0 с ASP.NET Core Module V2 |
| .NET | .NET 8.0 Runtime |
| SSL | Сертификат в LocalMachine\My |

### 8.2. Этапы развёртывания

1. **Подготовка директорий**
   ```
   C:\ClonerSuite\Criticality\publish-iis\
   C:\ClonerSuite\Criticality\logs\
   ```

2. **Копирование файлов публикации**
   - Criticality.exe
   - Criticality.dll
   - web.config
   - appsettings.Production.json

3. **Настройка IIS**
   - Создать AppPool: CriticalityAppPool
   - managedRuntimeVersion: (пусто)
   - managedPipelineMode: Integrated

4. **Создание сайта**
   - Порт HTTP: 7102
   - Порт HTTPS: 7103
   - Physical Path: C:\ClonerSuite\Criticality\publish-iis

5. **Настройка прав**
   - IIS_IUSRS: Modify на logs/ и publish-iis/

6. **Конфигурация SSL**
   - Импортировать сертификат в LocalMachine\My
   - Указать thumbprint в appsettings.Production.json

7. **Настройка appsettings.Production.json**
   - BaseUrl API
   - EncryptedApiKey
   - CertificateThumbprint

### 8.3. Проверка развёртывания

```powershell
# Проверка AppPool
Get-WebAppPoolState -Name "CriticalityAppPool"

# Проверка сайта
Get-Website -Name "Criticality"

# Тест API
Invoke-WebRequest -Uri http://localhost:7102/api/CriticalitySync/status
```

---

## 9. Эксплуатация

### 9.1. Штатная работа

- Синхронизация запускается автоматически каждые 15 минут
- За цикл обрабатывается не более 500 устройств
- Инкрементальная загрузка по last_updated

### 9.2. Мониторинг состояния

```powershell
# Статус синхронизации
Invoke-WebRequest -Uri http://localhost:7102/api/CriticalitySync/status

# Потребление памяти (AppPool)
Get-Process w3wp | Where-Object { $_.Id -eq <PID> }

# Просмотр логов в реальном времени
Get-Content C:\ClonerSuite\Criticality\publish-iis\logs\app.log -Tail 50 -Wait
```

### 9.3. Принудительный запуск синхронизации

```powershell
Invoke-WebRequest -Uri http://localhost:7102/api/CriticalitySync/start -Method POST
```

### 9.4. Сброс статуса синхронизации

```powershell
Invoke-WebRequest -Uri http://localhost:7102/api/CriticalitySync/reset -Method POST
```

### 9.5. Перезапуск сервиса

```powershell
# Перезапуск AppPool
Restart-WebAppPool -Name "CriticalityAppPool"

# Или полная перезагрузка IIS
iisreset /restart
```

---

## 10. Безопасность

### 10.1. Хранение учётных данных

- API ключ хранится в зашифрованном виде (EncryptedApiKey)
- Ключ шифрования (EncryptionKey) указывается в конфигурации
- Рекомендуется использовать Windows DPAPI для шифрования

### 10.2. TLS/SSL конфигурация

- Обязательно использование HTTPS для подключения к API
- Сертификат сервера хранится в LocalMachine\My
- Проверка сертификата включена (SkipCertificateValidation: false)

### 10.3. Права доступа

- IIS_IUSRS: Modify на директорию logs/
- IIS_IUSRS: Modify на директорию publish-iis/
- Запуск AppPool от имени ApplicationPoolIdentity

---

## 11. Устранение неполадок

### 11.1. Сервис не запускается

**Проверьте:**
1. Установлен ли .NET 8.0 Runtime
2. Установлен ли ASP.NET Core Module V2
3. Правильность web.config
4. Наличие логов stdout*.txt

### 11.2. Ошибка подключения к API

**Проверьте:**
1. Доступность URL API (BaseUrl)
2. Корректность API ключа
3. Наличие сертификата (для HTTPS)
4. Настройки брандмауэра

### 11.3. Синхронизация не работает

**Проверьте:**
1. last_sync установлен в XER_Integration
2. Наличие устройств с last_updated >= last_sync
3. Статусы устройств (Active/Planned/Staged)
4. Логи app.log на ошибки

### 11.4. Высокое потребление памяти

**Рекомендации:**
1. Проверить batch_size (рекомендуется ≤ 500)
2. Увеличить частоту синхронизации
3. Проверить логи на ошибки обработки
4. Перезапустить AppPool

---

**Документ подготовлен:** Июнь 2026  
**Продукт:** ClonerSuite Criticality  
**Клиент:** SVO (Sheremetyevo International Airport)
