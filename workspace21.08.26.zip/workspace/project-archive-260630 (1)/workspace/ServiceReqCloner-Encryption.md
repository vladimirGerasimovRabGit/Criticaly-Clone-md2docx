# Шифрование API-ключа в ServiceReq Cloner

## Обзор

Сервис ServiceReq Cloner поддерживает два формата хранения API-ключа HEAT:

| Формат | Конфигурационный путь | Безопасность |
|--------|----------------------|-------------|
| `ApiKey` | `HeatApi:ApiKey` | Открытый текст |
| `EncryptedApiKey` + `EncryptionKey` | `HeatApi:EncryptedApiKey` | Зашифрован AES-256 |

При запуске сервис разрешает ключ в приоритете: сначала проверяется `ApiKey` (открытый текст), затем `EncryptedApiKey` (расшифровывается).

**Важное отличие от Criticality**: ServiceReq Cloner использует два разных алгоритма шифрования:
- **C# EncryptionService** — PBKDF2 (10 000 итераций, SHA256) — идентичен Criticality
- **PowerShell encrypt-apikey.ps1** — SHA256 (одна итерация) — упрощённый, несовместим с C#

Оба инструмента генерируют **несовместимые** друг с другом шифротексты.

---

## Архитектура

```mermaid
graph LR
    A["appsettings.json"] --> B["Program.cs<br/>DI: IEncryptionService"]
    A --> C["HeatApiService.cs<br/>TryResolveApiKey()"]
    B --> C
    C --> D["encryptionService.Decrypt(...)"]
    D --> E["Plaintext API Key"]
    E --> F["HTTP Header:<br/>Authorization: rest_api_key={key}"]
```

```mermaid
flowchart TD
    subgraph "Шифрование (однократная настройка)"
        direction LR
        subgraph CS["C# EncryptionService"]
            CP["Password"] --> CK["PBKDF2 (10000 iter, SHA256)"]
            CK --> CA["AES-256-CBC Encrypt"]
            CK2["API Key"] --> CA
            CA --> CB["Salt + IV + Ciphertext -> Base64"]
        end
        subgraph PS["PowerShell encrypt-apikey.ps1"]
            PP["Password"] --> PK["SHA256 (1 iter)"]
            PK --> PA["AES-256-CBC Encrypt"]
            PK2["API Key"] --> PA
            PA --> PB["IV + Ciphertext -> Base64"]
        end
    end
    CB --> CONFIG["appsettings.json<br/>EncryptedApiKey: '8owtwbO...'"]
    PB --> CONFIG
```

```mermaid
flowchart TD
    subgraph "Расшифровка (при запуске)"
        CONFIG["appsettings.json"] --> DI["Program.cs: DI registers IEncryptionService"]
        CONFIG --> TRY["HeatApiService.TryResolveApiKey()"]
        DI --> TRY
        TRY --> DEC["encryptionService.Decrypt()"]
        DEC --> PT["API Key: 1404A984..."]
    end
    PT --> HEADER["Authorization: rest_api_key={key}"]
    HEADER --> API["POST https://svoivantisrv/HEAT/api/odata/..."]
```

---

## 1. EncryptionService (C#)

Файл: `Services/EncryptionService.cs`

### Параметры шифрования

| Параметр | Значение |
|----------|---------|
| Алгоритм | AES |
| KeySize | 256 бит |
| BlockSize | 128 бит |
| Режим | CBC |
| Padding | PKCS7 |
| Salt | 16 байт (случайный) |
| IV | 16 байт (случайный) |
| Вывод ключа | PBKDF2 / RFC 2898 |
| Хеш-функция | SHA256 |
| Итераций PBKDF2 | 10 000 |
| Формат вывода | Base64 |

### Формат зашифрованных данных

```mermaid
graph LR
    A["Salt (16 bytes)"] --> B["IV (16 bytes)"]
    B --> C["Ciphertext (N bytes)"]
    C --> D["Base64-encode"]
    D --> E["EncryptedApiKey string"]
```

Salt и IV генерируются случайно при каждом шифровании — один и тот же открытый текст с тем же паролем даёт **разный** шифротекст.

### Схема шифрования (Encrypt)

```mermaid
flowchart TD
    P["Password"] --> KDF["PBKDF2 (10000 iterations, SHA256)"]
    S["Random Salt (16 bytes)"] --> KDF
    KDF --> KEY["AES-256 Key"]
    IV["Random IV (16 bytes)"] --> ENC["AES-CBC Encryptor"]
    KEY --> ENC
    PT["Plaintext API Key"] --> ENC
    ENC --> CT["Ciphertext"]
    S --> COMBINE["Salt + IV + Ciphertext"]
    IV --> COMBINE
    CT --> COMBINE
    COMBINE --> B64["Base64"]
    B64 --> RESULT["EncryptedApiKey"]
```

### Схема расшифровки (Decrypt)

```mermaid
flowchart TD
    B64["EncryptedApiKey (Base64)"] --> DEC["Decode Base64"]
    DEC --> SALT["Extract Salt (first 16 bytes)"]
    DEC --> IVEXT["Extract IV (next 16 bytes)"]
    DEC --> CTEXT["Extract Ciphertext (remaining bytes)"]
    PWD["Password"] --> KDF2["PBKDF2 (10000 iterations, SHA256)"]
    SALT --> KDF2
    KDF2 --> KEY2["AES-256 Key"]
    IVEXT --> DECRYPT["AES-CBC Decryptor"]
    KEY2 --> DECRYPT
    CTEXT --> DECRYPT
    DECRYPT --> PT2["Plaintext API Key"]
```

### Листинг: Encrypt

```csharp
public string Encrypt(string plainText, string encryptionKey)
{
    using var aes = Aes.Create();
    aes.KeySize = 256;
    aes.BlockSize = 128;
    aes.Mode = CipherMode.CBC;
    aes.Padding = PaddingMode.PKCS7;

    var salt = RandomNumberGenerator.GetBytes(16);
    var key = DeriveKey(encryptionKey, salt);
    aes.Key = key;

    var iv = RandomNumberGenerator.GetBytes(16);
    aes.IV = iv;

    var encryptor = aes.CreateEncryptor(aes.Key, aes.IV);
    var plainBytes = Encoding.UTF8.GetBytes(plainText);

    using var memoryStream = new MemoryStream();
    memoryStream.Write(salt, 0, salt.Length);   // 16 bytes
    memoryStream.Write(iv, 0, iv.Length);       // 16 bytes

    using var cryptoStream = new CryptoStream(memoryStream, encryptor, CryptoStreamMode.Write);
    cryptoStream.Write(plainBytes, 0, plainBytes.Length);
    cryptoStream.FlushFinalBlock();

    var cipherBytes = memoryStream.ToArray();
    return Convert.ToBase64String(cipherBytes);
}
```

### Листинг: Decrypt

```csharp
public string Decrypt(string cipherText, string encryptionKey)
{
    var cipherBytes = Convert.FromBase64String(cipherText);

    using var aes = Aes.Create();
    aes.KeySize = 256;
    aes.BlockSize = 128;
    aes.Mode = CipherMode.CBC;
    aes.Padding = PaddingMode.PKCS7;

    var salt = new byte[16];
    Array.Copy(cipherBytes, 0, salt, 0, 16);

    var iv = new byte[16];
    Array.Copy(cipherBytes, 16, iv, 0, 16);

    var key = DeriveKey(encryptionKey, salt);
    aes.Key = key;
    aes.IV = iv;

    var decryptor = aes.CreateDecryptor(aes.Key, aes.IV);
    var dataOffset = 16 + 16;  // = 32

    using var memoryStream = new MemoryStream(cipherBytes, dataOffset, cipherBytes.Length - dataOffset);
    using var cryptoStream = new CryptoStream(memoryStream, decryptor, CryptoStreamMode.Read);
    using var resultStream = new MemoryStream();

    cryptoStream.CopyTo(resultStream);
    return Encoding.UTF8.GetString(resultStream.ToArray());
}
```

### Листинг: DeriveKey (PBKDF2)

```csharp
private static byte[] DeriveKey(string password, byte[] salt)
{
    using var deriveBytes = new Rfc2898DeriveBytes(
        password, salt, 10000, HashAlgorithmName.SHA256);
    return deriveBytes.GetBytes(32);  // 32 bytes = 256 bits
}
```

---

## 2. TryResolveApiKey — разрешение ключа при запуске

Файл: `Services/HeatApiService.cs:96-127`

Приоритет получения ключа:

1. Если задан `HeatApi:ApiKey` (открытый текст) — используется напрямую
2. Если задан `HeatApi:EncryptedApiKey`:
   - Проверяется наличие `IEncryptionService` в DI
   - Проверяется наличие `HeatApi:EncryptionKey` в конфигурации
   - Вызывается `encryptionService.Decrypt(EncryptedApiKey, EncryptionKey)`

```mermaid
flowchart TD
    START["Start"] --> APIKEY{"ApiKey configured?"}
    APIKEY -->|"Yes"| RETAP["Return ApiKey (plaintext)"]
    APIKEY -->|"No"| ENCKEY{"EncryptedApiKey configured?"}
    ENCKEY -->|"No"| RETNULL["Return null"]
    ENCKEY -->|"Yes"| ENCSVC{"IEncryptionService registered?"}
    ENCSVC -->|"No"| WARN1["Log warning, return null"]
    ENCSVC -->|"Yes"| ENCPWD{"EncryptionKey configured?"}
    ENCPWD -->|"No"| WARN2["Log warning, return null"]
    ENCPWD -->|"Yes"| DECRYPT["Decrypt(EncryptedApiKey, EncryptionKey)"]
    DECRYPT --> RETDEC["Return plaintext key"]
```

```csharp
private static string? TryResolveApiKey(HeatApiSettings config, IEncryptionService? encryptionService)
{
    if (!string.IsNullOrEmpty(config.ApiKey))
        return config.ApiKey;

    if (!string.IsNullOrEmpty(config.EncryptedApiKey))
    {
        if (encryptionService == null)
        {
            Console.WriteLine("WARNING: EncryptedApiKey configured but no IEncryptionService registered");
            return null;
        }

        var encryptionKey = config.EncryptionKey;
        if (string.IsNullOrEmpty(encryptionKey))
        {
            Console.WriteLine("WARNING: EncryptionKey not configured, cannot decrypt EncryptedApiKey");
            return null;
        }

        try
        {
            return encryptionService.Decrypt(config.EncryptedApiKey, encryptionKey);
        }
        catch
        {
            return null;
        }
    }

    return null;
}
```

Расшифрованный ключ используется для HTTP-заголовка:

```csharp
_httpClient.DefaultRequestHeaders.TryAddWithoutValidation(
    "Authorization", $"rest_api_key={_apiKey}");
```

---

## 3. appsettings.json — конфигурация

```json
{
  "HeatApi": {
    "BaseUrl": "https://svoivantisrv/HEAT/api",
    "ApiKey": "",
    "EncryptedApiKey": "8owtwbON81PUPSx0qf+FFi0J4wiRNZDbVua1AM5nglV3IU5SU8aVJUG9QThwHxgL6svCmc0cAQE+RVte7QpQ036inBRGdi+qXuJbNQal+Pg=",
    "EncryptionKey": "MySecretKey2024!",
    "TimeoutSeconds": 60,
    "SkipCertificateValidation": true,
    "RequireWebServer": false
  }
}
```

| Поле | Назначение | Безопасность |
|------|-----------|-------------|
| `ApiKey` | API-ключ открытым текстом | Не коммитить |
| `EncryptedApiKey` | Зашифрованный API-ключ (Base64) | Можно коммитить |
| `EncryptionKey` | Пароль для расшифровки | Не коммитить, хранить в переменной окружения |

---

## 4. encrypt-apikey.ps1 — утилита шифрования (PowerShell)

Файл: `encrypt-apikey.ps1`

**Важно**: PowerShell-скрипт использует упрощённый алгоритм (SHA256 вместо PBKDF2) и **несовместим** с C# EncryptionService. Скрипт предназначен для быстрого шифрования ключа без необходимости компиляции C# кода.

### Использование

```powershell
.\encrypt-apikey.ps1 -PlainKey "1404A984C43F48C88749CF8C1C14B40A" -Password "MySecretKey2024!"

# Из переменных окружения
.\encrypt-apikey.ps1 -PlainKey $env:HEAT_API_KEY -Password $env:ENCRYPTION_PASSWORD
```

### Алгоритм (PowerShell)

```mermaid
flowchart TD
    PWD["Password"] --> SHA["SHA256 (1 iteration)"]
    SHA --> KEY["32-byte AES Key"]
    PT["Plaintext API Key"] --> ENC["AES-256-CBC Encrypt"]
    KEY --> ENC
    IV["Random IV (16 bytes)"] --> ENC
    ENC --> COMB["IV + Ciphertext"]
    COMB --> B64["Base64"]
    B64 --> RESULT["EncryptedApiKey"]
```

```powershell
# Вывод ключа: SHA256(password) -> 32 байта
$sha256 = [System.Security.Cryptography.SHA256]::Create()
$keyBytes = $sha256.ComputeHash([System.Text.Encoding]::UTF8.GetBytes($Password))

# Случайный IV
$aes = [System.Security.Cryptography.Aes]::Create()
$aes.Key = $keyBytes
$aes.GenerateIV()
$ivBytes = $aes.IV

# Шифрование
$encryptor = $aes.CreateEncryptor($aes.Key, $ivBytes)
$plainBytes = [System.Text.Encoding]::UTF8.GetBytes($PlainKey)
$encryptedBytes = $encryptor.TransformFinalBlock($plainBytes, 0, $plainBytes.Length)

# IV + данные -> Base64
$combined = New-Object byte[] ($ivBytes.Length + $encryptedBytes.Length)
[System.Buffer]::BlockCopy($ivBytes, 0, $combined, 0, $ivBytes.Length)
[System.Buffer]::BlockCopy($encryptedBytes, 0, $combined, $ivBytes.Length, $encryptedBytes.Length)
$encryptedOutput = [System.Convert]::ToBase64String($combined)
```

### Параметры скрипта

| Параметр | Описание | Обязательный |
|----------|----------|-------------|
| `-PlainKey` | API-ключ открытым текстом | Да |
| `-Password` | Пароль для шифрования (мин. 16 символов) | Да |
| `-OutputFormat` | Формат вывода: `Base64` (по умолчанию) или `Hex` | Нет |

---

## 5. Полный процесс: от шифрования до HTTP-запроса

### Шифрование через C# EncryptionService (рекомендуемый способ)

```mermaid
flowchart TD
    subgraph "Шаг 1: Шифрование ключа"
        P["Password"] --> KDF["PBKDF2 (10000 iter)"]
        KDF --> ENC["AES-256-CBC"]
        APIKEY["API Key"] --> ENC
        ENC --> B64["Salt+IV+CT -> Base64"]
    end
    B64 --> CONFIG["Записать в appsettings.json<br/>EncryptedApiKey: '...'<br/>EncryptionKey: 'password'"]
```

### Расшифровка при запуске сервиса

```mermaid
flowchart TD
    CONFIG["appsettings.json"] --> DI["Program.cs: builder.Services.AddSingleton&lt;IEncryptionService&gt;()"]
    CONFIG --> HCON["HeatApiService constructor"]
    DI --> HCON
    HCON --> TRY["TryResolveApiKey()"]
    TRY --> DEC["encryptionService.Decrypt()"]
    DEC --> PT["API Key: 1404A984..."]
```

### HTTP-запрос к HEAT

```mermaid
flowchart LR
    KEY["API Key"] --> HEADER["Authorization: rest_api_key={key}"]
    HEADER --> API1["GET odata/businessobject/ServiceReqs"]
    HEADER --> API2["POST odata/businessobject/ServiceReqs"]
    HEADER --> API3["GET odata/businessobject/incidents"]
    HEADER --> API4["POST odata/businessobject/incidents"]
```

---

## 6. Сравнение: C# EncryptionService vs PowerShell encrypt-apikey.ps1

| Характеристика | EncryptionService.cs | encrypt-apikey.ps1 |
|---------------|---------------------|-------------------|
| Проект | ServiceReqCloner | ServiceReqCloner |
| Вывод ключа | PBKDF2 (RFC 2898, 10 000 итераций) | SHA256 (одна итерация) |
| Формат вывода | Salt(16) + IV(16) + Ciphertext | IV(16) + Ciphertext |
| Совместимость | Несовместим с PS-скриптом | Несовместим с C# сервисом |
| Безопасность | Высокая (PBKDF2 замедляет брутфорс) | Ниже (SHA256 без итераций) |
| Зависимости | Требует компиляции C# | Только PowerShell |
| Использование | `new EncryptionService().Encrypt(key, pwd)` | `.\encrypt-apikey.ps1 -PlainKey ...` |

```mermaid
flowchart LR
    subgraph PS["PowerShell encrypt-apikey.ps1"]
        direction LR
        P1["Password"] --> P2["SHA256 (1 iter)"]
        P2 --> P3["AES-256-CBC"]
        P4["API Key"] --> P3
        P3 --> P5["IV + Ciphertext -> Base64"]
    end
    subgraph CS["C# EncryptionService"]
        direction LR
        C1["Password"] --> C2["PBKDF2 (10000 iter, SHA256)"]
        C2 --> C3["AES-256-CBC"]
        C4["API Key"] --> C3
        C3 --> C5["Salt + IV + Ciphertext -> Base64"]
    end
    P5 -->|XX| X["INCOMPATIBLE"]
    C5 -->|XX| X
```

**Следствие**: если ключ зашифрован PowerShell-скриптом, C# сервис не сможет его расшифровать, и наоборот. Для промышленного использования рекомендуется C# EncryptionService.

---

## 7. Настройка в appsettings.Production.json

### Production-конфигурация с зашифрованным ключом

```json
{
  "HeatApi": {
    "BaseUrl": "https://svoivantisrv/HEAT/api",
    "ApiKey": "",
    "EncryptedApiKey": "8owtwbON81PUPSx0qf+FFi0J4wiRNZDbVua1AM5nglV3IU5SU8aVJUG9QThwHxgL6svCmc0cAQE+RVte7QpQ036inBRGdi+qXuJbNQal+Pg=",
    "EncryptionKey": "MySecretKey2024!",
    "TimeoutSeconds": 60,
    "DefaultUser": "HEATAdmin",
    "RequireWebServer": false,
    "SkipCertificateValidation": true
  }
}
```

---

## 8. Рекомендации по безопасному хранению

### Production: пароль в переменной окружения

```powershell
# Установить переменную окружения
$env:HEAT_ENCRYPTION_KEY = "MySecretKey2024!"
```

```json
// appsettings.Production.json — без EncryptionKey в файле
{
  "HeatApi": {
    "EncryptedApiKey": "8owtwbON81PUPSx0qf+FFi...",
    "EncryptionKey": ""   // пусто — берётся из переменной окружения
  }
}
```

```csharp
// Program.cs — переопределение EncryptionKey из переменной окружения
var encryptionKey = Environment.GetEnvironmentVariable("HEAT_ENCRYPTION_KEY");
if (!string.IsNullOrEmpty(encryptionKey))
{
    configuration["HeatApi:EncryptionKey"] = encryptionKey;
}
```

### Проверка работоспособности ключа

```powershell
# Проверить здоровье сервиса
Invoke-WebRequest -Uri http://localhost:7104/api/ServiceReqClone/health -UseBasicParsing

# Статус "healthy" означает, что ключ работает и HEAT API доступен
# Статус "degraded" — ключ не работает или HEAT API недоступен
```
