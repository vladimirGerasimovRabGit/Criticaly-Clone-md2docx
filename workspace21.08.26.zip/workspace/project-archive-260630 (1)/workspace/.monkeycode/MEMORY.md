# User Instructions Memory

This file records user instructions, preferences, and teachings for future reference.

## Format

### User Instruction Entry
[Instruction Summary]
- Date: [YYYY-MM-DD]
- Context: [Scenario or timing mentioned]
- Instructions:
  - [User taught or indicated content, described line by line]

### Project Knowledge Entry
Entries discovered by Agent during task execution:
- Date: [YYYY-MM-DD]
- Context: Agent discovered during [specific task description]
- Category: [code-structure|code-pattern|code-generation|build-method|test-method|dependency|environment]
- Instructions:
  - [Specific knowledge points, described line by line]

## Dedup Strategy
- Before adding new entries, check for similar or identical instructions
- If duplicate found, skip new entry or merge with existing one
- When merging, update context or date
- Keep file under 150 lines by consolidating same-category rules

## Entries

### Windows PS WinHTTP COM for GET requests
- Date: 2026-06-30
- Context: TLS/SSL issues with Invoke-RestMethod on Windows PowerShell 5.1 for HEAT API
- Instructions:
  - Use WinHttp.WinHttpRequest.5.1 COM object instead of .NET Invoke-RestMethod for GET requests
  - Set $http.Option(4) = 0x3300 for SSL (SecureProtocol_Tls1_1 + SecureProtocol_Tls1_2)
  - POST requests via Invoke-RestMethod work fine (only GET is broken)
  - PowerShell example: $http = New-Object -ComObject WinHttp.WinHttpRequest.5.1; $http.Option(4) = 0x3300

### SQB project: only standard fields
- Date: 2026-06-30
- Context: SQB (separate project from first project), no custom CI fields
- Instructions:
  - Use only standard cis table fields, no TRN_/XER_/SVO_/SWO_/IPCM_/TEMP_ prefixes
  - SQB has 504 standard fields in cis vs first project's 704 (including custom)
  - Skip 4 RVTools fields without standard analog: Powerstate, InUseMiB, ThinProvisioned, SnapshotSize

### RVTools import dedup key: VM UUID
- Date: 2026-06-30
- Context: 934 VMs from 4 vCenters, need dedup on import to HEAT
- Instructions:
  - Use VMUUID for deduplication (not SerialNumber - absent in RVTools)
  - 872 unique UUIDs, 62 duplicates across vCenters
  - vCenter: .30(VxRail), .110(H3C), .197(Lenovo), .216(Dell)

### RVTools to SQB field mapping (23 fields)
- Date: 2026-06-30
- Context: Mapping RVTools vInfo export to SQB standard cis fields
- Instructions:
  - Name → Name, VMUUID → VMUUID, IPAddress → IPAddress, FQDN → FQDN
  - OperatingSystem → OperatingSystem, CPUCount → CPUCount, CPUCoreCount → CPUCoreCount
  - TotalMemory → TotalMemory, PhysicalHostName → PhysicalHostName
  - PhysicalLocation → Datacenter, PhysicalName → Cluster, TotalDiskSpace → TotalDiskSpace
  - FreeDiskSpace → FreeDiskSpace, PercentFreeDiskspace → PercentFreeDiskspace
  - MACAddress → MACAddress, Subnet → VLAN, Description → Description
  - Manufacturer → Manufacturer, AgentVersion → AgentVersion
  - ComplianceState → ComplianceState, DiscoveryMethod → DiscoveryMethod
  - CreatedDateTime → CreatedDateTime, AppVersion → AppVersion

### HEAT API key handling
- Date: 2026-06-30
- Context: API key for HEAT OData REST API authentication
- Instructions:
  - API key stored encrypted, never display in responses
  - encrypt-apikey.ps1 for encryption
  - API base URLs: test https://localhost:7105/HEAT/api, prod https://svoivantisrv/HEAT/api

### 16 RVTools fields with no SQB standard analog
- Date: 2026-06-30
- Context: Fields present in RVTools vInfo but missing from standard SQB cis
- Instructions:
  - Powerstate, In Use MiB, Thin, Sockets, Snapshot size, Snapshot count
  - Disk UUID, Disk Mode, Disk Controller, Hot Add/Remove
  - Reservation, Limit, VLAN name, Adapter type
  - Decision: skip all, use only 23 mapped fields

### 89 branch nodes in directory
- Date: 2026-06-30
- Context: Branch structure for VM-to-branch assignment
- Instructions:
  - 14 regional centers, 67 branch offices
  - Codes with letter suffixes: 03R00, 22S00 format
  - RVTools has zero correlation with branches - external mapping required (MESM or registry)

### md2docx converter
- Date: 2026-06-30
- Context: Convert markdown documentation to DOCX
- Instructions:
  - Script: /workspace/tools/md2docx.py with template DocTemplate-1.dotx
  - Install: pip install --break-system-packages python-docx
