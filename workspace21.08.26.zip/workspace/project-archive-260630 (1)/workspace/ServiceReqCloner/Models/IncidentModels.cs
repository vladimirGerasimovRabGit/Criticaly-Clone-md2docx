using System.Text.Json.Serialization;
using ServiceReqCloner.Converters;

namespace ServiceReqCloner.Models;

public class Incident
{
    [JsonPropertyName("RecId")]
    public string RecId { get; set; } = string.Empty;

    [JsonPropertyName("IncidentNumber")]
    [JsonConverter(typeof(DecimalNotNullConverter))]
    public decimal IncidentNumber { get; set; }

    [JsonPropertyName("Subject")]
    public string? Subject { get; set; }

    [JsonPropertyName("Symptom")]
    public string? Symptom { get; set; }

    [JsonPropertyName("Status")]
    public string? Status { get; set; }

    [JsonPropertyName("Status_Valid")]
    public string? Status_Valid { get; set; }

    [JsonPropertyName("Priority")]
    public string? Priority { get; set; }

    [JsonPropertyName("Priority_Valid")]
    public string? Priority_Valid { get; set; }

    [JsonPropertyName("Impact")]
    public string? Impact { get; set; }

    [JsonPropertyName("Impact_Valid")]
    public string? Impact_Valid { get; set; }

    [JsonPropertyName("Urgency")]
    public string? Urgency { get; set; }

    [JsonPropertyName("Urgency_Valid")]
    public string? Urgency_Valid { get; set; }

    [JsonPropertyName("Service")]
    public string? Service { get; set; }

    [JsonPropertyName("Service_Valid")]
    public string? Service_Valid { get; set; }

    [JsonPropertyName("Category")]
    public string? Category { get; set; }

    [JsonPropertyName("Category_Valid")]
    public string? Category_Valid { get; set; }

    [JsonPropertyName("CauseCode")]
    public string? CauseCode { get; set; }

    [JsonPropertyName("CauseCode_Valid")]
    public string? CauseCode_Valid { get; set; }

    [JsonPropertyName("Source")]
    public string? Source { get; set; }

    [JsonPropertyName("Source_Valid")]
    public string? Source_Valid { get; set; }

    [JsonPropertyName("TypeOfIncident")]
    public string? TypeOfIncident { get; set; }

    [JsonPropertyName("ActualCategory")]
    public string? ActualCategory { get; set; }

    [JsonPropertyName("ActualCategory_Valid")]
    public string? ActualCategory_Valid { get; set; }

    [JsonPropertyName("ActualService")]
    public string? ActualService { get; set; }

    [JsonPropertyName("ActualService_Valid")]
    public string? ActualService_Valid { get; set; }

    [JsonPropertyName("CreatedBy")]
    public string? CreatedBy { get; set; }

    [JsonPropertyName("CreatedDateTime")]
    public DateTime? CreatedDateTime { get; set; }

    [JsonPropertyName("LastModBy")]
    public string? LastModBy { get; set; }

    [JsonPropertyName("LastModDateTime")]
    public DateTime? LastModDateTime { get; set; }

    [JsonPropertyName("ClosedBy")]
    public string? ClosedBy { get; set; }

    [JsonPropertyName("ClosedDateTime")]
    public DateTime? ClosedDateTime { get; set; }

    [JsonPropertyName("ClosedDuration")]
    [JsonConverter(typeof(DecimalJsonConverter))]
    public decimal? ClosedDuration { get; set; }

    [JsonPropertyName("ResolvedBy")]
    public string? ResolvedBy { get; set; }

    [JsonPropertyName("ResolvedDateTime")]
    public DateTime? ResolvedDateTime { get; set; }

    [JsonPropertyName("ResolvedByIncidentNumber")]
    [JsonConverter(typeof(DecimalJsonConverter))]
    public decimal? ResolvedByIncidentNumber { get; set; }

    [JsonPropertyName("ResolvedByType")]
    public string? ResolvedByType { get; set; }

    [JsonPropertyName("RespondedBy")]
    public string? RespondedBy { get; set; }

    [JsonPropertyName("RespondedDateTime")]
    public DateTime? RespondedDateTime { get; set; }

    [JsonPropertyName("Resolution")]
    public string? Resolution { get; set; }

    [JsonPropertyName("ProfileLink_Category")]
    public string? ProfileLink_Category { get; set; }

    [JsonPropertyName("ProfileLink_RecID")]
    public string? ProfileLink_RecID { get; set; }

    [JsonPropertyName("ProfileFullName")]
    public string? ProfileFullName { get; set; }

    [JsonPropertyName("ProfileFullName_Valid")]
    public string? ProfileFullName_Valid { get; set; }

    [JsonPropertyName("Email")]
    public string? Email { get; set; }

    [JsonPropertyName("LoginId")]
    public string? LoginId { get; set; }

    [JsonPropertyName("Phone")]
    public string? Phone { get; set; }

    [JsonPropertyName("Owner")]
    public string? Owner { get; set; }

    [JsonPropertyName("Owner_Valid")]
    public string? Owner_Valid { get; set; }

    [JsonPropertyName("OwnerEmail")]
    public string? OwnerEmail { get; set; }

    [JsonPropertyName("OwnerTeam")]
    public string? OwnerTeam { get; set; }

    [JsonPropertyName("OwnerTeam_Valid")]
    public string? OwnerTeam_Valid { get; set; }

    [JsonPropertyName("OwnerTeamEmail")]
    public string? OwnerTeamEmail { get; set; }

    [JsonPropertyName("OwnerType")]
    public string? OwnerType { get; set; }

    [JsonPropertyName("OwningOrgUnitId")]
    public string? OwningOrgUnitId { get; set; }

    [JsonPropertyName("OwningOrgUnitId_Valid")]
    public string? OwningOrgUnitId_Valid { get; set; }

    [JsonPropertyName("OrganizationUnitID")]
    public string? OrganizationUnitID { get; set; }

    [JsonPropertyName("CustomerDepartment")]
    public string? CustomerDepartment { get; set; }

    [JsonPropertyName("CustomerLocation")]
    public string? CustomerLocation { get; set; }

    [JsonPropertyName("CustomerLocation_Valid")]
    public string? CustomerLocation_Valid { get; set; }

    [JsonPropertyName("OrgUnitLink_Category")]
    public string? OrgUnitLink_Category { get; set; }

    [JsonPropertyName("OrgUnitLink_RecID")]
    public string? OrgUnitLink_RecID { get; set; }

    [JsonPropertyName("EntityLink_Category")]
    public string? EntityLink_Category { get; set; }

    [JsonPropertyName("EntityLink_RecID")]
    public string? EntityLink_RecID { get; set; }

    [JsonPropertyName("ReportingOrgUnitID")]
    public string? ReportingOrgUnitID { get; set; }

    [JsonPropertyName("ReportingOrgUnitID_Valid")]
    public string? ReportingOrgUnitID_Valid { get; set; }

    [JsonPropertyName("ReprintIP")]
    public string? ReprintIP { get; set; }

    [JsonPropertyName("ReprintIP_Valid")]
    public string? ReprintIP_Valid { get; set; }

    [JsonPropertyName("EventCIRecId")]
    public string? EventCIRecId { get; set; }

    [JsonPropertyName("ProblemLink_Category")]
    public string? ProblemLink_Category { get; set; }

    [JsonPropertyName("ProblemLink_RecID")]
    public string? ProblemLink_RecID { get; set; }

    [JsonPropertyName("ServiceReqLink_Category")]
    public string? ServiceReqLink_Category { get; set; }

    [JsonPropertyName("ServiceReqLink_RecID")]
    public string? ServiceReqLink_RecID { get; set; }

    [JsonPropertyName("HRCaseLink_Category")]
    public string? HRCaseLink_Category { get; set; }

    [JsonPropertyName("HRCaseLink_RecID")]
    public string? HRCaseLink_RecID { get; set; }

    [JsonPropertyName("KnowledgeLink_Category")]
    public string? KnowledgeLink_Category { get; set; }

    [JsonPropertyName("KnowledgeLink_RecID")]
    public string? KnowledgeLink_RecID { get; set; }

    [JsonPropertyName("MasterIncidentLink_Category")]
    public string? MasterIncidentLink_Category { get; set; }

    [JsonPropertyName("MasterIncidentLink_RecID")]
    public string? MasterIncidentLink_RecID { get; set; }

    [JsonPropertyName("SuportRequsetLink_Category")]
    public string? SuportRequsetLink_Category { get; set; }

    [JsonPropertyName("SuportRequsetLink_RecID")]
    public string? SuportRequsetLink_RecID { get; set; }

    [JsonPropertyName("ivnt_TeamsUserDetailsLink_Category")]
    public string? ivnt_TeamsUserDetailsLink_Category { get; set; }

    [JsonPropertyName("ivnt_TeamsUserDetailsLink_RecID")]
    public string? ivnt_TeamsUserDetailsLink_RecID { get; set; }

    [JsonPropertyName("ClosingEscLink_Category")]
    public string? ClosingEscLink_Category { get; set; }

    [JsonPropertyName("ClosingEscLink_RecID")]
    public string? ClosingEscLink_RecID { get; set; }

    [JsonPropertyName("ResolutionEscLink_Category")]
    public string? ResolutionEscLink_Category { get; set; }

    [JsonPropertyName("ResolutionEscLink_RecID")]
    public string? ResolutionEscLink_RecID { get; set; }

    [JsonPropertyName("ResponseEscLink_Category")]
    public string? ResponseEscLink_Category { get; set; }

    [JsonPropertyName("ResponseEscLink_RecID")]
    public string? ResponseEscLink_RecID { get; set; }

    [JsonPropertyName("WaitingEscLink_Category")]
    public string? WaitingEscLink_Category { get; set; }

    [JsonPropertyName("WaitingEscLink_RecID")]
    public string? WaitingEscLink_RecID { get; set; }

    [JsonPropertyName("SLA")]
    public string? SLA { get; set; }

    [JsonPropertyName("SLADisplayText")]
    public string? SLADisplayText { get; set; }

    [JsonPropertyName("SLALink_Category")]
    public string? SLALink_Category { get; set; }

    [JsonPropertyName("SLALink_RecID")]
    public string? SLALink_RecID { get; set; }

    [JsonPropertyName("HoursOfOperation")]
    public string? HoursOfOperation { get; set; }

    [JsonPropertyName("HoursOfOperation_Valid")]
    public string? HoursOfOperation_Valid { get; set; }

    [JsonPropertyName("ServiceOwnerEmail")]
    public string? ServiceOwnerEmail { get; set; }

    [JsonPropertyName("IsVIP")]
    public bool? IsVIP { get; set; }

    [JsonPropertyName("IsNotification")]
    public bool? IsNotification { get; set; }

    [JsonPropertyName("IsWorkAround")]
    public bool? IsWorkAround { get; set; }

    [JsonPropertyName("FirstCallResolution")]
    public bool? FirstCallResolution { get; set; }

    [JsonPropertyName("IsApprovalNeeded")]
    public bool? IsApprovalNeeded { get; set; }

    [JsonPropertyName("IsDSMTaskExisted")]
    public bool? IsDSMTaskExisted { get; set; }

    [JsonPropertyName("IsInFinalState")]
    public bool? IsInFinalState { get; set; }

    [JsonPropertyName("IsMasterIncident")]
    public bool? IsMasterIncident { get; set; }

    [JsonPropertyName("IsReclassifiedForResolution")]
    public bool? IsReclassifiedForResolution { get; set; }

    [JsonPropertyName("IsRelatedIncidentResolutionUpdate")]
    public bool? IsRelatedIncidentResolutionUpdate { get; set; }

    [JsonPropertyName("IsRelatedIncidentUpdate")]
    public bool? IsRelatedIncidentUpdate { get; set; }

    [JsonPropertyName("IsReportedByAlternateContact")]
    public bool? IsReportedByAlternateContact { get; set; }

    [JsonPropertyName("IsResolvedByMaster")]
    public bool? IsResolvedByMaster { get; set; }

    [JsonPropertyName("IsUnRead")]
    public bool? IsUnRead { get; set; }

    [JsonPropertyName("ReadOnly")]
    public bool? ReadOnly { get; set; }

    [JsonPropertyName("ProgressBarPosition")]
    public string? ProgressBarPosition { get; set; }

    [JsonPropertyName("PreviousState")]
    public string? PreviousState { get; set; }

    [JsonPropertyName("ReportedBy")]
    public string? ReportedBy { get; set; }

    [JsonPropertyName("ViewType")]
    public string? ViewType { get; set; }

    [JsonPropertyName("CreatedByType")]
    public string? CreatedByType { get; set; }

    [JsonPropertyName("IncidentDetailSummary")]
    public string? IncidentDetailSummary { get; set; }

    [JsonPropertyName("IncidentDetailWorkflowTag")]
    public string? IncidentDetailWorkflowTag { get; set; }

    [JsonPropertyName("IncidentNetworkUserName")]
    public string? IncidentNetworkUserName { get; set; }

    [JsonPropertyName("SocialTextHeader")]
    public string? SocialTextHeader { get; set; }

    [JsonPropertyName("AlternateContactEmail")]
    public string? AlternateContactEmail { get; set; }

    [JsonPropertyName("AlternateContactLink_Category")]
    public string? AlternateContactLink_Category { get; set; }

    [JsonPropertyName("AlternateContactLink_RecID")]
    public string? AlternateContactLink_RecID { get; set; }

    [JsonPropertyName("AlternateContactPhone")]
    public string? AlternateContactPhone { get; set; }

    [JsonPropertyName("ApprovalStatus")]
    public string? ApprovalStatus { get; set; }

    [JsonPropertyName("Approver")]
    public string? Approver { get; set; }

    [JsonPropertyName("Approver_Valid")]
    public string? Approver_Valid { get; set; }

    [JsonPropertyName("TeamManagerEmail")]
    public string? TeamManagerEmail { get; set; }

    [JsonPropertyName("Cost")]
    [JsonConverter(typeof(DecimalJsonConverter))]
    public decimal? Cost { get; set; }

    [JsonPropertyName("Cost_Currency")]
    public string? Cost_Currency { get; set; }

    [JsonPropertyName("Cost_CurrencyValid")]
    public string? Cost_CurrencyValid { get; set; }

    [JsonPropertyName("CostPerMinute")]
    [JsonConverter(typeof(DecimalJsonConverter))]
    public decimal? CostPerMinute { get; set; }

    [JsonPropertyName("CostPerMinute_Currency")]
    public string? CostPerMinute_Currency { get; set; }

    [JsonPropertyName("CostPerMinute_CurrencyValid")]
    public string? CostPerMinute_CurrencyValid { get; set; }

    [JsonPropertyName("TotalTimeSpent")]
    [JsonConverter(typeof(DecimalJsonConverter))]
    public decimal? TotalTimeSpent { get; set; }

    [JsonPropertyName("SVO_Aviacompany")]
    public string? SVO_Aviacompany { get; set; }

    [JsonPropertyName("SVO_Environment")]
    public string? SVO_Environment { get; set; }

    [JsonPropertyName("SVO_Environment_Valid")]
    public string? SVO_Environment_Valid { get; set; }

    [JsonPropertyName("SVO_KopaniyaIspolnitelya")]
    public string? SVO_KopaniyaIspolnitelya { get; set; }

    [JsonPropertyName("SVO_Moredetailed")]
    public string? SVO_Moredetailed { get; set; }

    [JsonPropertyName("SVO_ProgrammModule")]
    public string? SVO_ProgrammModule { get; set; }

    [JsonPropertyName("SVO_ProgrammModule_Valid")]
    public string? SVO_ProgrammModule_Valid { get; set; }

    [JsonPropertyName("SVO_RespondedDateTime")]
    public DateTime? SVO_RespondedDateTime { get; set; }

    [JsonPropertyName("SWO_flag_AVK")]
    public bool? SWO_flag_AVK { get; set; }

    [JsonPropertyName("SWO_flag_ServiceManager")]
    public bool? SWO_flag_ServiceManager { get; set; }

    [JsonPropertyName("SWO_Location1Lvl")]
    public string? SWO_Location1Lvl { get; set; }

    [JsonPropertyName("SWO_Location1Lvl_Valid")]
    public string? SWO_Location1Lvl_Valid { get; set; }

    [JsonPropertyName("SWO_Location2LVL")]
    public string? SWO_Location2LVL { get; set; }

    [JsonPropertyName("SWO_Location2LVL_Valid")]
    public string? SWO_Location2LVL_Valid { get; set; }

    [JsonPropertyName("SWO_Location3LVL")]
    public string? SWO_Location3LVL { get; set; }

    [JsonPropertyName("SWO_Location3LVL_Valid")]
    public string? SWO_Location3LVL_Valid { get; set; }

    [JsonPropertyName("SWO_Location4LVL")]
    public string? SWO_Location4LVL { get; set; }

    [JsonPropertyName("SWO_Location4LVL_Valid")]
    public string? SWO_Location4LVL_Valid { get; set; }

    [JsonPropertyName("TRN_BackToWorkReason")]
    public string? TRN_BackToWorkReason { get; set; }

    [JsonPropertyName("TRN_ChangeNumber")]
    public string? TRN_ChangeNumber { get; set; }

    [JsonPropertyName("TRN_CI")]
    public string? TRN_CI { get; set; }

    [JsonPropertyName("TRN_CI_Valid")]
    public string? TRN_CI_Valid { get; set; }

    [JsonPropertyName("TRN_CustomerAnswer")]
    public string? TRN_CustomerAnswer { get; set; }

    [JsonPropertyName("TRN_CustomerInfo")]
    public string? TRN_CustomerInfo { get; set; }

    [JsonPropertyName("TRN_DCSAviakompanii")]
    public string? TRN_DCSAviakompanii { get; set; }

    [JsonPropertyName("TRN_EscalationResolution75Percent")]
    public bool? TRN_EscalationResolution75Percent { get; set; }

    [JsonPropertyName("TRN_EscalationResolutionBreach")]
    public bool? TRN_EscalationResolutionBreach { get; set; }

    [JsonPropertyName("TRN_EscalationResponse75Percent")]
    public bool? TRN_EscalationResponse75Percent { get; set; }

    [JsonPropertyName("TRN_EscalationResponseBreach")]
    public bool? TRN_EscalationResponseBreach { get; set; }

    [JsonPropertyName("TRN_HasChildChange")]
    public bool? TRN_HasChildChange { get; set; }

    [JsonPropertyName("TRN_IconResolutionBreach")]
    public string? TRN_IconResolutionBreach { get; set; }

    [JsonPropertyName("TRN_IconResponseBreach")]
    public string? TRN_IconResponseBreach { get; set; }

    [JsonPropertyName("TRN_ID_SITA")]
    public string? TRN_ID_SITA { get; set; }

    [JsonPropertyName("TRN_ImyaPrintera")]
    public string? TRN_ImyaPrintera { get; set; }

    [JsonPropertyName("TRN_IncidentSozdan")]
    public bool? TRN_IncidentSozdan { get; set; }

    [JsonPropertyName("TRN_IPAdres")]
    public string? TRN_IPAdres { get; set; }

    [JsonPropertyName("TRN_IsLinkedToMasterIncident")]
    public bool? TRN_IsLinkedToMasterIncident { get; set; }

    [JsonPropertyName("TRN_IspolniteliLoginID")]
    public string? TRN_IspolniteliLoginID { get; set; }

    [JsonPropertyName("TRN_IspolniteliLoginIDBool")]
    public bool? TRN_IspolniteliLoginIDBool { get; set; }

    [JsonPropertyName("TRN_KalendarNaReakciyuIncidenta")]
    public string? TRN_KalendarNaReakciyuIncidenta { get; set; }

    [JsonPropertyName("TRN_KalendarNaReakciyuIncidenta_Valid")]
    public string? TRN_KalendarNaReakciyuIncidenta_Valid { get; set; }

    [JsonPropertyName("TRN_KalendarNaReshenieIncidenta")]
    public string? TRN_KalendarNaReshenieIncidenta { get; set; }

    [JsonPropertyName("TRN_KalendarNaReshenieIncidenta_Valid")]
    public string? TRN_KalendarNaReshenieIncidenta_Valid { get; set; }

    [JsonPropertyName("TRN_Kompaniya")]
    public string? TRN_Kompaniya { get; set; }

    [JsonPropertyName("TRN_Kompaniya_Valid")]
    public string? TRN_Kompaniya_Valid { get; set; }

    [JsonPropertyName("TRN_KontaktnoeLicoDlyaVzaimodeystviya")]
    public string? TRN_KontaktnoeLicoDlyaVzaimodeystviya { get; set; }

    [JsonPropertyName("TRN_LastNote")]
    public string? TRN_LastNote { get; set; }

    [JsonPropertyName("TRN_Mark")]
    public byte? TRN_Mark { get; set; }

    [JsonPropertyName("TRN_Mark_Valid")]
    public string? TRN_Mark_Valid { get; set; }

    [JsonPropertyName("TRN_MarkEmail")]
    public byte? TRN_MarkEmail { get; set; }

    [JsonPropertyName("TRN_MarkReason")]
    public string? TRN_MarkReason { get; set; }

    [JsonPropertyName("TRN_MarkReasonEmail")]
    public string? TRN_MarkReasonEmail { get; set; }

    [JsonPropertyName("TRN_Mestopolozhenie")]
    public string? TRN_Mestopolozhenie { get; set; }

    [JsonPropertyName("TRN_Mestopolozhenie_Valid")]
    public string? TRN_Mestopolozhenie_Valid { get; set; }

    [JsonPropertyName("TRN_MestopolozhenieLink_Category")]
    public string? TRN_MestopolozhenieLink_Category { get; set; }

    [JsonPropertyName("TRN_MestopolozhenieLink_RecID")]
    public string? TRN_MestopolozhenieLink_RecID { get; set; }

    [JsonPropertyName("TRN_MestoraspolozhenieOborudovaniya")]
    public string? TRN_MestoraspolozhenieOborudovaniya { get; set; }

    [JsonPropertyName("TRN_NomerIshodnogoIncident")]
    [JsonConverter(typeof(IntJsonConverter))]
    public int? TRN_NomerIshodnogoIncident { get; set; }

    [JsonPropertyName("TRN_NomerTelefona")]
    public string? TRN_NomerTelefona { get; set; }

    [JsonPropertyName("TRN_OtlozhenoDo")]
    public DateTime? TRN_OtlozhenoDo { get; set; }

    [JsonPropertyName("TRN_PokazatelyKPI")]
    public string? TRN_PokazatelyKPI { get; set; }

    [JsonPropertyName("TRN_PokazatelyKPI_Valid")]
    public string? TRN_PokazatelyKPI_Valid { get; set; }

    [JsonPropertyName("TRN_PredyduschiyStatus")]
    public string? TRN_PredyduschiyStatus { get; set; }

    [JsonPropertyName("TRN_PredyduschiyStatus_Valid")]
    public string? TRN_PredyduschiyStatus_Valid { get; set; }

    [JsonPropertyName("TRN_PrichinaOstanovki")]
    public string? TRN_PrichinaOstanovki { get; set; }

    [JsonPropertyName("TRN_PrimeryBirokBagazha")]
    public string? TRN_PrimeryBirokBagazha { get; set; }

    [JsonPropertyName("TRN_ResolutionDateTime")]
    public DateTime? TRN_ResolutionDateTime { get; set; }

    [JsonPropertyName("TRN_ResponseDateTime")]
    public DateTime? TRN_ResponseDateTime { get; set; }

    [JsonPropertyName("TRN_RG")]
    public string? TRN_RG { get; set; }

    [JsonPropertyName("TRN_Status")]
    public string? TRN_Status { get; set; }

    [JsonPropertyName("TRN_Status_Valid")]
    public string? TRN_Status_Valid { get; set; }

    [JsonPropertyName("TRN_TaskEscalation")]
    public bool? TRN_TaskEscalation { get; set; }

    [JsonPropertyName("TRN_TaskNeedAnswer")]
    public string? TRN_TaskNeedAnswer { get; set; }

    [JsonPropertyName("TRN_TeamManagerEmail")]
    public string? TRN_TeamManagerEmail { get; set; }

    [JsonPropertyName("TRN_TeamManagerFullName")]
    public string? TRN_TeamManagerFullName { get; set; }

    [JsonPropertyName("TRN_Terminal")]
    public string? TRN_Terminal { get; set; }

    [JsonPropertyName("TRN_Terminal_Valid")]
    public string? TRN_Terminal_Valid { get; set; }

    [JsonPropertyName("TRN_VoprosIniciatoruZadanIzIncidenta")]
    public bool? TRN_VoprosIniciatoruZadanIzIncidenta { get; set; }

    [JsonPropertyName("TRN_VremyaReakciiIncidenta")]
    public string? TRN_VremyaReakciiIncidenta { get; set; }

    [JsonPropertyName("TRN_VremyaReakciiIncidenta_Valid")]
    public string? TRN_VremyaReakciiIncidenta_Valid { get; set; }

    [JsonPropertyName("TRN_VremyaResheniyaIncidenta")]
    public string? TRN_VremyaResheniyaIncidenta { get; set; }

    [JsonPropertyName("TRN_VremyaResheniyaIncidenta_Valid")]
    public string? TRN_VremyaResheniyaIncidenta_Valid { get; set; }

    [JsonPropertyName("TRNHoursOfOperation")]
    public string? TRNHoursOfOperation { get; set; }

    [JsonPropertyName("TRNHoursOfOperation_Valid")]
    public string? TRNHoursOfOperation_Valid { get; set; }

    [JsonPropertyName("TRNReactionLevel")]
    public string? TRNReactionLevel { get; set; }

    [JsonPropertyName("TRNReactionLevel_Valid")]
    public string? TRNReactionLevel_Valid { get; set; }

    [JsonPropertyName("TRNResolutionLevel")]
    public string? TRNResolutionLevel { get; set; }

    [JsonPropertyName("TRNResolutionLevel_Valid")]
    public string? TRNResolutionLevel_Valid { get; set; }

    [JsonPropertyName("TRN_Category_Valid")]
    public string? TRN_Category_Valid { get; set; }

    [JsonPropertyName("XER_24_7")]
    public bool? XER_24_7 { get; set; }

    [JsonPropertyName("XER_ActualDowntime")]
    public DateTime? XER_ActualDowntime { get; set; }

    [JsonPropertyName("XER_ActualImpact")]
    public string? XER_ActualImpact { get; set; }

    [JsonPropertyName("XER_ActualImpact_Valid")]
    public string? XER_ActualImpact_Valid { get; set; }

    [JsonPropertyName("XER_Area")]
    public string? XER_Area { get; set; }

    [JsonPropertyName("XER_Area_Valid")]
    public string? XER_Area_Valid { get; set; }

    [JsonPropertyName("XER_Aviation_Company")]
    public string? XER_Aviation_Company { get; set; }

    [JsonPropertyName("XER_Aviation_Company_Valid")]
    public string? XER_Aviation_Company_Valid { get; set; }

    [JsonPropertyName("XER_Check_in_gate_number")]
    public string? XER_Check_in_gate_number { get; set; }

    [JsonPropertyName("XER_Check_in_gate_number_Valid")]
    public string? XER_Check_in_gate_number_Valid { get; set; }

    [JsonPropertyName("XER_CreateProblem")]
    public bool? XER_CreateProblem { get; set; }

    [JsonPropertyName("XER_CriticalFlag")]
    public bool? XER_CriticalFlag { get; set; }

    [JsonPropertyName("XER_Downtime_Note")]
    public string? XER_Downtime_Note { get; set; }

    [JsonPropertyName("XER_Kritichnost")]
    public string? XER_Kritichnost { get; set; }

    [JsonPropertyName("XER_LastReasonBadRouting")]
    public string? XER_LastReasonBadRouting { get; set; }

    [JsonPropertyName("XER_ReadOnlyPriority")]
    public bool? XER_ReadOnlyPriority { get; set; }

    [JsonPropertyName("XER_ReasonOfFailure")]
    public string? XER_ReasonOfFailure { get; set; }

    [JsonPropertyName("XER_ReasonOfFailure_Valid")]
    public string? XER_ReasonOfFailure_Valid { get; set; }

    [JsonPropertyName("XER_Scale_of_the_problem")]
    public string? XER_Scale_of_the_problem { get; set; }

    [JsonPropertyName("XER_Scale_of_the_problem_Valid")]
    public string? XER_Scale_of_the_problem_Valid { get; set; }

    [JsonPropertyName("XER_SelfServicePriority")]
    public string? XER_SelfServicePriority { get; set; }

    [JsonPropertyName("XER_SelfServicePriority_Valid")]
    public string? XER_SelfServicePriority_Valid { get; set; }

    [JsonPropertyName("XER_ServiceLink_Category")]
    public string? XER_ServiceLink_Category { get; set; }

    [JsonPropertyName("XER_ServiceLink_RecID")]
    public string? XER_ServiceLink_RecID { get; set; }

    [JsonPropertyName("XER_TaskAuto")]
    public bool? XER_TaskAuto { get; set; }

    [JsonPropertyName("XER_Terminal")]
    public string? XER_Terminal { get; set; }

    [JsonPropertyName("XER_Terminal_Valid")]
    public string? XER_Terminal_Valid { get; set; }

    [JsonPropertyName("XER_Zamar")]
    public string? XER_Zamar { get; set; }

    [JsonPropertyName("XER_Zamar_Valid")]
    public string? XER_Zamar_Valid { get; set; }

    [JsonPropertyName("XER_Cloned")]
    public bool? XER_Cloned { get; set; }

    [JsonPropertyName("XERVoiceActivityRecId")]
    public string? XERVoiceActivityRecId { get; set; }

    [JsonPropertyName("helpdesk_Priority")]
    public string? helpdesk_Priority { get; set; }

    [JsonPropertyName("helpdesk_Priority_Valid")]
    public string? helpdesk_Priority_Valid { get; set; }

    [JsonPropertyName("Subcategory")]
    public string? Subcategory { get; set; }

    [JsonPropertyName("Subcategory_Valid")]
    public string? Subcategory_Valid { get; set; }

    [JsonPropertyName("AddChatconversationtoActivityHistory")]
    public bool? AddChatconversationtoActivityHistory { get; set; }

    [JsonPropertyName("ivnt_RequestforInformationorData")]
    public bool? ivnt_RequestforInformationorData { get; set; }

    [JsonPropertyName("ivnt_UpdateRFI")]
    public string? ivnt_UpdateRFI { get; set; }
}

public class IncidentAttachment
{
    [JsonPropertyName("RecId")]
    public string RecId { get; set; } = string.Empty;

    [JsonPropertyName("ATTACHNAME")]
    public string? ATTACHNAME { get; set; }

    [JsonPropertyName("ATTACHDESC")]
    public string? ATTACHDESC { get; set; }

    [JsonPropertyName("AttachmentHost")]
    public string? AttachmentHost { get; set; }

    [JsonPropertyName("AttachmentPath")]
    public string? AttachmentPath { get; set; }

    [JsonPropertyName("AttachmentSize")]
    public int? AttachmentSize { get; set; }

    [JsonPropertyName("URL")]
    public string? URL { get; set; }

    [JsonPropertyName("SaveType")]
    public string? SaveType { get; set; }

    [JsonPropertyName("Uploaded")]
    public bool? Uploaded { get; set; }

    [JsonPropertyName("DataRecId")]
    public string? DataRecId { get; set; }

    [JsonPropertyName("ParentLink_Category")]
    public string? ParentLink_Category { get; set; }

    [JsonPropertyName("ParentLink_RecID")]
    public string? ParentLink_RecID { get; set; }

    [JsonPropertyName("CreatedBy")]
    public string? CreatedBy { get; set; }

    [JsonPropertyName("CreatedDateTime")]
    public DateTime? CreatedDateTime { get; set; }

    [JsonPropertyName("LastModBy")]
    public string? LastModBy { get; set; }

    [JsonPropertyName("LastModDateTime")]
    public DateTime? LastModDateTime { get; set; }

    [JsonPropertyName("ReadOnly")]
    public bool? ReadOnly { get; set; }
}

public class CloneIncidentRequest
{
    public string SourceRecId { get; set; } = string.Empty;
    public bool CloneAttachments { get; set; } = true;
    public bool OpenInNewTab { get; set; } = true;
    public string? RedirectBaseUrl { get; set; }
    public Dictionary<string, object>? OverrideFields { get; set; }
}

public class CloneIncidentResponse
{
    public string? NewRecId { get; set; }
    public decimal NewIncidentNumber { get; set; }
    public bool Success { get; set; }
    public string Message { get; set; } = string.Empty;
    public List<string> Errors { get; set; } = new();
    public string? RedirectUrl { get; set; }
    public bool OpenInNewTab { get; set; }
    public TimeSpan ElapsedTime { get; set; }
}
