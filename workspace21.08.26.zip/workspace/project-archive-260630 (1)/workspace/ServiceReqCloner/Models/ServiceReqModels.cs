using System.Text.Json.Serialization;
using ServiceReqCloner.Converters;

namespace ServiceReqCloner.Models;

public class ServiceReq
{
    [JsonPropertyName("RecId")]
    public string? RecId { get; set; }

    [JsonPropertyName("Cancelable")]
    public bool Cancelable { get; set; }

    [JsonPropertyName("SvcReqTmplLink_Category")]
    public string SvcReqTmplLink_Category { get; set; } = string.Empty;

    [JsonPropertyName("SvcReqTmplLink_RecID")]
    public string SvcReqTmplLink_RecID { get; set; } = string.Empty;

    [JsonPropertyName("ServiceReqNumber")]
    [JsonConverter(typeof(DecimalNotNullConverter))]
    public decimal ServiceReqNumber { get; set; }

    [JsonPropertyName("Subject")]
    public string? Subject { get; set; }

    [JsonPropertyName("Symptom")]
    public string? Symptom { get; set; }

    [JsonPropertyName("Status")]
    public string? Status { get; set; }

    [JsonPropertyName("Status_Valid")]
    public string? Status_Valid { get; set; }

    [JsonPropertyName("Service")]
    public string? Service { get; set; }

    [JsonPropertyName("Service_Valid")]
    public string? Service_Valid { get; set; }

    [JsonPropertyName("Source")]
    public string? Source { get; set; }

    [JsonPropertyName("Source_Valid")]
    public string? Source_Valid { get; set; }

    [JsonPropertyName("Urgency")]
    public string? Urgency { get; set; }

    [JsonPropertyName("Urgency_Valid")]
    public string? Urgency_Valid { get; set; }

    [JsonPropertyName("Impact")]
    public string? Impact { get; set; }

    [JsonPropertyName("Impact_Valid")]
    public string? Impact_Valid { get; set; }

    [JsonPropertyName("Resolution")]
    public string? Resolution { get; set; }

    [JsonPropertyName("CreatedBy")]
    public string? CreatedBy { get; set; }

    [JsonPropertyName("CreatedDateTime")]
    public DateTime? CreatedDateTime { get; set; }

    [JsonPropertyName("LastModBy")]
    public string? LastModBy { get; set; }

    [JsonPropertyName("LastModDateTime")]
    public DateTime? LastModDateTime { get; set; }

    [JsonPropertyName("ClosedBy")]
    public string? ClosedBy { get; set; }

    [JsonPropertyName("ClosedDateTime")]
    public DateTime? ClosedDateTime { get; set; }

    [JsonPropertyName("ResolvedBy")]
    public string? ResolvedBy { get; set; }

    [JsonPropertyName("ResolvedDateTime")]
    public DateTime? ResolvedDateTime { get; set; }

    [JsonPropertyName("ProfileLink_Category")]
    public string? ProfileLink_Category { get; set; }

    [JsonPropertyName("ProfileLink_RecID")]
    public string? ProfileLink_RecID { get; set; }

    [JsonPropertyName("ProfileLink")]
    public string? ProfileLink { get; set; }

    [JsonPropertyName("ProfileFullName")]
    public string? ProfileFullName { get; set; }

    [JsonPropertyName("ProfileLoginId")]
    public string? ProfileLoginId { get; set; }

    [JsonPropertyName("Email")]
    public string? Email { get; set; }

    [JsonPropertyName("LoginId")]
    public string? LoginId { get; set; }

    [JsonPropertyName("Phone")]
    public string? Phone { get; set; }

    [JsonPropertyName("FIO")]
    public string? FIO { get; set; }

    [JsonPropertyName("FIO_Valid")]
    public string? FIO_Valid { get; set; }

    [JsonPropertyName("PERNR")]
    public string? PERNR { get; set; }

    [JsonPropertyName("PERNR_ZAM")]
    public string? PERNR_ZAM { get; set; }

    [JsonPropertyName("Owner")]
    public string? Owner { get; set; }

    [JsonPropertyName("Owner_Valid")]
    public string? Owner_Valid { get; set; }

    [JsonPropertyName("OwnerEmail")]
    public string? OwnerEmail { get; set; }

    [JsonPropertyName("OwnerTeam")]
    public string? OwnerTeam { get; set; }

    [JsonPropertyName("OwnerTeam_Valid")]
    public string? OwnerTeam_Valid { get; set; }

    [JsonPropertyName("OwnerTeamEmail")]
    public string? OwnerTeamEmail { get; set; }

    [JsonPropertyName("OwnerType")]
    public string? OwnerType { get; set; }

    [JsonPropertyName("OrganizationUnitID")]
    public string? OrganizationUnitID { get; set; }

    [JsonPropertyName("CustomerLocation")]
    public string? CustomerLocation { get; set; }

    [JsonPropertyName("OrgUnitLink_Category")]
    public string? OrgUnitLink_Category { get; set; }

    [JsonPropertyName("OrgUnitLink_RecID")]
    public string? OrgUnitLink_RecID { get; set; }

    [JsonPropertyName("EntityLink_Category")]
    public string? EntityLink_Category { get; set; }

    [JsonPropertyName("EntityLink_RecID")]
    public string? EntityLink_RecID { get; set; }

    [JsonPropertyName("EmployeeLink_Category")]
    public string? EmployeeLink_Category { get; set; }

    [JsonPropertyName("EmployeeLink_RecID")]
    public string? EmployeeLink_RecID { get; set; }

    [JsonPropertyName("SvcReqSubscLink_Category")]
    public string? SvcReqSubscLink_Category { get; set; }

    [JsonPropertyName("SvcReqSubscLink_RecID")]
    public string? SvcReqSubscLink_RecID { get; set; }

    [JsonPropertyName("SvcReqSubscLink")]
    public string? SvcReqSubscLink { get; set; }

    [JsonPropertyName("SvcReqTmplLink")]
    public string? SvcReqTmplLink { get; set; }

    [JsonPropertyName("ParentSvcReqLink_Category")]
    public string? ParentSvcReqLink_Category { get; set; }

    [JsonPropertyName("ParentSvcReqLink_RecID")]
    public string? ParentSvcReqLink_RecID { get; set; }

    [JsonPropertyName("IncidentLink_Category")]
    public string? IncidentLink_Category { get; set; }

    [JsonPropertyName("IncidentLink_RecID")]
    public string? IncidentLink_RecID { get; set; }

    [JsonPropertyName("HRCaseLink_Category")]
    public string? HRCaseLink_Category { get; set; }

    [JsonPropertyName("HRCaseLink_RecID")]
    public string? HRCaseLink_RecID { get; set; }

    [JsonPropertyName("FulfillmentPlanLink_Category")]
    public string? FulfillmentPlanLink_Category { get; set; }

    [JsonPropertyName("FulfillmentPlanLink_RecID")]
    public string? FulfillmentPlanLink_RecID { get; set; }

    [JsonPropertyName("ServiceReqTemplateDefinitionLink_Category")]
    public string? ServiceReqTemplateDefinitionLink_Category { get; set; }

    [JsonPropertyName("ServiceReqTemplateDefinitionLink_RecID")]
    public string? ServiceReqTemplateDefinitionLink_RecID { get; set; }

    [JsonPropertyName("ivnt_CILink_Category")]
    public string? ivnt_CILink_Category { get; set; }

    [JsonPropertyName("ivnt_CILink_RecID")]
    public string? ivnt_CILink_RecID { get; set; }

    [JsonPropertyName("ivnt_LinkHRCases_Category")]
    public string? ivnt_LinkHRCases_Category { get; set; }

    [JsonPropertyName("ivnt_LinkHRCases_RecID")]
    public string? ivnt_LinkHRCases_RecID { get; set; }

    [JsonPropertyName("ivnt_ProductCatalogLink_Category")]
    public string? ivnt_ProductCatalogLink_Category { get; set; }

    [JsonPropertyName("ivnt_ProductCatalogLink_RecID")]
    public string? ivnt_ProductCatalogLink_RecID { get; set; }

    [JsonPropertyName("ivnt_WorkOrderLink_Category")]
    public string? ivnt_WorkOrderLink_Category { get; set; }

    [JsonPropertyName("ivnt_WorkOrderLink_RecID")]
    public string? ivnt_WorkOrderLink_RecID { get; set; }

    [JsonPropertyName("ClosingEscLink_Category")]
    public string? ClosingEscLink_Category { get; set; }

    [JsonPropertyName("ClosingEscLink_RecID")]
    public string? ClosingEscLink_RecID { get; set; }

    [JsonPropertyName("ResolutionEscLink_Category")]
    public string? ResolutionEscLink_Category { get; set; }

    [JsonPropertyName("ResolutionEscLink_RecID")]
    public string? ResolutionEscLink_RecID { get; set; }

    [JsonPropertyName("ResponseEscLink_Category")]
    public string? ResponseEscLink_Category { get; set; }

    [JsonPropertyName("ResponseEscLink_RecID")]
    public string? ResponseEscLink_RecID { get; set; }

    [JsonPropertyName("WaitingEscLink_Category")]
    public string? WaitingEscLink_Category { get; set; }

    [JsonPropertyName("WaitingEscLink_RecID")]
    public string? WaitingEscLink_RecID { get; set; }

    [JsonPropertyName("SLA")]
    public string? SLA { get; set; }

    [JsonPropertyName("SLADisplayText")]
    public string? SLADisplayText { get; set; }

    [JsonPropertyName("SLALink_Category")]
    public string? SLALink_Category { get; set; }

    [JsonPropertyName("SLALink_RecID")]
    public string? SLALink_RecID { get; set; }

    [JsonPropertyName("IsVIP")]
    public bool? IsVIP { get; set; }

    [JsonPropertyName("IsDraft")]
    public bool? IsDraft { get; set; }

    [JsonPropertyName("IsNewRequestNotificationSent")]
    public bool? IsNewRequestNotificationSent { get; set; }

    [JsonPropertyName("IsReportedByAlternateContact")]
    public bool? IsReportedByAlternateContact { get; set; }

    [JsonPropertyName("IsUnRead")]
    public bool? IsUnRead { get; set; }

    [JsonPropertyName("IsInFinalState")]
    public bool? IsInFinalState { get; set; }

    [JsonPropertyName("IsDSMTaskExisted")]
    public bool? IsDSMTaskExisted { get; set; }

    [JsonPropertyName("IsEditable")]
    public bool? IsEditable { get; set; }

    [JsonPropertyName("IsTemplateEditable")]
    public bool? IsTemplateEditable { get; set; }

    [JsonPropertyName("IsExternal")]
    public bool? IsExternal { get; set; }

    [JsonPropertyName("ReadOnly")]
    public bool? ReadOnly { get; set; }

    [JsonPropertyName("BlockRequest")]
    public bool? BlockRequest { get; set; }

    [JsonPropertyName("ForceNotCancelable")]
    public bool? ForceNotCancelable { get; set; }

    [JsonPropertyName("ForceNotEditable")]
    public bool? ForceNotEditable { get; set; }

    [JsonPropertyName("HasScriptRun")]
    public bool? HasScriptRun { get; set; }

    [JsonPropertyName("InShoppingCart")]
    public bool? InShoppingCart { get; set; }

    [JsonPropertyName("Reorder_global_constant")]
    public bool? Reorder_global_constant { get; set; }

    [JsonPropertyName("ReorderContinue")]
    public bool? ReorderContinue { get; set; }

    [JsonPropertyName("SendSurveyNotification")]
    public bool? SendSurveyNotification { get; set; }

    [JsonPropertyName("TemplateCancelable")]
    public bool? TemplateCancelable { get; set; }

    [JsonPropertyName("ivnt_TimeSheetDuplicate")]
    public bool? ivnt_TimeSheetDuplicate { get; set; }

    [JsonPropertyName("ProgressBarPosition")]
    public string? ProgressBarPosition { get; set; }

    [JsonPropertyName("AlternateContactLink_Category")]
    public string? AlternateContactLink_Category { get; set; }

    [JsonPropertyName("AlternateContactLink_RecID")]
    public string? AlternateContactLink_RecID { get; set; }

    [JsonPropertyName("DefaultApprover")]
    public string? DefaultApprover { get; set; }

    [JsonPropertyName("DefaultApprover_Valid")]
    public string? DefaultApprover_Valid { get; set; }

    [JsonPropertyName("ChargingAccount")]
    public string? ChargingAccount { get; set; }

    [JsonPropertyName("ChargingAccount_Valid")]
    public string? ChargingAccount_Valid { get; set; }

    [JsonPropertyName("OfferStatus")]
    public string? OfferStatus { get; set; }

    [JsonPropertyName("OfferStatus_Valid")]
    public string? OfferStatus_Valid { get; set; }

    [JsonPropertyName("Price")]
    [JsonConverter(typeof(DecimalJsonConverter))]
    public decimal? Price { get; set; }

    [JsonPropertyName("Price_Currency")]
    public string? Price_Currency { get; set; }

    [JsonPropertyName("Price_CurrencyValid")]
    public string? Price_CurrencyValid { get; set; }

    [JsonPropertyName("Cost")]
    [JsonConverter(typeof(DecimalJsonConverter))]
    public decimal? Cost { get; set; }

    [JsonPropertyName("Cost_Currency")]
    public string? Cost_Currency { get; set; }

    [JsonPropertyName("Cost_CurrencyValid")]
    public string? Cost_CurrencyValid { get; set; }

    [JsonPropertyName("CostPerMinute")]
    [JsonConverter(typeof(DecimalJsonConverter))]
    public decimal? CostPerMinute { get; set; }

    [JsonPropertyName("CostPerMinute_Currency")]
    public string? CostPerMinute_Currency { get; set; }

    [JsonPropertyName("CostPerMinute_CurrencyValid")]
    public string? CostPerMinute_CurrencyValid { get; set; }

    [JsonPropertyName("DraftPrice")]
    [JsonConverter(typeof(DecimalJsonConverter))]
    public decimal? DraftPrice { get; set; }

    [JsonPropertyName("DraftPrice_Currency")]
    public string? DraftPrice_Currency { get; set; }

    [JsonPropertyName("DraftPrice_CurrencyValid")]
    public string? DraftPrice_CurrencyValid { get; set; }

    [JsonPropertyName("RecurrentPrice")]
    [JsonConverter(typeof(DecimalJsonConverter))]
    public decimal? RecurrentPrice { get; set; }

    [JsonPropertyName("RecurrentPrice_Currency")]
    public string? RecurrentPrice_Currency { get; set; }

    [JsonPropertyName("RecurrentPrice_CurrencyValid")]
    public string? RecurrentPrice_CurrencyValid { get; set; }

    [JsonPropertyName("TaskPriceUSD")]
    [JsonConverter(typeof(DecimalJsonConverter))]
    public decimal? TaskPriceUSD { get; set; }

    [JsonPropertyName("TaskPriceUSD_Currency")]
    public string? TaskPriceUSD_Currency { get; set; }

    [JsonPropertyName("TaskPriceUSD_CurrencyValid")]
    public string? TaskPriceUSD_CurrencyValid { get; set; }

    [JsonPropertyName("TaskCostUSD")]
    [JsonConverter(typeof(DecimalJsonConverter))]
    public decimal? TaskCostUSD { get; set; }

    [JsonPropertyName("TaskCostUSD_Currency")]
    public string? TaskCostUSD_Currency { get; set; }

    [JsonPropertyName("TaskCostUSD_CurrencyValid")]
    public string? TaskCostUSD_CurrencyValid { get; set; }

    [JsonPropertyName("TotalTimeSpent")]
    [JsonConverter(typeof(DecimalJsonConverter))]
    public decimal? TotalTimeSpent { get; set; }

    [JsonPropertyName("RecurrentPeriod")]
    public short? RecurrentPeriod { get; set; }

    [JsonPropertyName("ivnt_PurchaseRequestCount")]
    public int? ivnt_PurchaseRequestCount { get; set; }

    [JsonPropertyName("ivnt_RequestedCatalogItemCount")]
    public int? ivnt_RequestedCatalogItemCount { get; set; }

    [JsonPropertyName("BEGDA")]
    public DateTime? BEGDA { get; set; }

    [JsonPropertyName("ENDDA")]
    public DateTime? ENDDA { get; set; }

    [JsonPropertyName("ExternalViewUrl")]
    public string? ExternalViewUrl { get; set; }

    [JsonPropertyName("WaitRequest")]
    public string? WaitRequest { get; set; }

    [JsonPropertyName("RequestOfferingWFTrigger")]
    public string? RequestOfferingWFTrigger { get; set; }

    [JsonPropertyName("SVO_KopaniyaIspolnitelya")]
    public string? SVO_KopaniyaIspolnitelya { get; set; }

    [JsonPropertyName("SVO_laborexpenditures")]
    public byte? SVO_laborexpenditures { get; set; }

    [JsonPropertyName("SVO_Moredetailed")]
    public string? SVO_Moredetailed { get; set; }

    [JsonPropertyName("SVO_PlanedEndDate")]
    public DateTime? SVO_PlanedEndDate { get; set; }

    [JsonPropertyName("SVO_PodrazdelenieIspolnitelya")]
    public string? SVO_PodrazdelenieIspolnitelya { get; set; }

    [JsonPropertyName("SVO_ProgrammModule")]
    public string? SVO_ProgrammModule { get; set; }

    [JsonPropertyName("SVO_ProgrammModule_Valid")]
    public string? SVO_ProgrammModule_Valid { get; set; }

    [JsonPropertyName("SVO_RespondedDateTime")]
    public DateTime? SVO_RespondedDateTime { get; set; }

    [JsonPropertyName("SWO_ConsumerId")]
    public string? SWO_ConsumerId { get; set; }

    [JsonPropertyName("SWO_flag_AVK")]
    public bool? SWO_flag_AVK { get; set; }

    [JsonPropertyName("SWO_flag_ServiceManager")]
    public bool? SWO_flag_ServiceManager { get; set; }

    [JsonPropertyName("TRN_ActiveTasks")]
    public string? TRN_ActiveTasks { get; set; }

    [JsonPropertyName("TRN_AktivnayaZadacha1")]
    public bool? TRN_AktivnayaZadacha1 { get; set; }

    [JsonPropertyName("TRN_AktivnayaZadacha10")]
    public bool? TRN_AktivnayaZadacha10 { get; set; }

    [JsonPropertyName("TRN_AktivnayaZadacha2")]
    public bool? TRN_AktivnayaZadacha2 { get; set; }

    [JsonPropertyName("TRN_AktivnayaZadacha3")]
    public bool? TRN_AktivnayaZadacha3 { get; set; }

    [JsonPropertyName("TRN_AktivnayaZadacha4")]
    public bool? TRN_AktivnayaZadacha4 { get; set; }

    [JsonPropertyName("TRN_AktivnayaZadacha5")]
    public bool? TRN_AktivnayaZadacha5 { get; set; }

    [JsonPropertyName("TRN_AktivnayaZadacha6")]
    public bool? TRN_AktivnayaZadacha6 { get; set; }

    [JsonPropertyName("TRN_AktivnayaZadacha7")]
    public bool? TRN_AktivnayaZadacha7 { get; set; }

    [JsonPropertyName("TRN_AktivnayaZadacha8")]
    public bool? TRN_AktivnayaZadacha8 { get; set; }

    [JsonPropertyName("TRN_AktivnayaZadacha9")]
    public bool? TRN_AktivnayaZadacha9 { get; set; }

    [JsonPropertyName("TRN_AlternateContactFullName")]
    public string? TRN_AlternateContactFullName { get; set; }

    [JsonPropertyName("TRN_ApprovalReason")]
    public string? TRN_ApprovalReason { get; set; }

    [JsonPropertyName("TRN_ApprovalTeam")]
    public string? TRN_ApprovalTeam { get; set; }

    [JsonPropertyName("TRN_ApprovalTeam_Valid")]
    public string? TRN_ApprovalTeam_Valid { get; set; }

    [JsonPropertyName("TRN_Approver")]
    public string? TRN_Approver { get; set; }

    [JsonPropertyName("TRN_Approver_Valid")]
    public string? TRN_Approver_Valid { get; set; }

    [JsonPropertyName("TRN_Approvers")]
    public string? TRN_Approvers { get; set; }

    [JsonPropertyName("TRN_Approvers_Valid")]
    public string? TRN_Approvers_Valid { get; set; }

    [JsonPropertyName("TRN_Approvers2")]
    public string? TRN_Approvers2 { get; set; }

    [JsonPropertyName("TRN_Approvers2_Valid")]
    public string? TRN_Approvers2_Valid { get; set; }

    [JsonPropertyName("TRN_ApproversAll")]
    public string? TRN_ApproversAll { get; set; }

    [JsonPropertyName("TRN_BackToWorkReason")]
    public string? TRN_BackToWorkReason { get; set; }

    [JsonPropertyName("TRN_BreachDateTime")]
    public DateTime? TRN_BreachDateTime { get; set; }

    [JsonPropertyName("TRN_ChangeDateWaiting")]
    public DateTime? TRN_ChangeDateWaiting { get; set; }

    [JsonPropertyName("TRN_ChangeNumber")]
    public string? TRN_ChangeNumber { get; set; }

    [JsonPropertyName("TRN_CustomerAnswer")]
    public string? TRN_CustomerAnswer { get; set; }

    [JsonPropertyName("TRN_CustomerInfo")]
    public string? TRN_CustomerInfo { get; set; }

    [JsonPropertyName("TRN_CustomerInfoCounter")]
    [JsonConverter(typeof(DecimalJsonConverter))]
    public decimal? TRN_CustomerInfoCounter { get; set; }

    [JsonPropertyName("TRN_CustomerInfoInitiator")]
    public string? TRN_CustomerInfoInitiator { get; set; }

    [JsonPropertyName("TRN_CustomerInfoOrgUnit")]
    public string? TRN_CustomerInfoOrgUnit { get; set; }

    [JsonPropertyName("TRN_DisplayVoteTracking")]
    public string? TRN_DisplayVoteTracking { get; set; }

    [JsonPropertyName("TRN_DisplayVoteTrackingSelfService")]
    public string? TRN_DisplayVoteTrackingSelfService { get; set; }

    [JsonPropertyName("TRN_Effort")]
    public long? TRN_Effort { get; set; }

    [JsonPropertyName("TRN_Escalation75Percent")]
    public bool? TRN_Escalation75Percent { get; set; }

    [JsonPropertyName("TRN_EscalationBreach")]
    public bool? TRN_EscalationBreach { get; set; }

    [JsonPropertyName("TRN_EscalationResponse75Percent")]
    public bool? TRN_EscalationResponse75Percent { get; set; }

    [JsonPropertyName("TRN_EscalationResponseBreach")]
    public bool? TRN_EscalationResponseBreach { get; set; }

    [JsonPropertyName("TRN_HasChildChange")]
    public bool? TRN_HasChildChange { get; set; }

    [JsonPropertyName("TRN_IconResolutionBreach")]
    public string? TRN_IconResolutionBreach { get; set; }

    [JsonPropertyName("TRN_IconResponseBreach")]
    public string? TRN_IconResponseBreach { get; set; }

    [JsonPropertyName("TRN_InitialEmailSent")]
    public bool? TRN_InitialEmailSent { get; set; }

    [JsonPropertyName("TRN_IspolniteliLoginID")]
    public string? TRN_IspolniteliLoginID { get; set; }

    [JsonPropertyName("TRN_IspolniteliLoginIDBool")]
    public bool? TRN_IspolniteliLoginIDBool { get; set; }

    [JsonPropertyName("TRN_KalendarNaReakciyuZNO")]
    public string? TRN_KalendarNaReakciyuZNO { get; set; }

    [JsonPropertyName("TRN_KalendarNaReakciyuZNO_Valid")]
    public string? TRN_KalendarNaReakciyuZNO_Valid { get; set; }

    [JsonPropertyName("TRN_KalendarNaVypolnenieZNO")]
    public string? TRN_KalendarNaVypolnenieZNO { get; set; }

    [JsonPropertyName("TRN_KalendarNaVypolnenieZNO_Valid")]
    public string? TRN_KalendarNaVypolnenieZNO_Valid { get; set; }

    [JsonPropertyName("TRN_Kompaniya")]
    public string? TRN_Kompaniya { get; set; }

    [JsonPropertyName("TRN_Kompaniya_Valid")]
    public string? TRN_Kompaniya_Valid { get; set; }

    [JsonPropertyName("TRN_LastNote")]
    public string? TRN_LastNote { get; set; }

    [JsonPropertyName("TRN_LastOwner")]
    public string? TRN_LastOwner { get; set; }

    [JsonPropertyName("TRN_LastStatus")]
    public string? TRN_LastStatus { get; set; }

    [JsonPropertyName("TRN_ManagerApprover")]
    public string? TRN_ManagerApprover { get; set; }

    [JsonPropertyName("TRN_Mark")]
    public byte? TRN_Mark { get; set; }

    [JsonPropertyName("TRN_Mark_Valid")]
    public string? TRN_Mark_Valid { get; set; }

    [JsonPropertyName("TRN_MarkReason")]
    public string? TRN_MarkReason { get; set; }

    [JsonPropertyName("TRN_Mestopolozhenie")]
    public string? TRN_Mestopolozhenie { get; set; }

    [JsonPropertyName("TRN_Mestopolozhenie_Valid")]
    public string? TRN_Mestopolozhenie_Valid { get; set; }

    [JsonPropertyName("TRN_NeedManagerApproval")]
    public bool? TRN_NeedManagerApproval { get; set; }

    [JsonPropertyName("TRN_NomerTelefona")]
    public string? TRN_NomerTelefona { get; set; }

    [JsonPropertyName("TRN_Phase")]
    public string? TRN_Phase { get; set; }

    [JsonPropertyName("TRN_Phase_Valid")]
    public string? TRN_Phase_Valid { get; set; }

    [JsonPropertyName("TRN_PokazatelyKPI")]
    public string? TRN_PokazatelyKPI { get; set; }

    [JsonPropertyName("TRN_PokazatelyKPI_Valid")]
    public string? TRN_PokazatelyKPI_Valid { get; set; }

    [JsonPropertyName("TRN_PrioritetZNO")]
    public string? TRN_PrioritetZNO { get; set; }

    [JsonPropertyName("TRN_PrioritetZNO_Valid")]
    public string? TRN_PrioritetZNO_Valid { get; set; }

    [JsonPropertyName("TRN_Priority")]
    public string? TRN_Priority { get; set; }

    [JsonPropertyName("TRN_Priority_Valid")]
    public string? TRN_Priority_Valid { get; set; }

    [JsonPropertyName("TRN_PublishNoteToWeb")]
    public bool? TRN_PublishNoteToWeb { get; set; }

    [JsonPropertyName("TRN_RegistratorFullName")]
    public string? TRN_RegistratorFullName { get; set; }

    [JsonPropertyName("TRN_ResponseDateTime")]
    public DateTime? TRN_ResponseDateTime { get; set; }

    [JsonPropertyName("TRN_SendAssignmentNotification")]
    public bool? TRN_SendAssignmentNotification { get; set; }

    [JsonPropertyName("TRN_ServiceReqParameters")]
    public string? TRN_ServiceReqParameters { get; set; }

    [JsonPropertyName("TRN_ServiceReqRejected")]
    public bool? TRN_ServiceReqRejected { get; set; }

    [JsonPropertyName("TRN_ServiceReqService")]
    public string? TRN_ServiceReqService { get; set; }

    [JsonPropertyName("TRN_Status")]
    public string? TRN_Status { get; set; }

    [JsonPropertyName("TRN_Status_Valid")]
    public string? TRN_Status_Valid { get; set; }

    [JsonPropertyName("TRN_StatusActive")]
    public bool? TRN_StatusActive { get; set; }

    [JsonPropertyName("TRN_Summary")]
    public string? TRN_Summary { get; set; }

    [JsonPropertyName("TRN_SupportReqLink_Category")]
    public string? TRN_SupportReqLink_Category { get; set; }

    [JsonPropertyName("TRN_SupportReqLink_RecID")]
    public string? TRN_SupportReqLink_RecID { get; set; }

    [JsonPropertyName("TRN_SupportReqNumber")]
    public long? TRN_SupportReqNumber { get; set; }

    [JsonPropertyName("TRN_TaskEscalation")]
    public bool? TRN_TaskEscalation { get; set; }

    [JsonPropertyName("TRN_TaskNeedAnswer")]
    public string? TRN_TaskNeedAnswer { get; set; }

    [JsonPropertyName("TRN_TaskRejectReason")]
    public string? TRN_TaskRejectReason { get; set; }

    [JsonPropertyName("TRN_TeamManagerEmail")]
    public string? TRN_TeamManagerEmail { get; set; }

    [JsonPropertyName("TRN_TeamManagerFullName")]
    public string? TRN_TeamManagerFullName { get; set; }

    [JsonPropertyName("TRN_VliyanieZNO")]
    public string? TRN_VliyanieZNO { get; set; }

    [JsonPropertyName("TRN_VliyanieZNO_Valid")]
    public string? TRN_VliyanieZNO_Valid { get; set; }

    [JsonPropertyName("TRN_VremyaReakciiZNO")]
    public string? TRN_VremyaReakciiZNO { get; set; }

    [JsonPropertyName("TRN_VremyaReakciiZNO_Valid")]
    public string? TRN_VremyaReakciiZNO_Valid { get; set; }

    [JsonPropertyName("TRN_VremyaVypolneniyaZNO")]
    public string? TRN_VremyaVypolneniyaZNO { get; set; }

    [JsonPropertyName("TRN_VremyaVypolneniyaZNO_Valid")]
    public string? TRN_VremyaVypolneniyaZNO_Valid { get; set; }

    [JsonPropertyName("TRN_WaitingDateTime")]
    public DateTime? TRN_WaitingDateTime { get; set; }

    [JsonPropertyName("TRN_WaitingReason")]
    public string? TRN_WaitingReason { get; set; }

    [JsonPropertyName("XER_ApproverAllDisplayName")]
    public string? XER_ApproverAllDisplayName { get; set; }

    [JsonPropertyName("XER_ApproverTeam2Valid")]
    public string? XER_ApproverTeam2Valid { get; set; }

    [JsonPropertyName("XER_ApproverTeamvalid")]
    public string? XER_ApproverTeamvalid { get; set; }

    [JsonPropertyName("XER_CancelledLink_Category")]
    public string? XER_CancelledLink_Category { get; set; }

    [JsonPropertyName("XER_CancelledLink_RecID")]
    public string? XER_CancelledLink_RecID { get; set; }

    [JsonPropertyName("XER_IntegrationResponse")]
    public string? XER_IntegrationResponse { get; set; }

    [JsonPropertyName("XER_LastReasonBadRouting")]
    public string? XER_LastReasonBadRouting { get; set; }

    [JsonPropertyName("XERVoiceActivityRecId")]
    public string? XERVoiceActivityRecId { get; set; }
}

public class ServiceReqParameter
{
    [JsonPropertyName("RecId")]
    public string? RecId { get; set; }

    [JsonPropertyName("ParameterName")]
    public string? ParameterName { get; set; }

    [JsonPropertyName("ParameterValue")]
    public string? ParameterValue { get; set; }

    [JsonPropertyName("DisplayType")]
    public string? DisplayType { get; set; }

    [JsonPropertyName("DisplayType_Valid")]
    public string? DisplayType_Valid { get; set; }

    [JsonPropertyName("ParameterDisplayValue")]
    public string? ParameterDisplayValue { get; set; }

    [JsonPropertyName("ParameterDisplayValue_de")]
    public string? ParameterDisplayValue_de { get; set; }

    [JsonPropertyName("ParameterDisplayValue_es")]
    public string? ParameterDisplayValue_es { get; set; }

    [JsonPropertyName("ParameterDisplayValue_fr")]
    public string? ParameterDisplayValue_fr { get; set; }

    [JsonPropertyName("ParameterDisplayValue_it")]
    public string? ParameterDisplayValue_it { get; set; }

    [JsonPropertyName("ParameterDisplayValue_ja")]
    public string? ParameterDisplayValue_ja { get; set; }

    [JsonPropertyName("ParameterDisplayValue_nl")]
    public string? ParameterDisplayValue_nl { get; set; }

    [JsonPropertyName("ParameterDisplayValue_pl")]
    public string? ParameterDisplayValue_pl { get; set; }

    [JsonPropertyName("ParameterDisplayValue_pt_BR")]
    public string? ParameterDisplayValue_pt_BR { get; set; }

    [JsonPropertyName("ParameterDisplayValue_ru")]
    public string? ParameterDisplayValue_ru { get; set; }

    [JsonPropertyName("ParameterDisplayValue_zh_CN")]
    public string? ParameterDisplayValue_zh_CN { get; set; }

    [JsonPropertyName("ParameterDisplayValue_zh_TW")]
    public string? ParameterDisplayValue_zh_TW { get; set; }

    [JsonPropertyName("ParameterName_de")]
    public string? ParameterName_de { get; set; }

    [JsonPropertyName("ParameterName_es")]
    public string? ParameterName_es { get; set; }

    [JsonPropertyName("ParameterName_fr")]
    public string? ParameterName_fr { get; set; }

    [JsonPropertyName("ParameterName_it")]
    public string? ParameterName_it { get; set; }

    [JsonPropertyName("ParameterName_ja")]
    public string? ParameterName_ja { get; set; }

    [JsonPropertyName("ParameterName_nl")]
    public string? ParameterName_nl { get; set; }

    [JsonPropertyName("ParameterName_pl")]
    public string? ParameterName_pl { get; set; }

    [JsonPropertyName("ParameterName_pt_BR")]
    public string? ParameterName_pt_BR { get; set; }

    [JsonPropertyName("ParameterName_ru")]
    public string? ParameterName_ru { get; set; }

    [JsonPropertyName("ParameterName_zh_CN")]
    public string? ParameterName_zh_CN { get; set; }

    [JsonPropertyName("ParameterName_zh_TW")]
    public string? ParameterName_zh_TW { get; set; }

    [JsonPropertyName("TRN_ParameterName")]
    public string? TRN_ParameterName { get; set; }

    [JsonPropertyName("ParentLink_Category")]
    public string? ParentLink_Category { get; set; }

    [JsonPropertyName("ParentLink_RecID")]
    public string? ParentLink_RecID { get; set; }

    [JsonPropertyName("SvcReqTmplParamLink_Category")]
    public string? SvcReqTmplParamLink_Category { get; set; }

    [JsonPropertyName("SvcReqTmplParamLink_RecID")]
    public string? SvcReqTmplParamLink_RecID { get; set; }

    [JsonPropertyName("ParameterLink_Category")]
    public string? ParameterLink_Category { get; set; }

    [JsonPropertyName("ParameterLink_RecID")]
    public string? ParameterLink_RecID { get; set; }

    [JsonPropertyName("EntityLink_Category")]
    public string? EntityLink_Category { get; set; }

    [JsonPropertyName("EntityLink_RecID")]
    public string? EntityLink_RecID { get; set; }

    [JsonPropertyName("PriceItemPriceLink_Category")]
    public string? PriceItemPriceLink_Category { get; set; }

    [JsonPropertyName("PriceItemPriceLink_RecID")]
    public string? PriceItemPriceLink_RecID { get; set; }

    [JsonPropertyName("PriceItemRecurringPriceLink_Category")]
    public string? PriceItemRecurringPriceLink_Category { get; set; }

    [JsonPropertyName("PriceItemRecurringPriceLink_RecID")]
    public string? PriceItemRecurringPriceLink_RecID { get; set; }

    [JsonPropertyName("PriceVarianceLink_Category")]
    public string? PriceVarianceLink_Category { get; set; }

    [JsonPropertyName("PriceVarianceLink_RecID")]
    public string? PriceVarianceLink_RecID { get; set; }

    [JsonPropertyName("PriceVarianceRecurringPriceLink_Category")]
    public string? PriceVarianceRecurringPriceLink_Category { get; set; }

    [JsonPropertyName("PriceVarianceRecurringPriceLink_RecID")]
    public string? PriceVarianceRecurringPriceLink_RecID { get; set; }

    [JsonPropertyName("CreatedBy")]
    public string? CreatedBy { get; set; }

    [JsonPropertyName("CreatedDateTime")]
    public DateTime? CreatedDateTime { get; set; }

    [JsonPropertyName("LastModBy")]
    public string? LastModBy { get; set; }

    [JsonPropertyName("LastModDateTime")]
    public DateTime? LastModDateTime { get; set; }

    [JsonPropertyName("ParameterPrice")]
    [JsonConverter(typeof(DecimalJsonConverter))]
    public decimal? ParameterPrice { get; set; }

    [JsonPropertyName("Price")]
    [JsonConverter(typeof(DecimalJsonConverter))]
    public decimal? Price { get; set; }

    [JsonPropertyName("Price_Currency")]
    public string? Price_Currency { get; set; }

    [JsonPropertyName("Price_CurrencyValid")]
    public string? Price_CurrencyValid { get; set; }

    [JsonPropertyName("RecurrentPrice")]
    [JsonConverter(typeof(DecimalJsonConverter))]
    public decimal? RecurrentPrice { get; set; }

    [JsonPropertyName("RecurrentPrice_Currency")]
    public string? RecurrentPrice_Currency { get; set; }

    [JsonPropertyName("RecurrentPrice_CurrencyValid")]
    public string? RecurrentPrice_CurrencyValid { get; set; }

    [JsonPropertyName("RecurrentPeriod")]
    public short? RecurrentPeriod { get; set; }

    [JsonPropertyName("RecurrenceType")]
    public string? RecurrenceType { get; set; }

    [JsonPropertyName("ReadOnly")]
    public bool? ReadOnly { get; set; }

    [JsonPropertyName("ReadOnlyExpression")]
    public string? ReadOnlyExpression { get; set; }
}

public class ServiceReqAttachment
{
    [JsonPropertyName("RecId")]
    public string? RecId { get; set; }

    [JsonPropertyName("ATTACHNAME")]
    public string? ATTACHNAME { get; set; }

    [JsonPropertyName("ATTACHDESC")]
    public string? ATTACHDESC { get; set; }

    [JsonPropertyName("AttachmentHost")]
    public string? AttachmentHost { get; set; }

    [JsonPropertyName("AttachmentPath")]
    public string? AttachmentPath { get; set; }

    [JsonPropertyName("AttachmentSize")]
    public int? AttachmentSize { get; set; }

    [JsonPropertyName("URL")]
    public string? URL { get; set; }

    [JsonPropertyName("SaveType")]
    public string? SaveType { get; set; }

    [JsonPropertyName("Uploaded")]
    public bool? Uploaded { get; set; }

    [JsonPropertyName("DataRecId")]
    public string? DataRecId { get; set; }

    [JsonPropertyName("ParentLink_Category")]
    public string? ParentLink_Category { get; set; }

    [JsonPropertyName("ParentLink_RecID")]
    public string? ParentLink_RecID { get; set; }

    [JsonPropertyName("CreatedBy")]
    public string? CreatedBy { get; set; }

    [JsonPropertyName("CreatedDateTime")]
    public DateTime? CreatedDateTime { get; set; }

    [JsonPropertyName("LastModBy")]
    public string? LastModBy { get; set; }

    [JsonPropertyName("LastModDateTime")]
    public DateTime? LastModDateTime { get; set; }

    [JsonPropertyName("ReadOnly")]
    public bool? ReadOnly { get; set; }
}

public class CloneRequest
{
    public string SourceRecId { get; set; } = string.Empty;
    public bool CloneParameters { get; set; } = true;
    public bool CloneAttachments { get; set; } = true;
    public bool OpenInNewTab { get; set; } = true;
    public string? RedirectBaseUrl { get; set; }
    public Dictionary<string, object>? OverrideFields { get; set; }
}

public class CloneResponse
{
    public string? NewRecId { get; set; }
    public decimal NewServiceReqNumber { get; set; }
    public bool Success { get; set; }
    public string Message { get; set; } = string.Empty;
    public List<string> Errors { get; set; } = new();
    public string? RedirectUrl { get; set; }
    public bool OpenInNewTab { get; set; }
    public TimeSpan ElapsedTime { get; set; }
}

public class ODataResponse<T>
{
    [JsonPropertyName("value")]
    public List<T> Value { get; set; } = new();

    [JsonPropertyName("@odata.count")]
    public int? Count { get; set; }

    [JsonPropertyName("@odata.nextLink")]
    public string? NextLink { get; set; }

    [JsonPropertyName("@odata.context")]
    public string? Context { get; set; }
}
