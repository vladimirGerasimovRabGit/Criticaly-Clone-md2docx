using ServiceReqCloner.Models;
using System.Reflection;

namespace ServiceReqCloner.Services;

/// <summary>
/// Сервис для клонирования ServiceReq со всеми связанными параметрами и вложениями
/// </summary>
public class ServiceReqClonerService : IServiceReqClonerService
{
    private readonly IHeatApiService _heatApiService;
    private readonly ILogger<ServiceReqClonerService> _logger;
    private readonly IConfiguration _configuration;

    private static readonly HashSet<string> FieldsToSkip = new(StringComparer.OrdinalIgnoreCase)
    {
        "RecId",
        "ServiceReqNumber",
        "CreatedDateTime",
        "CreatedBy",
        "LastModDateTime",
        "LastModBy",
        "ClosedDateTime",
        "ClosedBy",
        "ResolvedDateTime",
        "ResolvedBy",
        "IsNewRecord",
        "IsUnRead",
        "HasScriptRun",
        "InShoppingCart",
        "ivnt_PurchaseRequestCount",
        "ivnt_RequestedCatalogItemCount"
    };

    public ServiceReqClonerService(
        IHeatApiService heatApiService,
        ILogger<ServiceReqClonerService> logger,
        IConfiguration configuration)
    {
        _heatApiService = heatApiService;
        _logger = logger;
        _configuration = configuration;
    }

    public async Task<CloneResponse> CloneServiceReqAsync(CloneRequest request, CancellationToken cancellationToken = default)
    {
        var response = new CloneResponse { Success = false };
        var stopwatch = System.Diagnostics.Stopwatch.StartNew();

        try
        {
            _logger.LogInformation("========== START CLONING PROCESS ==========");
            _logger.LogInformation("SourceRecId: {SourceRecId}", request.SourceRecId);

            var sourceServiceReq = await _heatApiService.GetServiceReqAsync(request.SourceRecId, cancellationToken);
            if (sourceServiceReq == null)
            {
                response.Message = $"ServiceReq with ID {request.SourceRecId} not found";
                return response;
            }

            var nextNumber = await _heatApiService.GetNextServiceReqNumberAsync(cancellationToken);
            _logger.LogInformation("Next ServiceReq number: {NextNumber}", nextNumber ?? 0);

            List<ServiceReqParameter>? sourceParameters = null;
            if (request.CloneParameters)
            {
                sourceParameters = await _heatApiService.GetServiceReqParametersAsync(request.SourceRecId, cancellationToken);
                _logger.LogInformation("Found {Count} parameters to clone", sourceParameters?.Count ?? 0);
            }

            List<ServiceReqAttachment>? sourceAttachments = null;
            if (request.CloneAttachments)
            {
                sourceAttachments = await _heatApiService.GetServiceReqAttachmentsAsync(request.SourceRecId, cancellationToken);
                _logger.LogInformation("Found {Count} attachments to clone", sourceAttachments?.Count ?? 0);
            }

            var clonedReq = CloneServiceReqObject(sourceServiceReq);

            if (nextNumber.HasValue)
            {
                clonedReq.ServiceReqNumber = nextNumber.Value;
                _logger.LogInformation("Set ServiceReqNumber to: {ServiceReqNumber}", nextNumber.Value);
            }

            if (request.OverrideFields != null)
            {
                ApplyFieldOverrides(clonedReq, request.OverrideFields);
            }

            var newServiceReq = await _heatApiService.CreateServiceReqAsync(clonedReq, cancellationToken);
            if (newServiceReq?.RecId == null)
            {
                response.Message = "Failed to create new ServiceReq";
                return response;
            }

            response.NewRecId = newServiceReq.RecId;
            response.NewServiceReqNumber = newServiceReq.ServiceReqNumber;

            var errors = new List<string>();

            if (request.CloneParameters && sourceParameters != null && sourceParameters.Any())
            {
                int paramSuccess = 0;
                foreach (var parameter in sourceParameters)
                {
                    try
                    {
                        var newParameter = CloneParameter(parameter, newServiceReq.RecId);
                        var success = await _heatApiService.CreateParameterAsync(newParameter, cancellationToken);

                        if (success)
                        {
                            paramSuccess++;
                        }
                        else
                        {
                            errors.Add($"Failed to clone parameter {parameter.ParameterName}");
                        }
                    }
                    catch (Exception ex)
                    {
                        errors.Add($"Error cloning parameter {parameter.ParameterName}: {ex.Message}");
                    }
                }

                _logger.LogInformation("Cloned {SuccessCount} out of {TotalCount} parameters",
                    paramSuccess, sourceParameters.Count);
            }

            if (request.CloneAttachments && sourceAttachments != null && sourceAttachments.Any())
            {
                int attachSuccess = 0;
                foreach (var attachment in sourceAttachments)
                {
                    try
                    {
                        var newAttachment = CloneAttachment(attachment, newServiceReq.RecId);
                        var success = await _heatApiService.CreateAttachmentAsync(newAttachment, cancellationToken);

                        if (success)
                        {
                            attachSuccess++;
                        }
                        else
                        {
                            errors.Add($"Failed to clone attachment {attachment.ATTACHNAME}");
                        }
                    }
                    catch (Exception ex)
                    {
                        errors.Add($"Error cloning attachment {attachment.ATTACHNAME}: {ex.Message}");
                    }
                }

                _logger.LogInformation("Cloned {SuccessCount} out of {TotalCount} attachments",
                    attachSuccess, sourceAttachments.Count);
            }

            var baseUrl = !string.IsNullOrEmpty(request.RedirectBaseUrl)
                ? request.RedirectBaseUrl.TrimEnd('/')
                : _configuration["HeatUI:BaseUrl"] ?? "https://svoivantisrv/HEAT";

            response.RedirectUrl = $"{baseUrl}/Login.aspx?Scope=ObjectWorkspace&CommandId=Search&ObjectType=ServiceReq%23&CommandData=RecId%2c%3d%2c0%2c{newServiceReq.RecId}%2cstring%2cAND%7C";
            response.OpenInNewTab = request.OpenInNewTab;
            response.Success = true;
            response.Message = errors.Any()
                ? $"Cloned with {errors.Count} warnings"
                : "Successfully cloned";
            response.Errors = errors;
            response.ElapsedTime = stopwatch.Elapsed;

            _logger.LogInformation("========== CLONING COMPLETED SUCCESSFULLY ==========");
            _logger.LogInformation("New ServiceReq ID: {NewRecId}, Number: {NewNumber}",
                newServiceReq.RecId, newServiceReq.ServiceReqNumber);
            _logger.LogInformation("Parameters cloned: {ParamCount}, Attachments cloned: {AttachCount}",
                sourceParameters?.Count ?? 0, sourceAttachments?.Count ?? 0);

            return response;
        }
        catch (Exception ex)
        {
            stopwatch.Stop();
            _logger.LogError(ex, "Error cloning ServiceReq {SourceRecId}", request.SourceRecId);
            response.Message = $"Error: {ex.Message}";
            response.ElapsedTime = stopwatch.Elapsed;
            return response;
        }
    }

    private ServiceReq CloneServiceReqObject(ServiceReq source)
    {
        var clone = new ServiceReq();
    var properties = typeof(ServiceReq).GetProperties(BindingFlags.Public | BindingFlags.Instance);

    foreach (var prop in properties)
    {
        if (FieldsToSkip.Contains(prop.Name))
            continue;

        if (prop.Name.Contains("EscLink", StringComparison.OrdinalIgnoreCase))
            continue;

        if (prop.Name.Equals("ServiceReqNumber", StringComparison.OrdinalIgnoreCase))
            continue;
            
        if (prop.Name.Equals("Status_Valid", StringComparison.OrdinalIgnoreCase))
            continue;

        var value = prop.GetValue(source);
        if (value != null && prop.CanWrite)
        {
            if (value is string str && string.IsNullOrEmpty(str))
                continue;

            prop.SetValue(clone, value);
        }
    }

    clone.Status = "Draft";
    clone.TRN_Status = "Draft";
    clone.Status_Valid = null;
    
    clone.IsInFinalState = false;
    clone.ProgressBarPosition = "1";
    clone.ReadOnly = false;
    clone.IsEditable = true;
    clone.IsTemplateEditable = true;
    clone.Cancelable = true;
    
    clone.Owner = null;
    clone.Owner_Valid = null;
    clone.OwnerTeam = null;
    clone.OwnerTeam_Valid = null;

    clone.CreatedDateTime = DateTime.UtcNow;
    clone.LastModDateTime = DateTime.UtcNow;
    clone.CreatedBy = "HEATAdmin";
    clone.LastModBy = "HEATAdmin";
    
    clone.IsDraft = true;

    return clone;
    }

    private ServiceReqParameter CloneParameter(ServiceReqParameter source, string newServiceReqId)
    {
        return new ServiceReqParameter
        {
            ParentLink_Category = "ServiceReq",
            ParentLink_RecID = newServiceReqId,
            ParameterName = source.ParameterName,
            ParameterValue = source.ParameterValue,
            DisplayType = source.DisplayType,
            ParameterPrice = source.ParameterPrice,
            ReadOnly = source.ReadOnly,
            ParameterDisplayValue = source.ParameterDisplayValue,
            SvcReqTmplParamLink_Category = source.SvcReqTmplParamLink_Category,
            SvcReqTmplParamLink_RecID = source.SvcReqTmplParamLink_RecID,
            Price_Currency = source.Price_Currency,
            Price = source.Price,
            RecurrentPrice = source.RecurrentPrice,
            RecurrentPrice_Currency = source.RecurrentPrice_Currency,
            RecurrentPeriod = source.RecurrentPeriod,
            RecId = null,
            CreatedDateTime = DateTime.UtcNow,
            LastModDateTime = DateTime.UtcNow,
            CreatedBy = "HEATAdmin",
            LastModBy = "HEATAdmin"
        };
    }

    private ServiceReqAttachment CloneAttachment(ServiceReqAttachment source, string newServiceReqId)
    {
        return new ServiceReqAttachment
        {
            ParentLink_Category = "ServiceReq",
            ParentLink_RecID = newServiceReqId,
            ATTACHNAME = source.ATTACHNAME,
            ATTACHDESC = source.ATTACHDESC,
            AttachmentHost = source.AttachmentHost,
            AttachmentPath = source.AttachmentPath,
            AttachmentSize = source.AttachmentSize,
            Uploaded = source.Uploaded,
            SaveType = source.SaveType,
            URL = source.URL,
            DataRecId = source.DataRecId,
            RecId = null,
            CreatedDateTime = DateTime.UtcNow,
            LastModDateTime = DateTime.UtcNow,
            CreatedBy = "HEATAdmin",
            LastModBy = "HEATAdmin",
            ReadOnly = source.ReadOnly
        };
    }

    private void ApplyFieldOverrides(ServiceReq serviceReq, Dictionary<string, object>? overrides)
    {
        if (overrides == null || overrides.Count == 0)
            return;

        var properties = typeof(ServiceReq).GetProperties(BindingFlags.Public | BindingFlags.Instance)
            .ToDictionary(p => p.Name, StringComparer.OrdinalIgnoreCase);

        foreach (var field in overrides)
        {
            if (properties.TryGetValue(field.Key, out var property) &&
                property.CanWrite &&
                !FieldsToSkip.Contains(property.Name))
            {
                try
                {
                    if (property.PropertyType == typeof(decimal) || property.PropertyType == typeof(decimal?))
                    {
                        var value = Convert.ToDecimal(field.Value);
                        property.SetValue(serviceReq, value);
                    }
                    else
                    {
                        var value = Convert.ChangeType(field.Value, property.PropertyType);
                        property.SetValue(serviceReq, value);
                    }
                    _logger.LogDebug("Overrode field {FieldName} with value {Value}", field.Key, field.Value);
                }
                catch (Exception ex)
                {
                    _logger.LogWarning(ex, "Failed to override field {FieldName}", field.Key);
                }
            }
        }
    }
}
