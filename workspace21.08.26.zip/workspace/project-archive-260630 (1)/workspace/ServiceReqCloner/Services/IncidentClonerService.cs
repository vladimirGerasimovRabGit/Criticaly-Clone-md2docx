using ServiceReqCloner.Models;
using System.Reflection;

namespace ServiceReqCloner.Services;

/// <summary>
/// Сервис для клонирования инцидентов
/// </summary>
public class IncidentClonerService : IIncidentClonerService
{
    private readonly IHeatApiService _heatApiService;
    private readonly ILogger<IncidentClonerService> _logger;
    private readonly IConfiguration _configuration;

    private static readonly HashSet<string> FieldsToSkip = new(StringComparer.OrdinalIgnoreCase)
    {
        "RecId",
        "IncidentNumber",
        "CreatedDateTime",
        "CreatedBy",
        "LastModDateTime",
        "LastModBy",
        "ClosedDateTime",
        "ClosedBy",
        "ResolvedDateTime",
        "ResolvedBy",
        "IsNewRecord",
        "IsUnRead",
        "TotalTimeSpent",
        "Cost"
    };

    public IncidentClonerService(
        IHeatApiService heatApiService,
        ILogger<IncidentClonerService> logger,
        IConfiguration configuration)
    {
        _heatApiService = heatApiService;
        _logger = logger;
        _configuration = configuration;
    }

    public async Task<CloneIncidentResponse> CloneIncidentAsync(CloneIncidentRequest request, CancellationToken cancellationToken = default)
    {
        var response = new CloneIncidentResponse { Success = false };
        var stopwatch = System.Diagnostics.Stopwatch.StartNew();

        try
        {
            _logger.LogInformation("========== START INCIDENT CLONING ==========");
            _logger.LogInformation("SourceRecId: {SourceRecId}", request.SourceRecId);

            var sourceIncident = await _heatApiService.GetIncidentAsync(request.SourceRecId, cancellationToken);
            if (sourceIncident == null)
            {
                response.Message = $"Incident with ID {request.SourceRecId} not found";
                return response;
            }

            var clonedIncident = CloneIncidentObject(sourceIncident);

            if (request.OverrideFields != null)
            {
                ApplyFieldOverrides(clonedIncident, request.OverrideFields);
            }

            var newIncident = await _heatApiService.CreateIncidentAsync(clonedIncident, cancellationToken);
            if (newIncident?.RecId == null)
            {
                response.Message = "Failed to create new Incident";
                return response;
            }

            response.NewRecId = newIncident.RecId;
            response.NewIncidentNumber = newIncident.IncidentNumber;

            var baseUrl = !string.IsNullOrEmpty(request.RedirectBaseUrl)
                ? request.RedirectBaseUrl.TrimEnd('/')
                : "http://win-5jhv4t9rj4p/HEAT";

            response.RedirectUrl = $"{baseUrl}/Login.aspx?Scope=ObjectWorkspace&CommandId=Search&ObjectType=Incident%23&CommandData=RecId%2c%3d%2c0%2c{newIncident.RecId}%2cstring%2cAND%7C";
            response.OpenInNewTab = request.OpenInNewTab;
            response.Success = true;
            response.Message = "Successfully cloned";
            response.ElapsedTime = stopwatch.Elapsed;

            _logger.LogInformation("========== INCIDENT CLONING COMPLETED ==========");
            _logger.LogInformation("New Incident ID: {NewRecId}, Number: {NewNumber}",
                newIncident.RecId, newIncident.IncidentNumber);

            return response;
        }
        catch (Exception ex)
        {
            stopwatch.Stop();
            _logger.LogError(ex, "Error cloning Incident {SourceRecId}", request.SourceRecId);
            response.Message = $"Error: {ex.Message}";
            response.ElapsedTime = stopwatch.Elapsed;
            return response;
        }
    }

    private Incident CloneIncidentObject(Incident source)
{
    var clone = new Incident();

    clone.Service_Valid = source.Service_Valid;
    clone.Source_Valid = source.Source_Valid;
    clone.Priority_Valid = source.Priority_Valid;
    clone.Category_Valid = source.Category_Valid;
    clone.ActualCategory_Valid = source.ActualCategory_Valid;
    clone.CauseCode_Valid = source.CauseCode_Valid;
    clone.Urgency_Valid = source.Urgency_Valid;
    clone.Impact_Valid = source.Impact_Valid;
    clone.ProfileLink_RecID = source.ProfileLink_RecID;
    clone.TRN_Category_Valid = source.TRN_Category_Valid;
    clone.Owner = null;
    clone.Owner_Valid = null;
    clone.OwnerTeam = null;
    clone.OwnerTeam_Valid = null;

    clone.Subject = source.Subject;
    clone.Symptom = source.Symptom;
    clone.Email = source.Email;
    clone.LoginId = source.LoginId;
    clone.OrganizationUnitID = source.OrganizationUnitID;
    clone.HoursOfOperation = source.HoursOfOperation;

    clone.Status = "Открыт";
    clone.Status_Valid = null;
    clone.TRN_Status = "Открыт";
    clone.CreatedDateTime = DateTime.UtcNow;
    clone.LastModDateTime = DateTime.UtcNow;
    clone.CreatedBy = "HEATAdmin";
    clone.LastModBy = "HEATAdmin";
    clone.IsVIP = source.IsVIP;
    clone.FirstCallResolution = source.FirstCallResolution;
    clone.IsWorkAround = source.IsWorkAround;
    clone.IsNotification = source.IsNotification;
    clone.XER_Cloned = true;

    return clone;
}

    private void ApplyFieldOverrides(Incident incident, Dictionary<string, object>? overrides)
    {
        if (overrides == null || overrides.Count == 0)
            return;

        var properties = typeof(Incident).GetProperties(BindingFlags.Public | BindingFlags.Instance)
            .ToDictionary(p => p.Name, StringComparer.OrdinalIgnoreCase);

        foreach (var field in overrides)
        {
            if (properties.TryGetValue(field.Key, out var property) &&
                property.CanWrite &&
                !FieldsToSkip.Contains(property.Name))
            {
                try
                {
                    if (property.PropertyType == typeof(decimal) || property.PropertyType == typeof(decimal?))
                    {
                        var value = Convert.ToDecimal(field.Value);
                        property.SetValue(incident, value);
                    }
                    else
                    {
                        var value = Convert.ChangeType(field.Value, property.PropertyType);
                        property.SetValue(incident, value);
                    }
                    _logger.LogDebug("Overrode field {FieldName} with value {Value}", field.Key, field.Value);
                }
                catch (Exception ex)
                {
                    _logger.LogWarning(ex, "Failed to override field {FieldName}", field.Key);
                }
            }
        }
    }
}
