using System.Net;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text;
using System.Text.Json;
using Microsoft.Extensions.Options;
using Polly;
using Polly.Retry;
using ServiceReqCloner.Models;
using ServiceReqCloner.Configuration;

namespace ServiceReqCloner.Services;

public class HeatApiService : IHeatApiService
{
    private readonly HttpClient _httpClient;
    private readonly ILogger<HeatApiService> _logger;
    private readonly JsonSerializerOptions _jsonOptions;
    private readonly string? _apiKey;
    private const int _ciPageSize = 100;
    private const int _relationsChunkSize = 20;
    private readonly ResiliencePipeline<HttpResponseMessage> _httpRetryPipeline;

    public HeatApiService(
        IHttpClientFactory httpClientFactory,
        ILogger<HeatApiService> logger,
        IOptions<HeatApiSettings> settings,
        IEncryptionService? encryptionService = null)
    {
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        
        if (settings?.Value == null)
        {
            throw new ArgumentNullException(nameof(settings), "HeatApi settings are not configured");
        }
        
        var config = settings.Value;
        
        if (string.IsNullOrEmpty(config.BaseUrl))
        {
            throw new InvalidOperationException("BaseUrl is not configured in HeatApi settings");
        }
        
        _apiKey = TryResolveApiKey(config, encryptionService);
        if (string.IsNullOrEmpty(_apiKey))
            _logger.LogWarning("No API key configured. API calls will fail. Configure HeatApi:ApiKey or HeatApi:EncryptedApiKey.");
        
        _logger.LogInformation("Initializing HeatApiService with BaseUrl: {BaseUrl}", config.BaseUrl);
        
        var handler = new HttpClientHandler
        {
            AllowAutoRedirect = true,
        };

        if (config.SkipCertificateValidation)
        {
            _logger.LogWarning("Certificate validation is DISABLED. This should only be used in development environments.");
            handler.ServerCertificateCustomValidationCallback = (message, cert, chain, errors) => true;
        }
        
        _httpClient = new HttpClient(handler);
        _httpClient.BaseAddress = new Uri(config.BaseUrl.TrimEnd('/') + '/');
        _httpClient.Timeout = TimeSpan.FromSeconds(config.TimeoutSeconds);
        
        if (!string.IsNullOrEmpty(_apiKey))
        {
            _httpClient.DefaultRequestHeaders.TryAddWithoutValidation("Authorization", $"rest_api_key={_apiKey}");
        }
        _httpClient.DefaultRequestHeaders.Accept.Add(
            new MediaTypeWithQualityHeaderValue("application/json"));
        
        _jsonOptions = new JsonSerializerOptions
        {
            PropertyNameCaseInsensitive = true,
            PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
            DefaultIgnoreCondition = System.Text.Json.Serialization.JsonIgnoreCondition.WhenWritingNull
        };

        _httpRetryPipeline = new ResiliencePipelineBuilder<HttpResponseMessage>()
            .AddRetry(new RetryStrategyOptions<HttpResponseMessage>
            {
                MaxRetryAttempts = 3,
                Delay = TimeSpan.FromSeconds(2),
                BackoffType = DelayBackoffType.Exponential,
                ShouldHandle = args => ValueTask.FromResult(args.Outcome.Result is not { IsSuccessStatusCode: true }),
                OnRetry = args =>
                {
                    _logger.LogWarning("HTTP call failed (attempt {Attempt}), retrying in {Delay}s",
                        args.AttemptNumber, args.RetryDelay.TotalSeconds);
                    return default;
                }
            })
            .Build();
    }

    private static string? TryResolveApiKey(HeatApiSettings config, IEncryptionService? encryptionService)
    {
        if (!string.IsNullOrEmpty(config.ApiKey))
            return config.ApiKey;

        if (!string.IsNullOrEmpty(config.EncryptedApiKey))
        {
            if (encryptionService == null)
            {
                Console.WriteLine("WARNING: EncryptedApiKey configured but no IEncryptionService registered");
                return null;
            }

            var encryptionKey = config.EncryptionKey;
            if (string.IsNullOrEmpty(encryptionKey))
            {
                Console.WriteLine("WARNING: EncryptionKey not configured, cannot decrypt EncryptedApiKey");
                return null;
            }

            try
            {
                return encryptionService.Decrypt(config.EncryptedApiKey, encryptionKey);
            }
            catch
            {
                return null;
            }
        }

        return null;
    }

    public async Task<bool> HealthCheckAsync(CancellationToken cancellationToken = default)
    {
        try
        {
            var url = "odata/businessobject/ServiceReqs?$top=1";
            var response = await _httpClient.GetAsync(url, cancellationToken);
            return response.IsSuccessStatusCode;
        }
        catch
        {
            return false;
        }
    }

    #region ServiceReq Methods

    public async Task<ServiceReq?> GetServiceReqAsync(string recId, CancellationToken cancellationToken = default)
    {
        try
        {
            _logger.LogInformation("Getting ServiceReq with ID: {RecId}", recId);
            
            var url = $"odata/businessobject/ServiceReqs?$filter=RecId eq '{recId}'";
            var response = await _httpClient.GetAsync(url, cancellationToken);
            
            if (!response.IsSuccessStatusCode)
            {
                var error = await response.Content.ReadAsStringAsync(cancellationToken);
                _logger.LogError("Error response: {StatusCode} - {Error}", response.StatusCode, error);
                return null;
            }
            
            var result = await response.Content.ReadFromJsonAsync<ODataResponse<ServiceReq>>(_jsonOptions, cancellationToken);
            return result?.Value?.FirstOrDefault();
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error getting ServiceReq {RecId}", recId);
            return null;
        }
    }

    public async Task<ServiceReq?> CreateServiceReqAsync(ServiceReq serviceReq, CancellationToken cancellationToken = default)
    {
        try
        {
            _logger.LogInformation("========== CREATE SERVICE REQ ==========");
            
            serviceReq.ServiceReqNumber = 0;
            
            var serviceReqForApi = new
            {
                Status = serviceReq.Status,
                Status_Valid = serviceReq.Status_Valid,
                Subject = serviceReq.Subject,
                Symptom = serviceReq.Symptom,
                Service_Valid = serviceReq.Service_Valid,
                Source_Valid = serviceReq.Source_Valid,
                Urgency_Valid = serviceReq.Urgency_Valid,
                ProfileLink_Category = serviceReq.ProfileLink_Category,
                ProfileLink_RecID = serviceReq.ProfileLink_RecID,
                ProfileLink = serviceReq.ProfileLink,
                SvcReqTmplLink_Category = serviceReq.SvcReqTmplLink_Category,
                SvcReqTmplLink_RecID = serviceReq.SvcReqTmplLink_RecID,
                SvcReqTmplLink = serviceReq.SvcReqTmplLink,
                SvcReqSubscLink_Category = serviceReq.SvcReqSubscLink_Category,
                SvcReqSubscLink_RecID = serviceReq.SvcReqSubscLink_RecID,
                SvcReqSubscLink = serviceReq.SvcReqSubscLink,
                CreatedBy = serviceReq.CreatedBy,
                LastModBy = serviceReq.LastModBy,
                CreatedDateTime = serviceReq.CreatedDateTime,
                LastModDateTime = serviceReq.LastModDateTime,
                Owner_Valid = serviceReq.Owner_Valid,
                OwnerTeam_Valid = serviceReq.OwnerTeam_Valid,
                OrganizationUnitID = serviceReq.OrganizationUnitID,
                IsVIP = serviceReq.IsVIP,
                IsDraft = serviceReq.IsDraft,
                Cancelable = serviceReq.Cancelable,
                IsNewRecord = true,
                IsUnRead = true,
                Resolution = serviceReq.Resolution,
                Phone = serviceReq.Phone,
                Email = serviceReq.Email,
                Price_Currency = serviceReq.Price_Currency,
                Price = serviceReq.Price,
                ProfileLoginId = serviceReq.ProfileLoginId
            };

            var options = new JsonSerializerOptions 
            { 
                WriteIndented = true,
                DefaultIgnoreCondition = System.Text.Json.Serialization.JsonIgnoreCondition.WhenWritingNull
            };
            
            var json = JsonSerializer.Serialize(serviceReqForApi, options);
            _logger.LogInformation($"Request JSON: {json}");
            
            var url = "odata/businessobject/ServiceReqs";
            var content = new StringContent(json, System.Text.Encoding.UTF8, "application/json");
            
            var response = await _httpClient.PostAsync(url, content, cancellationToken);
            
            _logger.LogInformation($"Response Status: {(int)response.StatusCode} {response.StatusCode}");
            
            var responseJson = await response.Content.ReadAsStringAsync(cancellationToken);
            _logger.LogInformation($"Response JSON: {responseJson}");
            
            if (!response.IsSuccessStatusCode)
            {
                _logger.LogError($"Failed to create ServiceReq: {responseJson}");
                return null;
            }
            
            var created = JsonSerializer.Deserialize<ServiceReq>(responseJson, _jsonOptions);
            _logger.LogInformation($"Successfully created ServiceReq with ID: {created?.RecId}, Number: {created?.ServiceReqNumber}");
            
            return created;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error creating ServiceReq");
            return null;
        }
    }

    public async Task<int?> GetNextServiceReqNumberAsync(CancellationToken cancellationToken = default)
    {
        try
        {
            _logger.LogInformation("Getting next ServiceReq number");
            
            var url = "odata/businessobject/ServiceReqs?$top=1&$orderby=ServiceReqNumber desc&$select=ServiceReqNumber";
            var response = await _httpClient.GetAsync(url, cancellationToken);
            
            if (!response.IsSuccessStatusCode)
            {
                var error = await response.Content.ReadAsStringAsync(cancellationToken);
                _logger.LogError("Failed to get last ServiceReq number: {StatusCode} - {Error}", 
                    response.StatusCode, error);
                return null;
            }
            
            var jsonString = await response.Content.ReadAsStringAsync(cancellationToken);
            var result = JsonSerializer.Deserialize<ODataResponse<ServiceReq>>(jsonString, _jsonOptions);
            var lastNumber = result?.Value?.FirstOrDefault()?.ServiceReqNumber;
            
            if (lastNumber.HasValue)
            {
                var nextNumber = lastNumber.Value + 1;
                _logger.LogInformation("Next number: {NextNumber}", nextNumber);
                return (int?)nextNumber;
            }
            
            _logger.LogWarning("No ServiceReq found, using default 10000");
            return 10000;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error getting next ServiceReq number");
            return null;
        }
    }

    public async Task<List<ServiceReqParameter>> GetServiceReqParametersAsync(string serviceReqRecId, CancellationToken cancellationToken = default)
    {
        try
        {
            _logger.LogInformation("Getting parameters for ServiceReq ID: {RecId}", serviceReqRecId);
            
            var url = $"odata/businessobject/ServiceReqs('{serviceReqRecId}')/ServiceReqContainsServiceReqParam";
            var response = await _httpClient.GetAsync(url, cancellationToken);
            
            if (!response.IsSuccessStatusCode)
            {
                if (response.StatusCode == HttpStatusCode.NotFound)
                {
                    return new List<ServiceReqParameter>();
                }
                
                var error = await response.Content.ReadAsStringAsync(cancellationToken);
                _logger.LogError("Error response: {StatusCode} - {Error}", response.StatusCode, error);
                return new List<ServiceReqParameter>();
            }
            
            var jsonString = await response.Content.ReadAsStringAsync(cancellationToken);
            var result = JsonSerializer.Deserialize<ODataResponse<ServiceReqParameter>>(jsonString, _jsonOptions);
            
            return result?.Value ?? new List<ServiceReqParameter>();
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error getting parameters for ServiceReq {RecId}", serviceReqRecId);
            return new List<ServiceReqParameter>();
        }
    }

    public async Task<bool> CreateParameterAsync(ServiceReqParameter parameter, CancellationToken cancellationToken = default)
    {
        try
        {
            _logger.LogInformation("Creating parameter: {ParameterName}", parameter.ParameterName);
            
            var url = "odata/businessobject/ServiceReqParams";
            var json = JsonSerializer.Serialize(parameter, _jsonOptions);
            var content = new StringContent(json, System.Text.Encoding.UTF8, "application/json");
            
            var response = await _httpClient.PostAsync(url, content, cancellationToken);
            
            if (!response.IsSuccessStatusCode)
            {
                var error = await response.Content.ReadAsStringAsync(cancellationToken);
                _logger.LogError("Failed to create parameter: {StatusCode} - {Error}", response.StatusCode, error);
                return false;
            }
            
            return true;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error creating parameter {ParameterName}", parameter.ParameterName);
            return false;
        }
    }

    public async Task<List<ServiceReqAttachment>> GetServiceReqAttachmentsAsync(string serviceReqRecId, CancellationToken cancellationToken = default)
    {
        try
        {
            _logger.LogInformation("Getting attachments for ServiceReq ID: {RecId}", serviceReqRecId);
            
            var url = $"odata/businessobject/ServiceReqs('{serviceReqRecId}')/ServiceReqContainsAttachment";
            var response = await _httpClient.GetAsync(url, cancellationToken);
            
            if (!response.IsSuccessStatusCode)
            {
                if (response.StatusCode == HttpStatusCode.NotFound)
                {
                    return new List<ServiceReqAttachment>();
                }
                
                var error = await response.Content.ReadAsStringAsync(cancellationToken);
                _logger.LogError("Error response: {StatusCode} - {Error}", response.StatusCode, error);
                return new List<ServiceReqAttachment>();
            }
            
            var jsonString = await response.Content.ReadAsStringAsync(cancellationToken);
            var result = JsonSerializer.Deserialize<ODataResponse<ServiceReqAttachment>>(jsonString, _jsonOptions);
            
            _logger.LogInformation("Found {Count} attachments", result?.Value?.Count ?? 0);
            return result?.Value ?? new List<ServiceReqAttachment>();
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error getting attachments for ServiceReq {RecId}", serviceReqRecId);
            return new List<ServiceReqAttachment>();
        }
    }

    public async Task<bool> CreateAttachmentAsync(ServiceReqAttachment attachment, CancellationToken cancellationToken = default)
    {
        try
        {
            _logger.LogInformation("Creating attachment: {FileName}", attachment.ATTACHNAME);
            
            var url = "odata/businessobject/Attachments";
            var json = JsonSerializer.Serialize(attachment, _jsonOptions);
            var content = new StringContent(json, System.Text.Encoding.UTF8, "application/json");
            
            var response = await _httpClient.PostAsync(url, content, cancellationToken);
            
            if (!response.IsSuccessStatusCode)
            {
                var error = await response.Content.ReadAsStringAsync(cancellationToken);
                _logger.LogError("Failed to create attachment: {StatusCode} - {Error}", response.StatusCode, error);
                return false;
            }
            
            _logger.LogInformation("Successfully created attachment");
            return true;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error creating attachment");
            return false;
        }
    }

    #endregion

    #region Incident Methods

    public async Task<Incident?> GetIncidentAsync(string recId, CancellationToken cancellationToken = default)
    {
        try
        {
            _logger.LogInformation("Getting Incident with ID: {RecId}", recId);
            
            var url = $"odata/businessobject/incidents?$filter=RecId eq '{recId}'";
            var response = await _httpClient.GetAsync(url, cancellationToken);
            
            if (!response.IsSuccessStatusCode)
            {
                var error = await response.Content.ReadAsStringAsync(cancellationToken);
                _logger.LogError("Error response: {StatusCode} - {Error}", response.StatusCode, error);
                return null;
            }
            
            var result = await response.Content.ReadFromJsonAsync<ODataResponse<Incident>>(_jsonOptions, cancellationToken);
            return result?.Value?.FirstOrDefault();
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error getting Incident {RecId}", recId);
            return null;
        }
    }

    public async Task<int?> GetNextIncidentNumberAsync(CancellationToken cancellationToken = default)
    {
        try
        {
            _logger.LogInformation("Getting next Incident number");
            
            var url = "odata/businessobject/incidents?$top=1&$orderby=IncidentNumber desc&$select=IncidentNumber";
            var response = await _httpClient.GetAsync(url, cancellationToken);
            
            if (!response.IsSuccessStatusCode)
            {
                var error = await response.Content.ReadAsStringAsync(cancellationToken);
                _logger.LogError("Failed to get last Incident number: {StatusCode} - {Error}", 
                    response.StatusCode, error);
                return null;
            }
            
            var jsonString = await response.Content.ReadAsStringAsync(cancellationToken);
            _logger.LogDebug("Last Incident response: {Json}", jsonString);
            
            var result = JsonSerializer.Deserialize<ODataResponse<Incident>>(jsonString, _jsonOptions);
            var lastNumber = result?.Value?.FirstOrDefault()?.IncidentNumber;
            
            if (lastNumber.HasValue)
            {
                var nextNumber = lastNumber.Value + 1;
                _logger.LogInformation("Last Incident number: {LastNumber}, Next number: {NextNumber}", 
                    lastNumber, nextNumber);
                return (int?)nextNumber;
            }
            
            _logger.LogWarning("No Incidents found, using default starting number 10000");
            return 10000;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error getting next Incident number");
            return null;
        }
    }

    public async Task<Incident?> CreateIncidentAsync(Incident incident, CancellationToken cancellationToken = default)
    {
        try
        {
            _logger.LogInformation("========== CREATE INCIDENT ==========");
            
            var incidentForApi = new
            {
                Status = incident.Status,
                Subject = incident.Subject,
                Symptom = incident.Symptom,
                Service_Valid = incident.Service_Valid,
                Source_Valid = incident.Source_Valid,
                Priority_Valid = incident.Priority_Valid,
                Category_Valid = incident.Category_Valid,
                ActualCategory_Valid = incident.ActualCategory_Valid,
                CauseCode_Valid = incident.CauseCode_Valid,
                Urgency_Valid = incident.Urgency_Valid,
                Impact_Valid = incident.Impact_Valid,
                Owner_Valid = incident.Owner_Valid,
                OwnerTeam_Valid = incident.OwnerTeam_Valid,
                ProfileLink_RecID = incident.ProfileLink_RecID,
                CreatedBy = incident.CreatedBy,
                LastModBy = incident.LastModBy,
                CreatedDateTime = incident.CreatedDateTime,
                LastModDateTime = incident.LastModDateTime,
                OrganizationUnitID = incident.OrganizationUnitID,
                HoursOfOperation = incident.HoursOfOperation,
                Email = incident.Email,
                LoginId = incident.LoginId,
                IsVIP = incident.IsVIP,
                FirstCallResolution = incident.FirstCallResolution,
                IsWorkAround = incident.IsWorkAround,
                IsNotification = incident.IsNotification,
                XER_Cloned = incident.XER_Cloned
            };

            var options = new JsonSerializerOptions 
            { 
                WriteIndented = true,
                DefaultIgnoreCondition = System.Text.Json.Serialization.JsonIgnoreCondition.WhenWritingNull
            };
            
            var json = JsonSerializer.Serialize(incidentForApi, options);
            _logger.LogInformation($"Request JSON (без текстовых категорий): {json}");
            
            var url = "odata/businessobject/incidents";
            var content = new StringContent(json, System.Text.Encoding.UTF8, "application/json");
            
            var response = await _httpClient.PostAsync(url, content, cancellationToken);
            
            _logger.LogInformation($"Response Status: {(int)response.StatusCode} {response.StatusCode}");
            
            var responseJson = await response.Content.ReadAsStringAsync(cancellationToken);
            _logger.LogInformation($"Response JSON: {responseJson}");
            
            if (!response.IsSuccessStatusCode)
            {
                _logger.LogError($"Failed to create Incident: {responseJson}");
                return null;
            }
            
            var created = JsonSerializer.Deserialize<Incident>(responseJson, _jsonOptions);
            _logger.LogInformation($"Successfully created Incident with ID: {created?.RecId}, Number: {created?.IncidentNumber}");
            
            return created;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error creating Incident");
            return null;
        }
    }

    public async Task<List<IncidentAttachment>> GetIncidentAttachmentsAsync(string incidentRecId, CancellationToken cancellationToken = default)
    {
        try
        {
            _logger.LogInformation("Getting attachments for Incident ID: {RecId}", incidentRecId);
            
            var url = $"odata/businessobject/incidents('{incidentRecId}')/IncidentContainsAttachment";
            var response = await _httpClient.GetAsync(url, cancellationToken);
            
            if (!response.IsSuccessStatusCode)
            {
                if (response.StatusCode == HttpStatusCode.NotFound)
                {
                    return new List<IncidentAttachment>();
                }
                
                var error = await response.Content.ReadAsStringAsync(cancellationToken);
                _logger.LogError("Error response: {StatusCode} - {Error}", response.StatusCode, error);
                return new List<IncidentAttachment>();
            }
            
            var jsonString = await response.Content.ReadAsStringAsync(cancellationToken);
            var result = JsonSerializer.Deserialize<ODataResponse<IncidentAttachment>>(jsonString, _jsonOptions);
            
            _logger.LogInformation("Found {Count} attachments", result?.Value?.Count ?? 0);
            return result?.Value ?? new List<IncidentAttachment>();
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error getting attachments for Incident {RecId}", incidentRecId);
            return new List<IncidentAttachment>();
        }
    }

    public async Task<bool> CreateIncidentAttachmentAsync(IncidentAttachment attachment, CancellationToken cancellationToken = default)
    {
        try
        {
            _logger.LogInformation("Creating incident attachment: {FileName}", attachment.ATTACHNAME);
            
            var url = "odata/businessobject/Attachments";
            var json = JsonSerializer.Serialize(attachment, _jsonOptions);
            var content = new StringContent(json, System.Text.Encoding.UTF8, "application/json");
            
            var response = await _httpClient.PostAsync(url, content, cancellationToken);
            
            if (!response.IsSuccessStatusCode)
            {
                var error = await response.Content.ReadAsStringAsync(cancellationToken);
                _logger.LogError("Failed to create incident attachment: {StatusCode} - {Error}", response.StatusCode, error);
                return false;
            }
            
            _logger.LogInformation("Successfully created incident attachment");
            return true;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error creating incident attachment");
            return false;
        }
    }

    #endregion
}
