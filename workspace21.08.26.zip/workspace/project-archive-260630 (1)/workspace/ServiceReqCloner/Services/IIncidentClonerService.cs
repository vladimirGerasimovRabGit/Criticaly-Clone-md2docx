using ServiceReqCloner.Models;

namespace ServiceReqCloner.Services;

public interface IIncidentClonerService
{
    Task<CloneIncidentResponse> CloneIncidentAsync(CloneIncidentRequest request, CancellationToken cancellationToken = default);
}
