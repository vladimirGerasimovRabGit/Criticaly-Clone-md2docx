using ServiceReqCloner.Models;

namespace ServiceReqCloner.Services;

public interface IServiceReqClonerService
{
    Task<CloneResponse> CloneServiceReqAsync(CloneRequest request, CancellationToken cancellationToken = default);
}
