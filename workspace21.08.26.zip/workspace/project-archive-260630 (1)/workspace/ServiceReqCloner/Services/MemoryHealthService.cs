namespace ServiceReqCloner.Services;

public interface IMemoryHealthService
{
    MemoryHealthInfo GetMemoryInfo();
}

public class MemoryHealthService : IMemoryHealthService
{
    public MemoryHealthInfo GetMemoryInfo()
    {
        var process = System.Diagnostics.Process.GetCurrentProcess();

        return new MemoryHealthInfo
        {
            WorkingSetBytes = process.WorkingSet64,
            WorkingSetMB = Math.Round(process.WorkingSet64 / (1024.0 * 1024.0), 2),
            PrivateMemoryBytes = process.PrivateMemorySize64,
            PrivateMemoryMB = Math.Round(process.PrivateMemorySize64 / (1024.0 * 1024.0), 2),
            VirtualMemoryBytes = process.VirtualMemorySize64,
            VirtualMemoryMB = Math.Round(process.VirtualMemorySize64 / (1024.0 * 1024.0), 2),
            PagedMemoryBytes = process.PagedMemorySize64,
            PagedMemoryMB = Math.Round(process.PagedMemorySize64 / (1024.0 * 1024.0), 2),
            GcTotalAllocatedBytes = GC.GetTotalMemory(false),
            GcTotalAllocatedMB = Math.Round(GC.GetTotalMemory(false) / (1024.0 * 1024.0), 2),
            GcHeapSizeBytes = GC.GetGCMemoryInfo().HeapSizeBytes,
            GcHeapSizeMB = Math.Round(GC.GetGCMemoryInfo().HeapSizeBytes / (1024.0 * 1024.0), 2),
            GcGen0Collections = GC.CollectionCount(0),
            GcGen1Collections = GC.CollectionCount(1),
            GcGen2Collections = GC.CollectionCount(2),
            ThreadCount = process.Threads.Count,
            HandleCount = process.HandleCount,
            ProcessId = process.Id,
            ProcessName = process.ProcessName,
            Uptime = TimeSpan.FromMilliseconds(process.TotalProcessorTime.TotalMilliseconds),
            Timestamp = DateTime.UtcNow
        };
    }
}

public class MemoryHealthInfo
{
    public long WorkingSetBytes { get; set; }
    public double WorkingSetMB { get; set; }
    public long PrivateMemoryBytes { get; set; }
    public double PrivateMemoryMB { get; set; }
    public long VirtualMemoryBytes { get; set; }
    public double VirtualMemoryMB { get; set; }
    public long PagedMemoryBytes { get; set; }
    public double PagedMemoryMB { get; set; }
    public long GcTotalAllocatedBytes { get; set; }
    public double GcTotalAllocatedMB { get; set; }
    public long GcHeapSizeBytes { get; set; }
    public double GcHeapSizeMB { get; set; }
    public int GcGen0Collections { get; set; }
    public int GcGen1Collections { get; set; }
    public int GcGen2Collections { get; set; }
    public int ThreadCount { get; set; }
    public int HandleCount { get; set; }
    public int ProcessId { get; set; }
    public string ProcessName { get; set; } = string.Empty;
    public TimeSpan Uptime { get; set; }
    public DateTime Timestamp { get; set; }
}
