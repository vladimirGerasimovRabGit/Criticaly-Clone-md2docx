using ServiceReqCloner.Models;

namespace ServiceReqCloner.Services;

public interface IHeatApiService
{
    Task<ServiceReq?> GetServiceReqAsync(string recId, CancellationToken cancellationToken = default);
    Task<ServiceReq?> CreateServiceReqAsync(ServiceReq serviceReq, CancellationToken cancellationToken = default);
    Task<List<ServiceReqParameter>> GetServiceReqParametersAsync(string serviceReqRecId, CancellationToken cancellationToken = default);
    Task<bool> CreateParameterAsync(ServiceReqParameter parameter, CancellationToken cancellationToken = default);
    Task<bool> HealthCheckAsync(CancellationToken cancellationToken = default);
    Task<int?> GetNextServiceReqNumberAsync(CancellationToken cancellationToken = default);
	Task<List<ServiceReqAttachment>> GetServiceReqAttachmentsAsync(string serviceReqRecId, CancellationToken cancellationToken = default);
	Task<bool> CreateAttachmentAsync(ServiceReqAttachment attachment, CancellationToken cancellationToken = default);
	Task<Incident?> GetIncidentAsync(string recId, CancellationToken cancellationToken = default);
	Task<int?> GetNextIncidentNumberAsync(CancellationToken cancellationToken = default);
	Task<Incident?> CreateIncidentAsync(Incident incident, CancellationToken cancellationToken = default);
	Task<List<IncidentAttachment>> GetIncidentAttachmentsAsync(string incidentRecId, CancellationToken cancellationToken = default);
	Task<bool> CreateIncidentAttachmentAsync(IncidentAttachment attachment, CancellationToken cancellationToken = default);
}
