<#
.SYNOPSIS
    Publishes ServiceReqCloner as a self-contained package for offline deployment.
.DESCRIPTION
    Restores NuGet packages and publishes a self-contained, trimmed build
    to the .\publish directory. The output includes the .NET 8 runtime and
    all dependencies - no internet connection required to run the service.
.PARAMETER OutputDir
    Output directory for the published package. Default: .\publish
.PARAMETER Runtime
    Target runtime identifier. Default: linux-x64
.PARAMETER Configuration
    Build configuration. Default: Release
.EXAMPLE
    .\publish.ps1
.EXAMPLE
    .\publish.ps1 -Runtime win-x64 -OutputDir .\dist
#>
[CmdletBinding()]
param(
    [string]$OutputDir = ".\publish",
    [string]$Runtime = "linux-x64",
    [string]$Configuration = "Release"
)

$ErrorActionPreference = "Stop"

Write-Host ""
Write-Host "=============================================" -ForegroundColor Cyan
Write-Host " ServiceReqCloner - Offline Package Publisher" -ForegroundColor Cyan
Write-Host "=============================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "Runtime:        $Runtime" -ForegroundColor Yellow
Write-Host "Configuration:  $Configuration" -ForegroundColor Yellow
Write-Host "Output:         $OutputDir" -ForegroundColor Yellow
Write-Host ""

# 1. Clean previous publish
if (Test-Path $OutputDir) {
    Write-Host "[1/3] Cleaning previous publish..." -ForegroundColor Gray
    Remove-Item -Recurse -Force $OutputDir
} else {
    Write-Host "[1/3] No previous publish to clean." -ForegroundColor Gray
}

# 2. Restore NuGet packages
Write-Host "[2/3] Restoring NuGet packages..." -ForegroundColor Gray
dotnet restore --runtime $Runtime --force

# 3. Publish self-contained
Write-Host "[3/3] Publishing self-contained package..." -ForegroundColor Gray
dotnet publish `
    --configuration $Configuration `
    --runtime $Runtime `
    --self-contained true `
    --output $OutputDir `
    -p:PublishSingleFile=false `
    -p:PublishTrimmed=false

Write-Host ""
Write-Host "=============================================" -ForegroundColor Green
Write-Host " Publish complete!" -ForegroundColor Green
Write-Host "=============================================" -ForegroundColor Green
Write-Host ""
$packageSize = [math]::Round((Get-ChildItem $OutputDir -Recurse | Measure-Object -Property Length -Sum).Sum / 1MB, 2)
Write-Host "Package size: $packageSize MB" -ForegroundColor Yellow
Write-Host ""
Write-Host "To run the service offline:" -ForegroundColor Cyan
Write-Host "  .\run-server.ps1" -ForegroundColor White
Write-Host ""
