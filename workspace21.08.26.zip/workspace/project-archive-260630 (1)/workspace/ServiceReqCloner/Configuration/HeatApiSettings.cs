namespace ServiceReqCloner.Configuration;

public class HeatApiSettings
{
    public const string SectionName = "HeatApi";
    
    public string BaseUrl { get; set; } = string.Empty;
    public string ApiKey { get; set; } = string.Empty;
    public string? EncryptedApiKey { get; set; }
    public string? EncryptionKey { get; set; }
    public string? Username { get; set; }
    public string? Password { get; set; }
    public string? Domain { get; set; }
    public int TimeoutSeconds { get; set; } = 30;
    public bool UseWindowsAuthentication { get; set; } = true;
    public bool SkipCertificateValidation { get; set; }
    public bool RequireWebServer { get; set; }
}
