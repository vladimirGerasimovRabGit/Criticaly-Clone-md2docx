<#
.SYNOPSIS
    Runs the ServiceReqCloner service.
.DESCRIPTION
    Starts the ServiceReqCloner API. Uses the self-contained published
    build if available (.\publish\ServiceReqCloner), otherwise falls
    back to dotnet run.
.PARAMETER Environment
    ASP.NET Core environment. Default: Development
.PARAMETER UsePublished
    Force using the published build. Default: auto-detect.
.EXAMPLE
    .\run-server.ps1
.EXAMPLE
    .\run-server.ps1 -Environment Production
#>
[CmdletBinding()]
param(
    [string]$Environment = "Development",
    [switch]$UsePublished
)

$ErrorActionPreference = "Stop"

$publishExe = Join-Path $PSScriptRoot "publish\ServiceReqCloner"
$published = (Test-Path $publishExe) -and (Test-Path (Join-Path $PSScriptRoot "publish\appsettings.json"))

$env:ASPNETCORE_ENVIRONMENT = $Environment

Write-Host ""
Write-Host "=============================================" -ForegroundColor Cyan
Write-Host " ServiceReqCloner API" -ForegroundColor Cyan
Write-Host "=============================================" -ForegroundColor Cyan
Write-Host "Environment: $Environment" -ForegroundColor Yellow
Write-Host ""

if ($published -or $UsePublished) {
    Write-Host "Starting from published build (self-contained, offline ready)..." -ForegroundColor Green
    Write-Host ""
    & $publishExe
} else {
    Write-Host "No published build found. Starting via dotnet run..." -ForegroundColor Yellow
    Write-Host "For offline deployment, run: .\publish.ps1" -ForegroundColor Yellow
    Write-Host ""
    Push-Location $PSScriptRoot
    dotnet run --configuration Release
    Pop-Location
}
