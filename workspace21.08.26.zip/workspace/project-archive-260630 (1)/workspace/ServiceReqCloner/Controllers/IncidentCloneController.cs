using Microsoft.AspNetCore.Mvc;
using ServiceReqCloner.Models;
using ServiceReqCloner.Services;
using ServiceReqCloner.Configuration;
using System.Text;
using System.Text.Json;

namespace ServiceReqCloner.Controllers;

[ApiController]
[Route("api/[controller]")]
public class IncidentCloneController : ControllerBase
{
    private readonly IIncidentClonerService _clonerService;
    private readonly IHeatApiService _heatApiService;
    private readonly IConfiguration _configuration;
    private readonly ILogger<IncidentCloneController> _logger;

    public IncidentCloneController(
        IIncidentClonerService clonerService,
        IHeatApiService heatApiService,
        IConfiguration configuration,
        ILogger<IncidentCloneController> logger)
    {
        _clonerService = clonerService;
        _heatApiService = heatApiService;
        _configuration = configuration;
        _logger = logger;
    }

    [HttpGet("debug-create/{id}")]
    public async Task<IActionResult> DebugCreate(string id)
    {
        try
        {
            // 1. Получаем исходный инцидент
            var sourceIncident = await _heatApiService.GetIncidentAsync(id);
            if (sourceIncident == null)
                return NotFound(new { error = "Source incident not found" });

            // 2. Создаем клон вручную - БЕЗ лишних полей
            var clone = new
            {
                // Текстовые поля
                Subject = sourceIncident.Subject,
                Symptom = sourceIncident.Symptom,
                Status = "Logged",
                
                // Valid-поля (идентификаторы)
                Service_Valid = sourceIncident.Service_Valid,
                Source_Valid = sourceIncident.Source_Valid,
                Priority_Valid = sourceIncident.Priority_Valid,
                Category_Valid = sourceIncident.Category_Valid,
                ActualCategory_Valid = sourceIncident.ActualCategory_Valid,
                ProfileLink_RecID = sourceIncident.ProfileLink_RecID,
                Owner_Valid = sourceIncident.Owner_Valid,
                OwnerTeam_Valid = sourceIncident.OwnerTeam_Valid,
                
                // Системные поля
                CreatedBy = "HEATAdmin",
                LastModBy = "HEATAdmin",
                CreatedDateTime = DateTime.UtcNow,
                LastModDateTime = DateTime.UtcNow,
                
                // Дополнительные поля
                OrganizationUnitID = sourceIncident.OrganizationUnitID,
                Email = sourceIncident.Email,
                LoginId = sourceIncident.LoginId,
                HoursOfOperation = sourceIncident.HoursOfOperation,
                
                // Флаги
                IsVIP = sourceIncident.IsVIP,
                FirstCallResolution = sourceIncident.FirstCallResolution,
                IsWorkAround = sourceIncident.IsWorkAround,
                IsNotification = sourceIncident.IsNotification
            };

            // 3. Отправляем через прямой HTTP запрос
            var apiKey = _configuration["HeatApi:ApiKey"];
            var baseUrl = _configuration["HeatApi:BaseUrl"]?.TrimEnd('/');
            
            using var client = new HttpClient();
            client.DefaultRequestHeaders.TryAddWithoutValidation("Authorization", $"rest_api_key={apiKey}");
            
            var options = new JsonSerializerOptions 
            { 
                WriteIndented = true,
                DefaultIgnoreCondition = System.Text.Json.Serialization.JsonIgnoreCondition.WhenWritingNull
            };
            
            var json = JsonSerializer.Serialize(clone, options);
            _logger.LogInformation($"Sending: {json}");
            
            var content = new StringContent(json, Encoding.UTF8, "application/json");
            var response = await client.PostAsync($"{baseUrl}/odata/businessobject/incidents", content);
            var responseJson = await response.Content.ReadAsStringAsync();
            
            return Ok(new
            {
                success = response.IsSuccessStatusCode,
                statusCode = (int)response.StatusCode,
                requestJson = json,
                responseJson = responseJson
            });
        }
        catch (Exception ex)
        {
            return BadRequest(new { error = ex.Message, stackTrace = ex.StackTrace });
        }
    }

    [HttpGet("clone")]
    public async Task<ActionResult<CloneIncidentResponse>> CloneIncidentGet([FromQuery] string id, [FromQuery] bool openInNewTab = true)
    {
        if (string.IsNullOrWhiteSpace(id))
            return BadRequest(new { error = "ID cannot be empty" });

        var request = new CloneIncidentRequest
        {
            SourceRecId = id,
            OpenInNewTab = openInNewTab,
            RedirectBaseUrl = _configuration["HeatUI:BaseUrl"]
        };

        var result = await _clonerService.CloneIncidentAsync(request);
        
        if (!result.Success)
            return BadRequest(result);

        return Ok(result);
    }

    [HttpGet("clone-with-view")]
    public async Task<IActionResult> CloneWithView([FromQuery] string id, [FromQuery] bool openInNewTab = true)
    {
        if (string.IsNullOrWhiteSpace(id))
            return Redirect($"/clone-waiting.html?success=false&error=ID cannot be empty");

        var request = new CloneIncidentRequest
        {
            SourceRecId = id,
            OpenInNewTab = openInNewTab,
            RedirectBaseUrl = _configuration["HeatUI:BaseUrl"]
        };

        var result = await _clonerService.CloneIncidentAsync(request);
        
        if (!result.Success)
        {
            var errorDetails = JsonSerializer.Serialize(result);
            return Redirect($"/clone-waiting.html?success=false&error={Uri.EscapeDataString(result.Message)}&error_details={Uri.EscapeDataString(errorDetails)}&type=Incident");
        }

        // Используем HTTPS из конфигурации
        var baseUrl = _configuration["HeatUI:BaseUrl"]?.TrimEnd('/') ?? "https://svoivantisrv/HEAT";
        var redirectUrl = $"{baseUrl}/Login.aspx?Scope=ObjectWorkspace&CommandId=Search&ObjectType=Incident%23&CommandData=RecId%2c%3d%2c0%2c{result.NewRecId}%2cstring%2cAND%7C";
        
        return Redirect($"/clone-waiting.html?recId={result.NewRecId}&number={result.NewIncidentNumber}&success=true&url={Uri.EscapeDataString(redirectUrl)}&type=Incident");
    }

    [HttpGet("next-number")]
    public async Task<IActionResult> GetNextNumber()
    {
        try
        {
            var nextNumber = await _heatApiService.GetNextIncidentNumberAsync();
            return Ok(new 
            { 
                success = nextNumber.HasValue,
                nextNumber = nextNumber,
                message = nextNumber.HasValue ? "Success" : "Failed to get next number"
            });
        }
        catch (Exception ex)
        {
            return BadRequest(new { error = ex.Message });
        }
    }

    [HttpGet("health")]
    public IActionResult Health()
    {
        return Ok(new { status = "healthy", timestamp = DateTime.UtcNow });
    }
}
