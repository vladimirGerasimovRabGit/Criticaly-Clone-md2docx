using Microsoft.AspNetCore.Mvc;
using ServiceReqCloner.Services;
using System.Text.Json;

namespace ServiceReqCloner.Controllers;

[ApiController]
[Route("api/[controller]")]
public class DiagnosticController : ControllerBase
{
    private readonly IHttpClientFactory _httpClientFactory;
    private readonly IConfiguration _configuration;
    private readonly ILogger<DiagnosticController> _logger;
    private readonly IMemoryHealthService _memoryHealthService;
    private const string DiagnosticClientName = "diagnostic";

    public DiagnosticController(
        IHttpClientFactory httpClientFactory,
        IConfiguration configuration,
        ILogger<DiagnosticController> logger,
        IMemoryHealthService memoryHealthService)
    {
        _httpClientFactory = httpClientFactory;
        _configuration = configuration;
        _logger = logger;
        _memoryHealthService = memoryHealthService;
    }

    private HttpClient CreateClient()
    {
        var client = _httpClientFactory.CreateClient(DiagnosticClientName);
        return client;
    }

    [HttpGet("memory")]
    public ActionResult<MemoryHealthInfo> GetMemory()
    {
        return Ok(_memoryHealthService.GetMemoryInfo());
    }

    [HttpGet("ci/{id}")]
    public async Task<ActionResult> GetCI(string id)
    {
        using var client = CreateClient();

        var results = new Dictionary<string, object>();
        var urls = new[]
        {
            $"odata/businessobject/cis('{id}')",
            $"odata/businessobject/configurationitems('{id}')",
            $"odata/businessobject/ci('{id}')",
            $"api/businessobject/cis/{id}",
            $"api/businessobject/configurationitems/{id}",
            $"api/businessobject/ci/{id}"
        };

        foreach (var url in urls)
        {
            try
            {
                var response = await client.GetAsync(url);
                var content = await response.Content.ReadAsStringAsync();
                results[url] = new
                {
                    StatusCode = (int)response.StatusCode,
                    Success = response.IsSuccessStatusCode,
                    Content = content.Length > 1000 ? content.Substring(0, 1000) + "..." : content
                };
            }
            catch (Exception ex)
            {
                results[url] = new { Error = ex.Message };
            }
        }

        return Ok(results);
    }

    [HttpGet("ci/{id}/relations")]
    public async Task<ActionResult> GetRelations(string id)
    {
        using var client = CreateClient();

        var results = new Dictionary<string, object>();
        var urls = new[]
        {
            $"odata/businessobject/cinamedrellinks?$filter=SourceID eq '{id}' or TargetID eq '{id}'",
            $"odata/businessobject/cirelations?$filter=SourceID eq '{id}' or TargetID eq '{id}'",
            $"odata/businessobject/links?$filter=SourceID eq '{id}' or TargetID eq '{id}'",
            $"api/businessobject/cinamedrellinks?$filter=SourceID eq '{id}' or TargetID eq '{id}'",
            $"api/businessobject/cirelations?$filter=SourceID eq '{id}' or TargetID eq '{id}'"
        };

        foreach (var url in urls)
        {
            try
            {
                var response = await client.GetAsync(url);
                var content = await response.Content.ReadAsStringAsync();
                results[url] = new
                {
                    StatusCode = (int)response.StatusCode,
                    Success = response.IsSuccessStatusCode,
                    Content = content.Length > 1000 ? content.Substring(0, 1000) + "..." : content
                };
            }
            catch (Exception ex)
            {
                results[url] = new { Error = ex.Message };
            }
        }

        return Ok(results);
    }
}
