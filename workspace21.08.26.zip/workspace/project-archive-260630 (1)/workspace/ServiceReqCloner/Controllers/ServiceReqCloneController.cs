using Microsoft.AspNetCore.Mvc;
using ServiceReqCloner.Models;
using ServiceReqCloner.Services;
using ServiceReqCloner.Configuration;
using System.Text;
using System.Text.Json;

namespace ServiceReqCloner.Controllers;

[ApiController]
[Route("api/[controller]")]
public class ServiceReqCloneController : ControllerBase
{
    private readonly IServiceReqClonerService _clonerService;
    private readonly IHeatApiService _heatApiService;
    private readonly IConfiguration _configuration;
    private readonly ILogger<ServiceReqCloneController> _logger;

    public ServiceReqCloneController(
        IServiceReqClonerService clonerService,
        IHeatApiService heatApiService,
        IConfiguration configuration,
        ILogger<ServiceReqCloneController> logger)
    {
        _clonerService = clonerService;
        _heatApiService = heatApiService;
        _configuration = configuration;
        _logger = logger;
    }

    #region ========== ОСНОВНЫЕ МЕТОДЫ КЛОНИРОВАНИЯ ==========

    /// <summary>
    /// Клонирование заявки с ID в URL (POST-версия)
    /// </summary>
    [HttpPost("clone/{id}")]
    public async Task<ActionResult<CloneResponse>> CloneServiceReq(string id, [FromQuery] bool openInNewTab = true)
    {
        if (string.IsNullOrWhiteSpace(id))
            return BadRequest(new { error = "ID cannot be empty" });

        var request = new CloneRequest
        {
            SourceRecId = id,
            CloneParameters = true,
            OpenInNewTab = openInNewTab,
            RedirectBaseUrl = _configuration["HeatUI:BaseUrl"]
        };

        var result = await _clonerService.CloneServiceReqAsync(request);
        
        if (!result.Success)
            return BadRequest(result);

        // Если запрос из браузера - показываем красивую HTML страницу
        if (Request.Headers.Accept.ToString().Contains("text/html"))
            return Content(GenerateRedirectHtml(result), "text/html");

        return Ok(result);
    }

    /// <summary>
    /// Клонирование с полными опциями (POST-версия)
    /// </summary>
    [HttpPost("clone")]
    public async Task<ActionResult<CloneResponse>> CloneServiceReqWithOptions([FromBody] CloneRequest request)
    {
        if (string.IsNullOrWhiteSpace(request.SourceRecId))
            return BadRequest(new { error = "SourceRecId is required" });

        if (string.IsNullOrEmpty(request.RedirectBaseUrl))
            request.RedirectBaseUrl = _configuration["HeatUI:BaseUrl"];

        var result = await _clonerService.CloneServiceReqAsync(request);
        
        if (!result.Success)
            return BadRequest(result);

        if (Request.Headers.Accept.ToString().Contains("text/html"))
            return Content(GenerateRedirectHtml(result), "text/html");

        return Ok(result);
    }

    /// <summary>
    /// Клонирование с ID в параметрах запроса (GET-версия для UI Action)
    /// </summary>
    [HttpGet("clone")]
    public async Task<ActionResult<CloneResponse>> CloneServiceReqGet([FromQuery] string id, [FromQuery] bool openInNewTab = true)
    {
        if (string.IsNullOrWhiteSpace(id))
            return BadRequest(new { error = "ID cannot be empty" });

        var request = new CloneRequest
        {
            SourceRecId = id,
            CloneParameters = true,
            OpenInNewTab = openInNewTab,
            RedirectBaseUrl = _configuration["HeatUI:BaseUrl"]
        };

        var result = await _clonerService.CloneServiceReqAsync(request);
        
        if (!result.Success)
            return BadRequest(result);

        return Ok(result);
    }

    /// <summary>
    /// Клонирование с красивой страницей ожидания (для UI Action)
    /// </summary>
	[HttpGet("clone-with-view")]
	public async Task<IActionResult> CloneWithView([FromQuery] string id, [FromQuery] bool openInNewTab = true, [FromQuery] bool cloneAttachments = true)
	{
		if (string.IsNullOrWhiteSpace(id))
			return Redirect($"/clone-waiting.html?success=false&error=ID cannot be empty");

		var request = new CloneRequest
		{
			SourceRecId = id,
			CloneParameters = true,
			CloneAttachments = cloneAttachments,
			OpenInNewTab = openInNewTab,
			RedirectBaseUrl = _configuration["HeatUI:BaseUrl"]
		};

		var result = await _clonerService.CloneServiceReqAsync(request);
		
		if (!result.Success)
{
    var errorDetails = JsonSerializer.Serialize(result);
    return Redirect($"/clone-waiting.html?success=false&error={Uri.EscapeDataString(result.Message)}&error_details={Uri.EscapeDataString(errorDetails)}&type=ServiceReq");
}

		// Используем HTTPS из конфигурации
		var baseUrl = _configuration["HeatUI:BaseUrl"]?.TrimEnd('/') ?? "https://svoivantisrv/HEAT";
		var redirectUrl = $"{baseUrl}/Login.aspx?Scope=ObjectWorkspace&CommandId=Search&ObjectType=ServiceReq%23&CommandData=RecId%2c%3d%2c0%2c{result.NewRecId}%2cstring%2cAND%7C";
		
		// Добавлен параметр type=ServiceReq
		return Redirect($"/clone-waiting.html?recId={result.NewRecId}&number={result.NewServiceReqNumber}&success=true&url={Uri.EscapeDataString(redirectUrl)}&type=ServiceReq");
	}

    #endregion

    #region ========== ДИАГНОСТИЧЕСКИЕ МЕТОДЫ ==========

    /// <summary>
    /// Проверка здоровья сервиса
    /// </summary>
    [HttpGet("health")]
    public async Task<IActionResult> Health()
    {
        var heatApiHealthy = await _heatApiService.HealthCheckAsync();
        
        return Ok(new
        {
            status = heatApiHealthy ? "healthy" : "degraded",
            timestamp = DateTime.UtcNow,
            port = HttpContext.Connection.LocalPort
        });
    }

    /// <summary>
    /// Получение следующего номера заявки
    /// </summary>
    [HttpGet("next-number")]
    public async Task<IActionResult> GetNextNumber()
    {
        try
        {
            var nextNumber = await _heatApiService.GetNextServiceReqNumberAsync();
            return Ok(new 
            { 
                success = nextNumber.HasValue,
                nextNumber = nextNumber,
                message = nextNumber.HasValue ? "Success" : "Failed to get next number"
            });
        }
        catch (Exception ex)
        {
            return BadRequest(new { error = ex.Message });
        }
    }

    /// <summary>
    /// Информация о сервере (порты, URL)
    /// </summary>
    [HttpGet("server-info")]
    public IActionResult ServerInfo()
    {
        var port = HttpContext.Connection.LocalPort;
        var ipAddress = HttpContext.Connection.LocalIpAddress?.ToString() ?? "192.168.16.244";
        
        return Ok(new
        {
            message = "ServiceReq Cloner API",
            urls = new
            {
                localhost = $"http://localhost:{port}",
                ip = $"http://{ipAddress}:{port}",
                swagger = $"http://localhost:{port}/swagger",
                health = $"http://localhost:{port}/api/ServiceReqClone/health",
                clone = $"http://{ipAddress}:{port}/api/ServiceReqClone/clone",
                cloneWithView = $"http://{ipAddress}:{port}/api/ServiceReqClone/clone-with-view",
                nextNumber = $"http://{ipAddress}:{port}/api/ServiceReqClone/next-number"
            }
        });
    }

    #endregion

    #region ========== ВСПОМОГАТЕЛЬНЫЕ МЕТОДЫ ==========

    /// <summary>
    /// Генерация красивой HTML страницы с результатом клонирования
    /// </summary>
    private string GenerateRedirectHtml(CloneResponse response)
    {
        var targetAttr = response.OpenInNewTab ? "target='_blank'" : "";
        
        return $@"
<!DOCTYPE html>
<html>
<head>
    <title>Cloning Successful</title>
    <style>
        body {{
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            color: white;
        }}
        .container {{
            text-align: center;
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            padding: 40px;
            border-radius: 20px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            max-width: 600px;
            margin: 20px;
        }}
        h1 {{ margin-bottom: 20px; font-size: 2em; }}
        .success-icon {{ font-size: 80px; margin-bottom: 20px; color: #4CAF50; }}
        .details {{
            background: rgba(255,255,255,0.2);
            padding: 20px;
            border-radius: 10px;
            margin: 20px 0;
            text-align: left;
        }}
        .button {{
            display: inline-block;
            padding: 12px 30px;
            margin: 10px;
            border: none;
            border-radius: 25px;
            font-size: 16px;
            cursor: pointer;
            text-decoration: none;
            transition: all 0.3s;
        }}
        .button-primary {{
            background: #4CAF50;
            color: white;
        }}
        .button-primary:hover {{
            background: #45a049;
            transform: translateY(-2px);
        }}
        .button-secondary {{
            background: rgba(255,255,255,0.2);
            color: white;
            border: 1px solid white;
        }}
        .button-secondary:hover {{
            background: rgba(255,255,255,0.3);
            transform: translateY(-2px);
        }}
        .timer {{ margin-top: 20px; font-size: 14px; opacity: 0.8; }}
        .url-box {{
            background: rgba(0,0,0,0.3);
            padding: 10px;
            border-radius: 5px;
            font-size: 12px;
            margin-top: 10px;
            word-break: break-all;
        }}
        .error {{ color: #ff6b6b; margin-top: 10px; text-align: left; }}
    </style>
</head>
<body>
    <div class='container'>
        <div class='success-icon'>✓</div>
        <h1>ServiceReq Successfully Cloned!</h1>
        
        <div class='details'>
            <p><strong>New ServiceReq ID:</strong> {response.NewRecId}</p>
            <p><strong>New ServiceReq Number:</strong> {response.NewServiceReqNumber}</p>
            <p><strong>Status:</strong> {response.Message}</p>
            <div class='url-box'>
                <strong>Redirect URL:</strong><br>
                {response.RedirectUrl}
            </div>
        </div>

        <div>
            <a href='{response.RedirectUrl}' {targetAttr} class='button button-primary' id='openBtn'>
                {(response.OpenInNewTab ? "Open in New Tab" : "Open ServiceReq")}
            </a>
            <button onclick='window.close()' class='button button-secondary'>Close Window</button>
        </div>

        <div class='timer' id='timer'></div>
    </div>

    <script>
        let seconds = 5;
        const timerElement = document.getElementById('timer');
        const openBtn = document.getElementById('openBtn');
        
        function updateTimer() {{
            if (seconds > 0) {{
                timerElement.textContent = `Redirecting in $\{{seconds}} seconds...`;
                seconds--;
                setTimeout(updateTimer, 1000);
            }} else {{
                window.location.href = '{response.RedirectUrl}';
            }}
        }}
        
        {(response.OpenInNewTab ? "" : "updateTimer();")}
        
        if (openBtn.target === '_blank') {{
            timerElement.textContent = 'Click the button above to open in new tab';
        }}
    </script>
</body>
</html>";
    }

    [HttpGet("test-create-direct")]
    public async Task<IActionResult> TestCreateDirect([FromQuery] string id)
    {
        try
        {
            // 1. Получаем исходную заявку
            var sourceReq = await _heatApiService.GetServiceReqAsync(id);
            if (sourceReq == null)
                return NotFound(new { error = "Source not found" });

            // 2. Создаем клон вручную
            var clone = new ServiceReq
            {
                Subject = sourceReq.Subject,
                Symptom = sourceReq.Symptom,
                Status = "Submitted",
                Service_Valid = sourceReq.Service_Valid,
                Source_Valid = sourceReq.Source_Valid,
                Urgency_Valid = sourceReq.Urgency_Valid,
                ProfileLink_RecID = sourceReq.ProfileLink_RecID,
                SvcReqTmplLink_RecID = sourceReq.SvcReqTmplLink_RecID ?? "8D263B9E42684D6BA08EC283C4C2C09D",
                CreatedBy = "HEATAdmin",
                LastModBy = "HEATAdmin",
                CreatedDateTime = DateTime.UtcNow,
                LastModDateTime = DateTime.UtcNow
            };

            // 3. Отправляем через прямой HTTP запрос
            var apiKey = _configuration["HeatApi:ApiKey"];
            var baseUrl = _configuration["HeatApi:BaseUrl"]?.TrimEnd('/');
            
            // Добавляем обработку SSL для HTTPS
            var handler = new HttpClientHandler
            {
                ServerCertificateCustomValidationCallback = (message, cert, chain, errors) => true
            };
            
            using var client = new HttpClient(handler);
            client.DefaultRequestHeaders.TryAddWithoutValidation("Authorization", $"rest_api_key={apiKey}");
            
            var options = new JsonSerializerOptions 
            { 
                PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
                WriteIndented = true,
                DefaultIgnoreCondition = System.Text.Json.Serialization.JsonIgnoreCondition.WhenWritingNull
            };
            
            var json = JsonSerializer.Serialize(clone, options);
            _logger.LogInformation($"Sending: {json}");
            
            var content = new StringContent(json, Encoding.UTF8, "application/json");
            var response = await client.PostAsync($"{baseUrl}/odata/businessobject/ServiceReqs", content);
            var responseJson = await response.Content.ReadAsStringAsync();
            
            return Ok(new
            {
                success = response.IsSuccessStatusCode,
                statusCode = (int)response.StatusCode,
                requestJson = json,
                responseJson = responseJson
            });
        }
        catch (Exception ex)
        {
            return BadRequest(new { error = ex.Message });
        }
    }

    #endregion
}
