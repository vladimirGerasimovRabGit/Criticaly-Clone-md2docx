using Serilog;
using Serilog.Events;
using ServiceReqCloner.Configuration;
using ServiceReqCloner.Middleware;
using ServiceReqCloner.Services;
using System.Diagnostics;
using System.Net;
using System.Security.Cryptography.X509Certificates;

var builder = WebApplication.CreateBuilder(args);

var configuration = builder.Configuration;
var environment = builder.Environment.EnvironmentName;
var port = configuration.GetValue<int>("Server:Port", 7101);
var useHttps = configuration.GetValue<bool>("Server:UseHttps", false);
var certPath = configuration["Server:CertificatePath"];
var certPassword = configuration["Server:CertificatePassword"];
var certThumbprint = configuration["Server:CertificateThumbprint"];

builder.Host.UseSerilog((context, services, loggerConfig) =>
{
    var logPath = Path.Combine(AppContext.BaseDirectory, "logs", "app-.log");
    var fileSizeLimitBytes = 50L * 1024 * 1024; // 50 MB
    var retainedFileCount = 10;

    loggerConfig
        .MinimumLevel.Information()
        .MinimumLevel.Override("Microsoft.AspNetCore", LogEventLevel.Warning)
        .MinimumLevel.Override("ServiceReqCloner.Services.HeatApiService", LogEventLevel.Debug)
        .Enrich.FromLogContext()
        .Enrich.WithMachineName()
        .Enrich.WithThreadId()
        .WriteTo.Console(outputTemplate: "[{Timestamp:yyyy-MM-dd HH:mm:ss} {Level:u3}] {Message:lj}{NewLine}{Exception}")
        .WriteTo.File(
            path: logPath,
            rollingInterval: RollingInterval.Day,
            fileSizeLimitBytes: fileSizeLimitBytes,
            rollOnFileSizeLimit: true,
            retainedFileCountLimit: retainedFileCount,
            outputTemplate: "{Timestamp:yyyy-MM-dd HH:mm:ss.fff zzz} [{Level:u3}] [{SourceContext}] {Message:lj}{NewLine}{Exception}",
            shared: true);

    if (context.HostingEnvironment.IsDevelopment())
    {
        loggerConfig.MinimumLevel.Debug();
    }
});

var heatApiSettings = configuration.GetSection(HeatApiSettings.SectionName).Get<HeatApiSettings>();
if (heatApiSettings == null)
    throw new InvalidOperationException("HeatApi section is missing in configuration");

if (heatApiSettings.RequireWebServer && !environment.Equals("Production", StringComparison.OrdinalIgnoreCase))
{
    Log.Warning("RequireWebServer is enabled but current environment is '{Env}', not 'Production'. ApiKey will not be used.", environment);
}

builder.WebHost.ConfigureKestrel(options =>
{
    options.Listen(IPAddress.Any, port);

    if (useHttps)
    {
        var httpsPort = configuration.GetValue<int>("Server:HttpsPort", 7105);

        options.Listen(IPAddress.Any, httpsPort, listenOptions =>
        {
            var cert = LoadCertificate(certPath, certPassword, certThumbprint);
            if (cert != null)
            {
                listenOptions.UseHttps(cert);
                Log.Information("HTTPS enabled with certificate: {CertName}", cert.FriendlyName ?? cert.Subject);
            }
            else
            {
                Log.Warning("HTTPS enabled but no certificate configured. Using development certificate.");
                listenOptions.UseHttps();
            }
        });
    }
});

static X509Certificate2? LoadCertificate(string? certPath, string? certPassword, string? certThumbprint)
{
    if (!string.IsNullOrEmpty(certPath) && File.Exists(certPath))
    {
        var cert = new X509Certificate2(certPath, certPassword);
        Log.Information("HTTPS certificate loaded from file: {CertPath}", certPath);
        return cert;
    }

    if (!string.IsNullOrEmpty(certThumbprint))
    {
        try
        {
            using var store = new X509Store(StoreName.My, StoreLocation.LocalMachine);
            store.Open(OpenFlags.ReadOnly);
            var certs = store.Certificates.Find(X509FindType.FindByThumbprint, certThumbprint, validOnly: false);
            if (certs.Count > 0)
            {
                Log.Information("HTTPS certificate loaded from store (thumbprint): {Thumbprint}", certThumbprint);
                return certs[0];
            }
            Log.Warning("Certificate with thumbprint not found in LocalMachine\\My: {Thumbprint}", certThumbprint);
        }
        catch (Exception ex)
        {
            Log.Warning(ex, "Failed to load certificate from store by thumbprint");
        }
    }

    return null;
}

builder.Services.Configure<HeatApiSettings>(configuration.GetSection(HeatApiSettings.SectionName));

builder.Services.AddControllers();

var allowedOrigins = configuration.GetSection("AllowedOrigins").Get<string[]>() ?? Array.Empty<string>();
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowHeatUI", policy =>
    {
        if (allowedOrigins.Length > 0)
        {
            policy.WithOrigins(allowedOrigins)
                  .AllowAnyMethod()
                  .AllowAnyHeader();
        }
        else
        {
            policy.AllowAnyOrigin()
                  .AllowAnyMethod()
                  .AllowAnyHeader();
        }
    });
});

builder.Services.AddHttpClient();
builder.Services.AddHttpClient("diagnostic", (sp, client) =>
{
    var config = sp.GetRequiredService<IConfiguration>();
    var baseUrl = config["HeatApi:BaseUrl"]?.TrimEnd('/') + '/';
    client.BaseAddress = new Uri(baseUrl);
    var apiKey = config["HeatApi:ApiKey"];
    if (!string.IsNullOrEmpty(apiKey))
        client.DefaultRequestHeaders.TryAddWithoutValidation("Authorization", $"rest_api_key={apiKey}");
    client.Timeout = TimeSpan.FromSeconds(config.GetValue<int>("HeatApi:TimeoutSeconds", 60));
}).ConfigurePrimaryHttpMessageHandler(sp =>
{
    var config = sp.GetRequiredService<IConfiguration>();
    var skipCert = config.GetValue<bool>("HeatApi:SkipCertificateValidation");
    return new HttpClientHandler
    {
        AllowAutoRedirect = true,
        ServerCertificateCustomValidationCallback = skipCert
            ? (message, cert, chain, errors) => true
            : null
    };
});
builder.Services.AddSingleton<IEncryptionService, EncryptionService>();
builder.Services.AddSingleton<IMemoryHealthService, MemoryHealthService>();
builder.Services.AddScoped<IHeatApiService, HeatApiService>();
builder.Services.AddScoped<IServiceReqClonerService, ServiceReqClonerService>();
builder.Services.AddScoped<IIncidentClonerService, IncidentClonerService>();

var app = builder.Build();

app.UseCors("AllowHeatUI");
app.UseMiddleware<ServiceReqCloner.Middleware.RequestLoggingMiddleware>();
app.UseLocalhostOnly();
app.UseStaticFiles();
app.UseAuthorization();
app.MapControllers();

var ipAddress = GetLocalIPAddress();
var apiKeySource = !string.IsNullOrEmpty(heatApiSettings.EncryptedApiKey) ? "encrypted" : "plain";

Log.Information("=========================================");
Log.Information("ServiceReq Cloner API started!");
Log.Information("Environment: {Environment}", environment);
Log.Information("Port: {Port}", port);
Log.Information("URL: http://{IP}:{Port}", ipAddress, port);
Log.Information("-----------------------------------------");
Log.Information("API Key source: {Source}", apiKeySource);

if (useHttps)
{
    var httpsPort = configuration.GetValue<int>("Server:HttpsPort", 7105);
    Log.Information("HTTPS Port: {Port}", httpsPort);
    Log.Information("HTTPS URL: https://{IP}:{Port}", ipAddress, httpsPort);
}

Log.Information("-----------------------------------------");
Log.Information("[!] Swagger disabled (offline mode)");
Log.Information("-----------------------------------------");
Log.Information("ServiceReq Clone:");
Log.Information("  http://{IP}:{Port}/api/ServiceReqClone/clone-with-view?id=ID", ipAddress, port);
Log.Information("-----------------------------------------");
Log.Information("Incident Clone:");
Log.Information("  http://{IP}:{Port}/api/IncidentClone/clone-with-view?id=ID", ipAddress, port);
Log.Information("  http://{IP}:{Port}/api/IncidentClone/next-number", ipAddress, port);
Log.Information("=========================================");
Log.Information("For testing:");
Log.Information("  curl http://localhost:{Port}/api/IncidentClone/next-number", port);
Log.Information("  or open in browser");
Log.Information("=========================================");
Log.Information("Log files: {LogPath}", Path.Combine(AppContext.BaseDirectory, "logs"));
Log.Information("=========================================");

try
{
    await app.RunAsync();
}
catch (Exception ex)
{
    Log.Fatal(ex, "Application terminated unexpectedly");
}
finally
{
    await Log.CloseAndFlushAsync();
}

static string GetLocalIPAddress()
{
    try
    {
        var host = System.Net.Dns.GetHostEntry(System.Net.Dns.GetHostName());
        foreach (var ip in host.AddressList)
            if (ip.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork)
                return ip.ToString();
    }
    catch (Exception ex)
    {
        Log.Warning(ex, "Failed to resolve local IP address");
    }
    return "192.168.16.244";
}
