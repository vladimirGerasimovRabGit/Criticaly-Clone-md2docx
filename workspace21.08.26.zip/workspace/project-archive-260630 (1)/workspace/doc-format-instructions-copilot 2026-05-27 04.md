# Инструкция по формату краткой технической документации
### Для: Microsoft Copilot (copilot.microsoft.com)

> **Как использовать этот файл:** загрузите его вместе с `Doc1.dotx` в чат и напишите запрос вида:
> *«Используя прикреплённую инструкцию и шаблон Doc1.dotx, сгенерируй Python-скрипт для создания документа [название] со следующим содержимым: ...»*
>
> Copilot сгенерирует готовый `.py` файл. Запустите его локально — он создаст `output.docx`.

---

## Что нужно для работы

Два файла, всегда передаются вместе:

| Файл | Роль |
|---|---|
| `doc-format-instructions-copilot.md` | Эта инструкция |
| `Doc1.dotx` | Шаблон Word со стилями, шрифтами, нумерацией |

`Doc1.dotx` **нельзя заменить инструкцией** — он содержит бинарные данные. Скрипт читает его как ZIP и заменяет только `word/document.xml`.

---

## Задача для Copilot

При получении этого файла Copilot должен:

1. Сгенерировать **полный, запускаемый Python-скрипт** (`generate_doc.py`), который создаёт `.docx` файл.
2. Скрипт открывает `Doc1.dotx` как ZIP, заменяет `word/document.xml` сгенерированным содержимым, сохраняет результат как `output.docx`.
3. **Не использовать библиотеку `python-docx`** — только стандартный `zipfile` и строковую генерацию XML.
4. Все правила форматирования из этой инструкции применять точно — особенно правила про `rPr` (см. раздел 8).

---

## 1. Сборка документа — алгоритм скрипта

```python
import zipfile, os, re

TEMPLATE = 'Doc1.dotx'
OUTPUT   = 'output.docx'

# Шаг 1: читаем все файлы шаблона
with zipfile.ZipFile(TEMPLATE, 'r') as z:
    files = {n: z.read(n) for n in z.namelist()}

# Шаг 2: извлекаем sectPr из оригинального document.xml ДО замены
orig_doc = files['word/document.xml'].decode('utf-8')
sect_m = re.search(r'<w:sectPr\b.*?</w:sectPr>', orig_doc, re.DOTALL)
sect = sect_m.group(0) if sect_m else ''

# Шаг 3: получаем реальный rId колонтитула из rels
rels = files['word/_rels/document.xml.rels'].decode('utf-8')
rid_m = re.search(r'<Relationship Id="(rId\d+)"[^>]*footer[^>]*/>', rels)
footer_rid = rid_m.group(1) if rid_m else 'rId10'

# Шаг 4: находим numId для bullets из numbering.xml шаблона
nxml = files['word/numbering.xml'].decode('utf-8')
bullet_num_id = find_bullet_num_id(nxml)  # см. функцию ниже

# Шаг 5: генерируем document.xml с контентом
new_doc = build_document(sect, content_xml)

# Шаг 6: заменяем файлы
files['word/document.xml'] = new_doc.encode('utf-8')
files['word/footer1.xml']  = build_footer(footer_rid).encode('utf-8')

# Шаг 7: исправляем ContentType (ОБЯЗАТЕЛЬНО — иначе Word не откроет файл)
ct = files['[Content_Types].xml'].decode('utf-8')
ct = ct.replace('wordprocessingml.template.main+xml',
                'wordprocessingml.document.main+xml')
files['[Content_Types].xml'] = ct.encode('utf-8')

# Шаг 8: сохраняем
with zipfile.ZipFile(OUTPUT, 'w', zipfile.ZIP_DEFLATED) as z:
    for name, data in files.items():
        z.writestr(name, data)
```

### Функция поиска numId для bullets

```python
def find_bullet_num_id(nxml):
    """Найти numId с fmt=bullet и пустым lvlText в numbering.xml шаблона."""
    for m in re.finditer(r'<w:num\b[^>]*w:numId="(\d+)"', nxml):
        nid = m.group(1)
        abs_ref = re.search(
            rf'<w:num\b[^>]*w:numId="{nid}".*?<w:abstractNumId w:val="(\d+)"',
            nxml, re.DOTALL)
        if not abs_ref:
            continue
        aid = abs_ref.group(1)
        ab = re.search(
            rf'<w:abstractNum\b[^>]*w:abstractNumId="{aid}".*?</w:abstractNum>',
            nxml, re.DOTALL)
        if not ab:
            continue
        l0 = re.search(r'<w:lvl\b[^>]*w:ilvl="0".*?</w:lvl>',
                        ab.group(0), re.DOTALL)
        if not l0:
            continue
        fmt  = re.search(r'<w:numFmt w:val="([^"]+)"',  l0.group(0))
        ltxt = re.search(r'<w:lvlText w:val="([^"]*)"', l0.group(0))
        if fmt and fmt.group(1) == 'bullet' and ltxt and ltxt.group(1) == '':
            return nid
    return '3'  # fallback
```

---

## 2. Страница и поля

Брать из `sectPr` шаблона (см. шаг 2 выше). Не генерировать вручную.

Для справки — значения из шаблона:

| Параметр | DXA |
|---|---|
| Поле сверху / снизу | 1134 |
| Поле слева | 1701 |
| Поле справа | 850 |
| Колонтитулы | 708 |
| Страница (A4) | 11906 × 16838 |

---

## 3. ID стилей (использовать точно эти значения)

| Элемент | ID стиля | Примечание |
|---|---|---|
| Heading 1 | `1` | Нумерация через `styles.xml` |
| Heading 2 | `2` | Нумерация через `styles.xml` |
| Heading 3 | `3` | Нумерация через `styles.xml` |
| Title (название документа) | `a3` | + граница снизу |
| Subtitle (метаданные) | `a5` | |
| Normal (основной текст) | `a` | |
| List bullet | `a7` | + `numPr` с `numId` из шаблона |

---

## 4. XML-функции генерации (обязательный шаблон)

Copilot должен использовать именно эти функции в генерируемом скрипте:

```python
def esc(s):
    """Экранирование XML-спецсимволов."""
    return (s.replace('&','&amp;').replace('<','&lt;')
             .replace('>','&gt;').replace('"','&quot;'))

# ─── КРИТИЧНО: два разных типа runs ───────────────────────────────

def rh(text):
    """Run для заголовков (Heading 1-3, Title, Subtitle) — БЕЗ rPr.
    
    ВАЖНО: никогда не добавлять <w:rPr> в runs заголовков.
    Если rPr есть — Word переопределит шрифт из стиля и заголовок
    будет выглядеть неправильно (мелкий текст, не соответствует стилю).
    """
    return f'<w:r><w:t>{esc(text)}</w:t></w:r>'

def r(text, bold=False, italic=False):
    """Run для обычного текста (Normal, таблицы, списки) — с rPr."""
    b = '<w:b/><w:bCs/>' if bold else ''
    i = '<w:i/><w:iCs/>' if italic else ''
    fonts = '<w:rFonts w:asciiTheme="minorHAnsi" w:hAnsiTheme="minorHAnsi" w:cstheme="minorBidi"/>'
    rpr = f'<w:rPr>{fonts}{b}{i}<w:sz w:val="24"/><w:szCs w:val="24"/></w:rPr>'
    sp = ' xml:space="preserve"' if text != text.strip() or '  ' in text else ''
    return f'<w:r>{rpr}<w:t{sp}>{esc(text)}</w:t></w:r>'

# ─── Параграфы ────────────────────────────────────────────────────

def h1(text):
    """Heading 1 — только pStyle, без numPr (нумерация в styles.xml)."""
    return f'<w:p><w:pPr><w:pStyle w:val="1"/></w:pPr>{rh(text)}</w:p>\n'

def h2(text):
    return f'<w:p><w:pPr><w:pStyle w:val="2"/></w:pPr>{rh(text)}</w:p>\n'

def h3(text):
    return f'<w:p><w:pPr><w:pStyle w:val="3"/></w:pPr>{rh(text)}</w:p>\n'

def title(text):
    """Название документа — стиль a3 + горизонтальная черта снизу."""
    ppr = ('<w:pPr><w:pStyle w:val="a3"/>'
           '<w:pBdr><w:bottom w:val="single" w:sz="6" w:space="1" w:color="auto"/></w:pBdr>'
           '</w:pPr>')
    return f'<w:p>{ppr}{rh(text)}</w:p>\n'  # rh — без rPr!

def subtitle(text):
    """Метаданные — стиль a5, без rPr."""
    return f'<w:p><w:pPr><w:pStyle w:val="a5"/></w:pPr>{rh(text)}</w:p>\n'

def body(*runs):
    """Обычный абзац."""
    return f'<w:p><w:pPr><w:pStyle w:val="a"/><w:spacing w:after="80"/></w:pPr>{"".join(runs)}</w:p>\n'

def li(*runs, bullet_num_id='3', level=0):
    """Элемент маркированного списка."""
    ppr = (f'<w:pPr><w:pStyle w:val="a7"/>'
           f'<w:numPr><w:ilvl w:val="{level}"/><w:numId w:val="{bullet_num_id}"/></w:numPr>'
           f'<w:spacing w:after="40"/></w:pPr>')
    return f'<w:p>{ppr}{"".join(runs)}</w:p>\n'

def empty():
    return '<w:p><w:pPr><w:spacing w:after="40"/></w:pPr></w:p>\n'
```

---

## 5. XML колонтитула

```python
def build_footer(footer_rid):
    """Колонтитул «Страница X из Y», правое выравнивание."""
    # footer_rid — брать из rels шаблона (не хардкодить rId11!)
    return f"""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:ftr xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
  <w:p>
    <w:pPr><w:pStyle w:val="a"/><w:jc w:val="right"/></w:pPr>
    <w:r><w:rPr><w:rFonts w:asciiTheme="minorHAnsi" w:hAnsiTheme="minorHAnsi"/>
      <w:sz w:val="24"/><w:szCs w:val="24"/></w:rPr>
      <w:t xml:space="preserve">Страница </w:t></w:r>
    <w:r><w:rPr><w:rFonts w:asciiTheme="minorHAnsi" w:hAnsiTheme="minorHAnsi"/>
      <w:b/><w:bCs/><w:sz w:val="24"/><w:szCs w:val="24"/></w:rPr>
      <w:fldChar w:fldCharType="begin"/></w:r>
    <w:r><w:rPr><w:rFonts w:asciiTheme="minorHAnsi" w:hAnsiTheme="minorHAnsi"/>
      <w:b/><w:bCs/><w:sz w:val="24"/><w:szCs w:val="24"/></w:rPr>
      <w:instrText xml:space="preserve"> PAGE </w:instrText></w:r>
    <w:r><w:rPr><w:rFonts w:asciiTheme="minorHAnsi" w:hAnsiTheme="minorHAnsi"/>
      <w:b/><w:bCs/><w:sz w:val="24"/><w:szCs w:val="24"/></w:rPr>
      <w:fldChar w:fldCharType="end"/></w:r>
    <w:r><w:rPr><w:rFonts w:asciiTheme="minorHAnsi" w:hAnsiTheme="minorHAnsi"/>
      <w:sz w:val="24"/><w:szCs w:val="24"/></w:rPr>
      <w:t xml:space="preserve"> из </w:t></w:r>
    <w:r><w:rPr><w:rFonts w:asciiTheme="minorHAnsi" w:hAnsiTheme="minorHAnsi"/>
      <w:b/><w:bCs/><w:sz w:val="24"/><w:szCs w:val="24"/></w:rPr>
      <w:fldChar w:fldCharType="begin"/></w:r>
    <w:r><w:rPr><w:rFonts w:asciiTheme="minorHAnsi" w:hAnsiTheme="minorHAnsi"/>
      <w:b/><w:bCs/><w:sz w:val="24"/><w:szCs w:val="24"/></w:rPr>
      <w:instrText xml:space="preserve"> NUMPAGES </w:instrText></w:r>
    <w:r><w:rPr><w:rFonts w:asciiTheme="minorHAnsi" w:hAnsiTheme="minorHAnsi"/>
      <w:b/><w:bCs/><w:sz w:val="24"/><w:szCs w:val="24"/></w:rPr>
      <w:fldChar w:fldCharType="end"/></w:r>
  </w:p>
</w:ftr>"""
```

---

## 6. Сборка document.xml

```python
NS = ('xmlns:mc="http://schemas.openxmlformats.org/markup-compatibility/2006" '
      'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" '
      'xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" '
      'xmlns:w14="http://schemas.microsoft.com/office/word/2010/wordml" '
      'mc:Ignorable="w14"')

def build_document(sect, content):
    """sect — взять из шаблона через re.search sectPr."""
    return (f'<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n'
            f'<w:document {NS}>\n<w:body>\n'
            f'{content}'
            f'{sect}\n</w:body>\n</w:document>')
```

---

## 7. Таблицы

```python
BCOL = 'BDD7EE'  # светло-голубой фон заголовка
BORD = 'BFBFBF'  # цвет границ

def tbl(col_widths, rows):
    """
    col_widths: список ширин в DXA, сумма = ширина текстового поля (9355 DXA)
    rows: список строк; каждая строка — список dict {'t': текст, 'hdr': bool, 'b': bold}
    """
    _b = (f'<w:top w:val="single" w:sz="4" w:color="{BORD}"/>'
          f'<w:left w:val="single" w:sz="4" w:color="{BORD}"/>'
          f'<w:bottom w:val="single" w:sz="4" w:color="{BORD}"/>'
          f'<w:right w:val="single" w:sz="4" w:color="{BORD}"/>')
    TW = sum(col_widths)
    grid = ''.join(f'<w:gridCol w:w="{w}"/>' for w in col_widths)
    out = (f'<w:tbl><w:tblPr><w:tblW w:w="{TW}" w:type="dxa"/>'
           f'<w:tblBorders>{_b}</w:tblBorders>'
           f'<w:tblLook w:val="04A0"/></w:tblPr>'
           f'<w:tblGrid>{grid}</w:tblGrid>\n')
    for row in rows:
        is_hdr = row[0].get('hdr', False)
        trpr = '<w:trPr><w:tblHeader/></w:trPr>' if is_hdr else ''
        cells = ''
        for j, cell_data in enumerate(row):
            hdr = cell_data.get('hdr', False)
            bold = cell_data.get('b', hdr)
            shd = f'<w:shd w:val="clear" w:color="auto" w:fill="{BCOL}"/>' if hdr else ''
            w = col_widths[j]
            tcpr = (f'<w:tcPr><w:tcW w:w="{w}" w:type="dxa"/>'
                    f'<w:tcBorders>{_b}</w:tcBorders>{shd}'
                    f'<w:tcMar><w:top w:w="80" w:type="dxa"/>'
                    f'<w:left w:w="120" w:type="dxa"/>'
                    f'<w:bottom w:w="80" w:type="dxa"/>'
                    f'<w:right w:w="120" w:type="dxa"/></w:tcMar></w:tcPr>')
            inner = (f'<w:p><w:pPr><w:pStyle w:val="a"/>'
                     f'<w:spacing w:after="40"/></w:pPr>'
                     f'{r(cell_data.get("t",""), bold=bold)}</w:p>')
            cells += f'<w:tc>{tcpr}{inner}</w:tc>'
        out += f'<w:tr>{trpr}{cells}</w:tr>\n'
    return out + '</w:tbl>\n'

# Хелперы для ячеек:
def H(text): return {'t': text, 'hdr': True}           # заголовок таблицы
def D(text, bold=False): return {'t': text, 'b': bold}  # данные
```

---

## 8. Структура контента и правила

### 8.1 Шапка документа

```python
# ПРАВИЛЬНО — rh() без rPr для title и subtitle:
title("Название документа")
subtitle("Продукт | Клиент | Май 2026 г.")
empty()
```

Subtitle — одной строкой: `<Продукт> | <Клиент> | <Месяц Год>`

### 8.2 Оглавление

Вставлять как текстовую заглушку (поле TOC создаёт диалог при открытии):

```python
h1("Содержание")
body(r("[Здесь будет оглавление — вставьте его в Word: Ссылки → Оглавление]",
       italic=True))
empty()
```

### 8.3 Термины и аббревиатуры

Маркированный список по алфавиту (латиница → кириллица):

```python
h1("Термины и аббревиатуры")
li(r("ISM", bold=True), r(" – Ivanti Service Manager — система управления ИТ-услугами"),
   bullet_num_id=bullet_num_id)
li(r("ML", bold=True),  r(" – Machine Learning, машинное обучение"),
   bullet_num_id=bullet_num_id)
# ... и т.д.
```

### 8.4 Критичные правила — нарушение ломает форматирование

| Правило | Правильно | Неправильно |
|---|---|---|
| Runs в заголовках | `rh(text)` — без `rPr` | `r(text)` с `rPr` — переопределит шрифт |
| Runs в title/subtitle | `rh(text)` — без `rPr` | `r(text)` с `rPr` — будет мелкий текст |
| `numPr` в заголовках | Не добавлять в параграф | Нумерация появится дважды |
| `numId` для bullets | Брать из шаблона через `find_bullet_num_id()` | Угадывать число — маркеры могут не отобразиться |
| `ContentType` | Исправить `template` → `document` | Word не откроет файл |
| `sectPr` | Брать из шаблона | Генерировать вручную — неверный `rId` для footer |

---

## 9. Типовая структура документа

```
title("Название")
subtitle("Продукт | Клиент | Месяц Год")
empty()

h1("Содержание")          # + заглушка TOC
h1("Термины и аббревиатуры")  # + li() по алфавиту
h1("Назначение документа")    # обязательный раздел
h1("...")                      # разделы по содержанию
  h2("...")
    h3("...")
```

### Необязательные разделы (по типу документа)

- **Архитектура** — если описывается устройство системы
- **Требования** — если это спецификация
- **Конфигурация / Настройки** — параметры компонентов
- **Обслуживание** — эксплуатационная специфика

---

## 10. Стиль текста

- Язык — **русский**, технический, без излишней формальности
- Технические термины, имена объектов, параметры — **жирным** (`r(text, bold=True)`)
- Код в тексте — моноширинный (`Courier New`)
- Пути и URL — жирным

---

## 11. Что НЕ включать в документ

- Общую теорию и объяснения технологий
- Историю изменений (если не требуется явно)
- Скриншоты без подписей
- Контактные лица (если не требуется явно)
