import openpyxl
import re
from openpyxl.utils import get_column_letter
from openpyxl.styles import Font, PatternFill, Alignment

SRC = "/workspace/SQB/Сводная_инвентаризация_с_UID_исправленная.xlsx"
ERR = "/workspace/.monkeycode-tmp-files/92a2e3a2-FailedRows-Сводная_инвентаризация_с_UID_исправленная.xlsx-1.csv"
DST = "/workspace/SQB/Дозагрузка_неудачные.xlsx"

def main():
    # Read source data into UID map
    wb = openpyxl.load_workbook(SRC)
    ws = wb.active

    uid_map = {}
    for r in range(2, ws.max_row + 1):
        uid = str(ws.cell(r, 1).value or "").strip()
        if uid:
            uid_map[uid] = {
                "name": str(ws.cell(r, 3).value or "").strip(),
                "inv": ws.cell(r, 4).value,
                "serial": str(ws.cell(r, 5).value or "").strip(),
                "location": ws.cell(r, 6).value,
                "status": ws.cell(r, 7).value,
                "card": ws.cell(r, 8).value,
                "date": ws.cell(r, 9).value,
                "branch": ws.cell(r, 10).value,
            }

    # Read error CSV
    import csv
    failed_uids = []
    final_state_uids = []
    with open(ERR, encoding='utf-8') as f:
        reader = csv.reader(f)
        next(reader)  # header
        for row in reader:
            if len(row) < 1:
                continue
            uid = row[0].strip()
            err = row[-1] if row else ""
            if uid:
                if "final state" in err:
                    final_state_uids.append(uid)
                else:
                    failed_uids.append(uid)

    print(f"Required field / other errors: {len(failed_uids)}")
    print(f"Final state (already in CMDB): {len(final_state_uids)}")

    # Create output for re-upload (only the re-loadable ones)
    OUT_COLS = [
        "Уникальный инв. №", "№", "Имя", "Инвентарный номер",
        "Серийный номер", "Местоположение", "Статус CMDB",
        "№ Карт.", "Дата ввода", "Филиал",
    ]

    out_wb = openpyxl.Workbook()
    out_ws = out_wb.active
    out_ws.title = "Дозагрузка"

    header_style = Font(bold=True, size=10)
    header_fill = PatternFill("solid", fgColor="D9E1F2")
    header_align = Alignment(horizontal="center", wrap_text=True)

    for c, h in enumerate(OUT_COLS, 1):
        cell = out_ws.cell(1, c, h)
        cell.font = header_style
        cell.fill = header_fill
        cell.alignment = header_align

    out_r = 2
    found = 0
    for uid in failed_uids:
        data = uid_map.get(uid)
        if not data:
            print(f"  NOT FOUND: {uid}")
            continue
        found += 1
        out_ws.cell(out_r, 1, uid)
        out_ws.cell(out_r, 2, out_r - 1)
        out_ws.cell(out_r, 3, data["name"])
        out_ws.cell(out_r, 4, data["inv"])
        out_ws.cell(out_r, 5, data["serial"] if data["serial"] else "")
        out_ws.cell(out_r, 6, data["location"])
        out_ws.cell(out_r, 7, data["status"])
        out_ws.cell(out_r, 8, data["card"])
        out_ws.cell(out_r, 9, data["date"])
        out_ws.cell(out_r, 10, data["branch"])
        out_r += 1

    # Auto-width
    col_widths = {}
    for row in out_ws.iter_rows(min_row=1, max_row=min(out_ws.max_row, 200), values_only=True):
        for c, val in enumerate(row):
            length = len(str(val)) if val else 0
            col_widths[c] = max(col_widths.get(c, 0), min(length + 4, 60))
    for c, w in col_widths.items():
        out_ws.column_dimensions[get_column_letter(c + 1)].width = w

    out_ws.freeze_panes = "B2"
    out_ws.auto_filter.ref = f"A1:{get_column_letter(len(OUT_COLS))}{out_ws.max_row}"

    out_wb.save(DST)
    print(f"\nFound for re-upload: {found}/{len(failed_uids)}")
    print(f"Output: {DST}")
    print(f"\nFinal state items (already in CMDB, not included): {len(final_state_uids)}")

if __name__ == "__main__":
    main()
