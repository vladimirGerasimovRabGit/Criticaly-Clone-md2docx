import openpyxl
import xlrd
import os
import re
from openpyxl.utils import get_column_letter
from openpyxl.styles import Font, PatternFill, Alignment

SRC = "/workspace/SQB/Tarmoqlar"
DST = "/workspace/SQB/Сводная_инвентаризация.xlsx"

OUT_COLS = [
    "№", "Имя", "Инвентарный номер", "Серийный номер",
    "Местоположение", "Статус", "№ Карт.", "Дата ввода", "Филиал"
]

COL_KEYS = {
    "num":       ["№"],
    "name":      ["имя", "наименование"],
    "inv":       ["инвентарный номер", "инв. №", "инв.№", "инв №"],
    "serial":    ["серийный номер"],
    "location":  ["местоположение", "место расп."],
    "status":    ["статус"],
    "card":      ["№ карт.", "№ карт"],
    "date":      ["дата ввода", "дата в экспл", "дата", "под.ние"],
}

def clean(v):
    if v is None:
        return ""
    if isinstance(v, float):
        if v == int(v):
            return str(int(v))
        return str(v)
    return str(v).strip()

def norm(s):
    return re.sub(r"\s+", " ", clean(s).lower().replace(".", ""))

def find_header_row_xlsx(ws, max_check=10):
    for r in range(1, min(max_check + 1, ws.max_row + 1)):
        row_str = " ".join(clean(ws.cell(r, c).value) for c in range(1, max(7, ws.max_column + 1)))
        nl = norm(row_str)
        if any(kw in nl for kw in ["инвентарный", "инв. №", "наименование", "серийный"]):
            return r
    return None

def find_header_row_xls(ws, max_check=10):
    for r in range(min(max_check, ws.nrows)):
        row_str = " ".join(str(ws.cell_value(r, c)) for c in range(ws.ncols))
        nl = norm(row_str)
        if any(kw in nl for kw in ["инвентарный", "инв. №", "наименование", "серийный"]):
            return r
    return None

def build_mapping(headers):
    """Returns dict: target_col_key -> source_column_index (0-based)."""
    mapping = {}
    for i, h in enumerate(headers):
        nh = norm(h)
        for key, keywords in COL_KEYS.items():
            if key in mapping:
                continue
            for kw in keywords:
                if kw in nh:
                    mapping[key] = i
                    break
    return mapping

def extract_branch_xlsx(ws, header_row):
    """Try to find branch name: B1, or the cell above headers."""
    candidates = []
    # Check first row for a standalone label in col B
    for r in range(1, header_row):
        b = clean(ws.cell(r, 2).value)
        if b and len(b) > 3 and all(kw not in norm(b) for kw in ["№", "отчет", "основных"]):
            candidates.append(b)
    # Also check cell A1 of first row
    a1 = clean(ws.cell(1, 1).value)
    if a1 and len(a1) > 3:
        candidates.insert(0, a1)
    return candidates[0] if candidates else ""

def read_xlsx(path):
    wb = openpyxl.load_workbook(path, data_only=True)
    ws = wb[wb.sheetnames[0]]

    header_row = find_header_row_xlsx(ws)
    if header_row is None:
        return []

    branch = extract_branch_xlsx(ws, header_row)
    if not branch:
        branch = os.path.splitext(os.path.basename(path))[0]

    headers = [clean(ws.cell(header_row, c + 1).value) for c in range(ws.max_column)]
    mapping = build_mapping(headers)

    rows = []
    for r in range(header_row + 1, ws.max_row + 1):
        raw = [clean(ws.cell(r, c + 1).value) for c in range(ws.max_column)]
        if not any(v for v in raw):
            continue
        row = {}
        for key, idx in mapping.items():
            if idx < len(raw):
                row[key] = raw[idx]
        row["branch"] = branch
        rows.append(row)
    return rows

def read_xls(path):
    wb = xlrd.open_workbook(path)
    ws = wb.sheet_by_index(0)

    header_row = find_header_row_xls(ws)
    if header_row is None:
        return []

    branch = os.path.splitext(os.path.basename(path))[0]

    headers = [str(ws.cell_value(header_row, c)) for c in range(ws.ncols)]
    mapping = build_mapping(headers)

    rows = []
    for r in range(header_row + 1, ws.nrows):
        raw = [str(ws.cell_value(r, c)) for c in range(ws.ncols)]
        if not any(v for v in raw):
            continue
        row = {}
        for key, idx in mapping.items():
            if idx < len(raw):
                row[key] = raw[idx]
        row["branch"] = branch
        rows.append(row)
    return rows

def main():
    all_rows = []
    files = sorted(os.listdir(SRC))
    processed = 0

    for fname in files:
        path = os.path.join(SRC, fname)
        if not os.path.isfile(path):
            continue
        ext = os.path.splitext(fname)[1].lower()
        try:
            if ext == ".xlsx":
                rows = read_xlsx(path)
            elif ext == ".xls":
                rows = read_xls(path)
            else:
                continue
            all_rows.extend(rows)
            processed += 1
            print(f"  [{processed:2d}] {fname}: {len(rows)} строк")
        except Exception as e:
            print(f"  [!!] {fname}: ОШИБКА — {e}")

    if not all_rows:
        print("Нет данных.")
        return

    # Output workbook
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Инвентаризация"

    header_style = Font(bold=True, size=10)
    header_fill = PatternFill("solid", fgColor="D9E1F2")
    header_align = Alignment(horizontal="center", wrap_text=True)

    for c, h in enumerate(OUT_COLS, 1):
        cell = ws.cell(1, c, h)
        cell.font = header_style
        cell.fill = header_fill
        cell.alignment = header_align

    for i, row in enumerate(all_rows):
        r = i + 2
        ws.cell(r, 1, i + 1)
        ws.cell(r, 2, row.get("name", ""))
        ws.cell(r, 3, row.get("inv", ""))
        ws.cell(r, 4, row.get("serial", ""))
        ws.cell(r, 5, row.get("location", ""))
        ws.cell(r, 6, row.get("status", ""))
        ws.cell(r, 7, row.get("card", ""))
        ws.cell(r, 8, row.get("date", ""))
        ws.cell(r, 9, row.get("branch", ""))

    # Auto-width
    col_widths = {}
    for row in ws.iter_rows(min_row=1, max_row=ws.max_row, values_only=True):
        for c, val in enumerate(row):
            length = len(str(val)) if val else 0
            col_widths[c] = max(col_widths.get(c, 0), min(length + 4, 60))
    for c, w in col_widths.items():
        ws.column_dimensions[get_column_letter(c + 1)].width = w

    ws.freeze_panes = "A2"
    ws.auto_filter.ref = f"A1:{get_column_letter(len(OUT_COLS))}{ws.max_row}"

    wb.save(DST)
    print(f"\nГотово: {DST}")
    print(f"Файлов: {processed}, строк: {len(all_rows)}")

if __name__ == "__main__":
    main()
