import openpyxl
import re
from openpyxl.utils import get_column_letter
from openpyxl.styles import Font, PatternFill, Alignment

INVENTORY = "/workspace/SQB/Сводная_инвентаризация.xlsx"
REFERENCE = "/workspace/.monkeycode-tmp-files/f3e83244-ЦБУ ва Локал кодлар 2-1.xlsx"
DST       = "/workspace/SQB/Сводная_инвентаризация_с_UID.xlsx"

STATUS_MAP = {
    # In Use
    "рабочий": "In Use", "Рабочий": "In Use", "рабочи": "In Use",
    "работает": "In Use",
    "ишчи холатида": "In Use", "ишчи холтада": "In Use",
    "ишчи холатта": "In Use", "ishchi xolatda": "In Use",
    "ишчи холатда": "In Use", "ишчи холатда.": "In Use",
    "соз холатда": "In Use", "в эксплуатации": "In Use",
    "ярокли": "In Use", "+": "In Use",
    "ishchi holatda": "In Use", "ISHCHI XOLATDA": "In Use",

    # Down (faulty)
    "нерабочий": "Down", "не рабочи": "Down", "не робочи": "Down",
    "не рабочий": "Down", "не рабочий": "Down",
    "nosoz": "Down", "NOSOZ": "Down", "носоз": "Down",
    "носоз холатда": "Down", "nosoz holatda": "Down",
    "яроқсиз": "Down", "яроксиз": "Down",
    "ишламайди": "Down", "ишчи холатда эмас": "Down",
    "экран кетган": "Down",

    # Awaiting Disposal
    "к списанию": "Awaiting Disposal", "списание": "Awaiting Disposal",
    "списания": "Awaiting Disposal", "списат": "Awaiting Disposal",
    "списания": "Awaiting Disposal",
    "эскирган списания қилиш керак": "Awaiting Disposal",
    "маънан эскирган. ҳисобдан чиқарилади": "Awaiting Disposal",

    # Retired (obsolete/morally outdated but possibly still present)
    "устаревший": "Retired", "эскирган": "Retired",
    "морально устаревший": "Retired", "манан эскирган": "Retired",
    "ma`nan eskirgan": "Retired",
    "eski, ishlaydi": "Retired",
    "eski, ishlamaydi": "Retired",
    "5 йилдан кейин": "Retired",
    "яанги": "In Stock",

    # Under Maintenance
    "ишчи холатда. маънан эскирган": "Under Maintenance",

    # In Repair
    "тамир талаб": "In Repair",

    # Stolen
    "prokrotura olib ketilgan": "Stolen",

    # Unknown / garbage — keep empty
    "отабек ёки лазиз  ?": "",
    "билмадим": "",
    ".": "",
    "аввал исмоилов у да булган": "",
    "колади": "",
    "фарғона бхм да": "",
}

def load_reference(path):
    wb = openpyxl.load_workbook(path)
    ws = wb["Sheet1"]
    code_to_name = {}
    cbu_to_name = {}
    for r in range(2, ws.max_row + 1):
        local = str(ws.cell(r, 2).value or "").strip().replace('="', "").replace('"', "")
        cbu   = str(ws.cell(r, 3).value or "").strip().replace('="', "").replace('"', "")
        name  = str(ws.cell(r, 5).value or "").strip()
        if local:
            code_to_name[local.lower()] = name
        if cbu:
            cbu_to_name[cbu] = name
    return code_to_name, cbu_to_name

def clean(s):
    if s is None:
        return ""
    return str(s).strip()

def match_branch(branch):
    """Match inventory branch to 5-char local structure code."""
    b = branch.strip()
    bl = b.lower()

    # 1. Exact code prefix match (e.g., "26F00 - Миробод БХМ")
    m = re.match(r"^(\d{2}[A-ZА-Я0-9]\d{2})\s*[-–]\s*", b)
    if m:
        prefix = m.group(1).upper()
        prefix_norm = prefix[0:2] + re.sub(r"[OО]", "0", prefix[2], flags=re.IGNORECASE) + prefix[3:]
        return prefix_norm

    # 2. Keyword mapping to local structure codes
    keywords_map = {
        "al xorazmiy": "26L00",
        "xorazmiy": "26L00",
        "angren": "27A00",
        "bosh bank": "00000",
        "korp mark": "02K00",
        "buxoro": "06R00",
        "chilonzor": "26J00",
        "fergana": "30R00",
        "фаргона": "30R00",
        "jizzah": "08R00",
        "jizzax": "08R00",
        "жиза": "08R00",
        "ракат": "26M00",
        "rakat": "26M00",
        "korporativ": "02K00",
        "olmazor": "26B00",
        "olmalik": "27000",
        "олмалиқ": "27000",
        "olmaliq": "27000",
        "qator": "26H00",
        "қтортол": "26H00",
        "qorovulbozor": "06B00",
        "коровул": "06B00",
        "samarqand": "18R00",
        "самарканд": "18R00",
        "shahriston": "26D00",
        "шахрист": "26D00",
        "sirgali": "26E00",
        "sirg`ali": "26E00",
        "сергели": "26E00",
        "surxan": "22R00",
        "сурхан": "22R00",
        "shargun": "22S60",
        "uchtepa": "26G00",
        "учтепа": "26G00",
        "yashnobod": "26K00",
        "яшнобод": "26K00",
        "yunusobod": "26A00",
        "юнусобод": "26A00",
        "бекобод": "27B00",
        "bunyodkor": "03B00",
        "бунёдкор": "03B00",
        "бархаёт": "03B50",
        "кк бхо": "35R00",
        "кашкадар": "10R00",
        "qashqadar": "10R00",
        "кунград": "35Q00",
        "mirobod": "26F00",
        "миробод": "26F00",
        "навоий": "12R00",
        "navoi": "12R00",
        "namangan": "14R00",
        "наманган": "14R00",
        "сирдар": "24R00",
        "тахиатош": "35T00",
        "тош вил": "27R00",
        "тошкент шаҳар": "26R00",
        "toshkent shahar": "26R00",
        "урта бизнес": "26P00",
        "ўрта бизнес": "26P00",
        "лабзак": "26P00",
        "хонобод": "03X00",
        "хоразм": "33R00",
        "xorazm": "33R00",
        "чирчик": "27C00",
        "chirchiq": "27C00",
        "қибрай": "27Q00",
        "qibray": "27Q00",
        "қўқон": "30Q00",
        "qoqon": "30Q00",
        "quqon": "30Q00",
        "kokand": "30Q00",
    }

    for kw, code in keywords_map.items():
        if kw in bl:
            return code

    return "?????"

def normalize_status(raw):
    """Map free-text status to standard CMDB status model."""
    s = clean(raw).strip().lower()
    if not s:
        return ""
    return STATUS_MAP.get(s, s)

def format_inv_number(raw):
    """Pad numeric prefix to 10 digits."""
    s = clean(raw).strip()
    if not s:
        return "0000000000"
    m = re.match(r"^(\d+)(.*)", s)
    if m:
        num_part = m.group(1)
        rest = m.group(2)
        padded = num_part.zfill(10)
        return padded + rest
    return s.zfill(10)

def main():
    code_to_name, cbu_to_name = load_reference(REFERENCE)

    wb = openpyxl.load_workbook(INVENTORY)
    ws = wb.active

    # Build branch -> code cache
    branches = {}
    for r in range(2, ws.max_row + 1):
        b = str(ws.cell(r, 9).value or "").strip()
        if b and b not in branches:
            branches[b] = match_branch(b)

    print("Сопоставление филиалов:")
    for b, code in sorted(branches.items()):
        print(f"  [{code}] {b}")

    # Status mapping stats
    status_stats = {}
    unmapped = set()
    for r in range(2, ws.max_row + 1):
        raw = str(ws.cell(r, 6).value or "").strip()
        if raw:
            s = normalize_status(raw)
            status_stats[s] = status_stats.get(s, 0) + 1
            if s == raw and s:
                unmapped.add(raw)

    print(f"\nСтатусы после нормализации:")
    for s, c in sorted(status_stats.items(), key=lambda x: -x[1]):
        print(f"  {c:>5}  {s}")
    if unmapped:
        print(f"\nНе распознаны: {unmapped}")

    # Create output
    out_wb = openpyxl.Workbook()
    out_ws = out_wb.active
    out_ws.title = "Инвентаризация"

    OUT_COLS = [
        "Уникальный инв. №", "№", "Имя", "Инвентарный номер",
        "Серийный номер", "Местоположение", "Статус CMDB",
        "№ Карт.", "Дата ввода", "Филиал"
    ]

    header_style = Font(bold=True, size=10)
    header_fill = PatternFill("solid", fgColor="D9E1F2")
    header_align = Alignment(horizontal="center", wrap_text=True)

    for c, h in enumerate(OUT_COLS, 1):
        cell = out_ws.cell(1, c, h)
        cell.font = header_style
        cell.fill = header_fill
        cell.alignment = header_align

    out_r = 2
    for r in range(2, ws.max_row + 1):
        name_val = str(ws.cell(r, 2).value or "").strip()
        if not name_val:
            continue

        branch = str(ws.cell(r, 9).value or "").strip()
        code = branches.get(branch, "?????")
        inv_raw = str(ws.cell(r, 3).value or "").strip()
        raw_status = str(ws.cell(r, 6).value or "")
        norm_status = normalize_status(raw_status)

        uid = f"{code}-{format_inv_number(inv_raw)}"

        # Serial: move date-looking values to date column
        raw_serial = str(ws.cell(r, 4).value or "").strip()
        raw_date   = str(ws.cell(r, 8).value or "").strip()
        if re.match(r"^\d{4}[-/.]\d{2}[-/.]\d{2}", raw_serial):
            if not raw_date:
                raw_date = raw_serial
            raw_serial = ""

        out_ws.cell(out_r, 1, uid)
        out_ws.cell(out_r, 2, out_r - 1)                # № (renumber)
        out_ws.cell(out_r, 3, name_val)                 # Имя
        out_ws.cell(out_r, 4, ws.cell(r, 3).value)      # Инв. номер
        out_ws.cell(out_r, 5, raw_serial)               # Сер. номер
        out_ws.cell(out_r, 6, ws.cell(r, 5).value)      # Местоположение
        out_ws.cell(out_r, 7, norm_status)              # Статус CMDB
        out_ws.cell(out_r, 8, ws.cell(r, 7).value)      # № Карт.
        out_ws.cell(out_r, 9, raw_date)                 # Дата ввода
        out_ws.cell(out_r, 10, branch)
        out_r += 1

    # Auto-width
    col_widths = {}
    for row in out_ws.iter_rows(min_row=1, max_row=min(out_ws.max_row, 200), values_only=True):
        for c, val in enumerate(row):
            length = len(str(val)) if val else 0
            col_widths[c] = max(col_widths.get(c, 0), min(length + 4, 60))
    for c, w in col_widths.items():
        out_ws.column_dimensions[get_column_letter(c + 1)].width = w

    out_ws.freeze_panes = "B2"
    out_ws.auto_filter.ref = f"A1:{get_column_letter(len(OUT_COLS))}{out_ws.max_row}"

    out_wb.save(DST)
    print(f"\nГотово: {DST}")
    print(f"Строк: {out_ws.max_row - 1}")

if __name__ == "__main__":
    main()
