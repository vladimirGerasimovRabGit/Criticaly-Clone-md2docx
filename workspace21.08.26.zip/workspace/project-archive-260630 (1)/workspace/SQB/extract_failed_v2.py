import openpyxl
import re
from openpyxl.utils import get_column_letter
from openpyxl.styles import Font, PatternFill, Alignment
import csv

SRC = "/workspace/SQB/Сводная_инвентаризация_с_UID_исправленная.xlsx"
ERR = "/workspace/.monkeycode-tmp-files/f3234884-FailedRows-Дозагрузка_неудачные.xlsx-1.csv"
DST = "/workspace/SQB/Дозагрузка_неудачные_v2.xlsx"

MORE_INVALID_SERIAL = [
    r'^принтер термо$',
    r'^модем$',
    r'^сканер$',
    r'^сеть$',
    r'^клавиатура$',
    r'^маршрутизатор$',
    r'^главный$',
    r'^коммутатор$',
    r'^сервер$',
    r'^системный блок$',
    r'^роутер$',
    r'^wi.?fi$',
    r'^wi.?fi роутер$',
    r'^wifi модем$',
]

def is_generic_serial(s):
    s = s.strip().lower()
    if not s:
        return False
    if len(s) <= 2:
        return True
    for pat in MORE_INVALID_SERIAL:
        if re.fullmatch(pat, s, re.IGNORECASE):
            return True
    # Also catch if the serial IS the device type (single generic word)
    generic_words = [
        'компьютер', 'компютер', 'принтер', 'монитор', 'сканер', 'модем',
        'роутер', 'телефон', 'планшет', 'ноутбук', 'сервер', 'проектор',
        'клавиатура', 'мышь', 'мышка', 'колонка', 'наушник', 'камера',
        'телевизор', 'приставка', 'адаптер', 'зарядка', 'батарея',
        'аккумулятор', 'лампа', 'шкаф', 'сейф', 'кабель', 'патчкорд',
        'патч-корд', 'хаб', 'концентратор', 'свитч', 'коммутатор',
    ]
    cleaned = re.sub(r'[\s\-_/]+', '', s)
    for w in generic_words:
        if cleaned == w:
            return True
    return False

def main():
    wb = openpyxl.load_workbook(SRC)
    ws = wb.active

    uid_map = {}
    for r in range(2, ws.max_row + 1):
        uid = str(ws.cell(r, 1).value or "").strip()
        if uid:
            uid_map[uid] = {
                "name": str(ws.cell(r, 3).value or "").strip(),
                "inv": ws.cell(r, 4).value,
                "serial": str(ws.cell(r, 5).value or "").strip(),
                "location": ws.cell(r, 6).value,
                "status": ws.cell(r, 7).value,
                "card": ws.cell(r, 8).value,
                "date": ws.cell(r, 9).value,
                "branch": ws.cell(r, 10).value,
                "ci_type": str(ws.cell(r, 11).value or "").strip(),
                "ci_subtype": str(ws.cell(r, 12).value or "").strip(),
            }

    with open(ERR, encoding='utf-8') as f:
        reader = csv.reader(f)
        next(reader)
        failed_uids = []
        storage_uids = set()
        bad_serial_uids = set()
        for row in reader:
            if len(row) < 1:
                continue
            uid = row[0].strip()
            err = row[-1] if row else ""
            if not uid:
                continue
            if "Storage Space" in err:
                storage_uids.add(uid)
            elif "НОУТБУК" in err or "Серийный номер" in err:
                bad_serial_uids.add(uid)
            else:
                failed_uids.append(uid)

    print(f"CI Type errors: {len(failed_uids)}")
    print(f"Storage Space errors: {len(storage_uids)}")
    print(f"Bad serial errors: {len(bad_serial_uids)}")

    OUT_COLS = [
        "Уникальный инв. №", "№", "Имя", "Инвентарный номер",
        "Серийный номер", "Местоположение", "Статус CMDB",
        "№ Карт.", "Дата ввода", "Филиал",
        "CI Type", "CI Subtype",
    ]

    out_wb = openpyxl.Workbook()
    out_ws = out_wb.active
    out_ws.title = "Дозагрузка"

    header_style = Font(bold=True, size=10)
    header_fill = PatternFill("solid", fgColor="D9E1F2")
    header_align = Alignment(horizontal="center", wrap_text=True)

    for c, h in enumerate(OUT_COLS, 1):
        cell = out_ws.cell(1, c, h)
        cell.font = header_style
        cell.fill = header_fill
        cell.alignment = header_align

    all_uids = failed_uids + list(storage_uids) + list(bad_serial_uids)
    stats = {"serial_cleaned": 0, "status_changed": 0, "name_fixed": 0, "total": 0}

    out_r = 2
    for uid in all_uids:
        data = uid_map.get(uid)
        if not data:
            continue
        stats["total"] += 1

        name = data["name"]
        serial = data["serial"]
        status = data["status"]

        # Fix: Storage Space → change In Stock to Production
        if uid in storage_uids and status == "In Stock":
            status = "Production"
            stats["status_changed"] += 1

        # Fix: clean generic serials
        if is_generic_serial(serial):
            serial = ""
            stats["serial_cleaned"] += 1

        # Fix: corrupted data (HTML in serial)
        if uid in bad_serial_uids:
            serial = ""
            # Clean name (remove trailing comma and HTML)
            name = re.sub(r'<[^>]+>', '', name)
            name = name.rstrip(', ')
            stats["name_fixed"] += 1
            stats["serial_cleaned"] += 1

        # Fix: clean trailing cruft from names that confuse auto-classifier
        name_clean = name
        for suffix in [' - ,', ' - .', ' - /', ' - ..', ' - ...']:
            if name_clean.endswith(suffix):
                name_clean = name_clean[:-len(suffix)]
                stats["name_fixed"] += 1
                break

        out_ws.cell(out_r, 1, uid)
        out_ws.cell(out_r, 2, out_r - 1)
        out_ws.cell(out_r, 3, name_clean)
        out_ws.cell(out_r, 4, data["inv"])
        out_ws.cell(out_r, 5, serial)
        out_ws.cell(out_r, 6, data["location"])
        out_ws.cell(out_r, 7, status)
        out_ws.cell(out_r, 8, data["card"])
        out_ws.cell(out_r, 9, data["date"])
        out_ws.cell(out_r, 10, data["branch"])
        out_ws.cell(out_r, 11, data["ci_type"])
        out_ws.cell(out_r, 12, data["ci_subtype"])
        out_r += 1

    col_widths = {}
    for row in out_ws.iter_rows(min_row=1, max_row=min(out_ws.max_row, 200), values_only=True):
        for c, val in enumerate(row):
            length = len(str(val)) if val else 0
            col_widths[c] = max(col_widths.get(c, 0), min(length + 4, 60))
    for c, w in col_widths.items():
        out_ws.column_dimensions[get_column_letter(c + 1)].width = w

    out_ws.freeze_panes = "B2"
    out_ws.auto_filter.ref = f"A1:{get_column_letter(len(OUT_COLS))}{out_ws.max_row}"

    out_wb.save(DST)
    print(f"\nOutput: {DST}")
    print(f"Total rows: {stats['total']}")
    print(f"Status In Stock→Production: {stats['status_changed']}")
    print(f"Generic serials cleaned: {stats['serial_cleaned']}")
    print(f"Corrupted names fixed: {stats['name_fixed']}")

    # Show some cleaned serials
    print("\nSample cleaned serials:")
    count = 0
    for uid in all_uids:
        data = uid_map.get(uid)
        if not data:
            continue
        orig = data["serial"]
        if is_generic_serial(orig) or uid in bad_serial_uids:
            print(f"  [{orig[:50]}] → []  ({data['name'][:50]})")
            count += 1
            if count >= 15:
                break

if __name__ == "__main__":
    main()
