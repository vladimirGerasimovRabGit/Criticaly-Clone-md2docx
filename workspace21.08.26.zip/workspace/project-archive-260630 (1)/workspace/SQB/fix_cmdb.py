import openpyxl
import re
from openpyxl.utils import get_column_letter
from openpyxl.styles import Font, PatternFill, Alignment

SRC = "/workspace/SQB/Сводная_инвентаризация_с_UID.xlsx"
DST = "/workspace/SQB/Сводная_инвентаризация_продуктив.xlsx"

INVALID_SERIAL_PATTERNS = [
    r'^-$', r'^\d$',
    r'^IP телефон$', r'^Принтер$', r'^UPS$',
    r'^Коммутатор$', r'^Компьютер$', r'^Телефонный аппарат$',
    r'^HUB$', r'^USB Hub$', r'^Монитор$', r'^Маршрутизатор$',
    r'^Видеоконференция Cisco$', r'^Видеонаблюдение$', r'^Камера$',
    r'^Адаптер питания$', r'^SFP Module$', r'^Зарядное устройство$',
    r'^Macbook$', r'^MacBook$',
]

EXTRA_INVALID_SERIAL = [
    r'^принтер термо$', r'^модем$', r'^сканер$', r'^сеть$',
    r'^клавиатура$', r'^маршрутизатор$', r'^главный$',
    r'^системный блок$', r'^роутер$', r'^wi.?fi$',
    r'^wi.?fi роутер$', r'^wifi модем$',
]

GENERIC_WORDS = [
    'компьютер', 'компютер', 'принтер', 'монитор', 'сканер', 'модем',
    'роутер', 'телефон', 'планшет', 'ноутбук', 'сервер', 'проектор',
    'клавиатура', 'мышь', 'мышка', 'колонка', 'наушник', 'камера',
    'телевизор', 'приставка', 'адаптер', 'зарядка', 'батарея',
    'аккумулятор', 'лампа', 'шкаф', 'сейф', 'кабель', 'патчкорд',
    'патч-корд', 'хаб', 'концентратор', 'свитч', 'коммутатор',
]

TRAILING_CRUFT = [' - ,', ' - .', ' - /', ' - ..', ' - ...']

def is_invalid_serial(s):
    s = s.strip()
    if not s:
        return False
    for pat in INVALID_SERIAL_PATTERNS:
        if re.fullmatch(pat, s):
            return True
    if re.match(r'^\d{4}[-/.]\d{2}[-/.]\d{2}', s):
        return True
    return False

def is_generic_serial(s):
    s = s.strip().lower()
    if not s:
        return False
    if len(s) <= 2:
        return True
    for pat in EXTRA_INVALID_SERIAL:
        if re.fullmatch(pat, s, re.IGNORECASE):
            return True
    cleaned = re.sub(r'[\s\-_/]+', '', s)
    for w in GENERIC_WORDS:
        if cleaned == w:
            return True
    return False

def is_invalid_inv_number(s):
    s = s.strip()
    if not s:
        return False
    if re.match(r'^\d{4}[-/.]\d{2}[-/.]\d{2}', s):
        return True
    return False

def clean_name(name):
    n = name.strip()
    for suffix in TRAILING_CRUFT:
        if n.endswith(suffix):
            n = n[:-len(suffix)]
            break
    # Remove HTML tags and trailing comma
    n = re.sub(r'<[^>]+>', '', n)
    n = n.rstrip(', ')
    return n

def classify(name):
    n = name.strip()
    nl = n.lower()

    if not n:
        return "Other", "Other"

    # EnterpriseApplication / Software
    if re.search(r'\bПО\b|\bMicrosoft\b|\bWindows\b|\bWin\b|\bOffice\b|\bАРМ\b|\bпрограмма\b|\bпрограммное\b', nl):
        return "EnterpriseApplication", "Software"
    if re.search(r'\bлицензия\b|\bлизензия\b|\blicense\b', nl):
        return "EnterpriseApplication", "Software"

    if re.search(r'\bCisco\b|\bcisco\b', n) and re.search(r'программ|software|софт|ПО ', nl):
        return "EnterpriseApplication", "Software"

    # MobileDevice
    if re.search(r'\bпланшет\b|\btablet\b|\biPad\b|\bsamsung\s*galaxy\b|\bsamsung\s*tab\b', nl):
        return "MobileDevice", "Tablet"

    # Consumable
    if re.search(r'\bтонер\b|\bкартридж\b|\btoner\b|\bcartridge\b', nl):
        return "Consumable", "Toner"
    if re.search(r'\bпатч.?корд\b|\bпатч\s*корд\b|\bpatch.?cord\b', nl):
        return "Consumable", "Cable"

    # Facilities
    facilities_keywords = [
        (r'\bсветов\w*\s*реклам\w*\b', 'Signage'),
        (r'\bинфокиоск\b', 'Kiosk'),
        (r'\bвводн\w*\s*устройств\w*\b', 'Electrical Equipment'),
        (r'\bвру\b', 'Electrical Equipment'),
        (r'\bкабинетн\w*\s*набор\w*\b', 'Furniture'),
        (r'\bсилов\w*\s*электро\w*\b', 'Electrical Equipment'),
        (r'\bэлектрическ\w*\s*сет\w*\b', 'Electrical Equipment'),
        (r'\bщит\w*\b', 'Electrical Equipment'),
        (r'\bщиток\b', 'Electrical Equipment'),
        (r'\bгенератор\b', 'Electrical Equipment'),
        (r'\bтележк\w*\b', 'Furniture'),
        (r'\bэмбуссер\b', 'Equipment'),
        (r'\bсчётчик\s*банкнот\b', 'Counter'),
        (r'\bсчетчик\s*банкнот\b', 'Counter'),
        (r'\bсчетчик\s*купюр\b', 'Counter'),
        (r'\bсчётчик\s*купюр\b', 'Counter'),
        (r'\bдетектор\s*валют\b', 'Detector'),
        (r'\bсортировщик\s*банкнот\b', 'Counter'),
        (r'\bупаковщик\s*банкнот\b', 'Equipment'),
        (r'\bсейф\b', 'Safe'),
        (r'\bшкаф\b', 'Furniture'),
        (r'\bкондиционер\b', 'Air Conditioning'),
        (r'\bсплит.?систем\w*\b', 'Air Conditioning'),
        (r'\bобогревател\w*\b', 'Heating'),
        (r'\bхолодильник\b', 'Appliance'),
        (r'\bтелевизор\b', 'Appliance'),
        (r'\bкулер\b', 'Appliance'),
        (r'\bлампа\b', 'Lighting'),
        (r'\bсветильник\b', 'Lighting'),
        (r'\bэлектро.?щит\w*\b', 'Electrical Equipment'),
        (r'\bаккумулятор\b', 'Battery'),
        (r'\bбатаре\w*\b', 'Battery'),
        (r'\bстойк\w*\s*ресепш\w*\b', 'Furniture'),
        (r'\bресепш\w*\b', 'Furniture'),
        (r'\bстул\w*\b', 'Furniture'),
        (r'\bкресл\w*\b', 'Furniture'),
        (r'\bстол\b', 'Furniture'),
        (r'\bтумб\w*\b', 'Furniture'),
        (r'\bвешалк\w*\b', 'Furniture'),
        (r'\bжалюз\w*\b', 'Furniture'),
        (r'\bжаллюз\w*\b', 'Furniture'),
        (r'\bкронштейн\b', 'Mount'),
        (r'\bтурникет\b', 'Security'),
        (r'\bогнетушител\w*\b', 'Fire Safety'),
        (r'\bпожарн\w*\b', 'Fire Safety'),
        (r'\bвентилятор\b', 'Climate'),
        (r'\bбанкомат\b', 'ATM'),
        (r'\bтерминал\s*самообслуж\w*\b', 'ATM'),
        (r'\bэлектронн\w*\s*очеред\w*\b', 'Queue System'),
        (r'\bсистем\w*\s*управлен\w*\s*очеред\w*\b', 'Queue System'),
        (r'\b(?:аппаратн\w*.?программн\w*|программн\w*.?аппаратн\w*)\s*комплекс\b', 'Queue System'),
        (r'\bдат[аы]\s*центр\w*\b', 'Data Center'),
        (r'\bрцод\b', 'Data Center'),
        (r'\bоцод\b', 'Data Center'),
        (r'\bэкран\s*для\s*видеопроектор\w*\b', 'Projector Screen'),
    ]
    for pat, subtype in facilities_keywords:
        if re.search(pat, nl):
            return "Facilities", subtype

    # PeripheralDevice (check BEFORE Computer)
    if re.search(r'\bпринтер|\bprinter|\bмфу\b|\bmfp\b|\bmfu\b|\bмногофункциональн\w*\s*устройств\w*|\bтермопринтер|\bкопировальн\w*\b', nl):
        return "PeripheralDevice", "Printer"
    if re.search(r'\bсканер\b|\bscanner\b', nl):
        return "PeripheralDevice", "Scanner"
    if re.search(r'\bмонитор\b|\bmonitor\b|\bдисплей\b', nl):
        return "PeripheralDevice", "Monitor"
    if re.search(r'\bпроектор\b|\bprojector\b', nl):
        return "PeripheralDevice", "Projector"
    if re.search(r'\bклавиатур\w*\b|\bkeyboard\b', nl):
        return "PeripheralDevice", "Keyboard"
    if re.search(r'\bмыш\w*\b|\bmouse\b', nl):
        return "PeripheralDevice", "Mouse"
    if re.search(r'\bжестк\w*\s*диск\w*\b|\bhard.?disk\b|\bжесткий\b|\bвнешн\w*\s*диск\b|\bвнешнии\s*диск\b', nl):
        return "PeripheralDevice", "Hard-Drive"
    if re.search(r'\bвеб.?камер\w*\b|\bweb.?cam\w*\b', nl):
        return "PeripheralDevice", "WebCam"
    if re.search(r'\bфакс\b|\bfax\b', nl):
        return "PeripheralDevice", "Fax"
    if re.search(r'\bнаушник\w*\b|\bгарнитур\w*\b|\bheadset\b|\bheadphone\b', nl):
        return "PeripheralDevice", "Headset"
    if re.search(r'\bколонк\w*\b|\bдинамик\w*\b|\bspeaker\b', nl):
        return "PeripheralDevice", "Speaker"

    # ivnt_Infrastructure
    if re.search(r'\b[mм]аршрутизатор|\brouter\b|\bроутер\b', nl) or re.search(r'\bcisco\s*2811\b', nl):
        return "ivnt_Infrastructure", "Router"
    if re.search(r'\bкоммутатор\b|\bswitch\b|\bcatalyst', nl) or re.search(r'\bws-c\d', nl):
        return "ivnt_Infrastructure", "Switch"
    if re.search(r'\bмежсетев\w*\s*экран|\bfirewall\b|\bфаервол\b|\basa\s*\d|forti|zywall|juniper|firepower|fpr\d|ngfw', nl):
        return "ivnt_Infrastructure", "Firewall"
    if re.search(r'\bip.?телефон|\bip.?phone|\bтелефонн\w*\s*аппарат|\bтелефон аппарат|\bтелефон\s*стационарн|\bаппарат\s*телефонн|\bцифров\w*\s*беспроводн\w*\s*телефон|\bстационан\w*\s*телефон|\bтелефон\s*panasonic', nl):
        return "ivnt_Infrastructure", "Phone"
    if re.search(r'\bмини.?атс\b|\bмини.?atc\b|\bpanasoni[ck]\s*kx.?ns|\bpanasoni[ck]\s*kx.?tda|\bцифров\w*\s*мини\s*at[sc]|\bмини-атс\b', nl):
        return "ivnt_Infrastructure", "PBX"
    if re.search(r'\bups\b|\bибп\b|\bисточник\s*бесперебойн\w*\b|\bбесперебойн\w*\s*питан\w*\b', nl):
        return "ivnt_Infrastructure", "UPS"
    if re.search(r'\bhub\b|\bхаб\b|\bхап\b', nl):
        return "ivnt_Infrastructure", "Hub"
    if re.search(r'\bточк\w*\s*доступ\w*\b|\baccess.?point\b|\bwi.?fi.*точк\w*\b', nl):
        return "ivnt_Infrastructure", "Access Point"
    if re.search(r'\bвидеоконференц\w*\b|\bвидео.?конференц\w*\b|\bvideo.?conference\b|\bвидео присутстви\w*\b', nl):
        return "ivnt_Infrastructure", "Video Conference"
    if re.search(r'\bвидеонаблюден\w*\b|\bвидео.?наблюден\w*\b|\bcctv\b|\bвидеокамер\w*\b', nl):
        return "ivnt_Infrastructure", "Video Surveillance"
    if re.search(r'\bстойк\w*\b|\brack\b|\bсерверн\w*\s*шкаф\w*\b|\bтелекоммуникационн\w*\s*напольн\w*\b', nl):
        return "ivnt_Infrastructure", "Rack"
    if re.search(r'\bsfp\b|\bтрансивер\w*\b|\bgbase\b', nl):
        return "ivnt_Infrastructure", "SFP Module"
    if re.search(r'\bмедиа.?конверт[ое]р\b|\bmedia.?converter\b', nl):
        return "ivnt_Infrastructure", "Media Converter"
    if re.search(r'\bпатч.?панел\w*\b|\bpatch.?panel\b', nl):
        return "ivnt_Infrastructure", "Patch Panel"
    if re.search(r'\bадаптер\s*питан\w*\b|\bpower.?adapter\b|\bблок\s*питан\w*\b', nl):
        return "ivnt_Infrastructure", "Power Adapter"
    if re.search(r'\bзарядн\w*\s*устройств\w*\b|\bcharger\b', nl):
        return "ivnt_Infrastructure", "Charger"
    if re.search(r'\bмодем|\bmodem', nl):
        return "ivnt_Infrastructure", "Modem"
    if re.search(r'\bлвс\b|локал\w*[.\s]*сет|\bлокал\w*[.\s]*тармо', nl):
        return "ivnt_Infrastructure", "Network"
    if re.search(r'\bвидео\s*стен\w*\b', nl):
        return "ivnt_Infrastructure", "Video Wall"
    if re.search(r'\bмодул[ья]\w*\b|\bплат[аы]\b|\bmemory\s*extention\b', nl):
        return "ivnt_Infrastructure", "Module"

    # Computer (check LAST)
    if re.search(r'\bсервер\b|\bserver\b|\bсерверн\w*\s*обор\w*\b', nl):
        return "Computer", "Server"
    if re.search(r'\bноутбук\b|\blaptop\b|\bnotebook\b|\bthinkpad\b|\bthinkbook\b|\bmacbook\b|\bhp\s*elitebook\b|\bdell\s*latitude\b', nl):
        return "Computer", "Laptop"
    if re.search(r'\bмоноблок\b|\bmonoblock\b|\ball.in.one\b|\bмоно\s*блок\b', nl):
        return "Computer", "Desktop"
    if re.search(r'\bмини.?пк\b|\bмини компьютер\b|\bthin.?client\b|\bтонк\w*\s*клиент\w*\b|\bмини\s*pc\b|\bмультимедийны\w*\s*центр\w*\b', nl):
        return "Computer", "Thin Client"
    if re.search(r'\bкомпьютер|\bкомпютер|\bкомпъютер|\bcomputer\b|\bкомп\b|\bсистемн\w*\s*блок\w*\b|\bсистемныи\s*блок\b|\bперсональны\w*\s*компьютер|\bнр.?260\b', nl):
        return "Computer", "Desktop"

    # Brand-based fallback
    if re.search(r'\blenovo\b|\bdell\b|\bfujitsu\b|\bacer\b|\basus\b|\bavtech\b', nl):
        if re.search(r'\bноутбук\b|\blaptop\b', nl):
            return "Computer", "Laptop"
        return "Computer", "Desktop"

    # Printer brands
    if re.search(r'\bhp\s*laserjet\b|\bhp\s*mfp\b|\bcanon\b|\bkyocera\b|\bxerox\b|\bepson\b|\btaskalfa\b', nl):
        return "PeripheralDevice", "Printer"

    return "Other", "Other"


def main():
    wb = openpyxl.load_workbook(SRC)
    ws_in = wb.active

    OUT_COLS = [
        "Уникальный инв. №", "№", "Имя", "Инвентарный номер",
        "Серийный номер", "Местоположение", "Статус CMDB",
        "№ Карт.", "Дата ввода", "Филиал",
        "CI Type", "CI Subtype",
    ]

    out_wb = openpyxl.Workbook()
    out_ws = out_wb.active
    out_ws.title = "Инвентаризация"

    header_style = Font(bold=True, size=10)
    header_fill = PatternFill("solid", fgColor="D9E1F2")
    header_align = Alignment(horizontal="center", wrap_text=True)

    for c, h in enumerate(OUT_COLS, 1):
        cell = out_ws.cell(1, c, h)
        cell.font = header_style
        cell.fill = header_fill
        cell.alignment = header_align

    stats = {
        "serial_cleared": 0,
        "inv_cleared": 0,
        "name_cleaned": 0,
        "type_classified": {},
        "total": 0,
    }

    out_r = 2
    for r in range(2, ws_in.max_row + 1):
        uid       = str(ws_in.cell(r, 1).value or "").strip()
        name      = str(ws_in.cell(r, 3).value or "").strip()
        inv_raw   = ws_in.cell(r, 4).value
        serial    = str(ws_in.cell(r, 5).value or "").strip()
        location  = ws_in.cell(r, 6).value
        status    = ws_in.cell(r, 7).value
        card_no   = ws_in.cell(r, 8).value
        date_in   = ws_in.cell(r, 9).value
        branch    = ws_in.cell(r, 10).value

        if not name:
            continue

        stats["total"] += 1

        # Fix inventory number (date-as-inv-number)
        inv_str = str(inv_raw).strip() if inv_raw else ""
        if is_invalid_inv_number(inv_str):
            stats["inv_cleared"] += 1
            inv_raw = ""

        # Fix serial
        if is_invalid_serial(serial) or is_generic_serial(serial):
            stats["serial_cleared"] += 1
            serial = ""

        # Fix corrupted data (HTML tags in serial/name)
        if '<br' in serial or '<br' in name:
            serial = re.sub(r'<[^>]+>', '', serial)
            serial = re.sub(r"for 'Field.*$", '', serial)
            serial = serial.strip().rstrip("'")
            if is_generic_serial(serial):
                serial = ""
            stats["serial_cleared"] += 1

        # Clean name
        orig_name = name
        name = clean_name(name)
        if name != orig_name:
            stats["name_cleaned"] += 1

        # Classify
        ci_type, ci_subtype = classify(name)
        key = f"{ci_type}/{ci_subtype}"
        stats["type_classified"][key] = stats["type_classified"].get(key, 0) + 1

        out_ws.cell(out_r, 1, uid)
        out_ws.cell(out_r, 2, out_r - 1)
        out_ws.cell(out_r, 3, name)
        out_ws.cell(out_r, 4, inv_raw)
        out_ws.cell(out_r, 5, serial if serial else "")
        out_ws.cell(out_r, 6, location)
        out_ws.cell(out_r, 7, status)
        out_ws.cell(out_r, 8, card_no)
        out_ws.cell(out_r, 9, date_in)
        out_ws.cell(out_r, 10, branch)
        out_ws.cell(out_r, 11, ci_type)
        out_ws.cell(out_r, 12, ci_subtype)
        out_r += 1

    # Auto-width
    col_widths = {}
    for row in out_ws.iter_rows(min_row=1, max_row=min(out_ws.max_row, 200), values_only=True):
        for c, val in enumerate(row):
            length = len(str(val)) if val else 0
            col_widths[c] = max(col_widths.get(c, 0), min(length + 4, 60))
    for c, w in col_widths.items():
        out_ws.column_dimensions[get_column_letter(c + 1)].width = w

    out_ws.freeze_panes = "B2"
    out_ws.auto_filter.ref = f"A1:{get_column_letter(len(OUT_COLS))}{out_ws.max_row}"

    out_wb.save(DST)
    print(f"Готово: {DST}")
    print(f"Всего строк: {stats['total']}")
    print(f"Очищено невалидных сер. номеров: {stats['serial_cleared']}")
    print(f"Очищено невалидных инв. номеров: {stats['inv_cleared']}")
    print(f"Очищено хвостового мусора из имён: {stats['name_cleaned']}")
    print(f"\nРаспределение типов/подтипов:")
    for k, v in sorted(stats["type_classified"].items(), key=lambda x: -x[1]):
        print(f"  {v:>5}  {k}")


if __name__ == "__main__":
    main()
