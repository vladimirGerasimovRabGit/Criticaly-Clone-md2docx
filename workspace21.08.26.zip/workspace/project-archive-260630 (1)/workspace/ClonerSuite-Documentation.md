# ClonerSuite — Руководство по развёртыванию и эксплуатации

## Содержание

1. [Общая информация](#1-общая-информация)
2. [Требования к системе](#2-требования-к-системе)
3. [Архитектура системы](#3-архитектура-системы)
4. [Установка и настройка](#4-установка-и-настройка)
5. [Настройка HTTPS](#5-настройка-https)
6. [Шифрование API-ключа](#6-шифрование-api-ключа)
7. [Развёртывание в IIS](#7-развёртывание-в-iis)
8. [Диагностика и мониторинг](#8-диагностика-и-мониторинг)
9. [Решение проблем](#9-решение-проблем)

---

## 1. Общая информация

**ClonerSuite** — это комплекс из двух микросервисов для работы с системой HEAT (BMC Remedyforce):

| Сервис | Описание | Порты (HTTP/HTTPS) |
|--------|----------|-------------------|
| **Criticality** | Синхронизация критичности CI | 7102 / 7103 |
| **ServiceReqCloner** | Клонирование заявок и инцидентов | 7101 / 7104 |

---

## 2. Требования к системе

### Минимальные требования
- **ОС**: Windows Server 2016 / Windows 10 или новее
- **.NET**: .NET 8 Runtime (если не используется self-contained версия)
- **RAM**: 512 MB на каждый сервис
- **CPU**: 1 ядро на сервис

### Для работы с HEAT API
- Доступ к серверу HEAT по HTTPS
- API-ключ HEAT (REST API Key)
- Права на чтение/запись CI и заявок

### Для развёртывания в IIS
- IIS 10.0+
- Модули: **URL Rewrite**, **Application Request Routing (ARR)**
- SSL-сертификат (самоподписанный или доверенный)

---

## 3. Архитектура системы

```
┌─────────────────────────────────────────────────────────┐
│                      IIS (HTTPS 443)                     │
│                   SSL Termination                        │
└─────────────────────────────────────────────────────────┘
                            │
            ┌───────────────┴───────────────┐
            │                               │
            ▼                               ▼
┌───────────────────────┐       ┌───────────────────────┐
│   Criticality         │       │   ServiceReqCloner    │
│   Порт: 7102          │       │   Порт: 7101          │
│   (фоновая синхр.)    │       │   (клониение)         │
└───────────────────────┘       └───────────────────────┘
            │                               │
            └───────────────┬───────────────┘
                            ▼
                ┌───────────────────────┐
                │   HEAT API Server     │
                │   https://svoivantisrv │
                └───────────────────────┘
```

---

## 4. Установка и настройка

### 4.1 Подготовка файлов

1. Скопируйте папки сервисов на целевой сервер:
   ```
   C:\ClonerSuite\
   ├── Criticality\
   │   └── publish-standalone\
   ├── ServiceReqCloner\
   │   └── publish-standalone\
   └── tools\
       └── ApiKeyEncryptor\
   ```

### 4.2 Конфигурация Criticality

Откройте файл `C:\ClonerSuite\Criticality\publish-standalone\appsettings.json`:

```json
{
  "HeatApi": {
    "BaseUrl": "https://svoivantisrv/HEAT/api",
    "ApiKey": "",
    "EncryptedApiKey": "<ВАШ_ЗАШИФРОВАННЫЙ_КЛЮЧ>",
    "EncryptionKey": "<ВАШ_ПАРОЛЬ>",
    "TimeoutSeconds": 60,
    "SkipCertificateValidation": true,
    "RequireWebServer": false
  },
  "Server": {
    "Port": 7102,
    "UseHttps": true,
    "HttpsPort": 7103,
    "CertificateThumbprint": "<ОТПЕЧАТОК_СЕРТИФИКАТА>"
  },
  "CriticalitySync": {
    "InheritanceTypes": [
      "XER_Criticality",
      "XER_Kritichnost"
    ],
    "BackgroundSyncIntervalMinutes": 15,
    "BatchSize": 200,
    "CiPageSize": 100,
    "RelationsChunkSize": 20,
    "MaxParentDepth": 50
  }
}
```

### 4.3 Конфигурация ServiceReqCloner

Откройте файл `C:\ClonerSuite\ServiceReqCloner\publish-standalone\appsettings.json`:

```json
{
  "HeatApi": {
    "BaseUrl": "https://svoivantisrv/HEAT/api",
    "ApiKey": "",
    "EncryptedApiKey": "<ВАШ_ЗАШИФРОВАННЫЙ_КЛЮЧ>",
    "EncryptionKey": "<ВАШ_ПАРОЛЬ>",
    "TimeoutSeconds": 60,
    "SkipCertificateValidation": true,
    "RequireWebServer": false
  },
  "Server": {
    "Port": 7101,
    "UseHttps": true,
    "HttpsPort": 7104,
    "CertificateThumbprint": "<ОТПЕЧАТОК_СЕРТИФИКАТА>"
  }
}
```

### 4.4 Запуск сервисов

Откройте два отдельных окна PowerShell или CMD:

**Окно 1 — Criticality:**
```cmd
cd C:\ClonerSuite\Criticality\publish-standalone
Criticality.exe
```

**Окно 2 — ServiceReqCloner:**
```cmd
cd C:\ClonerSuite\ServiceReqCloner\publish-standalone
ServiceReqCloner.exe
```

---

## 5. Настройка HTTPS

### 5.1 Получение отпечатка сертификата

Выполните в PowerShell:
```powershell
Get-ChildItem Cert:\LocalMachine\My | Select-Object Thumbprint, Subject, NotAfter
```

Найдите нужный сертификат и скопируйте значение `Thumbprint` (без пробелов).

### 5.2 Если сертификат неэкспортируемый

Используйте существующий сертификат из хранилища, указав его `CertificateThumbprint` в `appsettings.json`.

### 5.3 Если нужен новый сертификат

```powershell
# Создать самоподписанный сертификат
New-SelfSignedCertificate -DnsName "svoivantisrv.svo.air.loc","localhost" `
    -CertStoreLocation Cert:\LocalMachine\My `
    -NotAfter (Get-Date).AddYears(10)

# Экспортировать в файл (если нужно)
$pwd = ConvertTo-SecureString -String "MyPassword123" -Force -AsPlainText
Export-PfxCertificate -Cert "Cert:\LocalMachine\My\<THUMBPRINT>" `
    -FilePath "C:\ClonerSuite\cert.pfx" -Password $pwd
```

---

## 6. Шифрование API-ключа

### 6.1 Использование утилиты ApiKeyEncryptor

```cmd
cd C:\ClonerSuite\tools\ApiKeyEncryptor\publish
ApiKeyEncryptor.exe "<ВАШ_API_КЛЮЧ>" "<ПАРОЛЬ_ДЛЯ_ШИФРОВАНИЯ>"
```

**Пример:**
```cmd
ApiKeyEncryptor.exe "1404A984C43F48C88749CF8C1C14B40A" "MySecretKey2024!"
```

**Результат:**
```
Encrypted Key:
8owtwbON81PUPSx0qf+FFi0J4wiRNZDbVua1AM5nglV3IU5SU8aVJUG9QThwHxgL...

Usage in appsettings.json:
"EncryptedApiKey": "8owtwbON81PUPSx0qf+FFi0J4wiRNZDbVua1AM5nglV3IU5SU8aVJUG9QThwHxgL...",
"EncryptionKey": "MySecretKey2024!"
```

### 6.2 Применение зашифрованного ключа

Вставьте полученные значения в `appsettings.json` обоих сервисов:

```json
"HeatApi": {
  "EncryptedApiKey": "8owtwbON81PUPSx0qf+FFi0J4wiRNZDbVua1AM5nglV3IU5SU8aVJUG9QThwHxgL...",
  "EncryptionKey": "MySecretKey2024!"
}
```

---

## 7. Развёртывание в IIS

### 7.1 Подготовка

1. Установите модули IIS:
   - **URL Rewrite Module 2**
   - **Application Request Routing (ARR) 3**

2. Остановите запущенные сервисы (если работают как `.exe`)

### 7.2 Скрипт настройки IIS

Создайте файл `Setup-IIS-Proxy.ps1`:

```powershell
<#
.SYNOPSIS
    Настраивает IIS как Reverse Proxy для ClonerSuite
#>
[CmdletBinding()]
param(
    [string]$Thumbprint = "D772E9F0E8628B3702B5C5D1C30227FE438521EB",
    [string]$SiteName = "Default Web Site"
)

$ErrorActionPreference = "Stop"
Import-Module WebAdministration

Write-Host "Enabling ARR Proxy..." -ForegroundColor Cyan
Set-WebConfigurationProperty -Filter "system.webServer/proxy" -Name "enabled" -Value "true" -PSPath "IIS:\"

Write-Host "Configuring URL Rewrite rules..." -ForegroundColor Cyan
$configPath = "C:\inetpub\wwwroot\web.config"
$backupPath = "$configPath.backup.$(Get-Date -Format 'yyyyMMddHHmmss')"

if (Test-Path $configPath) {
    Copy-Item $configPath $backupPath -Force
}

$xmlContent = @"
<?xml version="1.0" encoding="UTF-8"?>
<configuration>
    <system.webServer>
        <rewrite>
            <rules>
                <rule name="ProxyCriticality" stopProcessing="true">
                    <match url="^Criticality/(.*)" />
                    <action type="Rewrite" url="http://localhost:7102/{R:1}" />
                </rule>
                <rule name="ProxyServiceReq" stopProcessing="true">
                    <match url="^ServiceReq/(.*)" />
                    <action type="Rewrite" url="http://localhost:7101/{R:1}" />
                </rule>
            </rules>
        </rewrite>
    </system.webServer>
</configuration>
"@

$xmlContent | Out-File -FilePath $configPath -Encoding utf8

Write-Host "Binding HTTPS Certificate..." -ForegroundColor Cyan
$binding = Get-WebBinding -Name $SiteName -Protocol "https" -Port 443 -ErrorAction SilentlyContinue
if ($binding) { $binding | Remove-WebBinding }

New-WebBinding -Name $SiteName -Protocol "https" -Port 443 -IPAddress "*" `
    -CertificateThumbPrint $Thumbprint -CertStoreLocation "Cert:\LocalMachine\My" -Force

Restart-WebItem "IIS:\Sites\$SiteName"

Write-Host "Готово!" -ForegroundColor Green
Write-Host "Criticality:  https://localhost/Criticality/api/CriticalitySync/status"
Write-Host "ServiceReq:   https://localhost/ServiceReq/api/ServiceReqClone/clone-with-view?id=..."
```

### 7.3 Запуск скрипта

```powershell
# От имени Администратора
powershell -ExecutionPolicy Bypass -File C:\ClonerSuite\Setup-IIS-Proxy.ps1
```

### 7.4 Проверка работы

Откройте в браузере:
- **Criticality**: `https://svoivantisrv.svo.air.loc/Criticality/api/CriticalitySync/status`
- **ServiceReq**: `https://svoivantisrv.svo.air.loc/ServiceReq/api/IncidentClone/next-number`

---

## 8. Диагностика и мониторинг

### 8.1 Endpoints для проверки

| Сервис | Endpoint | Метод | Описание |
|--------|---------|-------|----------|
| Criticality | `/api/CriticalitySync/status` | GET | Статус синхронизации |
| Criticality | `/api/CriticalitySync/start` | POST | Запуск синхронизации |
| Criticality | `/api/CriticalitySync/reset` | POST | Сброс состояния |
| ServiceReq | `/api/IncidentClone/next-number` | GET | Следующий номер заявки |
| ServiceReq | `/api/diagnostic/memory` | GET | Информация о памяти |
| ServiceReq | `/api/diagnostic/ci/{id}` | GET | Проверка CI в HEAT |

### 8.2 PowerShell команды для проверки

```powershell
# Включить TLS 1.2
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

# Игнорировать ошибки сертификатов
[System.Net.ServicePointManager]::ServerCertificateValidationCallback = { $true }

# Проверка Criticality
Invoke-RestMethod -Uri "http://127.0.0.1:7102/api/CriticalitySync/status"

# Проверка ServiceReq
Invoke-RestMethod -Uri "http://127.0.0.1:7101/api/IncidentClone/next-number"

# Сброс синхронизации
Invoke-RestMethod -Uri "http://127.0.0.1:7102/api/CriticalitySync/reset" -Method Post

# Запуск синхронизации
Invoke-RestMethod -Uri "http://127.0.0.1:7102/api/CriticalitySync/start" -Method Post
```

### 8.3 Просмотр логов

Логи находятся в папках:
- `C:\ClonerSuite\Criticality\publish-standalone\logs\app-ГГГГММДД.log`
- `C:\ClonerSuite\ServiceReqCloner\publish-standalone\logs\app-ГГГГММДД.log`

---

## 9. Решение проблем

### 9.1 Ошибка `Unauthorized (ISM_4001)`

**Причина**: API-ключ не расшифровывается или не настроен.

**Решение**:
1. Проверьте, что `EncryptedApiKey` и `EncryptionKey` заполнены в `appsettings.json`
2. Убедитесь, что ключ зашифрован правильной утилитой (совпадающей с `EncryptionService`)
3. Перезапустите сервис

### 9.2 Ошибка `Certificate validation is DISABLED`

**Это предупреждение, а не ошибка**. Оно означает, что проверка SSL-сертификата HEAT отключена (настроено в `appsettings.json`).

Для продакшена рекомендуется:
- Установить `"SkipCertificateValidation": false`
- Импортировать корневой сертификат HEAT в доверенные

### 9.3 Ошибка `Address already in use`

**Причина**: Порт уже занят другим процессом.

**Решение**:
1. Найдите процесс: `netstat -ano | findstr :7102`
2. Освободите порт или измените порт в `appsettings.json`

### 9.4 Ошибка `NET::ERR_CERT_AUTHORITY_INVALID` в браузере

**Причина**: Браузер не доверяет самоподписанному сертификату.

**Решение**:
1. Нажмите **"Дополнительно"** → **"Перейти на сайт"**
2. Или импортируйте сертификат в доверенные корневые центры

### 9.5 Ошибка `Access denied. This endpoint is only available from localhost`

**Причина**: Включена защита `LocalhostOnlyMiddleware`.

**Решение**:
- Обращайтесь к сервису через `localhost` или `127.0.0.1`
- Или отключите middleware в `Program.cs` для доступа извне

### 9.6 Синхронизация не запускается

**Причина**: Статус показывает `Batch already completed`.

**Решение**:
```powershell
# Сбросить состояние
Invoke-RestMethod -Uri "http://127.0.0.1:7102/api/CriticalitySync/reset" -Method Post
```

---

## Приложения

### A. Порты по умолчанию

| Сервис | HTTP | HTTPS | Описание |
|--------|------|-------|----------|
| Criticality | 7102 | 7103 | Синхронизация критичности |
| ServiceReqCloner | 7101 | 7104 | Клонирование заявок |
| IIS (Reverse Proxy) | 80 | 443 | Шлюз для обоих сервисов |

### B. Структура каталогов

```
C:\ClonerSuite\
├── Criticality\
│   └── publish-standalone\
│       ├── Criticality.exe
│       ├── appsettings.json
│       ├── logs\
│       └── wwwroot\ (опционально)
├── ServiceReqCloner\
│   └── publish-standalone\
│       ├── ServiceReqCloner.exe
│       ├── appsettings.json
│       ├── logs\
│       └── wwwroot\
└── tools\
    └── ApiKeyEncryptor\
        └── publish\
            └── ApiKeyEncryptor.exe
```

### C. Контрольный список развёртывания

- [ ] Сертификат установлен в хранилище `LocalMachine\My`
- [ ] Отпечаток сертификата добавлен в `appsettings.json`
- [ ] API-ключ зашифрован и добавлен в конфиг
- [ ] Порты не конфликтуют с другими сервисами
- [ ] IIS настроен (если используется)
- [ ] Модули URL Rewrite и ARR установлены
- [ ] Брандмауэр открывает нужные порты
- [ ] Сервисы запущены и логи чистые

---

**Версия документа**: 1.0  
**Дата**: 2026-05-27  
**Контакт**: Команда разработки ClonerSuite
