<#
.SYNOPSIS
    Encrypts an API key for secure storage in appsettings.json.
.DESCRIPTION
    Uses AES-256 encryption to encrypt the Heat API key. The encrypted
    value can be stored in appsettings.json (HeatApi:EncryptedApiKey)
    and decrypted at runtime by EncryptionService.
.PARAMETER PlainKey
    The plain text API key to encrypt.
.PARAMETER Password
    The encryption password (store securely, not in source control!).
.PARAMETER OutputFormat
    Output format: 'Base64' (default) or 'Hex'.
.EXAMPLE
    .\encrypt-apikey.ps1 -PlainKey "my-secret-key" -Password "MySecretKey2024!Secure"
.EXAMPLE
    .\encrypt-apikey.ps1 -PlainKey $env:HEAT_API_KEY -Password $env:ENCRYPTION_PASSWORD
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)]
    [string]$PlainKey,
    
    [Parameter(Mandatory=$true)]
    [string]$Password,
    
    [ValidateSet('Base64', 'Hex')]
    [string]$OutputFormat = 'Base64'
)

$ErrorActionPreference = "Stop"

Write-Host ""
Write-Host "=============================================" -ForegroundColor Cyan
Write-Host " API Key Encryption Tool" -ForegroundColor Cyan
Write-Host "=============================================" -ForegroundColor Cyan
Write-Host ""

# Validate input
if ([string]::IsNullOrWhiteSpace($PlainKey)) {
    Write-Host "ERROR: PlainKey cannot be empty" -ForegroundColor Red
    exit 1
}

if ([string]::IsNullOrWhiteSpace($Password)) {
    Write-Host "ERROR: Password cannot be empty" -ForegroundColor Red
    exit 1
}

if ($Password.Length -lt 16) {
    Write-Host "WARNING: Password is short (less than 16 characters). Consider using a stronger password." -ForegroundColor Yellow
}

try {
    # Create encryption key from password (SHA256 hash = 32 bytes = 256 bits)
    $sha256 = [System.Security.Cryptography.SHA256]::Create()
    $keyBytes = $sha256.ComputeHash([System.Text.Encoding]::UTF8.GetBytes($Password))
    
    # Generate random IV (16 bytes for AES)
    $aes = [System.Security.Cryptography.Aes]::Create()
    $aes.Key = $keyBytes
    $aes.GenerateIV()
    $ivBytes = $aes.IV
    
    # Encrypt
    $encryptor = $aes.CreateEncryptor($aes.Key, $ivBytes)
    $plainBytes = [System.Text.Encoding]::UTF8.GetBytes($PlainKey)
    $encryptedBytes = $encryptor.TransformFinalBlock($plainBytes, 0, $plainBytes.Length)
    
    # Combine IV + encrypted data (IV is needed for decryption)
    $combined = New-Object byte[] ($ivBytes.Length + $encryptedBytes.Length)
    [System.Buffer]::BlockCopy($ivBytes, 0, $combined, 0, $ivBytes.Length)
    [System.Buffer]::BlockCopy($encryptedBytes, 0, $combined, $ivBytes.Length, $encryptedBytes.Length)
    
    # Output
    if ($OutputFormat -eq 'Hex') {
        $encryptedOutput = [System.BitConverter]::ToString($combined).Replace('-', '').ToLower()
    } else {
        $encryptedOutput = [System.Convert]::ToBase64String($combined)
    }
    
    Write-Host "Encrypted Key:" -ForegroundColor Green
    Write-Host ""
    Write-Host $encryptedOutput -ForegroundColor White
    Write-Host ""
    Write-Host "=============================================" -ForegroundColor Cyan
    Write-Host "Usage in appsettings.json:" -ForegroundColor Cyan
    Write-Host "=============================================" -ForegroundColor Cyan
    Write-Host ""
    Write-Host `"EncryptedApiKey`": `"$encryptedOutput`"," -ForegroundColor Gray
    Write-Host `"EncryptionKey`": `"$Password`"" -ForegroundColor Gray
    Write-Host ""
    Write-Host "IMPORTANT:" -ForegroundColor Red
    Write-Host "  - Store EncryptionKey securely (environment variable, secret manager)"
    Write-Host "  - Do NOT commit EncryptionKey to source control"
    Write-Host "  - EncryptedApiKey CAN be committed (it's encrypted)"
    Write-Host ""
    
} catch {
    Write-Host "ERROR: Encryption failed" -ForegroundColor Red
    Write-Host $_.Exception.Message -ForegroundColor Red
    exit 1
}
