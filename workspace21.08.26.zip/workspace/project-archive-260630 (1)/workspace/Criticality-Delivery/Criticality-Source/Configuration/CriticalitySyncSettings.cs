namespace Criticality.Configuration;

public class CriticalitySyncSettings
{
    public const string SectionName = "CriticalitySync";
    
    public List<string> InheritanceTypes { get; set; } = new();
    public int BackgroundSyncIntervalMinutes { get; set; } = 5;
    public int BatchSize { get; set; } = 200;
    public int CiPageSize { get; set; } = 100;
    public int RelationsChunkSize { get; set; } = 20;
    public int MaxParentDepth { get; set; } = 50;
    public int RelationsPageSize { get; set; } = 100;
}
