using System.Text.Json.Serialization;

namespace Criticality.Models;

public class BatchState
{
    public string LastProcessedRecId { get; set; } = string.Empty;
    public bool IsCompleted { get; set; }
    public DateTime LastRunTime { get; set; }
}
