using System.Text.Json.Serialization;
using Criticality.Converters;

namespace Criticality.Models;

public class Criticality
{
    [JsonPropertyName("RecId")]
    public string RecId { get; set; } = string.Empty;

    [JsonPropertyName("XER_SortOrder")]
    [JsonConverter(typeof(IntJsonConverter))]
    public int? XER_SortOrder { get; set; }
}
