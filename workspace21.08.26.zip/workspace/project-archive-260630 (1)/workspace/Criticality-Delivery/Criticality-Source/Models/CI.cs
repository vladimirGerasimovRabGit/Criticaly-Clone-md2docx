using System.Text.Json.Serialization;
using Criticality.Converters;

namespace Criticality.Models;

public class CI
{
    [JsonPropertyName("RecId")]
    public string RecId { get; set; } = string.Empty;

    [JsonPropertyName("CIType")]
    public string CIType { get; set; } = string.Empty;

    [JsonPropertyName("Name")]
    public string? Name { get; set; }

    [JsonPropertyName("TRN_KritichnostKE_Valid")]
    public string? TRN_KritichnostKE_Valid { get; set; }

    [JsonPropertyName("XER_CSI_Valid")]
    [JsonConverter(typeof(StringJsonConverter))]
    public string? XER_CSI_Valid { get; set; }

    [JsonPropertyName("TargetAvailability")]
    [JsonConverter(typeof(StringJsonConverter))]
    public string? TargetAvailability { get; set; }

    [JsonPropertyName("LastChangeDateTime")]
    [JsonConverter(typeof(DateTimeJsonConverter))]
    public DateTime? LastChangeDateTime { get; set; }
}
