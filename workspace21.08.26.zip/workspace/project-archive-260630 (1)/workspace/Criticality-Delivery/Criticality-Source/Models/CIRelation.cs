using System.Text.Json.Serialization;

namespace Criticality.Models;

public class CIRelation
{
    [JsonPropertyName("RecId")]
    public string RecId { get; set; } = string.Empty;

    [JsonPropertyName("SourceID")]
    public string SourceID { get; set; } = string.Empty;

    [JsonPropertyName("TargetID")]
    public string TargetID { get; set; } = string.Empty;
}
