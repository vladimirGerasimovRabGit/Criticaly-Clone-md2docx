namespace Criticality.Models;

public class RelationsPage
{
    public List<CIRelation> Items { get; set; } = new();
    public string? NextState { get; set; }
}
