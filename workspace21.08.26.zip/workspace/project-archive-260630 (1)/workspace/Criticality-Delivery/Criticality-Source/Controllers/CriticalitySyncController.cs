using Microsoft.AspNetCore.Mvc;
using Criticality.Services;

namespace Criticality.Controllers;

[ApiController]
[Route("api/[controller]")]
public class CriticalitySyncController : ControllerBase
{
    private readonly ICriticalitySyncService _syncService;

    public CriticalitySyncController(ICriticalitySyncService syncService)
    {
        _syncService = syncService;
    }

    [HttpPost("start")]
    [HttpGet("start")]
    public async Task<ActionResult> StartSync()
    {
        var result = await _syncService.RunSyncAsync();
        if (!result.Success) return BadRequest(result);
        return Ok(result);
    }

    [HttpGet("status")]
    public async Task<ActionResult> GetStatus()
    {
        var state = await _syncService.GetStatusAsync();
        return Ok(new
        {
            state.LastProcessedRecId,
            state.IsCompleted,
            state.LastRunTime
        });
    }

    [HttpPost("reset")]
    public async Task<IActionResult> Reset()
    {
        await _syncService.ResetAsync();
        return Ok(new { message = "Batch state reset." });
    }
}
