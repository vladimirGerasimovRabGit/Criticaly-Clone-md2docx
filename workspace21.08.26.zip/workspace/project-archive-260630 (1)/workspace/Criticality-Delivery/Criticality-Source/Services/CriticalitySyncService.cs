using System.Text.Json;
using Microsoft.Extensions.Options;
using Polly;
using Criticality.Configuration;
using Criticality.Models;

namespace Criticality.Services;

public class CriticalitySyncService : ICriticalitySyncService
{
    private readonly IHeatApiService _heatApiService;
    private readonly IBatchStateManager _batchStateManager;
    private readonly ILogger<CriticalitySyncService> _logger;
    private readonly CriticalitySyncSettings _syncSettings;

    private const string InformationSystemType = "InformationSystem";
    private const string ServiceType = "Service";

    public CriticalitySyncService(
        IHeatApiService heatApiService,
        IBatchStateManager batchStateManager,
        ILogger<CriticalitySyncService> logger,
        IOptions<CriticalitySyncSettings> syncSettings)
    {
        _heatApiService = heatApiService;
        _batchStateManager = batchStateManager;
        _logger = logger;
        _syncSettings = syncSettings.Value;
    }

    private string[] GetAllowedTypes() =>
        new[] { ServiceType }.Concat(_syncSettings.InheritanceTypes).ToArray();

    public async Task<BatchState> GetStatusAsync(CancellationToken cancellationToken = default)
    {
        return await _batchStateManager.LoadStateAsync(cancellationToken);
    }

    public async Task<SyncResult> RunSyncAsync(CancellationToken cancellationToken = default)
    {
        var result = new SyncResult();
        var stopwatch = System.Diagnostics.Stopwatch.StartNew();

        try
        {
            _logger.LogInformation("Starting criticality sync batch...");

            var state = await _batchStateManager.LoadStateAsync(cancellationToken);
            if (state.IsCompleted)
            {
                result.Message = "Batch already completed. Reset to start over.";
                return result;
            }

            var uniqueRecIds = await BuildUniqueCiRecIdsAsync(cancellationToken);
            _logger.LogInformation("Unique CI RecIds from relations: {Count}", uniqueRecIds.Count);

            var parentsGraph = await BuildParentsGraphAsync(cancellationToken);

            var ciCache = new Dictionary<string, CI>();
            var sortOrderCache = new Dictionary<string, int?>();

            var allowedTypes = GetAllowedTypes();
            var idsToProcess = uniqueRecIds
                .Where(id => string.Compare(id, state.LastProcessedRecId) > 0)
                .OrderBy(id => id)
                .Take(_syncSettings.BatchSize)
                .ToList();

            _logger.LogInformation("Processing batch of {Count} CIs", idsToProcess.Count);

            foreach (var recId in idsToProcess)
            {
                cancellationToken.ThrowIfCancellationRequested();
                try
                {
                    if (!ciCache.TryGetValue(recId, out var ci))
                    {
                        ci = await _heatApiService.GetCIAsync(recId, cancellationToken);
                        if (ci != null)
                            ciCache[recId] = ci;
                    }

                    if (ci == null)
                    {
                        _logger.LogWarning("CI {RecId} not found, skipping", recId);
                        state.LastProcessedRecId = recId;
                        await _batchStateManager.SaveStateAsync(state, cancellationToken);
                        continue;
                    }

                    if (!allowedTypes.Contains(ci.CIType))
                    {
                        _logger.LogDebug("CI {RecId} has type {CIType}, not in allowed list, skipping", recId, ci.CIType);
                        state.LastProcessedRecId = recId;
                        await _batchStateManager.SaveStateAsync(state, cancellationToken);
                        continue;
                    }

                    await ProcessSingleCI(ci, parentsGraph, ciCache, sortOrderCache, cancellationToken);
                    result.ProcessedCount++;
                    state.LastProcessedRecId = recId;
                    await _batchStateManager.SaveStateAsync(state, cancellationToken);
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Error processing CI {RecId}. Stopping.", recId);
                    await _batchStateManager.SaveStateAsync(state, cancellationToken);
                    throw;
                }
            }

            if (idsToProcess.Count < _syncSettings.BatchSize)
            {
                state.IsCompleted = true;
                result.IsCompleted = true;
            }

            state.LastRunTime = DateTime.UtcNow;
            await _batchStateManager.SaveStateAsync(state, cancellationToken);

            stopwatch.Stop();
            result.Success = true;
            result.Message = $"Processed {result.ProcessedCount} CIs.";
            result.LastProcessedRecId = state.LastProcessedRecId;
            result.ElapsedTime = stopwatch.Elapsed;

            _logger.LogInformation("Sync batch finished. Processed: {Count}, Completed: {Completed}", result.ProcessedCount, state.IsCompleted);
            return result;
        }
        catch (Exception ex)
        {
            stopwatch.Stop();
            _logger.LogError(ex, "Critical error during sync");
            result.Message = $"Error: {ex.Message}";
            result.ElapsedTime = stopwatch.Elapsed;
            return result;
        }
    }

    public async Task ResetAsync(CancellationToken cancellationToken = default)
    {
        _batchStateManager.ResetState();
        await Task.CompletedTask;
    }

    private async Task<HashSet<string>> BuildUniqueCiRecIdsAsync(CancellationToken cancellationToken)
    {
        var uniqueRecIds = new HashSet<string>();
        var pageState = default(string);

        do
        {
            var page = await _heatApiService.GetRelationsPageAsync(_syncSettings.RelationsPageSize, pageState, cancellationToken);
            
            foreach (var rel in page.Items)
            {
                if (!string.IsNullOrEmpty(rel.SourceID))
                    uniqueRecIds.Add(rel.SourceID);
                if (!string.IsNullOrEmpty(rel.TargetID))
                    uniqueRecIds.Add(rel.TargetID);
            }

            pageState = page.NextState;
            _logger.LogDebug("Loaded relations page. Total unique RecIds so far: {Count}", uniqueRecIds.Count);
        }
        while (pageState != null);

        return uniqueRecIds;
    }

    private async Task<Dictionary<string, List<string>>> BuildParentsGraphAsync(CancellationToken cancellationToken)
    {
        var parentsGraph = new Dictionary<string, List<string>>();
        var pageState = default(string);

        do
        {
            var page = await _heatApiService.GetRelationsPageAsync(_syncSettings.RelationsPageSize, pageState, cancellationToken);
            
            foreach (var rel in page.Items)
            {
                if (!string.IsNullOrEmpty(rel.TargetID) && !string.IsNullOrEmpty(rel.SourceID))
                {
                    if (!parentsGraph.TryGetValue(rel.TargetID, out var sources))
                    {
                        sources = new List<string>();
                        parentsGraph[rel.TargetID] = sources;
                    }
                    sources.Add(rel.SourceID);
                }
            }

            pageState = page.NextState;
        }
        while (pageState != null);

        _logger.LogInformation("Built parents graph with {Count} entries", parentsGraph.Count);
        return parentsGraph;
    }

    private async Task ProcessSingleCI(
        CI ci,
        Dictionary<string, List<string>> parentsGraph,
        Dictionary<string, CI> ciCache,
        Dictionary<string, int?> sortOrderCache,
        CancellationToken cancellationToken)
    {
        string? newCriticality = null;
        string? newCsi = null;
        string? newAvailability = null;

        if (ci.CIType == InformationSystemType)
        {
            // only date update
        }
        else if (ci.CIType == ServiceType)
        {
            var best = await FindBestParentCriticality(ci.RecId, [InformationSystemType], parentsGraph, ciCache, sortOrderCache, cancellationToken);
            newCriticality = best.criticalityRecId;
            newCsi = best.csiId;
            newAvailability = best.targetAvailability;
        }
        else if (_syncSettings.InheritanceTypes.Contains(ci.CIType))
        {
            var best = await FindBestParentCriticality(ci.RecId, [InformationSystemType, ServiceType], parentsGraph, ciCache, sortOrderCache, cancellationToken);
            newCriticality = best.criticalityRecId;
            newCsi = best.csiId;
            newAvailability = best.targetAvailability;
        }

        var updates = new Dictionary<string, object>();
        if (newCriticality != null && newCriticality != ci.TRN_KritichnostKE_Valid)
            updates["TRN_KritichnostKE_Valid"] = newCriticality;
        if (newCsi != null && newCsi != ci.XER_CSI_Valid)
            updates["XER_CSI_Valid"] = newCsi;
        if (newAvailability != null && newAvailability != ci.TargetAvailability)
            updates["TargetAvailability"] = newAvailability;

        updates["LastChangeDateTime"] = DateTime.UtcNow;

        if (updates.Count > 0)
            await _heatApiService.UpdateCIAsync(ci.RecId, updates, cancellationToken);
    }

    private async Task<(string? criticalityRecId, string? csiId, string? targetAvailability)>
        FindBestParentCriticality(
            string startRecId,
            string[] allowedParentTypes,
            Dictionary<string, List<string>> parentsGraph,
            Dictionary<string, CI> ciCache,
            Dictionary<string, int?> sortOrderCache,
            CancellationToken cancellationToken)
    {
        string? bestCrit = null, bestCsi = null, bestAvail = null;
        int bestSort = int.MaxValue;

        var visited = new HashSet<string>();
        var queue = new Queue<(string recId, int depth)>();
        queue.Enqueue((startRecId, 0));

        while (queue.Count > 0)
        {
            var (currentId, depth) = queue.Dequeue();
            if (depth > _syncSettings.MaxParentDepth) continue;
            if (!visited.Add(currentId)) continue;

            if (parentsGraph.TryGetValue(currentId, out var parentIds))
            {
                foreach (var parentId in parentIds)
                {
                    if (!ciCache.TryGetValue(parentId, out var parentCI))
                    {
                        parentCI = await _heatApiService.GetCIAsync(parentId, cancellationToken);
                        if (parentCI != null)
                            ciCache[parentId] = parentCI;
                    }

                    if (parentCI == null) continue;
                    if (!allowedParentTypes.Contains(parentCI.CIType)) continue;

                    var critId = parentCI.TRN_KritichnostKE_Valid;
                    if (!string.IsNullOrEmpty(critId))
                    {
                        if (!sortOrderCache.TryGetValue(critId, out var sortOrder))
                        {
                            sortOrder = await _heatApiService.GetCriticalitySortOrderAsync(critId, cancellationToken);
                            sortOrderCache[critId] = sortOrder;
                        }
                        if (sortOrder.HasValue && sortOrder.Value < bestSort)
                        {
                            bestSort = sortOrder.Value;
                            bestCrit = critId;
                            bestCsi = parentCI.XER_CSI_Valid;
                            bestAvail = parentCI.TargetAvailability;
                        }
                    }
                    queue.Enqueue((parentId, depth + 1));
                }
            }
        }
        return (bestCrit, bestCsi, bestAvail);
    }
}
