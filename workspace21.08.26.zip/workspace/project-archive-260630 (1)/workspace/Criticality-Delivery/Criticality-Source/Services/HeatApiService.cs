using System.Net;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text;
using System.Text.Json;
using Microsoft.Extensions.Options;
using Polly;
using Polly.Retry;
using Criticality.Models;
using Criticality.Configuration;

namespace Criticality.Services;

public class HeatApiService : IHeatApiService
{
    private readonly HttpClient _httpClient;
    private readonly ILogger<HeatApiService> _logger;
    private readonly JsonSerializerOptions _jsonOptions;
    private readonly string? _apiKey;
    private readonly int _ciPageSize;
    private readonly int _relationsChunkSize;
    private readonly ResiliencePipeline<HttpResponseMessage> _httpRetryPipeline;

    public HeatApiService(
        IHttpClientFactory httpClientFactory,
        ILogger<HeatApiService> logger,
        IOptions<HeatApiSettings> settings,
        IOptions<CriticalitySyncSettings> syncSettings,
        IEncryptionService? encryptionService = null)
    {
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        
        if (settings?.Value == null)
            throw new ArgumentNullException(nameof(settings), "HeatApi settings are not configured");
        
        var config = settings.Value;
        
        if (string.IsNullOrEmpty(config.BaseUrl))
            throw new InvalidOperationException("BaseUrl is not configured in HeatApi settings");
        
        _apiKey = TryResolveApiKey(config, encryptionService);
        if (string.IsNullOrEmpty(_apiKey))
            _logger.LogWarning("No API key configured. API calls will fail. Configure HeatApi:ApiKey or HeatApi:EncryptedApiKey.");
        else
        _ciPageSize = syncSettings?.Value?.CiPageSize ?? 100;
        _relationsChunkSize = syncSettings?.Value?.RelationsChunkSize ?? 20;
        
        _logger.LogInformation("Initializing HeatApiService with BaseUrl: {BaseUrl}", config.BaseUrl);
        
        var handler = new HttpClientHandler { AllowAutoRedirect = true };

        if (config.SkipCertificateValidation)
        {
            _logger.LogWarning("Certificate validation is DISABLED. This should only be used in development environments.");
            handler.ServerCertificateCustomValidationCallback = (message, cert, chain, errors) => true;
        }
        
        _httpClient = new HttpClient(handler);
        _httpClient.BaseAddress = new Uri(config.BaseUrl.TrimEnd('/') + '/');
        _httpClient.Timeout = TimeSpan.FromSeconds(config.TimeoutSeconds);
        
        if (!string.IsNullOrEmpty(_apiKey))
        {
            _httpClient.DefaultRequestHeaders.TryAddWithoutValidation("Authorization", $"rest_api_key={_apiKey}");
        }
        _httpClient.DefaultRequestHeaders.Accept.Add(
            new MediaTypeWithQualityHeaderValue("application/json"));
        
        _jsonOptions = new JsonSerializerOptions
        {
            PropertyNameCaseInsensitive = true,
            PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
            DefaultIgnoreCondition = System.Text.Json.Serialization.JsonIgnoreCondition.WhenWritingNull
        };

        _httpRetryPipeline = new ResiliencePipelineBuilder<HttpResponseMessage>()
            .AddRetry(new RetryStrategyOptions<HttpResponseMessage>
            {
                MaxRetryAttempts = 3,
                Delay = TimeSpan.FromSeconds(2),
                BackoffType = DelayBackoffType.Exponential,
                ShouldHandle = args => ValueTask.FromResult(args.Outcome.Result is not { IsSuccessStatusCode: true }),
                OnRetry = args =>
                {
                    _logger.LogWarning("HTTP call failed (attempt {Attempt}), retrying in {Delay}s",
                        args.AttemptNumber, args.RetryDelay.TotalSeconds);
                    return default;
                }
            })
            .Build();
    }

    private static string? TryResolveApiKey(HeatApiSettings config, IEncryptionService? encryptionService)
    {
        if (!string.IsNullOrEmpty(config.ApiKey))
            return config.ApiKey;

        if (!string.IsNullOrEmpty(config.EncryptedApiKey))
        {
            if (encryptionService == null)
            {
                Console.WriteLine("WARNING: EncryptedApiKey configured but no IEncryptionService registered");
                return null;
            }

            var encryptionKey = config.EncryptionKey;
            if (string.IsNullOrEmpty(encryptionKey))
            {
                Console.WriteLine("WARNING: EncryptionKey not configured, cannot decrypt EncryptedApiKey");
                return null;
            }

            try
            {
                return encryptionService.Decrypt(config.EncryptedApiKey, encryptionKey);
            }
            catch
            {
                return null;
            }
        }

        return null;
    }

    public async Task<bool> HealthCheckAsync(CancellationToken cancellationToken = default)
    {
        try
        {
            var url = "odata/businessobject/cis?$top=1&$select=RecId";
            var response = await _httpClient.GetAsync(url, cancellationToken);
            return response.IsSuccessStatusCode;
        }
        catch
        {
            return false;
        }
    }

    public async Task<List<CI>> GetAllRelevantCIsAsync(IEnumerable<string> allowedTypes, CancellationToken cancellationToken = default)
    {
        var allCIs = new List<CI>();
        var filter = string.Join(" or ", allowedTypes.Select(t => $"CIType eq '{t}'"));
        string? lastRecId = null;
        bool hasMore;

        do
        {
            var filterClause = string.IsNullOrEmpty(lastRecId) 
                ? filter 
                : $"({filter}) and RecId gt '{lastRecId}'";
            
            var url = $"odata/businessobject/cis?$filter={filterClause}&$select=RecId,CIType,Name,TRN_KritichnostKE_Valid,XER_CSI_Valid,TargetAvailability,LastChangeDateTime&$orderby=RecId&$top={_ciPageSize}";
            _logger.LogInformation("Requesting CIs page (lastRecId={LastRecId}): {Url}", lastRecId ?? "null", url);

            var response = await _httpClient.GetAsync(url, cancellationToken);
            _logger.LogInformation("CI response: {StatusCode}", response.StatusCode);
            response.EnsureSuccessStatusCode();

            var json = await response.Content.ReadAsStringAsync(cancellationToken);
            var odata = JsonSerializer.Deserialize<ODataResponse<CI>>(json, _jsonOptions);
            var pageCIs = odata?.Value ?? new List<CI>();
            
            if (pageCIs.Any())
            {
                allCIs.AddRange(pageCIs);
                lastRecId = pageCIs.Last().RecId;
                _logger.LogInformation("Loaded {Count} CIs (total so far: {Total})", pageCIs.Count, allCIs.Count);
                hasMore = pageCIs.Count == _ciPageSize;
            }
            else
            {
                hasMore = false;
            }
        } while (hasMore);

        _logger.LogInformation("Total loaded CIs: {Count}", allCIs.Count);
        return allCIs;
    }

    public async Task<List<CIRelation>> GetAllRelationsAsync(IEnumerable<string> ciRecIds, CancellationToken cancellationToken = default)
    {
        var relations = new List<CIRelation>();
        var ids = ciRecIds.ToList();
        if (!ids.Any()) return relations;

        foreach (var chunk in ids.Chunk(_relationsChunkSize))
        {
            var filter = string.Join(" or ", chunk.Select(id => $"TargetID eq '{id}' or SourceID eq '{id}'"));
            var url = $"odata/businessobject/cinamedrellinks?$filter=({filter})&$select=RecId,SourceID,TargetID";
            _logger.LogInformation("Requesting relations chunk (size {Count})", chunk.Length);

            while (!string.IsNullOrEmpty(url))
            {
                var response = await _httpClient.GetAsync(url, cancellationToken);
                _logger.LogInformation("Relations response: {StatusCode}", response.StatusCode);

                if (!response.IsSuccessStatusCode)
                {
                    if (response.StatusCode == HttpStatusCode.NotFound)
                    {
                        _logger.LogWarning("Relations chunk returned 404 (no relations for this set)");
                        break;
                    }
                    response.EnsureSuccessStatusCode();
                }

                var json = await response.Content.ReadAsStringAsync(cancellationToken);
                var odata = JsonSerializer.Deserialize<ODataResponse<CIRelation>>(json, _jsonOptions);
                if (odata?.Value != null)
                    relations.AddRange(odata.Value);
                url = odata?.NextLink;
            }
        }

        _logger.LogInformation("Loaded {Count} relations", relations.Count);
        return relations;
    }

    public async Task<int?> GetCriticalitySortOrderAsync(string? critRecId, CancellationToken cancellationToken = default)
    {
        if (string.IsNullOrEmpty(critRecId)) return null;

        var url = $"odata/businessobject/trn_kritichnostkes('{critRecId}')?$select=XER_SortOrder";
        _logger.LogInformation("Requesting criticality sort order: {Url}", url);
        var response = await _httpClient.GetAsync(url, cancellationToken);
        _logger.LogInformation("Criticality response: {StatusCode}", response.StatusCode);
        if (!response.IsSuccessStatusCode) return null;
        var json = await response.Content.ReadAsStringAsync(cancellationToken);
        var crit = JsonSerializer.Deserialize<Criticality.Models.Criticality>(json, _jsonOptions);
        return crit?.XER_SortOrder;
    }

    public async Task<bool> UpdateCIAsync(string recId, object updateFields, CancellationToken cancellationToken = default)
    {
        try
        {
            var url = $"odata/businessobject/cis('{recId}')";
            var json = JsonSerializer.Serialize(updateFields, _jsonOptions);
            var content = new StringContent(json, Encoding.UTF8, "application/json");
            var request = new HttpRequestMessage(HttpMethod.Patch, url) { Content = content };
            _logger.LogInformation("Updating CI {RecId}: {Url}", recId, url);
            var response = await _httpClient.SendAsync(request, cancellationToken);
            _logger.LogInformation("Update response: {StatusCode}", response.StatusCode);
            if (!response.IsSuccessStatusCode)
            {
                var error = await response.Content.ReadAsStringAsync(cancellationToken);
                _logger.LogError("Failed to update CI {RecId}: {Error}", recId, error);
                return false;
            }
            return true;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error updating CI {RecId}", recId);
            return false;
        }
    }

    public async Task<CI?> GetCIAsync(string recId, CancellationToken cancellationToken = default)
    {
        try
        {
            var url = $"odata/businessobject/cis('{recId}')";
            _logger.LogInformation("Requesting CI {RecId}: {Url}", recId, url);
            var response = await _httpClient.GetAsync(url, cancellationToken);
            if (!response.IsSuccessStatusCode)
            {
                _logger.LogWarning("CI {RecId} not found or inaccessible: {StatusCode}", recId, response.StatusCode);
                return null;
            }
            var json = await response.Content.ReadAsStringAsync(cancellationToken);
            var ci = JsonSerializer.Deserialize<CI>(json, _jsonOptions);
            return ci;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error getting CI {RecId}", recId);
            return null;
        }
    }

    public async Task<List<CIRelation>> GetAllRelationsAsync(CancellationToken cancellationToken = default)
    {
        var allRelations = new List<CIRelation>();
        var skip = 0;
        bool hasMore;
        
        do
        {
            var url = $"odata/businessobject/cinamedrellinks?$select=RecId,SourceID,TargetID&$top={_ciPageSize}&$skip={skip}";
            _logger.LogInformation("Requesting relations page (skip={Skip}, top={Top})", skip, _ciPageSize);
            
            var response = await _httpClient.GetAsync(url, cancellationToken);
            if (!response.IsSuccessStatusCode)
            {
                var error = await response.Content.ReadAsStringAsync(cancellationToken);
                _logger.LogError("Failed to get relations: {StatusCode} - {Error}", response.StatusCode, error);
                break;
            }
            
            var json = await response.Content.ReadAsStringAsync(cancellationToken);
            var odata = JsonSerializer.Deserialize<ODataResponse<CIRelation>>(json, _jsonOptions);
            var pageCount = odata?.Value?.Count ?? 0;
            if (odata?.Value != null)
                allRelations.AddRange(odata.Value);
            
            _logger.LogInformation("Loaded {Count} relations (total so far: {Total})", pageCount, allRelations.Count);
            
            hasMore = pageCount == _ciPageSize;
            skip += _ciPageSize;
        } while (hasMore);
        
        _logger.LogInformation("Total loaded relations: {Count}", allRelations.Count);
        return allRelations;
    }

    public async Task<RelationsPage> GetRelationsPageAsync(int pageSize, string? continuationState, CancellationToken cancellationToken = default)
    {
        var skip = 0;
        if (!string.IsNullOrEmpty(continuationState))
        {
            if (int.TryParse(continuationState, out var parsed))
                skip = parsed;
        }

        var url = $"odata/businessobject/cinamedrellinks?$select=RecId,SourceID,TargetID&$top={pageSize}&$skip={skip}";
        var response = await _httpClient.GetAsync(url, cancellationToken);

        if (!response.IsSuccessStatusCode)
        {
            if (response.StatusCode == HttpStatusCode.NotFound)
                return new RelationsPage { Items = new List<CIRelation>(), NextState = null };

            var error = await response.Content.ReadAsStringAsync(cancellationToken);
            _logger.LogError("Failed to get relations page (skip={Skip}): {StatusCode} - {Error}", skip, response.StatusCode, error);
            return new RelationsPage { Items = new List<CIRelation>(), NextState = null };
        }

        var json = await response.Content.ReadAsStringAsync(cancellationToken);
        var odata = JsonSerializer.Deserialize<ODataResponse<CIRelation>>(json, _jsonOptions);
        var items = odata?.Value ?? new List<CIRelation>();

        string? nextState = null;
        if (items.Count == pageSize)
            nextState = (skip + pageSize).ToString();

        _logger.LogDebug("Relations page: skip={Skip}, returned={Count}, hasNext={HasNext}", skip, items.Count, nextState != null);
        return new RelationsPage { Items = items, NextState = nextState };
    }
}
