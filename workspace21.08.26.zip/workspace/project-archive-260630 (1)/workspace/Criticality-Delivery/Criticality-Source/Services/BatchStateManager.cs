using System.Text.Json;
using Criticality.Models;

namespace Criticality.Services;

public interface IBatchStateManager
{
    BatchState LoadState();
    Task<BatchState> LoadStateAsync(CancellationToken cancellationToken = default);
    void SaveState(BatchState state);
    Task SaveStateAsync(BatchState state, CancellationToken cancellationToken = default);
    void ResetState();
}

public class BatchStateManager : IBatchStateManager
{
    private readonly string _stateFilePath;
    private readonly SemaphoreSlim _lock = new(1, 1);
    private readonly ILogger<BatchStateManager> _logger;

    public BatchStateManager(ILogger<BatchStateManager> logger)
    {
        _logger = logger;
        _stateFilePath = Path.Combine(AppContext.BaseDirectory, "batch_state.json");
    }

    public BatchState LoadState()
    {
        _lock.Wait();
        try
        {
            if (!File.Exists(_stateFilePath))
                return new BatchState();

            var json = File.ReadAllText(_stateFilePath);
            return JsonSerializer.Deserialize<BatchState>(json) ?? new BatchState();
        }
        finally
        {
            _lock.Release();
        }
    }

    public async Task<BatchState> LoadStateAsync(CancellationToken cancellationToken = default)
    {
        await _lock.WaitAsync(cancellationToken);
        try
        {
            if (!File.Exists(_stateFilePath))
                return new BatchState();

            var json = await File.ReadAllTextAsync(_stateFilePath, cancellationToken);
            return JsonSerializer.Deserialize<BatchState>(json) ?? new BatchState();
        }
        finally
        {
            _lock.Release();
        }
    }

    public void SaveState(BatchState state)
    {
        _lock.Wait();
        try
        {
            var json = JsonSerializer.Serialize(state, new JsonSerializerOptions { WriteIndented = true });
            var tempPath = _stateFilePath + ".tmp";

            File.WriteAllText(tempPath, json);
            File.Move(tempPath, _stateFilePath, overwrite: true);
        }
        finally
        {
            _lock.Release();
        }
    }

    public async Task SaveStateAsync(BatchState state, CancellationToken cancellationToken = default)
    {
        await _lock.WaitAsync(cancellationToken);
        try
        {
            var json = JsonSerializer.Serialize(state, new JsonSerializerOptions { WriteIndented = true });
            var tempPath = _stateFilePath + ".tmp";

            await File.WriteAllTextAsync(tempPath, json, cancellationToken);
            File.Move(tempPath, _stateFilePath, overwrite: true);

            _logger.LogDebug("Batch state saved atomically to {Path}", _stateFilePath);
        }
        finally
        {
            _lock.Release();
        }
    }

    public void ResetState()
    {
        _lock.Wait();
        try
        {
            if (File.Exists(_stateFilePath))
                File.Delete(_stateFilePath);
            _logger.LogInformation("Batch state reset.");
        }
        finally
        {
            _lock.Release();
        }
    }
}
