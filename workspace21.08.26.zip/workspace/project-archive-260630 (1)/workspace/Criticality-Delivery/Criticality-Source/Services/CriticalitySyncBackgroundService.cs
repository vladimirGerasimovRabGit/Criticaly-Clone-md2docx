using Microsoft.Extensions.Options;
using Criticality.Configuration;

namespace Criticality.Services;

public class CriticalitySyncBackgroundService : BackgroundService
{
    private readonly IServiceScopeFactory _scopeFactory;
    private readonly ILogger<CriticalitySyncBackgroundService> _logger;
    private readonly CriticalitySyncSettings _settings;

    public CriticalitySyncBackgroundService(
        IServiceScopeFactory scopeFactory,
        ILogger<CriticalitySyncBackgroundService> logger,
        IOptions<CriticalitySyncSettings> settings)
    {
        _scopeFactory = scopeFactory;
        _logger = logger;
        _settings = settings.Value;
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        var interval = TimeSpan.FromMinutes(_settings.BackgroundSyncIntervalMinutes);
        _logger.LogInformation("Criticality Sync Background Service started with interval {Interval} minutes.", _settings.BackgroundSyncIntervalMinutes);

        await ResetIfNewDay(stoppingToken);

        while (!stoppingToken.IsCancellationRequested)
        {
            try
            {
                await ResetIfNewDay(stoppingToken);

                using var scope = _scopeFactory.CreateScope();
                var syncService = scope.ServiceProvider.GetRequiredService<ICriticalitySyncService>();

                var result = await syncService.RunSyncAsync(stoppingToken);
                _logger.LogInformation("Scheduled sync completed: {Message}, Processed: {Count}, Completed: {IsCompleted}",
                    result.Message, result.ProcessedCount, result.IsCompleted);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error during scheduled criticality sync");
            }

            await Task.Delay(interval, stoppingToken);
        }

        _logger.LogInformation("Criticality Sync Background Service stopped.");
    }

    private async Task ResetIfNewDay(CancellationToken cancellationToken)
    {
        try
        {
            using var scope = _scopeFactory.CreateScope();
            var syncService = scope.ServiceProvider.GetRequiredService<ICriticalitySyncService>();

            var state = await syncService.GetStatusAsync(cancellationToken);
            var lastRun = state.LastRunTime;

            if (lastRun.Date < DateTime.UtcNow.Date)
            {
                _logger.LogInformation("New day detected (last run: {LastRun}). Resetting batch state.", lastRun);
                await syncService.ResetAsync(cancellationToken);
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error during daily reset check");
        }
    }
}
