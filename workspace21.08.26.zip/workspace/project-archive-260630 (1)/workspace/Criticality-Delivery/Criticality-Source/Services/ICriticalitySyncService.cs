using Criticality.Models;

namespace Criticality.Services;

public interface ICriticalitySyncService
{
    Task<BatchState> GetStatusAsync(CancellationToken cancellationToken = default);
    Task<SyncResult> RunSyncAsync(CancellationToken cancellationToken = default);
    Task ResetAsync(CancellationToken cancellationToken = default);
}

public class SyncResult
{
    public bool Success { get; set; }
    public string Message { get; set; } = string.Empty;
    public int ProcessedCount { get; set; }
    public string? LastProcessedRecId { get; set; }
    public bool IsCompleted { get; set; }
    public TimeSpan ElapsedTime { get; set; }
}
