using Criticality.Models;

namespace Criticality.Services;

public interface IHeatApiService
{
    Task<bool> HealthCheckAsync(CancellationToken cancellationToken = default);
    
    Task<List<CI>> GetAllRelevantCIsAsync(IEnumerable<string> allowedTypes, CancellationToken cancellationToken = default);
    Task<List<CIRelation>> GetAllRelationsAsync(IEnumerable<string> ciRecIds, CancellationToken cancellationToken = default);
    Task<int?> GetCriticalitySortOrderAsync(string? critRecId, CancellationToken cancellationToken = default);
    Task<bool> UpdateCIAsync(string recId, object updateFields, CancellationToken cancellationToken = default);
    Task<CI?> GetCIAsync(string recId, CancellationToken cancellationToken = default);
    Task<List<CIRelation>> GetAllRelationsAsync(CancellationToken cancellationToken = default);
    Task<RelationsPage> GetRelationsPageAsync(int pageSize, string? continuationState, CancellationToken cancellationToken = default);
}
