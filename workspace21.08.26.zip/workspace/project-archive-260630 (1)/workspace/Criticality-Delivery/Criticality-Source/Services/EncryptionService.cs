using System.Security.Cryptography;
using System.Text;

namespace Criticality.Services;

public interface IEncryptionService
{
    string Encrypt(string plainText, string encryptionKey);
    string Decrypt(string cipherText, string encryptionKey);
}

public class EncryptionService : IEncryptionService
{
    private const int KeySize = 256;
    private const int BlockSize = 128;
    private const int SaltSize = 16;
    private const int IvSize = 16;
    private const int Iterations = 10000;

    public string Encrypt(string plainText, string encryptionKey)
    {
        if (string.IsNullOrEmpty(plainText))
            throw new ArgumentNullException(nameof(plainText));
        if (string.IsNullOrEmpty(encryptionKey))
            throw new ArgumentNullException(nameof(encryptionKey));

        using var aes = Aes.Create();
        aes.KeySize = KeySize;
        aes.BlockSize = BlockSize;
        aes.Mode = CipherMode.CBC;
        aes.Padding = PaddingMode.PKCS7;

        var salt = RandomNumberGenerator.GetBytes(SaltSize);
        var key = DeriveKey(encryptionKey, salt);
        aes.Key = key;

        var iv = RandomNumberGenerator.GetBytes(IvSize);
        aes.IV = iv;

        var encryptor = aes.CreateEncryptor(aes.Key, aes.IV);
        var plainBytes = Encoding.UTF8.GetBytes(plainText);

        using var memoryStream = new MemoryStream();
        memoryStream.Write(salt, 0, salt.Length);
        memoryStream.Write(iv, 0, iv.Length);

        using var cryptoStream = new CryptoStream(memoryStream, encryptor, CryptoStreamMode.Write);
        cryptoStream.Write(plainBytes, 0, plainBytes.Length);
        cryptoStream.FlushFinalBlock();

        var cipherBytes = memoryStream.ToArray();
        return Convert.ToBase64String(cipherBytes);
    }

    public string Decrypt(string cipherText, string encryptionKey)
    {
        if (string.IsNullOrEmpty(cipherText))
            throw new ArgumentNullException(nameof(cipherText));
        if (string.IsNullOrEmpty(encryptionKey))
            throw new ArgumentNullException(nameof(encryptionKey));

        var cipherBytes = Convert.FromBase64String(cipherText);

        using var aes = Aes.Create();
        aes.KeySize = KeySize;
        aes.BlockSize = BlockSize;
        aes.Mode = CipherMode.CBC;
        aes.Padding = PaddingMode.PKCS7;

        var salt = new byte[SaltSize];
        Array.Copy(cipherBytes, 0, salt, 0, salt.Length);

        var iv = new byte[IvSize];
        Array.Copy(cipherBytes, salt.Length, iv, 0, iv.Length);

        var key = DeriveKey(encryptionKey, salt);
        aes.Key = key;
        aes.IV = iv;

        var decryptor = aes.CreateDecryptor(aes.Key, aes.IV);
        var dataOffset = salt.Length + iv.Length;

        using var memoryStream = new MemoryStream(cipherBytes, dataOffset, cipherBytes.Length - dataOffset);
        using var cryptoStream = new CryptoStream(memoryStream, decryptor, CryptoStreamMode.Read);
        using var resultStream = new MemoryStream();

        cryptoStream.CopyTo(resultStream);
        return Encoding.UTF8.GetString(resultStream.ToArray());
    }

    private static byte[] DeriveKey(string password, byte[] salt)
    {
        using var deriveBytes = new Rfc2898DeriveBytes(password, salt, Iterations, HashAlgorithmName.SHA256);
        return deriveBytes.GetBytes(32);
    }
}
