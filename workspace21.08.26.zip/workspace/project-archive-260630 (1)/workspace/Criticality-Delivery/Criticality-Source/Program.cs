using Serilog;
using Serilog.Events;
using Criticality.Configuration;
using Criticality.Middleware;
using Criticality.Services;
using System.Diagnostics;
using System.Net;
using System.Security.Cryptography.X509Certificates;

var builder = WebApplication.CreateBuilder(args);

var configuration = builder.Configuration;
var environment = builder.Environment.EnvironmentName;
var port = configuration.GetValue<int>("Server:Port", 7102);
var useHttps = configuration.GetValue<bool>("Server:UseHttps", false);
var certPath = configuration["Server:CertificatePath"];
var certPassword = configuration["Server:CertificatePassword"];

builder.Host.UseSerilog((context, services, loggerConfig) =>
{
    var logPath = Path.Combine(AppContext.BaseDirectory, "logs", "app-.log");
    var fileSizeLimitBytes = 50L * 1024 * 1024; // 50 MB
    var retainedFileCount = 10;

    loggerConfig
        .MinimumLevel.Information()
        .MinimumLevel.Override("Microsoft.AspNetCore", LogEventLevel.Warning)
        .MinimumLevel.Override("Criticality.Services.HeatApiService", LogEventLevel.Debug)
        .Enrich.FromLogContext()
        .Enrich.WithMachineName()
        .Enrich.WithThreadId()
        .WriteTo.Console(outputTemplate: "[{Timestamp:yyyy-MM-dd HH:mm:ss} {Level:u3}] {Message:lj}{NewLine}{Exception}")
        .WriteTo.File(
            path: logPath,
            rollingInterval: RollingInterval.Day,
            fileSizeLimitBytes: fileSizeLimitBytes,
            rollOnFileSizeLimit: true,
            retainedFileCountLimit: retainedFileCount,
            outputTemplate: "{Timestamp:yyyy-MM-dd HH:mm:ss.fff zzz} [{Level:u3}] [{SourceContext}] {Message:lj}{NewLine}{Exception}",
            shared: true);

    if (context.HostingEnvironment.IsDevelopment())
    {
        loggerConfig.MinimumLevel.Debug();
    }
});

var heatApiSettings = configuration.GetSection(HeatApiSettings.SectionName).Get<HeatApiSettings>();
if (heatApiSettings == null)
    throw new InvalidOperationException("HeatApi section is missing in configuration");

if (heatApiSettings.RequireWebServer && !environment.Equals("Production", StringComparison.OrdinalIgnoreCase))
{
    Log.Warning("RequireWebServer is enabled but current environment is '{Env}', not 'Production'. ApiKey will not be used.", environment);
}

builder.WebHost.ConfigureKestrel(options =>
{
    options.Listen(IPAddress.Any, port);

    if (useHttps)
    {
        var httpsPort = configuration.GetValue<int>("Server:HttpsPort", 7103);
        var certThumbprint = configuration["Server:CertificateThumbprint"]; // NEW

        options.Listen(IPAddress.Any, httpsPort, listenOptions =>
        {
            X509Certificate2? cert = null;

            // 1. Попробовать загрузить из файла
            if (!string.IsNullOrEmpty(certPath) && File.Exists(certPath))
            {
                try
                {
                    cert = new X509Certificate2(certPath, certPassword);
                    Log.Information("HTTPS enabled via file: {CertPath}", certPath);
                }
                catch (Exception ex)
                {
                    Log.Error(ex, "Failed to load certificate from file {CertPath}", certPath);
                }
            }

            // 2. Если файл не указан/ошибка, попробовать загрузить по Thumbprint из хранилища
            if (cert == null && !string.IsNullOrEmpty(certThumbprint))
            {
                try
                {
                    using var store = new X509Store(StoreName.My, StoreLocation.LocalMachine);
                    store.Open(OpenFlags.ReadOnly);
                    var certs = store.Certificates.Find(X509FindType.FindByThumbprint, certThumbprint, validOnly: false);

                    if (certs.Count > 0)
                    {
                        cert = certs[0];
                        Log.Information("HTTPS enabled via Thumbprint: {Thumbprint}", certThumbprint);
                    }
                    else
                    {
                        Log.Warning("Certificate with Thumbprint {Thumbprint} not found in store.", certThumbprint);
                    }
                }
                catch (Exception ex)
                {
                    Log.Error(ex, "Failed to load certificate by Thumbprint {Thumbprint}", certThumbprint);
                }
            }

            // 3. Применить сертификат или fallback на dev
            if (cert != null)
            {
                listenOptions.UseHttps(cert);
            }
            else
            {
                Log.Warning("No valid certificate configured. Using development certificate.");
                listenOptions.UseHttps();
            }
        });
    }
});

builder.Services.Configure<HeatApiSettings>(configuration.GetSection(HeatApiSettings.SectionName));
builder.Services.Configure<CriticalitySyncSettings>(
    builder.Configuration.GetSection(CriticalitySyncSettings.SectionName));

builder.Services.AddControllers();

builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowLocal", policy =>
    {
        policy.AllowAnyOrigin()
              .AllowAnyMethod()
              .AllowAnyHeader();
    });
});

builder.Services.AddHttpClient();
builder.Services.AddHttpClient("diagnostic", (sp, client) =>
{
    var config = sp.GetRequiredService<IConfiguration>();
    var baseUrl = config["HeatApi:BaseUrl"]?.TrimEnd('/') + '/';
    client.BaseAddress = new Uri(baseUrl);
    var apiKey = config["HeatApi:ApiKey"];
    if (!string.IsNullOrEmpty(apiKey))
        client.DefaultRequestHeaders.TryAddWithoutValidation("Authorization", $"rest_api_key={apiKey}");
    client.Timeout = TimeSpan.FromSeconds(config.GetValue<int>("HeatApi:TimeoutSeconds", 60));
}).ConfigurePrimaryHttpMessageHandler(sp =>
{
    var config = sp.GetRequiredService<IConfiguration>();
    var skipCert = config.GetValue<bool>("HeatApi:SkipCertificateValidation");
    return new HttpClientHandler
    {
        AllowAutoRedirect = true,
        ServerCertificateCustomValidationCallback = skipCert
            ? (message, cert, chain, errors) => true
            : null
    };
});

builder.Services.AddSingleton<IEncryptionService, EncryptionService>();
builder.Services.AddSingleton<IBatchStateManager, BatchStateManager>();
builder.Services.AddScoped<IHeatApiService, HeatApiService>();
builder.Services.AddScoped<ICriticalitySyncService, CriticalitySyncService>();
builder.Services.AddHostedService<CriticalitySyncBackgroundService>();

var app = builder.Build();

app.UseCors("AllowLocal");
app.UseMiddleware<RequestLoggingMiddleware>();
app.UseLocalhostOnly();
app.UseAuthorization();
app.MapControllers();

var ipAddress = GetLocalIPAddress();
var apiKeySource = !string.IsNullOrEmpty(heatApiSettings.EncryptedApiKey) ? "encrypted" : "plain";

Log.Information("=========================================");
Log.Information("Criticality Sync Service started!");
Log.Information("Environment: {Environment}", environment);
Log.Information("Port: {Port}", port);
Log.Information("URL: http://{IP}:{Port}", ipAddress, port);
Log.Information("-----------------------------------------");
Log.Information("API Key source: {Source}", apiKeySource);

if (useHttps)
{
    var httpsPort = configuration.GetValue<int>("Server:HttpsPort", 7103);
    Log.Information("HTTPS Port: {Port}", httpsPort);
    Log.Information("HTTPS URL: https://{IP}:{Port}", ipAddress, httpsPort);
}

Log.Information("-----------------------------------------");
Log.Information("[!] Swagger disabled (offline mode)");
Log.Information("-----------------------------------------");
Log.Information("Criticality Sync:");
Log.Information("  http://localhost:{Port}/api/CriticalitySync/start", port);
Log.Information("  http://localhost:{Port}/api/CriticalitySync/status", port);
Log.Information("  http://localhost:{Port}/api/CriticalitySync/reset", port);
Log.Information("=========================================");
Log.Information("For testing:");
Log.Information("  curl http://localhost:{Port}/api/CriticalitySync/status", port);
Log.Information("  or open in browser");
Log.Information("=========================================");
Log.Information("Log files: {LogPath}", Path.Combine(AppContext.BaseDirectory, "logs"));
Log.Information("=========================================");

try
{
    await app.RunAsync();
}
catch (Exception ex)
{
    Log.Fatal(ex, "Application terminated unexpectedly");
}
finally
{
    await Log.CloseAndFlushAsync();
}

static string GetLocalIPAddress()
{
    try
    {
        var host = System.Net.Dns.GetHostEntry(System.Net.Dns.GetHostName());
        foreach (var ip in host.AddressList)
            if (ip.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork)
                return ip.ToString();
    }
    catch (Exception ex)
    {
        Log.Warning(ex, "Failed to resolve local IP address");
    }
    return "192.168.16.244";
}
