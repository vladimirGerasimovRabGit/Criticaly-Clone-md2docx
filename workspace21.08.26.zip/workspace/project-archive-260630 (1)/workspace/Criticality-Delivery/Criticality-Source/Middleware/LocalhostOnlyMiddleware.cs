using System.Net;

namespace Criticality.Middleware;

public class LocalhostOnlyMiddleware
{
    private readonly RequestDelegate _next;
    private readonly string[] _restrictedPrefixes;
    private readonly ILogger<LocalhostOnlyMiddleware> _logger;

    public LocalhostOnlyMiddleware(
        RequestDelegate next,
        ILogger<LocalhostOnlyMiddleware> logger)
    {
        _next = next;
        _logger = logger;
        _restrictedPrefixes = new[] { "/api/criticalitysync" };
    }

    public async Task InvokeAsync(HttpContext context)
    {
        var path = context.Request.Path.Value?.ToLowerInvariant() ?? string.Empty;
        var isRestricted = _restrictedPrefixes.Any(path.StartsWith);

        if (isRestricted)
        {
            var remoteIp = context.Connection.RemoteIpAddress;

            if (!IsLocalhost(remoteIp))
            {
                _logger.LogWarning("Blocked external access to restricted endpoint: {Path} from {IP}", path, remoteIp);
                context.Response.StatusCode = (int)HttpStatusCode.Forbidden;
                await context.Response.WriteAsJsonAsync(new
                {
                    error = "Access denied. This endpoint is only available from localhost.",
                    path = path
                });
                return;
            }
        }

        await _next(context);
    }

    private static bool IsLocalhost(IPAddress? ip)
    {
        if (ip == null) return false;
        return IPAddress.IsLoopback(ip)
            || ip.Equals(IPAddress.IPv6Loopback)
            || ip.Equals(IPAddress.Any)
            || ip.Equals(IPAddress.IPv6Any);
    }
}

public static class LocalhostOnlyMiddlewareExtensions
{
    public static IApplicationBuilder UseLocalhostOnly(this IApplicationBuilder app)
    {
        return app.UseMiddleware<LocalhostOnlyMiddleware>();
    }
}
