using System.Diagnostics;
using Serilog;
using Serilog.Events;

namespace Criticality.Middleware;

/// <summary>
/// Middleware for logging all HTTP requests and responses to the application log.
/// </summary>
public class RequestLoggingMiddleware
{
    private readonly RequestDelegate _next;

    public RequestLoggingMiddleware(RequestDelegate next)
    {
        _next = next;
    }

    public async Task InvokeAsync(HttpContext context)
    {
        var logger = Log.ForContext("SourceContext", "Criticality.Request");
        var request = context.Request;
        var method = request.Method;
        var path = request.Path;
        var queryString = request.QueryString.HasValue ? request.QueryString.Value : string.Empty;
        var start = Stopwatch.GetTimestamp();

        logger.Information("{Method} {Path}{QueryString} started", method, path, queryString);

        try
        {
            await _next(context);
        }
        finally
        {
            var elapsed = Stopwatch.GetElapsedTime(start);
            var statusCode = context.Response.StatusCode;
            var logLevel = statusCode >= 500
                ? LogEventLevel.Error
                : statusCode >= 400
                    ? LogEventLevel.Warning
                    : LogEventLevel.Information;

            logger.Write(logLevel, "{Method} {Path} completed in {ElapsedMs}ms with status {StatusCode}",
                method, path, elapsed.TotalMilliseconds, statusCode);
        }
    }
}
