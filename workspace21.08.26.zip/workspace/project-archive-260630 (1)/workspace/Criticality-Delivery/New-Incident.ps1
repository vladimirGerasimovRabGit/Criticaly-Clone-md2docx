$Tenant   = "win-5jhv4t9rj4p"
$ApiKey   = "73BB0E4F9A804ACF8DEEDF3408B09CD8"
$Subject  = "Test Subject"
$Symptom  = "Test Symptom"
$ProfileLinkRecId = "BBC683FF4152482BBAFD44192B175374"
$Service      = "IT General Administration"
$OwnerTeam    = "Service Desk"

$ErrorActionPreference = "Stop"

$url  = "http://${Tenant}/HEAT/api/odata/businessobject/incidents"
$body = @{
    Status            = "Logged"
    Subject           = $Subject
    Symptom           = $Symptom
    CreatedBy         = "HEATAdmin"
    LastModBy         = "HEATAdmin"
    CreatedDateTime   = (Get-Date -Format "yyyy-MM-ddTHH:mm:ss.fffZ")
    LastModDateTime   = (Get-Date -Format "yyyy-MM-ddTHH:mm:ss.fffZ")
    OwnerTeam         = $OwnerTeam
    Owner             = $null
    Owner_Valid       = $null
    ProfileLink_RecID = $ProfileLinkRecId
    Service           = $Service
} | ConvertTo-Json

Invoke-WebRequest -Uri $url -Method Post `
    -Headers @{Authorization="rest_api_key=$ApiKey"} `
    -Body $body -ContentType "application/json" -UseBasicParsing |
    Select-Object -ExpandProperty Content |
    ConvertFrom-Json |
    Select-Object RecId, IncidentNumber, Status, Subject
