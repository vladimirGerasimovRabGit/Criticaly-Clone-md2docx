$Tenant     = "win-5jhv4t9rj4p"
$ApiKey     = "73BB0E4F9A804ACF8DEEDF3408B09CD8"
$IncidentId = "E4A8836D968D4EB2927E1D6C70107B3E"
$NewStatus  = "Открыт"

$ErrorActionPreference = "Stop"

$url  = "http://${Tenant}/HEAT/api/odata/businessobject/incidents('${IncidentId}')"
$body = @{
    Status     = $NewStatus
    TRN_Status = $NewStatus
} | ConvertTo-Json

Invoke-WebRequest -Uri $url -Method Patch `
    -Headers @{Authorization="rest_api_key=$ApiKey"} `
    -Body $body -ContentType "application/json" -UseBasicParsing |
    Select-Object -ExpandProperty Content |
    ConvertFrom-Json |
    Select-Object RecId, IncidentNumber, Status
