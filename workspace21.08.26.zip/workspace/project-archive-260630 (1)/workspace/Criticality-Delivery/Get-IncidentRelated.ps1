$Tenant     = "win-5jhv4t9rj4p"
$ApiKey     = "73BB0E4F9A804ACF8DEEDF3408B09CD8"
$IncidentId = "E4A8836D968D4EB2927E1D6C70107B3E"

$ErrorActionPreference = "Stop"

$base      = "http://${Tenant}/HEAT/api/odata/businessobject"
$headers   = @{Authorization="rest_api_key=$ApiKey"}

function Fetch($label, $url) {
    Write-Host "--- $label ---" -ForegroundColor Cyan
    Write-Host "GET $url" -ForegroundColor Gray
    try {
        $r = Invoke-WebRequest -Uri $url -Headers $headers -UseBasicParsing -ErrorAction Stop
        $data = $r.Content | ConvertFrom-Json
        if ($data.value) {
            $count = @($data.value).Count
            Write-Host "  Records: $count" -ForegroundColor Green
            $data.value | Format-Table -AutoSize -Wrap
        } else {
            $data | Format-List
        }
    } catch {
        $code = if ($_.Exception.Response) { [int]$_.Exception.Response.StatusCode } else { "?" }
        Write-Host "  $code — $_" -ForegroundColor DarkYellow
    }
}

# Вложения
Fetch "ATTACHMENTS" "$base/incidents('${IncidentId}')/IncidentContainsAttachment"

# Заметки и почта (всё в одном)
Fetch "JOURNAL (заметки + почта)" "$base/incidents('${IncidentId}')/IncidentContainsJournal"
