# Шифрование API-ключа в Criticality Service

## Обзор

Сервис Criticality поддерживает два формата хранения API-ключа HEAT:

| Формат | Конфигурационный путь | Безопасность |
|--------|----------------------|-------------|
| `ApiKey` | `HeatApi:ApiKey` | Открытый текст |
| `EncryptedApiKey` + `EncryptionKey` | `HeatApi:EncryptedApiKey` | Зашифрован AES-256 |

При запуске сервис разрешает ключ в приоритете: сначала проверяется `ApiKey` (открытый текст), затем `EncryptedApiKey` (расшифровывается).

---

## Архитектура

```mermaid
graph LR
    A["appsettings.json"] --> B["Program.cs<br/>DI: IEncryptionService"]
    A --> C["HeatApiService.cs<br/>TryResolveApiKey()"]
    B --> C
    C --> D["encryptionService.Decrypt(...)"]
    D --> E["Plaintext API Key"]
    E --> F["HTTP Header:<br/>Authorization: rest_api_key={key}"]
```

---

## 1. EncryptionService (C#)

Файл: `Services/EncryptionService.cs`

### Параметры шифрования

| Параметр | Значение |
|----------|---------|
| Алгоритм | AES |
| KeySize | 256 бит |
| BlockSize | 128 бит |
| Режим | CBC |
| Padding | PKCS7 |
| Salt | 16 байт (случайный) |
| IV | 16 байт (случайный) |
| Вывод ключа | PBKDF2 / RFC 2898 |
| Хеш-функция | SHA256 |
| Итераций PBKDF2 | 10 000 |
| Формат вывода | Base64 |

### Формат зашифрованных данных

```mermaid
graph LR
    A["Salt (16 bytes)"] --> B["IV (16 bytes)"]
    B --> C["Ciphertext (N bytes)"]
    C --> D["Base64-encode"]
    D --> E["EncryptedApiKey string"]
```

Salt и IV генерируются случайно при каждом шифровании — один и тот же открытый текст с тем же паролем даёт **разный** шифротекст.

### Схема шифрования (Encrypt)

```mermaid
flowchart TD
    P["Password"] --> KDF["PBKDF2 (10000 iterations, SHA256)"]
    S["Random Salt (16 bytes)"] --> KDF
    KDF --> KEY["AES-256 Key"]
    IV["Random IV (16 bytes)"] --> ENC["AES-CBC Encryptor"]
    KEY --> ENC
    PT["Plaintext API Key"] --> ENC
    ENC --> CT["Ciphertext"]
    S --> COMBINE["Salt + IV + Ciphertext"]
    IV --> COMBINE
    CT --> COMBINE
    COMBINE --> B64["Base64"]
    B64 --> RESULT["EncryptedApiKey"]
```

### Схема расшифровки (Decrypt)

```mermaid
flowchart TD
    B64["EncryptedApiKey (Base64)"] --> DEC["Decode Base64"]
    DEC --> SALT["Extract Salt (first 16 bytes)"]
    DEC --> IVEXT["Extract IV (next 16 bytes)"]
    DEC --> CTEXT["Extract Ciphertext (remaining bytes)"]
    PWD["Password"] --> KDF2["PBKDF2 (10000 iterations, SHA256)"]
    SALT --> KDF2
    KDF2 --> KEY2["AES-256 Key"]
    IVEXT --> DECRYPT["AES-CBC Decryptor"]
    KEY2 --> DECRYPT
    CTEXT --> DECRYPT
    DECRYPT --> PT2["Plaintext API Key"]
```

### Листинг: Encrypt

```csharp
public string Encrypt(string plainText, string encryptionKey)
{
    using var aes = Aes.Create();
    aes.KeySize = 256;
    aes.BlockSize = 128;
    aes.Mode = CipherMode.CBC;
    aes.Padding = PaddingMode.PKCS7;

    // 1. Случайная соль, вывод ключа через PBKDF2
    var salt = RandomNumberGenerator.GetBytes(16);
    var key = DeriveKey(encryptionKey, salt);
    aes.Key = key;

    // 2. Случайный IV
    var iv = RandomNumberGenerator.GetBytes(16);
    aes.IV = iv;

    var encryptor = aes.CreateEncryptor(aes.Key, aes.IV);
    var plainBytes = Encoding.UTF8.GetBytes(plainText);

    // 3. Запись: salt + iv + ciphertext
    using var memoryStream = new MemoryStream();
    memoryStream.Write(salt, 0, salt.Length);   // 16 байт
    memoryStream.Write(iv, 0, iv.Length);       // 16 байт

    using var cryptoStream = new CryptoStream(memoryStream, encryptor, CryptoStreamMode.Write);
    cryptoStream.Write(plainBytes, 0, plainBytes.Length);
    cryptoStream.FlushFinalBlock();

    // 4. Кодирование в Base64
    var cipherBytes = memoryStream.ToArray();
    return Convert.ToBase64String(cipherBytes);
}
```

### Листинг: Decrypt

```csharp
public string Decrypt(string cipherText, string encryptionKey)
{
    var cipherBytes = Convert.FromBase64String(cipherText);

    using var aes = Aes.Create();
    aes.KeySize = 256;
    aes.BlockSize = 128;
    aes.Mode = CipherMode.CBC;
    aes.Padding = PaddingMode.PKCS7;

    // 1. Извлечение salt (первые 16 байт)
    var salt = new byte[16];
    Array.Copy(cipherBytes, 0, salt, 0, 16);

    // 2. Извлечение IV (следующие 16 байт)
    var iv = new byte[16];
    Array.Copy(cipherBytes, 16, iv, 0, 16);

    // 3. Вывод ключа из пароля и соли
    var key = DeriveKey(encryptionKey, salt);
    aes.Key = key;
    aes.IV = iv;

    // 4. Расшифровка (байты после salt+iv)
    var decryptor = aes.CreateDecryptor(aes.Key, aes.IV);
    var dataOffset = 16 + 16;  // = 32

    using var memoryStream = new MemoryStream(cipherBytes, dataOffset, cipherBytes.Length - dataOffset);
    using var cryptoStream = new CryptoStream(memoryStream, decryptor, CryptoStreamMode.Read);
    using var resultStream = new MemoryStream();

    cryptoStream.CopyTo(resultStream);
    return Encoding.UTF8.GetString(resultStream.ToArray());
}
```

### Листинг: DeriveKey (PBKDF2)

```csharp
private static byte[] DeriveKey(string password, byte[] salt)
{
    using var deriveBytes = new Rfc2898DeriveBytes(
        password, salt, 10000, HashAlgorithmName.SHA256);
    return deriveBytes.GetBytes(32);  // 32 байта = 256 бит
}
```

---

## 2. TryResolveApiKey — разрешение ключа при запуске

Файл: `Services/HeatApiService.cs:93-124`

Приоритет получения ключа:

1. Если задан `HeatApi:ApiKey` (открытый текст) — используется напрямую
2. Если задан `HeatApi:EncryptedApiKey`:
   - Проверяется наличие `IEncryptionService` в DI
   - Проверяется наличие `HeatApi:EncryptionKey` в конфигурации
   - Вызывается `encryptionService.Decrypt(EncryptedApiKey, EncryptionKey)`

```mermaid
flowchart TD
    START["Start"] --> APIKEY{"ApiKey configured?"}
    APIKEY -->|Yes| RETAP["Return ApiKey (plaintext)"]
    APIKEY -->|No| ENCKEY{"EncryptedApiKey configured?"}
    ENCKEY -->|No| RETNULL["Return null"]
    ENCKEY -->|Yes| ENCSVC{"IEncryptionService registered?"}
    ENCSVC -->|No| WARN1["Log warning, return null"]
    ENCSVC -->|Yes| ENCPWD{"EncryptionKey configured?"}
    ENCPWD -->|No| WARN2["Log warning, return null"]
    ENCPWD -->|Yes| DECRYPT["Decrypt(EncryptedApiKey, EncryptionKey)"]
    DECRYPT --> RETDEC["Return plaintext key"]
```

```csharp
private static string? TryResolveApiKey(HeatApiSettings config, IEncryptionService? encryptionService)
{
    // Приоритет 1: открытый текст
    if (!string.IsNullOrEmpty(config.ApiKey))
        return config.ApiKey;

    // Приоритет 2: зашифрованный ключ
    if (!string.IsNullOrEmpty(config.EncryptedApiKey))
    {
        if (encryptionService == null)
        {
            Console.WriteLine("WARNING: EncryptedApiKey configured but no IEncryptionService registered");
            return null;
        }

        var encryptionKey = config.EncryptionKey;
        if (string.IsNullOrEmpty(encryptionKey))
        {
            Console.WriteLine("WARNING: EncryptionKey not configured, cannot decrypt EncryptedApiKey");
            return null;
        }

        try
        {
            return encryptionService.Decrypt(config.EncryptedApiKey, encryptionKey);
        }
        catch
        {
            return null;
        }
    }

    return null;
}
```

Расшифрованный ключ используется для HTTP-заголовка:

```csharp
_httpClient.DefaultRequestHeaders.TryAddWithoutValidation(
    "Authorization", $"rest_api_key={_apiKey}");
```

---

## 3. appsettings.json — конфигурация

```json
{
  "HeatApi": {
    "BaseUrl": "https://svoivantisrv/HEAT/api",
    "ApiKey": "",
    "EncryptedApiKey": "8owtwbON81PUPSx0qf+FFi0J4wiRNZDbVua1AM5nglV3IU5SU8aVJUG9QThwHxgL6svCmc0cAQE+RVte7QpQ036inBRGdi+qXuJbNQal+Pg=",
    "EncryptionKey": "MySecretKey2024!",
    "TimeoutSeconds": 60,
    "SkipCertificateValidation": true,
    "RequireWebServer": false
  }
}
```

| Поле | Назначение | Безопасность |
|------|-----------|-------------|
| `ApiKey` | API-ключ открытым текстом | Не коммитить |
| `EncryptedApiKey` | Зашифрованный API-ключ (Base64) | Можно коммитить |
| `EncryptionKey` | Пароль для расшифровки | Не коммитить, хранить в переменной окружения |

---

## 4. encrypt-apikey.ps1 — утилита шифрования

Файл: `encrypt-apikey.ps1`

**Важно**: PowerShell-скрипт использует упрощённый алгоритм (SHA256 вместо PBKDF2) и **несовместим** с C# EncryptionService. Скрипт предназначен для проекта ServiceReqCloner, где используется другой EncryptionService.

### Использование

```powershell
.\encrypt-apikey.ps1 -PlainKey "1404A984C43F48C88749CF8C1C14B40A" -Password "MySecretKey2024!"
```

### Алгоритм (PowerShell)

```mermaid
flowchart TD
    PWD["Password"] --> SHA["SHA256 (1 iteration)"]
    SHA --> KEY["32-byte AES Key"]
    PT["Plaintext API Key"] --> ENC["AES-256-CBC Encrypt"]
    KEY --> ENC
    IV["Random IV (16 bytes)"] --> ENC
    ENC --> COMB["IV + Ciphertext"]
    COMB --> B64["Base64"]
    B64 --> RESULT["EncryptedApiKey"]
```

```powershell
# Вывод ключа: SHA256(password) → 32 байта
$sha256 = [System.Security.Cryptography.SHA256]::Create()
$keyBytes = $sha256.ComputeHash([System.Text.Encoding]::UTF8.GetBytes($Password))

# Случайный IV
$aes = [System.Security.Cryptography.Aes]::Create()
$aes.Key = $keyBytes
$aes.GenerateIV()
$ivBytes = $aes.IV

# Шифрование
$encryptor = $aes.CreateEncryptor($aes.Key, $ivBytes)
$plainBytes = [System.Text.Encoding]::UTF8.GetBytes($PlainKey)
$encryptedBytes = $encryptor.TransformFinalBlock($plainBytes, 0, $plainBytes.Length)

# IV + данные → Base64
$combined = New-Object byte[] ($ivBytes.Length + $encryptedBytes.Length)
[System.Buffer]::BlockCopy($ivBytes, 0, $combined, 0, $ivBytes.Length)
[System.Buffer]::BlockCopy($encryptedBytes, 0, $combined, $ivBytes.Length, $encryptedBytes.Length)
$encryptedOutput = [System.Convert]::ToBase64String($combined)
```

---

## 5. Полный процесс: от шифрования до HTTP-запроса

### Шифрование (однократная настройка)

```mermaid
flowchart TD
    subgraph CSharp["C# EncryptionService"]
        CP["Password"] --> CK["PBKDF2 (10000 iterations)"]
        CK --> CA["AES-256-CBC Encrypt"]
        CK2["API Key"] --> CA
        CA --> CB["Salt + IV + Ciphertext -> Base64"]
    end
    CB --> CONFIG["appsettings.json<br/>EncryptedApiKey: '8owtwbO...'<br/>EncryptionKey: 'MySecret...'"]
```

### Расшифровка (при запуске сервиса)

```mermaid
flowchart TD
    CONFIG["appsettings.json"] --> DI["Program.cs: DI registers IEncryptionService"]
    CONFIG --> TRY["HeatApiService.TryResolveApiKey()"]
    DI --> TRY
    TRY --> DEC["encryptionService.Decrypt()"]
    DEC --> PT["API Key: 1404A984..."]
```

### HTTP-запрос

```mermaid
flowchart LR
    KEY["API Key"] --> HEADER["Authorization: rest_api_key={key}"]
    HEADER --> API["GET https://svoivantisrv/HEAT/api/data/..."]
```

---

## 6. Сравнение: C# EncryptionService vs PowerShell encrypt-apikey.ps1

| Характеристика | EncryptionService.cs | encrypt-apikey.ps1 |
|---------------|---------------------|-------------------|
| Проект | Criticality | ServiceReqCloner |
| Вывод ключа | PBKDF2 (RFC 2898, 10 000 итераций) | SHA256 (одна итерация) |
| Формат вывода | Salt(16) + IV(16) + Ciphertext | IV(16) + Ciphertext |
| Совместимость | Несовместим с PS-скриптом | Несовместим с C# сервисом |
| Безопасность | Высокая (PBKDF2 замедляет брутфорс) | Ниже (SHA256 без итераций) |

```mermaid
flowchart LR
    subgraph PS["PowerShell encrypt-apikey.ps1"]
        direction LR
        P1["Password"] --> P2["SHA256 (1 iter)"]
        P2 --> P3["AES-256-CBC"]
        P4["API Key"] --> P3
        P3 --> P5["IV + Ciphertext -> Base64"]
    end
    subgraph CS["C# EncryptionService"]
        direction LR
        C1["Password"] --> C2["PBKDF2 (10000 iter, SHA256)"]
        C2 --> C3["AES-256-CBC"]
        C4["API Key"] --> C3
        C3 --> C5["Salt + IV + Ciphertext -> Base64"]
    end
    P5 -->|XX| X["INCOMPATIBLE"]
    C5 -->|XX| X
```

**Следствие**: зашифрованное PS-скриптом значение нельзя расшифровать C# EncryptionService, и наоборот. Для Criticality используйте только C# `EncryptionService.Encrypt()`.

---

## 7. Рекомендации по безопасному хранению

```powershell
# Production: пароль в переменной окружения
$env:CRITICALITY_ENCRYPTION_KEY = "MySecretKey2024!"

# appsettings.Production.json — без EncryptionKey
{
  "HeatApi": {
    "EncryptedApiKey": "8owtwbON81PUPSx0qf+FFi...",
    "EncryptionKey": ""   // пусто — берётся из переменной окружения
  }
}
```

```csharp
// Program.cs — переопределение EncryptionKey из переменной окружения
var encryptionKey = Environment.GetEnvironmentVariable("CRITICALITY_ENCRYPTION_KEY");
if (!string.IsNullOrEmpty(encryptionKey))
{
    configuration["HeatApi:EncryptionKey"] = encryptionKey;
}
```
