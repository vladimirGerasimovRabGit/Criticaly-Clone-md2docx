# REST API — Управление инцидентами HEAT

Три PowerShell-скрипта для работы с инцидентами через HEAT OData REST API.
Все переменные (Tenant, ApiKey, параметры) вынесены в первые строки скрипта.

---

## 1. Создание инцидента (`New-Incident.ps1`)

### Эндпоинт

```
POST http://<Tenant>/HEAT/api/odata/businessobject/incidents
```

### Настраиваемые переменные

| Переменная | Описание | Пример |
|---|---|---|
| `$Tenant` | Хост HEAT-сервера | `"win-5jhv4t9rj4p"` |
| `$ApiKey` | REST API ключ | `"73BB0E4F9A804ACF8DEEDF3408B09CD8"` |
| `$Subject` | Тема инцидента | `"Test Subject"` |
| `$Symptom` | Описание | `"Test Symptom"` |
| `$ProfileLinkRecId` | RecId заказчика (Customer) | `"BBC683FF4152482BBAFD44192B175374"` |
| `$Service` | Сервис (название) | `"IT General Administration"` |
| `$OwnerTeam` | Группа владельца | `"Service Desk"` |

### Обязательные поля тела запроса

- `Status` — `"Logged"` (иначе требуется `Customer`)
- `ProfileLink_RecID` — RecId заказчика (поле `Customer`)
- `OwnerTeam` — группа (если не указана, сервер может подставить невалидное значение)
- `Owner`, `Owner_Valid` — сброшены в `$null`

### Вывод

```
RecId           : E4A8836D968D4EB2927E1D6C70107B3E
IncidentNumber  : 11163
Status          : Logged
Subject         : Test Subject
```

---

## 2. Смена статуса (`Set-IncidentStatus.ps1`)

### Эндпоинт

```
PATCH http://<Tenant>/HEAT/api/odata/businessobject/incidents('<RecId>')
```

### Настраиваемые переменные

| Переменная | Описание | Пример |
|---|---|---|
| `$Tenant` | Хост HEAT-сервера | `"win-5jhv4t9rj4p"` |
| `$ApiKey` | REST API ключ | `"73BB0E4F9A804ACF8DEEDF3408B09CD8"` |
| `$IncidentId` | RecId инцидента | `"E4A8836D968D4EB2927E1D6C70107B3E"` |
| `$NewStatus` | Новый статус | `"Открыт"` / `"Logged"` / `"Закрыт"` |

### Примечание

Меняются одновременно два поля: `Status` и `TRN_Status`. Формат статуса чувствителен к регистру — используйте русские значения как в интерфейсе HEAT.

---

## 3. Получение вложений, заметок и почты (`Get-IncidentRelated.ps1`)

### Эндпоинты

```
GET .../incidents('<RecId>')/IncidentContainsAttachment   — вложения
GET .../incidents('<RecId>')/IncidentContainsJournal      — заметки + почта
```

### Настраиваемые переменные

| Переменная | Описание | Пример |
|---|---|---|
| `$Tenant` | Хост HEAT-сервера | `"win-5jhv4t9rj4p"` |
| `$ApiKey` | REST API ключ | `"73BB0E4F9A804ACF8DEEDF3408B09CD8"` |
| `$IncidentId` | RecId инцидента | `"E4A8836D968D4EB2927E1D6C70107B3E"` |

### Важно

- **Заметки и почта** хранятся в одном объекте `IncidentContainsJournal` — отдельной связи для email не существует.
- Ответ содержит связи (RecId записей журнала/почты), по которым затем можно получить полное содержимое через `JournalIncident('<RecId>')`.

---

## Аутентификация

Все запросы используют заголовок:

```
Authorization: rest_api_key=<ApiKey>
```

API ключ передаётся в открытом виде (не шифруется). Для продакшена используйте `EncryptedApiKey` + `EncryptionKey` в `appsettings.json` (см. `Criticality-Encryption.md`).

---

## Окружение

- **Протокол**: HTTP (без TLS)
- **Кодировка**: все русские строки в теле запроса — в UTF-8 (PowerShell по умолчанию)
- **PowerShell**: версия 5.1+
