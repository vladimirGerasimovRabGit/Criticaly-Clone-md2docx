# Criticality Sync Service — Техническая документация

**Продукт**: ClonerSuite  
**Клиент**: SVO AVIA  
**Дата**: Июнь 2026 г.

---

## 1. Назначение документа

Настоящий документ описывает архитектуру, развертывание и эксплуатацию сервиса **Criticality Sync Service** — компонента системы ClonerSuite для автоматической синхронизации критичности конфигурационных единиц (CI) в системе Ivanti HEAT.

Документ предназначен для:
- Системных администраторов, выполняющих развертывание сервиса
- Инженеров поддержки, осуществляющих диагностику и устранение неполадок
- Разработчиков, расширяющих функциональность сервиса

---

## 2. Термины и аббревиатуры

- **CI (Configuration Item)** — конфигурационная единица в системе управления ИТ-услугами
- **Criticality (Критичность)** — уровень важности CI для бизнеса
- **CSI (Corporate Service Item)** — корпоративный сервис в Ivanti
- **HEAT** — система управления ИТ-услугами BMC (Ivanti Service Manager)
- **IS (Information System)** — информационная система
- **OData** — протокол REST API для доступа к данным HEAT
- **RecId** — уникальный идентификатор записи в HEAT
- **Sync Service** — сервис синхронизации критичности

---

## 3. Архитектура сервиса

### 3.1 Общая схема

```mermaid
flowchart TD
    subgraph IIS ["IIS (HTTPS 443)"]
        direction TB
        SSL["SSL Termination"]
    end
    
    subgraph Criticality ["Criticality Sync Service"]
        direction TB
        Ports["Порт: 7102 (HTTP) / 7103 (HTTPS)"]
        
        subgraph Background ["Background Service"]
            B1["Автоматический запуск (5 мин)"]
            B2["Сброс состояния (новый день)"]
        end
        
        subgraph API ["API Endpoints"]
            A1["/api/CriticalitySync/start"]
            A2["/api/CriticalitySync/status"]
            A3["/api/CriticalitySync/reset"]
        end
    end
    
    subgraph HEAT ["Ivanti HEAT API Server"]
        direction TB
        URL["https://svoivantiprod1.svo.air.loc/HEAT/api"]
        Endpoints["odata/businessobject/cis<br/>odata/businessobject/cinamedrellinks<br/>odata/businessobject/trn_kritichnostkes"]
    end
    
    IIS --> Criticality
    Criticality --> HEAT
```

### 3.2 Компоненты сервиса

| Компонент | Файл | Описание |
|-----------|------|----------|
| **Program.cs** | Program.cs | Точка входа, настройка DI, логирования, Kestrel |
| **CriticalitySyncService** | Services/CriticalitySyncService.cs | Основная логика синхронизации |
| **CriticalitySyncBackgroundService** | Services/CriticalitySyncBackgroundService.cs | Фоновая служба автоматического запуска |
| **HeatApiService** | Services/HeatApiService.cs | HTTP-клиент для HEAT API |
| **CriticalitySyncController** | Controllers/CriticalitySyncController.cs | REST API контроллер |
| **BatchStateManager** | Services/BatchStateManager.cs | Управление состоянием пакетной обработки |
| **HeatApiSettings** | Configuration/HeatApiSettings.cs | Конфигурация подключения к HEAT |
| **CriticalitySyncSettings** | Configuration/CriticalitySyncSettings.cs | Параметры синхронизации |

### 3.3 Модель данных

#### CI (Configuration Item)
```csharp
public class CI
{
    public string RecId { get; set; }           // Уникальный ID
    public string CIType { get; set; }          // Тип CI (Service, IS, etc.)
    public string? Name { get; set; }           // Наименование
    public string? TRN_KritichnostKE_Valid { get; set; }  // Критичность
    public string? XER_CSI_Valid { get; set; }  // CSI
    public string? TargetAvailability { get; set; }      // Доступность
    public DateTime? LastChangeDateTime { get; set; }    // Время изменения
}
```

#### CIRelation
```csharp
public class CIRelation
{
    public string RecId { get; set; }      // ID связи
    public string SourceID { get; set; }   // Источник
    public string TargetID { get; set; }   // Назначение
}
```

#### BatchState
```csharp
public class BatchState
{
    public string LastProcessedRecId { get; set; }  // Последний обработанный CI
    public bool IsCompleted { get; set; }           // Завершена ли обработка
    public DateTime LastRunTime { get; set; }       // Время последнего запуска
}
```

### 3.4 Диаграмма последовательности синхронизации

```mermaid
sequenceDiagram
    participant BS as Background Service
    participant CS as CriticalitySyncService
    participant BS2 as BatchStateManager
    participant HAS as HeatApiService
    participant HEAT as HEAT API
    
    Note over BS,HEAT: Запуск синхронизации (каждые 5 мин)
    
    BS->>CS: RunSyncAsync()
    CS->>BS2: LoadStateAsync()
    BS2-->>CS: BatchState
    
    alt IsCompleted = true
        CS-->>BS: "Batch already completed"
    else IsCompleted = false
        CS->>HAS: BuildUniqueCiRecIdsAsync()
        HAS->>HEAT: GET odata/cinamedrellinks
        HEAT-->>HAS: Relations Page
        HAS-->>CS: HashSet&lt;RecId&gt;
        
        CS->>HAS: BuildParentsGraphAsync()
        HAS->>HEAT: GET odata/cinamedrellinks
        HEAT-->>HAS: Relations Page
        HAS-->>CS: Dictionary&lt;Target, Sources&gt;
        
        loop Для каждого CI (BatchSize=200)
            CS->>HAS: GetCIAsync(recId)
            HAS->>HEAT: GET odata/cis('{recId}')
            HEAT-->>HAS: CI Data
            HAS-->>CS: CI Object
            
            CS->>CS: FindBestParentCriticality()
            CS->>HAS: GetCriticalitySortOrder()
            HAS->>HEAT: GET odata/trn_kritichnostkes
            HEAT-->>HAS: SortOrder
            HAS-->>CS: SortOrder value
            
            CS->>HAS: UpdateCIAsync(recId, updates)
            HAS->>HEAT: PATCH odata/cis('{recId}')
            HEAT-->>HAS: 200 OK
            HAS-->>CS: true
            
            CS->>BS2: SaveStateAsync()
        end
        
        CS->>BS2: SaveState(IsCompleted=true)
        CS-->>BS: SyncResult
    end
```

### 3.5 Блок-схема процесса обработки CI

```mermaid
flowchart TD
    Start(["Начало"]) --> LoadState[Загрузить BatchState]
    LoadState --> CheckComplete{Обработка<br/>завершена?}
    
    CheckComplete -->|Да| ReturnResult[Вернуть результат]
    CheckComplete -->|Нет| BuildRelations[Построить граф связей]
    
    BuildRelations --> GetUniqueIds[Получить уникальные RecId]
    GetUniqueIds --> BuildParents[Построить граф родителей]
    
    BuildParents --> FilterIds[Отфильтровать по LastProcessedRecId]
    FilterIds --> TakeBatch[Взять BatchSize=200]
    
    TakeBatch --> LoopCI{Есть CI<br/>в пакете?}
    LoopCI -->|Нет| CheckBatchSize{Меньше<br/>BatchSize?}
    LoopCI -->|Да| GetCI[Получить CI из HEAT]
    
    GetCI --> CheckCI{CI найден?}
    CheckCI -->|Нет| SkipCI[Пропустить CI]
    CheckCI -->|Да| CheckType{Тип в<br/>allowedTypes?}
    
    CheckType -->|Нет| SkipCI
    CheckType -->|Да| FindParent[Найти лучшую критичность<br/>родителя]
    
    FindParent --> CompareCrit{Критичность<br/>отличается?}
    CompareCrit -->|Да| UpdateCI[Обновить CI в HEAT]
    CompareCrit -->|Нет| SkipUpdate
    
    UpdateCI --> SkipUpdate[Сохранить LastProcessedRecId]
    SkipCI --> SkipUpdate
    SkipUpdate --> LoopCI
    
    CheckBatchSize -->|Да| SetComplete[Установить IsCompleted=true]
    CheckBatchSize -->|Нет| ContinueNext[Продолжить следующий пакет]
    
    SetComplete --> SaveState[Сохранить BatchState]
    ContinueNext --> SaveState
    SaveState --> ReturnResult
    
    ReturnResult --> End(["Конец"])
```

### 3.6 Диаграмма классов

```mermaid
classDiagram
    class CriticalitySyncService {
        -IHeatApiService _heatApiService
        -IBatchStateManager _batchStateManager
        -ILogger _logger
        -CriticalitySyncSettings _syncSettings
        +RunSyncAsync() SyncResult
        +GetStatusAsync() BatchState
        +ResetAsync() Task
        -BuildUniqueCiRecIdsAsync() HashSet~string~
        -BuildParentsGraphAsync() Dictionary~string,List~string~~
        -ProcessSingleCI() Task
        -FindBestParentCriticality() Tuple
    }
    
    class CriticalitySyncBackgroundService {
        -IServiceScopeFactory _scopeFactory
        -ILogger _logger
        -CriticalitySyncSettings _settings
        +ExecuteAsync() Task
        -ResetIfNewDay() Task
    }
    
    class HeatApiService {
        -HttpClient _httpClient
        -ILogger _logger
        -string _apiKey
        +GetCIAsync() CI
        +GetRelationsPageAsync() RelationsPage
        +GetCriticalitySortOrderAsync() int?
        +UpdateCIAsync() bool
        +HealthCheckAsync() bool
    }
    
    class BatchStateManager {
        -string _stateFilePath
        +LoadStateAsync() BatchState
        +SaveStateAsync() Task
        +ResetState() void
    }
    
    class CI {
        +string RecId
        +string CIType
        +string Name
        +string TRN_KritichnostKE_Valid
        +string XER_CSI_Valid
        +string TargetAvailability
        +DateTime LastChangeDateTime
    }
    
    class BatchState {
        +string LastProcessedRecId
        +bool IsCompleted
        +DateTime LastRunTime
    }
    
    class CriticalitySyncSettings {
        +List~string~ InheritanceTypes
        +int BackgroundSyncIntervalMinutes
        +int BatchSize
        +int RelationsPageSize
        +int MaxParentDepth
    }
    
    CriticalitySyncService --> IHeatApiService
    CriticalitySyncService --> IBatchStateManager
    CriticalitySyncService --> CriticalitySyncSettings
    CriticalitySyncBackgroundService --> CriticalitySyncService
    HeatApiService --> CI
    BatchStateManager --> BatchState
    CriticalitySyncService --> CI
```

---

## 4. Расположение на сервере

### 4.1 Структура каталогов

```
C:\ClonerSuite\Criticality\
├── publish\                          # Опубликованные файлы сервиса
│   ├── Criticality.exe               # Исполняемый файл
│   ├── Criticality.dll               # Основной assembly
│   ├── appsettings.json              # Конфигурация
│   ├── appsettings.Production.json   # Продакшен конфигурация
│   ├── web.config                    # IIS конфигурация
│   ├── logs\                         # Директория логов
│   │   └── app-ГГГГММДД.log          # Логи по датам
│   └── wwwroot\                      # Статические файлы (если есть)
├── Configuration\
│   ├── HeatApiSettings.cs            # Настройки HEAT API
│   └── CriticalitySyncSettings.cs    # Настройки синхронизации
├── Controllers\
│   └── CriticalitySyncController.cs  # API контроллер
├── Services\
│   ├── CriticalitySyncService.cs     # Сервис синхронизации
│   ├── CriticalitySyncBackgroundService.cs  # Фоновая служба
│   ├── HeatApiService.cs             # HTTP клиент HEAT
│   ├── BatchStateManager.cs          # Менеджер состояния
│   └── EncryptionService.cs          # Шифрование API ключа
├── Models\
│   ├── CI.cs                         # Модель CI
│   ├── CIRelation.cs                 # Модель связи
│   ├── Criticality.cs                # Модель критичности
│   └── BatchState.cs                 # Состояние пакета
├── Middleware\
│   ├── RequestLoggingMiddleware.cs   # Логирование запросов
│   └── LocalhostOnlyMiddleware.cs    # Ограничение localhost
├── Criticality.csproj                # Проект .NET
├── publish.ps1                       # Скрипт публикации
├── run-server.ps1                    # Скрипт запуска
└── encrypt-apikey.ps1                # Шифрование API ключа
```

### 4.2 URLHEAT API

Базовый URL Ivanti HEAT API:
```
https://svoivantiprod1.svo.air.loc/HEAT/api
```

#### Используемые конечные точки OData

| Метод | URL | Описание |
|-------|-----|----------|
| GET | `odata/businessobject/cis` | Получение списка CI |
| GET | `odata/businessobject/cis('{RecId}')` | Получение конкретного CI |
| PATCH | `odata/businessobject/cis('{RecId}')` | Обновление CI |
| GET | `odata/businessobject/cinamedrellinks` | Получение связей между CI |
| GET | `odata/businessobject/trn_kritichnostkes('{RecId}')` | Получение критичности |

---

## 5. Процедура развертывания на сервере IIS

### 5.1 Предварительные требования

#### 5.1.1 Системные требования

| Компонент | Требование |
|-----------|------------|
| **ОС** | Windows Server 2016 / Windows 10 или новее |
| **.NET** | .NET 8 Runtime (если не self-contained) |
| **RAM** | 512 MB минимум |
| **CPU** | 1 ядро |
| **Диск** | 500 MB свободного места |

#### 5.1.2 Модули IIS

Установите следующие модули IIS (через Server Manager или PowerShell):

```powershell
# Установить необходимые компоненты IIS
Install-WindowsFeature Web-Server, Web-WebServer, Web-Common-Http, Web-Static-Content, 
    Web-Default-Doc, Web-Dir-Browsing, Web-Http-Errors, Web-Http-Logging, 
    Web-Request-Monitor, Web-Filtering, Web-Stat-Compression, 
    Web-Stat-Compression, Web-Net-Ext45, Web-Asp-Net45, Web-ISAPI-Ext, 
    Web-ISAPI-Filter, Web-Mgmt-Console

# URL Rewrite Module 2 (скачать отдельно)
# https://www.iis.net/downloads/microsoft/url-rewrite

# Application Request Routing (ARR) 3 (скачать отдельно)
# https://www.iis.net/downloads/microsoft/application-request-routing
```

#### 5.1.3 SSL-сертификат

Получите и установите SSL-сертификат:

```powershell
# Просмотреть доступные сертификаты
Get-ChildItem Cert:\LocalMachine\My | Select-Object Thumbprint, Subject, NotAfter

# Создать самоподписанный сертификат (для тестирования)
New-SelfSignedCertificate -DnsName "svoivantiprod1.svo.air.loc","localhost" `
    -CertStoreLocation Cert:\LocalMachine\My `
    -NotAfter (Get-Date).AddYears(10)
```

### 5.2 Публикация сервиса

#### 5.2.1 Публикация self-contained версии

```powershell
# На машине разработчика
cd C:\Projects\Criticality

# Опубликовать для Windows x64
.\publish.ps1 -Runtime win-x64 -OutputDir .\publish

# Проверить результат
ls .\publish\
```

#### 5.2.2 Копирование на сервер

```powershell
# Скопировать на целевой сервер
robocopy C:\Projects\Criticality\publish \\svoivantiprod1.svo.air.loc\C$\ClonerSuite\Criticality /E /Z /R:3
```

### 5.3 Настройка конфигурации

#### 5.3.1 Редактирование appsettings.Production.json

Откройте файл `C:\ClonerSuite\Criticality\publish\appsettings.Production.json`:

```json
{
  "Logging": {
    "LogLevel": {
      "Default": "Information",
      "Microsoft.AspNetCore": "Warning"
    }
  },
  "Server": {
    "Port": 7102,
    "UseHttps": true,
    "HttpsPort": 7103,
    "CertificatePath": "",
    "CertificatePassword": ""
  },
  "HeatApi": {
    "BaseUrl": "https://svoivantiprod1.svo.air.loc/HEAT/api",
    "ApiKey": "",
    "EncryptedApiKey": "<ЗАШИФРОВАННЫЙ_КЛЮЧ>",
    "EncryptionKey": "<ПАРОЛЬ_ШИФРОВАНИЯ>",
    "RequireWebServer": true,
    "SkipCertificateValidation": false
  },
  "CriticalitySync": {
    "InheritanceTypes": [
      "XER_Criticality",
      "XER_Kritichnost"
    ],
    "BackgroundSyncIntervalMinutes": 5,
    "BatchSize": 200,
    "CiPageSize": 100,
    "RelationsChunkSize": 20,
    "MaxParentDepth": 50,
    "RelationsPageSize": 100
  }
}
```

#### 5.3.2 Шифрование API-ключа

```powershell
# Перейти к утилите шифрования
cd C:\ClonerSuite\tools\ApiKeyEncryptor\publish

# Зашифровать API-ключ
.\ApiKeyEncryptor.exe "<ВАШ_API_КЛЮЧ_HEAT>" "<ПАРОЛЬ_ДЛЯ_ШИФРОВАНИЯ>"

# Пример:
.\ApiKeyEncryptor.exe "1404A984C43F48C88749CF8C1C14B40A" "MySecretKey2026!"
```

Скопируйте зашифрованный ключ в `appsettings.Production.json`.

### 5.4 Развертывание в IIS

#### 5.4.1 Создание пула приложений

```powershell
Import-Module WebAdministration

# Создать пул приложений
New-WebAppPool -Name "CriticalityAppPool"
Set-ItemProperty "IIS:\AppPools\CriticalityAppPool" managedRuntimeVersion ""
Set-ItemProperty "IIS:\AppPools\CriticalityAppPool" startMode "AlwaysRunning"
Set-ItemProperty "IIS:\AppPools\CriticalityAppPool" idleTimeout "00:00:00"

# Настроить параметры пула
Set-ItemProperty "IIS:\AppPools\CriticalityAppPool" enable32BitAppOnWin64 "false"
Set-ItemProperty "IIS:\AppPools\CriticalityAppPool" recycling.period "1740"
```

#### 5.4.2 Создание веб-приложения

```powershell
# Создать приложение в IIS
New-WebApplication -Name "Criticality" -Site "Default Web Site" `
    -PhysicalPath "C:\ClonerSuite\Criticality\publish" `
    -ApplicationPool "CriticalityAppPool"
```

#### 5.4.3 Настройка привязки HTTPS

```powershell
# Получить отпечаток сертификата
$thumbprint = "D772E9F0E8628B3702B5C5D1C30227FE438521EB"

# Добавить HTTPS привязку
New-WebBinding -Name "Default Web Site" -Protocol "https" -Port 443 `
    -IPAddress "*" -CertificateThumbPrint $thumbprint `
    -CertStoreLocation "Cert:\LocalMachine\My" -Force
```

#### 5.4.4 Настройка URL Rewrite

Создайте файл `C:\ClonerSuite\Criticality\publish\web.config`:

```xml
<?xml version="1.0" encoding="UTF-8"?>
<configuration>
    <system.webServer>
        <rewrite>
            <rules>
                <rule name="Criticality API" stopProcessing="true">
                    <match url="^Criticality/(.*)" />
                    <action type="Rewrite" url="http://localhost:7102/api/{R:1}" />
                </rule>
            </rules>
        </rewrite>
        <security>
            <requestFiltering>
                <hiddenSegments>
                    <add segment="appsettings.json" />
                    <add segment="logs" />
                </hiddenSegments>
            </requestFiltering>
        </security>
    </system.webServer>
</configuration>
```

#### 5.4.5 Включение ARR Proxy

```powershell
# Включить проксирование в ARR
Set-WebConfigurationProperty -Filter "system.webServer/proxy" `
    -Name "enabled" -Value "true" -PSPath "IIS:\"

# Перезапустить IIS
iisreset
```

### 5.5 Запуск и проверка

#### 5.5.1 Запуск пула приложений

```powershell
# Запустить пул приложений
Start-WebAppPool -Name "CriticalityAppPool"

# Проверить статус
Get-WebAppPoolState -Name "CriticalityAppPool"
```

#### 5.5.2 Проверка работы

```powershell
# Включить TLS 1.2
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

# Игнорировать ошибки сертификатов (для тестирования)
[System.Net.ServicePointManager]::ServerCertificateValidationCallback = { $true }

# Проверить статус сервиса
Invoke-RestMethod -Uri "https://svoivantiprod1.svo.air.loc/Criticality/api/CriticalitySync/status"

# Ожидаемый ответ:
# {"lastProcessedRecId":"","isCompleted":false,"lastRunTime":"0001-01-01T00:00:00"}
```

---

## 6. Листинг исходного кода

### 6.1 Program.cs

```csharp
using Serilog;
using Serilog.Events;
using Criticality.Configuration;
using Criticality.Middleware;
using Criticality.Services;
using System.Diagnostics;
using System.Net;
using System.Security.Cryptography.X509Certificates;

var builder = WebApplication.CreateBuilder(args);

var configuration = builder.Configuration;
var environment = builder.Environment.EnvironmentName;
var port = configuration.GetValue<int>("Server:Port", 7102);
var useHttps = configuration.GetValue<bool>("Server:UseHttps", false);
var certPath = configuration["Server:CertificatePath"];
var certPassword = configuration["Server:CertificatePassword"];

builder.Host.UseSerilog((context, services, loggerConfig) =>
{
    var logPath = Path.Combine(AppContext.BaseDirectory, "logs", "app-.log");
    var fileSizeLimitBytes = 50L * 1024 * 1024; // 50 MB
    var retainedFileCount = 10;

    loggerConfig
        .MinimumLevel.Information()
        .MinimumLevel.Override("Microsoft.AspNetCore", LogEventLevel.Warning)
        .MinimumLevel.Override("Criticality.Services.HeatApiService", LogEventLevel.Debug)
        .Enrich.FromLogContext()
        .Enrich.WithMachineName()
        .Enrich.WithThreadId()
        .WriteTo.Console(outputTemplate: "[{Timestamp:yyyy-MM-dd HH:mm:ss} {Level:u3}] {Message:lj}{NewLine}{Exception}")
        .WriteTo.File(
            path: logPath,
            rollingInterval: RollingInterval.Day,
            fileSizeLimitBytes: fileSizeLimitBytes,
            rollOnFileSizeLimit: true,
            retainedFileCountLimit: retainedFileCount,
            outputTemplate: "{Timestamp:yyyy-MM-dd HH:mm:ss.fff zzz} [{Level:u3}] [{SourceContext}] {Message:lj}{NewLine}{Exception}",
            shared: true);

    if (context.HostingEnvironment.IsDevelopment())
    {
        loggerConfig.MinimumLevel.Debug();
    }
});

var heatApiSettings = configuration.GetSection(HeatApiSettings.SectionName).Get<HeatApiSettings>();
if (heatApiSettings == null)
    throw new InvalidOperationException("HeatApi section is missing in configuration");

if (heatApiSettings.RequireWebServer && !environment.Equals("Production", StringComparison.OrdinalIgnoreCase))
{
    Log.Warning("RequireWebServer is enabled but current environment is '{Env}', not 'Production'. ApiKey will not be used.", environment);
}

builder.WebHost.ConfigureKestrel(options =>
{
    options.Listen(IPAddress.Any, port);

    if (useHttps)
    {
        var httpsPort = configuration.GetValue<int>("Server:HttpsPort", 7103);
        var certThumbprint = configuration["Server:CertificateThumbprint"];

        options.Listen(IPAddress.Any, httpsPort, listenOptions =>
        {
            X509Certificate2? cert = null;

            // 1. Попробовать загрузить из файла
            if (!string.IsNullOrEmpty(certPath) && File.Exists(certPath))
            {
                try
                {
                    cert = new X509Certificate2(certPath, certPassword);
                    Log.Information("HTTPS enabled via file: {CertPath}", certPath);
                }
                catch (Exception ex)
                {
                    Log.Error(ex, "Failed to load certificate from file {CertPath}", certPath);
                }
            }

            // 2. Если файл не указан/ошибка, попробовать загрузить по Thumbprint из хранилища
            if (cert == null && !string.IsNullOrEmpty(certThumbprint))
            {
                try
                {
                    using var store = new X509Store(StoreName.My, StoreLocation.LocalMachine);
                    store.Open(OpenFlags.ReadOnly);
                    var certs = store.Certificates.Find(X509FindType.FindByThumbprint, certThumbprint, validOnly: false);

                    if (certs.Count > 0)
                    {
                        cert = certs[0];
                        Log.Information("HTTPS enabled via Thumbprint: {Thumbprint}", certThumbprint);
                    }
                    else
                    {
                        Log.Warning("Certificate with Thumbprint {Thumbprint} not found in store.", certThumbprint);
                    }
                }
                catch (Exception ex)
                {
                    Log.Error(ex, "Failed to load certificate by Thumbprint {Thumbprint}", certThumbprint);
                }
            }

            // 3. Применить сертификат или fallback на dev
            if (cert != null)
            {
                listenOptions.UseHttps(cert);
            }
            else
            {
                Log.Warning("No valid certificate configured. Using development certificate.");
                listenOptions.UseHttps();
            }
        });
    }
});

builder.Services.Configure<HeatApiSettings>(configuration.GetSection(HeatApiSettings.SectionName));
builder.Services.Configure<CriticalitySyncSettings>(
    builder.Configuration.GetSection(CriticalitySyncSettings.SectionName));

builder.Services.AddControllers();

builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowLocal", policy =>
    {
        policy.AllowAnyOrigin()
              .AllowAnyMethod()
              .AllowAnyHeader();
    });
});

builder.Services.AddHttpClient();
builder.Services.AddHttpClient("diagnostic", (sp, client) =>
{
    var config = sp.GetRequiredService<IConfiguration>();
    var baseUrl = config["HeatApi:BaseUrl"]?.TrimEnd('/') + '/';
    client.BaseAddress = new Uri(baseUrl);
    var apiKey = config["HeatApi:ApiKey"];
    if (!string.IsNullOrEmpty(apiKey))
        client.DefaultRequestHeaders.TryAddWithoutValidation("Authorization", $"rest_api_key={apiKey}");
    client.Timeout = TimeSpan.FromSeconds(config.GetValue<int>("HeatApi:TimeoutSeconds", 60));
}).ConfigurePrimaryHttpMessageHandler(sp =>
{
    var config = sp.GetRequiredService<IConfiguration>();
    var skipCert = config.GetValue<bool>("HeatApi:SkipCertificateValidation");
    return new HttpClientHandler
    {
        AllowAutoRedirect = true,
        ServerCertificateCustomValidationCallback = skipCert
            ? (message, cert, chain, errors) => true
            : null
    };
});

builder.Services.AddSingleton<IEncryptionService, EncryptionService>();
builder.Services.AddSingleton<IBatchStateManager, BatchStateManager>();
builder.Services.AddScoped<IHeatApiService, HeatApiService>();
builder.Services.AddScoped<ICriticalitySyncService, CriticalitySyncService>();
builder.Services.AddHostedService<CriticalitySyncBackgroundService>();

var app = builder.Build();

app.UseCors("AllowLocal");
app.UseMiddleware<RequestLoggingMiddleware>();
app.UseLocalhostOnly();
app.UseAuthorization();
app.MapControllers();

var ipAddress = GetLocalIPAddress();
var apiKeySource = !string.IsNullOrEmpty(heatApiSettings.EncryptedApiKey) ? "encrypted" : "plain";

Log.Information("=========================================");
Log.Information("Criticality Sync Service started!");
Log.Information("Environment: {Environment}", environment);
Log.Information("Port: {Port}", port);
Log.Information("URL: http://{IP}:{Port}", ipAddress, port);
Log.Information("-----------------------------------------");
Log.Information("API Key source: {Source}", apiKeySource);

if (useHttps)
{
    var httpsPort = configuration.GetValue<int>("Server:HttpsPort", 7103);
    Log.Information("HTTPS Port: {Port}", httpsPort);
    Log.Information("HTTPS URL: https://{IP}:{Port}", ipAddress, httpsPort);
}

Log.Information("-----------------------------------------");
Log.Information("[!] Swagger disabled (offline mode)");
Log.Information("-----------------------------------------");
Log.Information("Criticality Sync:");
Log.Information("  http://localhost:{Port}/api/CriticalitySync/start", port);
Log.Information("  http://localhost:{Port}/api/CriticalitySync/status", port);
Log.Information("  http://localhost:{Port}/api/CriticalitySync/reset", port);
Log.Information("=========================================");
Log.Information("For testing:");
Log.Information("  curl http://localhost:{Port}/api/CriticalitySync/status", port);
Log.Information("  or open in browser");
Log.Information("=========================================");
Log.Information("Log files: {LogPath}", Path.Combine(AppContext.BaseDirectory, "logs"));
Log.Information("=========================================");

try
{
    await app.RunAsync();
}
catch (Exception ex)
{
    Log.Fatal(ex, "Application terminated unexpectedly");
}
finally
{
    await Log.CloseAndFlushAsync();
}

static string GetLocalIPAddress()
{
    try
    {
        var host = System.Net.Dns.GetHostEntry(System.Net.Dns.GetHostName());
        foreach (var ip in host.AddressList)
            if (ip.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork)
                return ip.ToString();
    }
    catch (Exception ex)
    {
        Log.Warning(ex, "Failed to resolve local IP address");
    }
    return "192.168.16.244";
}
```

### 6.2 CriticalitySyncService.cs

```csharp
using System.Text.Json;
using Microsoft.Extensions.Options;
using Polly;
using Criticality.Configuration;
using Criticality.Models;

namespace Criticality.Services;

public class CriticalitySyncService : ICriticalitySyncService
{
    private readonly IHeatApiService _heatApiService;
    private readonly IBatchStateManager _batchStateManager;
    private readonly ILogger<CriticalitySyncService> _logger;
    private readonly CriticalitySyncSettings _syncSettings;

    private const string InformationSystemType = "InformationSystem";
    private const string ServiceType = "Service";

    public CriticalitySyncService(
        IHeatApiService heatApiService,
        IBatchStateManager batchStateManager,
        ILogger<CriticalitySyncService> logger,
        IOptions<CriticalitySyncSettings> syncSettings)
    {
        _heatApiService = heatApiService;
        _batchStateManager = batchStateManager;
        _logger = logger;
        _syncSettings = syncSettings.Value;
    }

    private string[] GetAllowedTypes() =>
        new[] { ServiceType }.Concat(_syncSettings.InheritanceTypes).ToArray();

    public async Task<BatchState> GetStatusAsync(CancellationToken cancellationToken = default)
    {
        return await _batchStateManager.LoadStateAsync(cancellationToken);
    }

    public async Task<SyncResult> RunSyncAsync(CancellationToken cancellationToken = default)
    {
        var result = new SyncResult();
        var stopwatch = System.Diagnostics.Stopwatch.StartNew();

        try
        {
            _logger.LogInformation("Starting criticality sync batch...");

            var state = await _batchStateManager.LoadStateAsync(cancellationToken);
            if (state.IsCompleted)
            {
                result.Message = "Batch already completed. Reset to start over.";
                return result;
            }

            var uniqueRecIds = await BuildUniqueCiRecIdsAsync(cancellationToken);
            _logger.LogInformation("Unique CI RecIds from relations: {Count}", uniqueRecIds.Count);

            var parentsGraph = await BuildParentsGraphAsync(cancellationToken);

            var ciCache = new Dictionary<string, CI>();
            var sortOrderCache = new Dictionary<string, int?>();

            var allowedTypes = GetAllowedTypes();
            var idsToProcess = uniqueRecIds
                .Where(id => string.Compare(id, state.LastProcessedRecId) > 0)
                .OrderBy(id => id)
                .Take(_syncSettings.BatchSize)
                .ToList();

            _logger.LogInformation("Processing batch of {Count} CIs", idsToProcess.Count);

            foreach (var recId in idsToProcess)
            {
                cancellationToken.ThrowIfCancellationRequested();
                try
                {
                    if (!ciCache.TryGetValue(recId, out var ci))
                    {
                        ci = await _heatApiService.GetCIAsync(recId, cancellationToken);
                        if (ci != null)
                            ciCache[recId] = ci;
                    }

                    if (ci == null)
                    {
                        _logger.LogWarning("CI {RecId} not found, skipping", recId);
                        state.LastProcessedRecId = recId;
                        await _batchStateManager.SaveStateAsync(state, cancellationToken);
                        continue;
                    }

                    if (!allowedTypes.Contains(ci.CIType))
                    {
                        _logger.LogDebug("CI {RecId} has type {CIType}, not in allowed list, skipping", recId, ci.CIType);
                        state.LastProcessedRecId = recId;
                        await _batchStateManager.SaveStateAsync(state, cancellationToken);
                        continue;
                    }

                    await ProcessSingleCI(ci, parentsGraph, ciCache, sortOrderCache, cancellationToken);
                    result.ProcessedCount++;
                    state.LastProcessedRecId = recId;
                    await _batchStateManager.SaveStateAsync(state, cancellationToken);
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Error processing CI {RecId}. Stopping.", recId);
                    await _batchStateManager.SaveStateAsync(state, cancellationToken);
                    throw;
                }
            }

            if (idsToProcess.Count < _syncSettings.BatchSize)
            {
                state.IsCompleted = true;
                result.IsCompleted = true;
            }

            state.LastRunTime = DateTime.UtcNow;
            await _batchStateManager.SaveStateAsync(state, cancellationToken);

            stopwatch.Stop();
            result.Success = true;
            result.Message = $"Processed {result.ProcessedCount} CIs.";
            result.LastProcessedRecId = state.LastProcessedRecId;
            result.ElapsedTime = stopwatch.Elapsed;

            _logger.LogInformation("Sync batch finished. Processed: {Count}, Completed: {Completed}", result.ProcessedCount, state.IsCompleted);
            return result;
        }
        catch (Exception ex)
        {
            stopwatch.Stop();
            _logger.LogError(ex, "Critical error during sync");
            result.Message = $"Error: {ex.Message}";
            result.ElapsedTime = stopwatch.Elapsed;
            return result;
        }
    }

    public async Task ResetAsync(CancellationToken cancellationToken = default)
    {
        _batchStateManager.ResetState();
        await Task.CompletedTask;
    }

    private async Task<HashSet<string>> BuildUniqueCiRecIdsAsync(CancellationToken cancellationToken)
    {
        var uniqueRecIds = new HashSet<string>();
        var pageState = default(string);

        do
        {
            var page = await _heatApiService.GetRelationsPageAsync(_syncSettings.RelationsPageSize, pageState, cancellationToken);
            
            foreach (var rel in page.Items)
            {
                if (!string.IsNullOrEmpty(rel.SourceID))
                    uniqueRecIds.Add(rel.SourceID);
                if (!string.IsNullOrEmpty(rel.TargetID))
                    uniqueRecIds.Add(rel.TargetID);
            }

            pageState = page.NextState;
            _logger.LogDebug("Loaded relations page. Total unique RecIds so far: {Count}", uniqueRecIds.Count);
        }
        while (pageState != null);

        return uniqueRecIds;
    }

    private async Task<Dictionary<string, List<string>>> BuildParentsGraphAsync(CancellationToken cancellationToken)
    {
        var parentsGraph = new Dictionary<string, List<string>>();
        var pageState = default(string);

        do
        {
            var page = await _heatApiService.GetRelationsPageAsync(_syncSettings.RelationsPageSize, pageState, cancellationToken);
            
            foreach (var rel in page.Items)
            {
                if (!string.IsNullOrEmpty(rel.TargetID) && !string.IsNullOrEmpty(rel.SourceID))
                {
                    if (!parentsGraph.TryGetValue(rel.TargetID, out var sources))
                    {
                        sources = new List<string>();
                        parentsGraph[rel.TargetID] = sources;
                    }
                    sources.Add(rel.SourceID);
                }
            }

            pageState = page.NextState;
        }
        while (pageState != null);

        _logger.LogInformation("Built parents graph with {Count} entries", parentsGraph.Count);
        return parentsGraph;
    }

    private async Task ProcessSingleCI(
        CI ci,
        Dictionary<string, List<string>> parentsGraph,
        Dictionary<string, CI> ciCache,
        Dictionary<string, int?> sortOrderCache,
        CancellationToken cancellationToken)
    {
        string? newCriticality = null;
        string? newCsi = null;
        string? newAvailability = null;

        if (ci.CIType == InformationSystemType)
        {
            // only date update
        }
        else if (ci.CIType == ServiceType)
        {
            var best = await FindBestParentCriticality(ci.RecId, [InformationSystemType], parentsGraph, ciCache, sortOrderCache, cancellationToken);
            newCriticality = best.criticalityRecId;
            newCsi = best.csiId;
            newAvailability = best.targetAvailability;
        }
        else if (_syncSettings.InheritanceTypes.Contains(ci.CIType))
        {
            var best = await FindBestParentCriticality(ci.RecId, [InformationSystemType, ServiceType], parentsGraph, ciCache, sortOrderCache, cancellationToken);
            newCriticality = best.criticalityRecId;
            newCsi = best.csiId;
            newAvailability = best.targetAvailability;
        }

        var updates = new Dictionary<string, object>();
        if (newCriticality != null && newCriticality != ci.TRN_KritichnostKE_Valid)
            updates["TRN_KritichnostKE_Valid"] = newCriticality;
        if (newCsi != null && newCsi != ci.XER_CSI_Valid)
            updates["XER_CSI_Valid"] = newCsi;
        if (newAvailability != null && newAvailability != ci.TargetAvailability)
            updates["TargetAvailability"] = newAvailability;

        updates["LastChangeDateTime"] = DateTime.UtcNow;

        if (updates.Count > 0)
            await _heatApiService.UpdateCIAsync(ci.RecId, updates, cancellationToken);
    }

    private async Task<(string? criticalityRecId, string? csiId, string? targetAvailability)>
        FindBestParentCriticality(
            string startRecId,
            string[] allowedParentTypes,
            Dictionary<string, List<string>> parentsGraph,
            Dictionary<string, CI> ciCache,
            Dictionary<string, int?> sortOrderCache,
            CancellationToken cancellationToken)
    {
        string? bestCrit = null, bestCsi = null, bestAvail = null;
        int bestSort = int.MaxValue;

        var visited = new HashSet<string>();
        var queue = new Queue<(string recId, int depth)>();
        queue.Enqueue((startRecId, 0));

        while (queue.Count > 0)
        {
            var (currentId, depth) = queue.Dequeue();
            if (depth > _syncSettings.MaxParentDepth) continue;
            if (!visited.Add(currentId)) continue;

            if (parentsGraph.TryGetValue(currentId, out var parentIds))
            {
                foreach (var parentId in parentIds)
                {
                    if (!ciCache.TryGetValue(parentId, out var parentCI))
                    {
                        parentCI = await _heatApiService.GetCIAsync(parentId, cancellationToken);
                        if (parentCI != null)
                            ciCache[parentId] = parentCI;
                    }

                    if (parentCI == null) continue;
                    if (!allowedParentTypes.Contains(parentCI.CIType)) continue;

                    var critId = parentCI.TRN_KritichnostKE_Valid;
                    if (!string.IsNullOrEmpty(critId))
                    {
                        if (!sortOrderCache.TryGetValue(critId, out var sortOrder))
                        {
                            sortOrder = await _heatApiService.GetCriticalitySortOrderAsync(critId, cancellationToken);
                            sortOrderCache[critId] = sortOrder;
                        }
                        if (sortOrder.HasValue && sortOrder.Value < bestSort)
                        {
                            bestSort = sortOrder.Value;
                            bestCrit = critId;
                            bestCsi = parentCI.XER_CSI_Valid;
                            bestAvail = parentCI.TargetAvailability;
                        }
                    }
                    queue.Enqueue((parentId, depth + 1));
                }
            }
        }
        return (bestCrit, bestCsi, bestAvail);
    }
}
```

---

## 7. Диагностика неполадок и их устранение

### 7.1 Журналирование

#### 7.1.1 Расположение логов

Логи сервиса записываются в директории:
```
C:\ClonerSuite\Criticality\publish\logs\app-ГГГГММДД.log
```

#### 7.1.2 Формат логов

```
2026-06-09 10:04:04.123 +03:00 [INF] [Criticality.Services.CriticalitySyncService] Starting criticality sync batch...
2026-06-09 10:04:05.456 +03:00 [INF] [Criticality.Services.CriticalitySyncService] Unique CI RecIds from relations: 1500
2026-06-09 10:04:06.789 +03:00 [INF] [Criticality.Services.CriticalitySyncService] Processing batch of 200 CIs
```

#### 7.1.3 Уровни логирования

| Уровень | Описание |
|---------|----------|
| **Debug** | Детальная отладочная информация |
| **Information** | Штатная работа сервиса |
| **Warning** | Предупреждения (некритичные ошибки) |
| **Error** | Критические ошибки |

### 7.2 API Endpoints для диагностики

#### 7.2.1 Проверка статуса

**Запрос:**
```bash
GET http://localhost:7102/api/CriticalitySync/status
```

**Ответ:**
```json
{
  "lastProcessedRecId": "REC12345",
  "isCompleted": false,
  "lastRunTime": "2026-06-09T10:04:04Z"
}
```

**Поля:**
- `lastProcessedRecId` — последний обработанный CI
- `isCompleted` — завершена ли полная синхронизация
- `lastRunTime` — время последнего запуска

#### 7.2.2 Запуск синхронизации

**Запрос:**
```bash
POST http://localhost:7102/api/CriticalitySync/start
```

**Ответ:**
```json
{
  "success": true,
  "message": "Processed 200 CIs.",
  "processedCount": 200,
  "isCompleted": false,
  "lastProcessedRecId": "REC12345",
  "elapsedTime": "00:01:23.4567890"
}
```

#### 7.2.3 Сброс состояния

**Запрос:**
```bash
POST http://localhost:7102/api/CriticalitySync/reset
```

**Ответ:**
```json
{
  "message": "Batch state reset."
}
```

### 7.3 Типовые проблемы и решения

#### 7.3.1 AppPool остановлен

**Симптомы:**
- IIS возвращает 503 Service Unavailable
- Пул приложений в состоянии Stopped

**Диагностика:**
```powershell
Get-WebAppPoolState -Name "CriticalityAppPool"
Get-WinEvent -LogName "Application" -ProviderName "IIS-Aspnetcore" | 
    Where-Object Id -eq 1033 | Select-Object -First 5
```

**Причины:**
1. **Idle Timeout** — пул остановлен из-за простоя
2. **Crash** — аварийное завершение процесса
3. **Recycling** — плановая перезагрузка

**Решение:**

```powershell
# 1. Проверить настройки Idle Timeout
Get-ItemProperty "IIS:\AppPools\CriticalityAppPool" | 
    Select-Object idleTimeout, startMode

# 2. Установить idleTimeout=0 (отключить)
Set-ItemProperty "IIS:\AppPools\CriticalityAppPool" idleTimeout "00:00:00"
Set-ItemProperty "IIS:\AppPools\CriticalityAppPool" startMode "AlwaysRunning"

# 3. Запустить пул
Start-WebAppPool -Name "CriticalityAppPool"
```

#### 7.3.1.1 Диаграмма состояний AppPool

```mermaid
stateDiagram-v2
    [*] --> Started : Start
    Started --> Stopped : Idle Timeout
    Started --> Stopped : Crash
    Started --> Recycling : Recycling
    
    Stopped --> Started : Start-WebAppPool
    Stopped --> [*] : Delete
    
    Recycling --> Started : Complete
    Recycling --> Stopped : Failed
    
    note right of Started
        Normal Operation
        - API available
        - Sync running
        - Logs writing
    end note
    
    note right of Stopped
        Requires Intervention
        - API unavailable (503)
        - Scheduled Task monitor
        - Auto-restart needed
    end note
    
    note right of Recycling
        Temporary Unavailable
        - 10-30 seconds
        - API returns 503
        - Auto-recovers
    end note
```

#### 7.3.2 Ошибка подключения к HEAT API

**Симптомы:**
- В логах: `Unauthorized (ISM_4001)`
- В логах: `401 Unauthorized`
- Синхронизация не запускается

**Диагностика:**
```powershell
# Проверить конфигурацию
Get-Content C:\ClonerSuite\Criticality\publish\appsettings.Production.json | 
    ConvertFrom-Json | Select-Object -ExpandProperty HeatApi

# Проверить доступность HEAT API
Invoke-RestMethod -Uri "https://svoivantiprod1.svo.air.loc/HEAT/api/odata/businessobject/cis?`$top=1" `
    -Headers @{"Authorization"="rest_api_key=ВАШ_КЛЮЧ"}
```

**Причины:**
1. **Неверный API-ключ** — ключ не расшифровывается
2. **Истек срок действия ключа** — ключ недействителен
3. **Проблемы SSL** — неверифицируемый сертификат

**Решение:**

```powershell
# 1. Перешифровать API-ключ
cd C:\ClonerSuite\tools\ApiKeyEncryptor\publish
.\ApiKeyEncryptor.exe "<НОВЫЙ_КЛЮЧ>" "<ПАРОЛЬ>"

# 2. Обновить appsettings.Production.json
# 3. Перезапустить пул приложений
iisreset /restart
```

#### 7.3.3 Синхронизация зависла

**Симптомы:**
- `isCompleted: false` длительное время
- `lastProcessedRecId` не меняется
- В логах нет обновлений

**Диагностика:**
```powershell
# Проверить статус
Invoke-RestMethod -Uri "http://localhost:7102/api/CriticalitySync/status"

# Проверить логи
Get-Content C:\ClonerSuite\Criticality\publish\logs\app-*.log -Tail 100
```

**Причины:**
1. **Блокировка на HTTP-запросе** — таймаут HEAT API
2. **Исключение в обработчике** — ошибка обработки CI
3. **Deadlock** — блокировка потоков

**Решение:**

```powershell
# 1. Сбросить состояние
Invoke-RestMethod -Uri "http://localhost:7102/api/CriticalitySync/reset" -Method Post

# 2. Перезапустить пул
Restart-WebAppPool -Name "CriticalityAppPool"

# 3. Проверить логи на наличие ошибок
Select-String -Path "C:\ClonerSuite\Criticality\publish\logs\*.log" -Pattern "ERROR" | 
    Select-Object -First 20
```

#### 7.3.4 Ошибка SSL-сертификата

**Симптомы:**
- В логах: `The remote certificate is invalid according to the validation procedure`
- HTTPS запросы не проходят

**Диагностика:**
```powershell
# Проверить сертификат
Test-NetConnection -ComputerName svoivantiprod1.svo.air.loc -Port 443

# Проверить цепочку сертификатов
$cert = Get-ChildItem Cert:\LocalMachine\My | 
    Where-Object {$_.Subject -like "*svoivantiprod1*"}
$cert | Format-List Subject, Thumbprint, NotAfter, Issuer
```

**Причины:**
1. **Сертификат истек** — срок действия закончился
2. **Недоверенный CA** — корневой сертификат не в доверенных
3. **Неверное имя** — CN не совпадает с hostname

**Решение:**

```powershell
# 1. Продлить сертификат
New-SelfSignedCertificate -DnsName "svoivantiprod1.svo.air.loc","localhost" `
    -CertStoreLocation Cert:\LocalMachine\My `
    -NotAfter (Get-Date).AddYears(10)

# 2. Импортировать корневой сертификат в доверенные
Import-Certificate -FilePath "C:\certs\HEAT-RootCA.cer" `
    -CertStoreLocation Cert:\LocalMachine\Root

# 3. Временно отключить проверку (только для тестирования!)
# В appsettings.Production.json:
# "SkipCertificateValidation": true
```

#### 7.3.5 Превышен лимит записей HEAT

**Симптомы:**
- В логах: `You cannot query more than 100 records`
- Синхронизация останавливается

**Диагностика:**
```powershell
# Проверить настройки
Get-Content C:\ClonerSuite\Criticality\publish\appsettings.Production.json | 
    ConvertFrom-Json | 
    Select-Object -ExpandProperty CriticalitySync | 
    Select-Object RelationsPageSize, CiPageSize
```

**Причины:**
1. **RelationsPageSize > 100** — превышает лимит HEAT API

**Решение:**

```json
// В appsettings.Production.json установить:
"CriticalitySync": {
  "RelationsPageSize": 100,
  "CiPageSize": 100
}
```

### 7.4 Скрипты диагностики

#### 7.4.1 Проверка здоровья сервиса

```powershell
# Health-Check.ps1
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
[System.Net.ServicePointManager]::ServerCertificateValidationCallback = { $true }

Write-Host "=== Criticality Service Health Check ===" -ForegroundColor Cyan

# 1. Проверка пула приложений
$poolState = Get-WebAppPoolState -Name "CriticalityAppPool"
Write-Host "AppPool State: $($poolState.Value)" -ForegroundColor $(
    if ($poolState.Value -eq "Started") {"Green"} else {"Red"}
)

# 2. Проверка API
try {
    $status = Invoke-RestMethod -Uri "http://localhost:7102/api/CriticalitySync/status" -ErrorAction Stop
    Write-Host "API Status: OK" -ForegroundColor Green
    Write-Host "  LastProcessedRecId: $($status.lastProcessedRecId)"
    Write-Host "  IsCompleted: $($status.isCompleted)"
    Write-Host "  LastRunTime: $($status.lastRunTime)"
} catch {
    Write-Host "API Status: FAILED" -ForegroundColor Red
    Write-Host "  Error: $($_.Exception.Message)"
}

# 3. Проверка логов
$latestLog = Get-ChildItem "C:\ClonerSuite\Criticality\publish\logs\app-*.log" | 
    Sort-Object LastWriteTime -Descending | Select-Object -First 1
if ($latestLog) {
    $errors = Select-String -Path $latestLog.FullName -Pattern "ERROR" | 
        Measure-Object | Select-Object -ExpandProperty Count
    Write-Host "Errors in latest log: $errors" -ForegroundColor $(
        if ($errors -eq 0) {"Green"} elseif ($errors -lt 10) {"Yellow"} else {"Red"}
    )
}
```

#### 7.4.2 Автоматический перезапуск при сбое

```powershell
# Restart-Criticality.ps1
$ErrorActionPreference = "Continue"

Write-Host "=== Criticality Service Auto-Restart ===" -ForegroundColor Cyan

# 1. Проверить пул
$poolState = Get-WebAppPoolState -Name "CriticalityAppPool"

if ($poolState.Value -ne "Started") {
    Write-Host "AppPool is $($poolState.Value). Starting..." -ForegroundColor Yellow
    Start-WebAppPool -Name "CriticalityAppPool"
    Start-Sleep -Seconds 5
    
    $poolState = Get-WebAppPoolState -Name "CriticalityAppPool"
    if ($poolState.Value -eq "Started") {
        Write-Host "AppPool started successfully" -ForegroundColor Green
    } else {
        Write-Host "Failed to start AppPool" -ForegroundColor Red
        exit 1
    }
}

# 2. Проверить API
try {
    $status = Invoke-RestMethod -Uri "http://localhost:7102/api/CriticalitySync/status" -ErrorAction Stop
    Write-Host "API is responsive" -ForegroundColor Green
} catch {
    Write-Host "API not responsive. Restarting AppPool..." -ForegroundColor Yellow
    Restart-WebAppPool -Name "CriticalityAppPool"
    Start-Sleep -Seconds 10
    
    try {
        $status = Invoke-RestMethod -Uri "http://localhost:7102/api/CriticalitySync/status" -ErrorAction Stop
        Write-Host "AppPool restarted successfully" -ForegroundColor Green
    } catch {
        Write-Host "Failed to restart AppPool" -ForegroundColor Red
        exit 1
    }
}

Write-Host "Health check complete" -ForegroundColor Green
```

---

## 8. Мониторинг и обслуживание

### 8.1 Плановое обслуживание

#### 8.1.1 Ежедневная проверка

```powershell
# 1. Проверить статус сервиса
Invoke-RestMethod -Uri "http://localhost:7102/api/CriticalitySync/status"

# 2. Проверить логи за сегодня
Get-Content C:\ClonerSuite\Criticality\publish\logs\app-$(Get-Date -Format 'yyyyMMdd').log | 
    Select-String "ERROR" | Measure-Object

# 3. Проверить место на диске
Get-PSDrive C | Select-Object Used, Free
```

#### 8.1.2 Еженедельная проверка

```powershell
# 1. Проверить размер логов
Get-ChildItem C:\ClonerSuite\Criticality\publish\logs\*.log | 
    Measure-Object -Property Length -Sum | 
    Select-Object @{N="SizeMB";E={[math]::Round($_.Sum/1MB,2)}}

# 2. Очистить старые логи (>30 дней)
Get-ChildItem C:\ClonerSuite\Criticality\publish\logs\*.log | 
    Where-Object LastWriteTime -lt (Get-Date).AddDays(-30) | 
    Remove-Item -Force

# 3. Проверить сертификат
Get-ChildItem Cert:\LocalMachine\My | 
    Where-Object {$_.Subject -like "*svoivantiprod1*"} | 
    Select-Object Subject, NotAfter
```

### 8.2 Резервное копирование

#### 8.2.1 Конфигурация

```powershell
# Backup-Config.ps1
$backupDir = "C:\Backups\Criticality\$(Get-Date -Format 'yyyyMMdd_HHmmss')"
New-Item -ItemType Directory -Path $backupDir -Force

Copy-Item "C:\ClonerSuite\Criticality\publish\appsettings*.json" $backupDir
Copy-Item "C:\ClonerSuite\Criticality\publish\web.config" $backupDir

Write-Host "Configuration backed up to $backupDir" -ForegroundColor Green
```

---

## 9. Контрольный список развертывания

### 9.1 Предварительная подготовка

- [ ] .NET 8 Runtime установлен (если не self-contained)
- [ ] IIS установлен и настроен
- [ ] URL Rewrite Module установлен
- [ ] ARR 3 установлен
- [ ] SSL-сертификат получен и установлен

### 9.2 Развертывание сервиса

- [ ] Файлы сервиса скопированы на сервер
- [ ] `appsettings.Production.json` настроен
- [ ] API-ключ зашифрован и добавлен в конфиг
- [ ] Пул приложений создан
- [ ] Приложение в IIS создано
- [ ] HTTPS привязка настроена
- [ ] URL Rewrite правила настроены

### 9.3 Проверка работы

- [ ] Пул приложений запущен
- [ ] API endpoint отвечает (`/api/CriticalitySync/status`)
- [ ] Логи записываются
- [ ] Синхронизация запускается вручную
- [ ] Фоновая служба работает

---

**Версия документа**: 1.0  
**Дата**: 2026-06-09  
**Статус**: Утверждена
